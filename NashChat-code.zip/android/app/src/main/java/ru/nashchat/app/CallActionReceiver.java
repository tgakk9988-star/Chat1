package ru.nashchat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Кнопка «Отклонить» в уведомлении о входящем звонке. */
public class CallActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final String id = intent.getStringExtra("call_id");
        ChatService.cancelCall(context);
        if (id == null || id.isEmpty()) return;
        ChatService.ringShown = id;
        final PendingResult pr = goAsync();
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                ChatService.declineRing(app, id);
            } finally {
                pr.finish();
            }
        }, "call-decline").start();
    }
}
