package ru.nashchat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Запускает фоновую службу после перезагрузки телефона и после обновления приложения. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            ChatService.start(context);
        }
    }
}
