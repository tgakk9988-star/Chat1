package ru.nashchat.app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Size;
import android.webkit.WebResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Галерея телефона внутри приложения: список последних фото и видео,
 * миниатюры и сами файлы отдаются странице по адресам /gallery/thumb/… и /gallery/file/…
 * Ничего не уходит в интернет — только в само приложение, когда пользователь выбрал фото.
 */
class Gallery {

    static String[] permissions() {
        if (Build.VERSION.SDK_INT >= 34) return new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"};
        if (Build.VERSION.SDK_INT >= 33) return new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO};
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    /** full — все фото, partial — только выбранные (Android 14), none — нет доступа */
    static String state(Context c) {
        if (Build.VERSION.SDK_INT >= 33) {
            boolean img = c.checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
            if (img) return "full";
            if (Build.VERSION.SDK_INT >= 34 && c.checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") == PackageManager.PERMISSION_GRANTED) return "partial";
            return "none";
        }
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ? "full" : "none";
    }

    static Uri uriOf(String type, long id) {
        return ContentUris.withAppendedId("v".equals(type) ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
    }

    static String list(Context c, int offset, int limit) {
        JSONArray out = new JSONArray();
        Uri files = MediaStore.Files.getContentUri("external");
        String[] cols = {MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.DATE_ADDED, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE,
                MediaStore.Video.VideoColumns.DURATION, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT};
        String sel = MediaStore.Files.FileColumns.MEDIA_TYPE + " IN (" + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE + "," + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO + ")";
        Cursor cur = null;
        try {
            ContentResolver cr = c.getContentResolver();
            if (Build.VERSION.SDK_INT >= 30) {
                Bundle q = new Bundle();
                q.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel);
                q.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{MediaStore.Files.FileColumns.DATE_ADDED});
                q.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
                q.putInt(ContentResolver.QUERY_ARG_LIMIT, limit);
                q.putInt(ContentResolver.QUERY_ARG_OFFSET, offset);
                cur = cr.query(files, cols, q, null);
            } else {
                cur = cr.query(files, cols, sel, null, MediaStore.Files.FileColumns.DATE_ADDED + " DESC LIMIT " + limit + " OFFSET " + offset);
            }
            if (cur == null) return out.toString();
            while (cur.moveToNext()) {
                JSONObject o = new JSONObject();
                boolean video = cur.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
                o.put("id", cur.getLong(0));
                o.put("t", video ? "v" : "i");
                o.put("mime", cur.getString(2) == null ? (video ? "video/mp4" : "image/jpeg") : cur.getString(2));
                o.put("date", cur.getLong(3));
                o.put("name", cur.getString(4) == null ? "" : cur.getString(4));
                o.put("size", cur.getLong(5));
                o.put("dur", video ? cur.getLong(6) : 0);
                o.put("w", cur.getInt(7));
                o.put("h", cur.getInt(8));
                out.put(o);
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return out.toString();
    }

    /** path: thumb/i/123  или  file/v/456 */
    static WebResourceResponse handle(Context c, String path) {
        try {
            String[] p = path.split("/");
            if (p.length < 3) return null;
            String kind = p[0], type = p[1];
            long id = Long.parseLong(p[2]);
            Uri uri = uriOf(type, id);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-store");
            if ("thumb".equals(kind)) {
                Bitmap bm = c.getContentResolver().loadThumbnail(uri, new Size(360, 360), null);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 85, bo);
                return new WebResourceResponse("image/jpeg", null, 200, "OK", h, new ByteArrayInputStream(bo.toByteArray()));
            }
            if ("file".equals(kind)) {
                String mime = c.getContentResolver().getType(uri);
                InputStream in = c.getContentResolver().openInputStream(uri);
                if (in == null) return null;
                return new WebResourceResponse(mime == null ? "application/octet-stream" : mime, null, 200, "OK", h, in);
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
