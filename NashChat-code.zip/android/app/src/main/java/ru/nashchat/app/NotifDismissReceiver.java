package ru.nashchat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Уведомление о сообщениях смахнули — больше не показываем эти сообщения. */
public class NotifDismissReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String room = intent.getStringExtra("room");
        if (room != null) ChatService.lines.remove(room);
    }
}
