package ru.nashchat.app;

import android.Manifest;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.util.Rational;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.view.WindowManager;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.OutputStream;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    static volatile boolean inForeground = false;

    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_HOST + "/assets/www/index.html";
    private static final int REQ_FILE = 1, REQ_PERM = 2, REQ_NOTIF = 3, REQ_GAL = 4;

    private WebView web;
    private View fullView;
    private WebChromeClient.CustomViewCallback fullCallback;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean sysNight = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        styleBars(sysNight);

        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/gallery/", path -> Gallery.handle(MainActivity.this, path))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handlePermission(request));
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                fullView = view;
                fullCallback = callback;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                view.setBackgroundColor(Color.BLACK);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                exitFullView();
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(buildPicker(params), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        try {
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        } catch (Exception ignored) {
        }
        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        web.loadUrl(START_URL);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        if (ChatService.isConfigured(this)) ChatService.start(this);
        handleCallIntent(getIntent());
    }

    private void styleBars(boolean night) {
        Window w = getWindow();
        int bar = night ? Color.parseColor("#221D19") : Color.parseColor("#FFFFFF");
        w.setStatusBarColor(bar);
        w.setNavigationBarColor(bar);
        int flags = 0;
        if (!night) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    // ---------- выбор файлов ----------
    private Intent buildPicker(WebChromeClient.FileChooserParams params) {
        boolean multiple = params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        boolean media = false;
        for (String t : params.getAcceptTypes()) {
            if (t != null && (t.contains("image") || t.contains("video"))) media = true;
        }
        if (media && Build.VERSION.SDK_INT >= 33) {
            Intent i = new Intent(MediaStore.ACTION_PICK_IMAGES);
            if (multiple) i.putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, Math.min(50, MediaStore.getPickImagesMaxLimit()));
            return i;
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        if (media) i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
        return Intent.createChooser(i, "Выберите");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            List<Uri> uris = new ArrayList<>();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) result = uris.toArray(new Uri[0]);
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ---------- камера и микрофон ----------
    private void handlePermission(PermissionRequest request) {
        Uri origin = request.getOrigin();
        if (origin == null || !APP_HOST.equals(origin.getHost())) {
            request.deny();
            return;
        }
        List<String> need = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) need.add(Manifest.permission.CAMERA);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) need.add(Manifest.permission.RECORD_AUDIO);
        }
        List<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingPermission != null) pendingPermission.deny();
            pendingPermission = request;
            requestPermissions(missing.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_GAL) {
            final String st = Gallery.state(this);
            if (web != null) web.post(() -> { if (web != null) web.evaluateJavascript("window.onGalleryPerm && window.onGalleryPerm('" + st + "')", null); });
            return;
        }
        if (requestCode != REQ_PERM || pendingPermission == null) return;
        PermissionRequest r = pendingPermission;
        pendingPermission = null;
        List<String> ok = new ArrayList<>();
        for (String res : r.getResources()) {
            String p = PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) ? Manifest.permission.CAMERA
                    : PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) ? Manifest.permission.RECORD_AUDIO : null;
            if (p != null && checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) ok.add(res);
        }
        if (ok.size() == r.getResources().length) r.grant(r.getResources());
        else r.deny();
    }

    // ---------- жизненный цикл ----------
    // ---------- звонки ----------
    private volatile String pendingCall = "", pendingCallRoom = "", pendingChat = "";
    private volatile boolean pipAllowed = false;

    private PictureInPictureParams pipParams(boolean auto) {
        PictureInPictureParams.Builder b = new PictureInPictureParams.Builder().setAspectRatio(new Rational(9, 16));
        if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(auto).setSeamlessResizeEnabled(true);
        return b.build();
    }

    private void pipEnable(boolean on) {
        pipAllowed = on;
        try {
            if (Build.VERSION.SDK_INT >= 31) setPictureInPictureParams(pipParams(on));
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (pipAllowed && Build.VERSION.SDK_INT < 31) {
            try {
                enterPictureInPictureMode(pipParams(false));
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (web != null) web.evaluateJavascript("window.nativePip && window.nativePip(" + inPip + ")", null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleCallIntent(intent);
    }

    private void handleCallIntent(Intent intent) {
        if (intent == null) return;
        String chat = intent.getStringExtra("open_chat");
        if (chat != null && !chat.isEmpty()) {
            intent.removeExtra("open_chat");
            pendingChat = chat;
            if (web != null) {
                final String js = "window.nativeOpenChat && window.nativeOpenChat(" + JSONObject.quote(chat) + ")";
                web.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
            }
        }
        String id = intent.getStringExtra("call_id"), act = intent.getStringExtra("call_act");
        if (id == null || act == null) return;
        String room = intent.getStringExtra("call_room");
        pendingCallRoom = room == null ? "" : room;
        intent.removeExtra("call_id");
        intent.removeExtra("call_act");
        pendingCall = act + ":" + id;
        ChatService.cancelCall(this);
        showOverLock(true);
        if (web != null) {
            final String js = "window.nativeCallIntent && window.nativeCallIntent(" + JSONObject.quote(pendingCall) + ")";
            web.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
        }
    }

    private void showOverLock(boolean on) {
        try {
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(on);
                setTurnScreenOn(on);
            } else if (on) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            }
        } catch (Exception ignored) {
        }
    }

    // ---------- куда идёт звук звонка: наушники, динамик или разговорный динамик ----------
    private boolean callOn = false, callVideo = false;
    private String routeWant = "auto"; // auto | speaker | earpiece
    private android.media.AudioDeviceCallback devCb;
    private boolean scoOn = false;
    private PowerManager.WakeLock prox;

    /** Голосовой звонок у уха: экран гаснет, когда телефон поднесли к лицу (датчик приближения). */
    private void setProximity(boolean on) {
        try {
            if (on) {
                if (prox == null) {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm == null || !pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) return;
                    prox = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "nashchat:proximity");
                    prox.setReferenceCounted(false);
                }
                if (!prox.isHeld()) prox.acquire(4 * 60 * 60 * 1000L);
            } else if (prox != null && prox.isHeld()) {
                prox.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY);
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean isHeadset(int t) {
        return t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                || (Build.VERSION.SDK_INT >= 31 && (t == AudioDeviceInfo.TYPE_BLE_HEADSET));
    }

    private static boolean isBt(int t) {
        return t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                || (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET);
    }

    /** Подключённые наушники (проводные важнее Bluetooth). */
    private AudioDeviceInfo findHeadset(AudioManager am) {
        AudioDeviceInfo bt = null;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                for (AudioDeviceInfo d : am.getAvailableCommunicationDevices()) {
                    if (!isHeadset(d.getType())) continue;
                    if (isBt(d.getType())) { if (bt == null) bt = d; } else return d;
                }
            } else {
                for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                    int t = d.getType();
                    if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_USB_HEADSET) return d;
                    if (isBt(t) && bt == null) bt = d;
                }
            }
        } catch (Exception ignored) {
        }
        return bt;
    }

    private void applyRoute() {
        if (!callOn) return;
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        String result;
        try {
            AudioDeviceInfo hs = findHeadset(am);
            boolean speaker = "speaker".equals(routeWant) || ("auto".equals(routeWant) && hs == null && callVideo);
            if (Build.VERSION.SDK_INT >= 31) {
                AudioDeviceInfo target = null;
                if (speaker) {
                    for (AudioDeviceInfo d : am.getAvailableCommunicationDevices())
                        if (d.getType() == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) { target = d; break; }
                } else if (hs != null && !"earpiece".equals(routeWant)) {
                    target = hs;
                } else {
                    for (AudioDeviceInfo d : am.getAvailableCommunicationDevices())
                        if (d.getType() == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) { target = d; break; }
                }
                if (target != null) am.setCommunicationDevice(target); else am.clearCommunicationDevice();
            } else {
                boolean bt = hs != null && isBt(hs.getType()) && !speaker && !"earpiece".equals(routeWant);
                if (bt && !scoOn) { try { am.startBluetoothSco(); am.setBluetoothScoOn(true); scoOn = true; } catch (Exception ignored) { } }
                if (!bt && scoOn) { try { am.setBluetoothScoOn(false); am.stopBluetoothSco(); } catch (Exception ignored) { } scoOn = false; }
                am.setSpeakerphoneOn(speaker);
            }
            result = speaker ? "speaker" : (hs != null && !"earpiece".equals(routeWant)) ? (isBt(hs.getType()) ? "bt" : "headset") : "earpiece";
        } catch (Exception e) {
            result = "earpiece";
        }
        setProximity(callOn && !callVideo && "earpiece".equals(result));
        final String r = result;
        if (web != null) web.post(() -> web.evaluateJavascript("window.nativeAudioRoute && window.nativeAudioRoute('" + r + "')", null));
    }

    private void callAudio(boolean on, boolean video) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        try {
            if (on) {
                callOn = true; callVideo = video; routeWant = "auto";
                am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (devCb == null) {
                    devCb = new android.media.AudioDeviceCallback() {
                        @Override
                        public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
                            // подключили наушники посреди звонка — переключаемся на них
                            for (AudioDeviceInfo d : added) if (isHeadset(d.getType()) || isBt(d.getType())) routeWant = "auto";
                            if (web != null) web.postDelayed(MainActivity.this::applyRoute, 300);
                        }

                        @Override
                        public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
                            routeWant = "auto";
                            if (web != null) web.postDelayed(MainActivity.this::applyRoute, 300);
                        }
                    };
                    am.registerAudioDeviceCallback(devCb, null);
                }
                applyRoute();
            } else {
                callOn = false;
                setProximity(false);
                if (devCb != null) { try { am.unregisterAudioDeviceCallback(devCb); } catch (Exception ignored) { } devCb = null; }
                if (scoOn) { try { am.setBluetoothScoOn(false); am.stopBluetoothSco(); } catch (Exception ignored) { } scoOn = false; }
                if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice();
                else am.setSpeakerphoneOn(false);
                am.setMode(AudioManager.MODE_NORMAL);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                showOverLock(false);
            }
        } catch (Exception ignored) {
        }
        ChatService.setCallMode(this, on);
    }

    @Override
    protected void onResume() {
        super.onResume();
        inForeground = true;
        cancelNotifications();
        if (web != null) web.evaluateJavascript("window.nativeResume && window.nativeResume()", null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        inForeground = false;
    }

    private void exitFullView() {
        if (fullView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(fullView);
        fullView = null;
        if (fullCallback != null) fullCallback.onCustomViewHidden();
        fullCallback = null;
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        styleBars(night);
    }

    @Override
    public void onBackPressed() {
        if (fullView != null) {
            exitFullView();
            return;
        }
        web.evaluateJavascript("(window.nativeBack && window.nativeBack()) ? 'yes' : 'no'", v -> {
            if (v == null || !v.contains("yes")) moveTaskToBack(true);
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void cancelNotifications() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(ChatService.NOTIF_MESSAGE);
    }

    private void openExternal(String url) {
        Uri u = Uri.parse(url);
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        Intent i;
        if (scheme.equals("tel")) i = new Intent(Intent.ACTION_DIAL, u);
        else if (scheme.equals("mailto")) i = new Intent(Intent.ACTION_SENDTO, u);
        else {
            i = new Intent(Intent.ACTION_VIEW, u);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, u), "Открыть с помощью"));
            } catch (Exception e2) {
                if (web != null) web.evaluateJavascript("toast('Не нашлось приложения, чтобы открыть ссылку')", null);
            }
        }
    }

    // ---------- отпечаток пальца ----------
    private static final String BIO_ALIAS = "nashchat_bio";
    private CancellationSignal bioCancel;

    private void toJs(String kind, String data) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript("window.onBio && window.onBio(" + JSONObject.quote(kind) + "," + JSONObject.quote(data) + ")", null);
        });
    }

    boolean bioAvailable() {
        try {
            BiometricManager bm = getSystemService(BiometricManager.class);
            if (bm == null) return false;
            if (Build.VERSION.SDK_INT >= 30) {
                return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS;
            }
            return bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    private SecretKey bioKey(boolean create) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(BIO_ALIAS)) {
            if (!create) return (SecretKey) ks.getKey(BIO_ALIAS, null);
            ks.deleteEntry(BIO_ALIAS);
        } else if (!create) {
            return null;
        }
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(BIO_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true);
        if (Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(b.build());
        return kg.generateKey();
    }

    private void bioClear() {
        ChatService.prefs(this).edit().remove("bio_iv").remove("bio_ct").apply();
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(BIO_ALIAS)) ks.deleteEntry(BIO_ALIAS);
        } catch (Exception ignored) {
        }
    }

    private void bioPrompt(Cipher cipher, String title, String kind, BioDone done) {
        if (bioCancel != null) bioCancel.cancel();
        bioCancel = new CancellationSignal();
        BiometricPrompt.Builder pb = new BiometricPrompt.Builder(this)
                .setTitle(title)
                .setSubtitle("Наш чат")
                .setNegativeButton(kind.equals("unlock") ? "Ввести PIN" : "Отмена", getMainExecutor(),
                        (d, w) -> toJs("cancel", kind));
        if (Build.VERSION.SDK_INT >= 29) pb.setConfirmationRequired(false);
        pb.build().authenticate(new BiometricPrompt.CryptoObject(cipher), bioCancel, getMainExecutor(),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        try {
                            done.run(result.getCryptoObject().getCipher());
                        } catch (Exception e) {
                            toJs("error", "Не удалось расшифровать ключ");
                        }
                    }

                    @Override
                    public void onAuthenticationError(int code, CharSequence msg) {
                        if (code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                                || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED) {
                            toJs("cancel", kind);
                        } else {
                            toJs("error", msg == null ? "Ошибка отпечатка" : msg.toString());
                        }
                    }
                });
    }

    private interface BioDone {
        void run(Cipher c) throws Exception;
    }

    void bioEnable(String rawB64) {
        try {
            SecretKey key = bioKey(true);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key);
            byte[] raw = Base64.decode(rawB64, Base64.NO_WRAP);
            bioPrompt(c, "Подтвердите отпечаток", "enable", cipher -> {
                byte[] ct = cipher.doFinal(raw);
                ChatService.prefs(this).edit()
                        .putString("bio_iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                        .putString("bio_ct", Base64.encodeToString(ct, Base64.NO_WRAP))
                        .apply();
                toJs("enabled", "ok");
            });
        } catch (Exception e) {
            bioClear();
            toJs("error", "Не удалось включить вход по отпечатку");
        }
    }

    void bioUnlock() {
        SharedPreferences p = ChatService.prefs(this);
        String iv = p.getString("bio_iv", ""), ct = p.getString("bio_ct", "");
        if (iv.isEmpty() || ct.isEmpty()) {
            toJs("cancel", "unlock");
            return;
        }
        try {
            SecretKey key = bioKey(false);
            if (key == null) {
                bioClear();
                toJs("invalid", "");
                return;
            }
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            bioPrompt(c, "Вход по отпечатку", "unlock", cipher -> {
                byte[] raw = cipher.doFinal(Base64.decode(ct, Base64.NO_WRAP));
                toJs("unlock", Base64.encodeToString(raw, Base64.NO_WRAP));
            });
        } catch (KeyPermanentlyInvalidatedException e) {
            bioClear();
            toJs("invalid", "");
        } catch (Exception e) {
            toJs("error", "Отпечаток сейчас недоступен");
        }
    }

    // ---------- мост для JavaScript ----------
    private static class SaveJob {
        Uri uri;
        OutputStream out;
        String where;
    }

    private class Bridge {
        private final Map<Integer, SaveJob> jobs = new HashMap<>();
        private int nextJob = 1;

        @JavascriptInterface
        public void configure(String url, String token, String dev) {
            ChatService.prefs(MainActivity.this).edit()
                    .putString("url", url).putString("token", token).putString("dev", dev).apply();
            ChatService.start(MainActivity.this);
        }

        @JavascriptInterface
        public void setSeen(String id) {
            try {
                long v = Long.parseLong(id);
                ChatService.markSeen(MainActivity.this, v);
            } catch (NumberFormatException ignored) {
            }
            runOnUiThread(MainActivity.this::cancelNotifications);
        }

        @JavascriptInterface
        public void pipEnable(boolean on) {
            runOnUiThread(() -> MainActivity.this.pipEnable(on));
        }

        @JavascriptInterface
        public String takeCallIntent() {
            String v = pendingCall;
            pendingCall = "";
            return v;
        }

        /** из какого чата звонок, по которому открыли приложение (не сбрасывает его) */
        @JavascriptInterface
        public String peekCallRoom() {
            return pendingCall.isEmpty() ? "" : pendingCallRoom;
        }

        // ---------- галерея телефона ----------
        @JavascriptInterface
        public String galleryState() {
            return Gallery.state(MainActivity.this);
        }

        @JavascriptInterface
        public void galleryAsk() {
            runOnUiThread(() -> requestPermissions(Gallery.permissions(), REQ_GAL));
        }

        @JavascriptInterface
        public String galleryList(int offset, int limit) {
            return Gallery.list(MainActivity.this, offset, limit);
        }

        @JavascriptInterface
        public String takeOpenChat() {
            String v = pendingChat;
            pendingChat = "";
            return v;
        }

        /** список чатов для фоновой службы (с ключами — только если включён текст в уведомлениях) */
        @JavascriptInterface
        public void setRooms(String json) {
            ChatService.saveRooms(MainActivity.this, json);
            ChatService.start(MainActivity.this);
        }

        @JavascriptInterface
        public void setSeenRoom(String room, String id) {
            try {
                ChatService.markSeenRoom(MainActivity.this, room, Long.parseLong(id));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                try {
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType("text/plain");
                    s.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(s, "Отправить код приглашения"));
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void cancelCallNotif() {
            ChatService.cancelCall(MainActivity.this);
        }

        @JavascriptInterface
        public void callAudio(boolean on) {
            runOnUiThread(() -> MainActivity.this.callAudio(on, false));
        }

        @JavascriptInterface
        public void callAudio2(boolean on, boolean video) {
            runOnUiThread(() -> MainActivity.this.callAudio(on, video));
        }

        /** auto — наушники, если подключены; speaker — громкая связь; earpiece — у уха */
        @JavascriptInterface
        public void callRoute(String want) {
            runOnUiThread(() -> { routeWant = want == null ? "auto" : want; applyRoute(); });
        }

        @JavascriptInterface
        public void callSpeaker(boolean on) {
            runOnUiThread(() -> { routeWant = on ? "speaker" : "auto"; applyRoute(); });
        }

        @JavascriptInterface
        public void setPartnerName(String name) {
            if (name != null) ChatService.prefs(MainActivity.this).edit().putString("partner", name).apply();
        }

        @JavascriptInterface
        public boolean canFullScreen() {
            if (Build.VERSION.SDK_INT < 34) return true;
            try {
                return ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();
            } catch (Exception e) {
                return true;
            }
        }

        @JavascriptInterface
        public void openFullScreenSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                        i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void setDark(boolean dark) {
            runOnUiThread(() -> styleBars(dark));
        }

        @JavascriptInterface
        public boolean bioAvailable() {
            return MainActivity.this.bioAvailable();
        }

        @JavascriptInterface
        public boolean bioEnabled() {
            return !ChatService.prefs(MainActivity.this).getString("bio_ct", "").isEmpty();
        }

        @JavascriptInterface
        public void bioEnable(String rawB64) {
            runOnUiThread(() -> MainActivity.this.bioEnable(rawB64));
        }

        @JavascriptInterface
        public void bioUnlock() {
            runOnUiThread(MainActivity.this::bioUnlock);
        }

        @JavascriptInterface
        public void bioDisable() {
            runOnUiThread(MainActivity.this::bioClear);
        }

        @JavascriptInterface
        public void reset() {
            bioClear();
            ChatService.clearRooms(MainActivity.this);
            ChatService.prefs(MainActivity.this).edit().clear().apply();
            stopService(new Intent(MainActivity.this, ChatService.class));
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Наш чат", text));
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            String l = url == null ? "" : url.toLowerCase();
            if (l.startsWith("https://") || l.startsWith("http://") || l.startsWith("mailto:") || l.startsWith("tel:")) {
                runOnUiThread(() -> openExternal(url));
            }
        }

        @JavascriptInterface
        public void openBgNotifSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    i.putExtra(Settings.EXTRA_CHANNEL_ID, "service");
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                        i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        /** приложению разрешено работать в фоне без ограничений батареи? */
        @JavascriptInterface
        public boolean bgAllowed() {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                return pm == null || pm.isIgnoringBatteryOptimizations(getPackageName());
            } catch (Exception e) {
                return true;
            }
        }

        @JavascriptInterface
        public void requestBackground() {
            runOnUiThread(() -> {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                try {
                    if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } else {
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    }
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public synchronized int saveStart(String name, String mime) {
            try {
                ContentResolver cr = getContentResolver();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection;
                String where;
                if (mime != null && mime.startsWith("image/")) {
                    collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Наш чат");
                    where = "Сохранено в Галерею";
                } else if (mime != null && mime.startsWith("video/")) {
                    collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Наш чат");
                    where = "Сохранено в Галерею";
                } else {
                    collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Наш чат");
                    where = "Сохранено в Загрузки";
                }
                Uri uri = cr.insert(collection, cv);
                if (uri == null) return -1;
                SaveJob j = new SaveJob();
                j.uri = uri;
                j.out = cr.openOutputStream(uri);
                j.where = where;
                if (j.out == null) return -1;
                int id = nextJob++;
                jobs.put(id, j);
                return id;
            } catch (Exception e) {
                return -1;
            }
        }

        @JavascriptInterface
        public synchronized boolean saveChunk(int id, String b64) {
            SaveJob j = jobs.get(id);
            if (j == null) return false;
            try {
                j.out.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized String saveEnd(int id) {
            SaveJob j = jobs.remove(id);
            if (j == null) return "Ошибка сохранения";
            try {
                j.out.close();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(j.uri, cv, null, null);
                return j.where;
            } catch (Exception e) {
                return "Ошибка сохранения";
            }
        }
    }
}
