package ru.nashchat.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    static volatile boolean inForeground = false;

    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_HOST + "/assets/www/index.html";
    private static final int REQ_FILE = 1, REQ_PERM = 2, REQ_NOTIF = 3;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean sysNight = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        styleBars(sysNight);

        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handlePermission(request));
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(buildPicker(params), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        web.loadUrl(START_URL);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        if (ChatService.isConfigured(this)) ChatService.start(this);
    }

    private void styleBars(boolean night) {
        Window w = getWindow();
        int bar = night ? Color.parseColor("#221D19") : Color.parseColor("#FFFFFF");
        w.setStatusBarColor(bar);
        w.setNavigationBarColor(bar);
        int flags = 0;
        if (!night) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    // ---------- выбор файлов ----------
    private Intent buildPicker(WebChromeClient.FileChooserParams params) {
        boolean multiple = params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        boolean media = false;
        for (String t : params.getAcceptTypes()) {
            if (t != null && (t.contains("image") || t.contains("video"))) media = true;
        }
        if (media && Build.VERSION.SDK_INT >= 33) {
            Intent i = new Intent(MediaStore.ACTION_PICK_IMAGES);
            if (multiple) i.putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, Math.min(50, MediaStore.getPickImagesMaxLimit()));
            return i;
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        if (media) i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
        return Intent.createChooser(i, "Выберите");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            List<Uri> uris = new ArrayList<>();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) result = uris.toArray(new Uri[0]);
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ---------- камера и микрофон ----------
    private void handlePermission(PermissionRequest request) {
        Uri origin = request.getOrigin();
        if (origin == null || !APP_HOST.equals(origin.getHost())) {
            request.deny();
            return;
        }
        List<String> need = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) need.add(Manifest.permission.CAMERA);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) need.add(Manifest.permission.RECORD_AUDIO);
        }
        List<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingPermission != null) pendingPermission.deny();
            pendingPermission = request;
            requestPermissions(missing.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERM || pendingPermission == null) return;
        PermissionRequest r = pendingPermission;
        pendingPermission = null;
        List<String> ok = new ArrayList<>();
        for (String res : r.getResources()) {
            String p = PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) ? Manifest.permission.CAMERA
                    : PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) ? Manifest.permission.RECORD_AUDIO : null;
            if (p != null && checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) ok.add(res);
        }
        if (ok.size() == r.getResources().length) r.grant(r.getResources());
        else r.deny();
    }

    // ---------- жизненный цикл ----------
    @Override
    protected void onResume() {
        super.onResume();
        inForeground = true;
        cancelNotifications();
        if (web != null) web.evaluateJavascript("window.nativeResume && window.nativeResume()", null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        inForeground = false;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.nativeBack && window.nativeBack()) ? 'yes' : 'no'", v -> {
            if (v == null || !v.contains("yes")) moveTaskToBack(true);
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void cancelNotifications() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(ChatService.NOTIF_MESSAGE);
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {
        }
    }

    // ---------- мост для JavaScript ----------
    private static class SaveJob {
        Uri uri;
        OutputStream out;
        String where;
    }

    private class Bridge {
        private final Map<Integer, SaveJob> jobs = new HashMap<>();
        private int nextJob = 1;

        @JavascriptInterface
        public void configure(String url, String token, String dev) {
            ChatService.prefs(MainActivity.this).edit()
                    .putString("url", url).putString("token", token).putString("dev", dev).apply();
            ChatService.start(MainActivity.this);
        }

        @JavascriptInterface
        public void setSeen(String id) {
            try {
                long v = Long.parseLong(id);
                ChatService.markSeen(MainActivity.this, v);
            } catch (NumberFormatException ignored) {
            }
            runOnUiThread(MainActivity.this::cancelNotifications);
        }

        @JavascriptInterface
        public void setDark(boolean dark) {
            runOnUiThread(() -> styleBars(dark));
        }

        @JavascriptInterface
        public void reset() {
            ChatService.prefs(MainActivity.this).edit().clear().apply();
            stopService(new Intent(MainActivity.this, ChatService.class));
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Наш чат", text));
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
                runOnUiThread(() -> openExternal(url));
            }
        }

        @JavascriptInterface
        public void requestBackground() {
            runOnUiThread(() -> {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                try {
                    if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } else {
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    }
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public synchronized int saveStart(String name, String mime) {
            try {
                ContentResolver cr = getContentResolver();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection;
                String where;
                if (mime != null && mime.startsWith("image/")) {
                    collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Наш чат");
                    where = "Сохранено в Галерею";
                } else if (mime != null && mime.startsWith("video/")) {
                    collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Наш чат");
                    where = "Сохранено в Галерею";
                } else {
                    collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Наш чат");
                    where = "Сохранено в Загрузки";
                }
                Uri uri = cr.insert(collection, cv);
                if (uri == null) return -1;
                SaveJob j = new SaveJob();
                j.uri = uri;
                j.out = cr.openOutputStream(uri);
                j.where = where;
                if (j.out == null) return -1;
                int id = nextJob++;
                jobs.put(id, j);
                return id;
            } catch (Exception e) {
                return -1;
            }
        }

        @JavascriptInterface
        public synchronized boolean saveChunk(int id, String b64) {
            SaveJob j = jobs.get(id);
            if (j == null) return false;
            try {
                j.out.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized String saveEnd(int id) {
            SaveJob j = jobs.remove(id);
            if (j == null) return "Ошибка сохранения";
            try {
                j.out.close();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(j.uri, cv, null, null);
                return j.where;
            } catch (Exception e) {
                return "Ошибка сохранения";
            }
        }
    }
}
