package ru.nashchat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import androidx.core.app.NotificationCompat;
import androidx.core.app.Person;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Фоновая служба: держит соединение с сервером и показывает уведомления о новых сообщениях
 * и входящих звонках во всех чатах. Если в настройках включён «текст в уведомлениях»,
 * приложение передаёт ей ключи чатов (они хранятся зашифрованными ключом из Android Keystore),
 * и служба сама расшифровывает, кто и что написал. Иначе показывается только «Новое сообщение».
 */
public class ChatService extends Service {

    static final int NOTIF_SERVICE = 1, NOTIF_MESSAGE = 2, NOTIF_CALL = 3;
    private static final String CH_MSG = "messages", CH_SVC = "service", CH_CALL = "calls";
    static final String ACT_CALL_ON = "ru.nashchat.CALL_ON", ACT_CALL_OFF = "ru.nashchat.CALL_OFF";
    private static final String KS_ALIAS = "nc_rooms";
    static volatile String ringShown = "", ringRoom = "";
    static volatile boolean callMode = false;

    private volatile boolean running = false;
    private Thread worker;
    private int unread = 0;
    /** последние строки уведомления по каждому чату: {кто, текст, время} */
    static final Map<String, List<Object[]>> lines = new ConcurrentHashMap<>();
    private final Map<String, byte[]> encKeys = new HashMap<>();

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("chat", Context.MODE_PRIVATE);
    }

    static boolean isConfigured(Context c) {
        SharedPreferences p = prefs(c);
        return (!p.getString("url", "").isEmpty() && !p.getString("token", "").isEmpty()) || !p.getString("rooms_ct", "").isEmpty();
    }

    static void start(Context c) {
        if (!isConfigured(c)) return;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, ChatService.class));
        } catch (Exception ignored) {
        }
    }

    /** Во время звонка служба получает право на микрофон, чтобы звук не пропадал, если свернуть приложение. */
    static void setCallMode(Context c, boolean on) {
        if (!isConfigured(c)) return;
        try {
            Intent i = new Intent(c, ChatService.class).setAction(on ? ACT_CALL_ON : ACT_CALL_OFF);
            ContextCompat.startForegroundService(c, i);
        } catch (Exception ignored) {
        }
    }

    static void cancelCall(Context c) {
        try {
            c.getSystemService(NotificationManager.class).cancel(NOTIF_CALL);
        } catch (Exception ignored) {
        }
    }

    static synchronized void markSeen(Context c, long id) {
        SharedPreferences p = prefs(c);
        if (id > p.getLong("seen", 0)) p.edit().putLong("seen", id).apply();
    }

    static int notifId(String room) {
        return 1000 + (room.hashCode() & 0x7fff);
    }

    /** Чат открыт и прочитан: убираем его уведомление. */
    static synchronized void markSeenRoom(Context c, String room, long id) {
        SharedPreferences p = prefs(c);
        if (id > p.getLong("seen_" + room, 0)) p.edit().putLong("seen_" + room, id).apply();
        if ("main".equals(room)) markSeen(c, id);
        lines.remove(room);
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            nm.cancel(notifId(room));
            if ("main".equals(room)) nm.cancel(NOTIF_MESSAGE);
        } catch (Exception ignored) {
        }
    }

    // ---------- список чатов: хранится зашифрованным ключом из Android Keystore ----------
    private static SecretKey ksKey(boolean create) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KS_ALIAS)) return (SecretKey) ks.getKey(KS_ALIAS, null);
        if (!create) return null;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KS_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return kg.generateKey();
    }

    static void saveRooms(Context c, String json) {
        try {
            SecretKey k = ksKey(true);
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.ENCRYPT_MODE, k);
            byte[] ct = ci.doFinal(json.getBytes(StandardCharsets.UTF_8));
            byte[] iv = ci.getIV();
            byte[] out = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, out, 0, iv.length);
            System.arraycopy(ct, 0, out, iv.length, ct.length);
            SharedPreferences p = prefs(c);
            SharedPreferences.Editor e = p.edit().putString("rooms_ct", Base64.encodeToString(out, Base64.NO_WRAP)).putInt("rooms_iv", iv.length);
            // переносим отметки главного чата со старой версии
            if (!p.contains("pos_main") && p.getLong("pos", 0) > 0) e.putLong("pos_main", p.getLong("pos", 0));
            if (!p.contains("seen_main") && p.getLong("seen", 0) > 0) e.putLong("seen_main", p.getLong("seen", 0));
            e.apply();
        } catch (Exception ignored) {
        }
    }

    static JSONArray loadRooms(Context c) {
        try {
            SharedPreferences p = prefs(c);
            String s = p.getString("rooms_ct", "");
            if (s.isEmpty()) return null;
            byte[] all = Base64.decode(s, Base64.NO_WRAP);
            int ivLen = p.getInt("rooms_iv", 12);
            SecretKey k = ksKey(false);
            if (k == null) return null;
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.DECRYPT_MODE, k, new GCMParameterSpec(128, all, 0, ivLen));
            return new JSONArray(new String(ci.doFinal(all, ivLen, all.length - ivLen), StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    static void clearRooms(Context c) {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(KS_ALIAS)) ks.deleteEntry(KS_ALIAS);
        } catch (Exception ignored) {
        }
        lines.clear();
    }

    static JSONObject roomById(Context c, String id) {
        JSONArray a = loadRooms(c);
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject r = a.optJSONObject(i);
            if (r != null && id.equals(r.optString("id"))) return r;
        }
        return null;
    }

    // ---------- расшифровка (так же, как в приложении: HKDF-SHA256 + AES-256-GCM) ----------
    static byte[] hkdf(byte[] ikm, byte[] salt, byte[] info) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(salt, "HmacSHA256"));
        byte[] prk = mac.doFinal(ikm);
        mac.init(new SecretKeySpec(prk, "HmacSHA256"));
        mac.update(info);
        mac.update((byte) 1);
        return Arrays.copyOf(mac.doFinal(), 32);
    }

    static String open(byte[] key, String ctB64) throws Exception {
        byte[] d = Base64.decode(ctB64, Base64.DEFAULT);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, d, 0, 12));
        return new String(c.doFinal(d, 12, d.length - 12), StandardCharsets.UTF_8);
    }

    private byte[] encKey(JSONObject room) {
        String id = room.optString("id"), raw = room.optString("key", "");
        if (raw.isEmpty()) return null;
        byte[] k = encKeys.get(id + raw.hashCode());
        if (k != null) return k;
        try {
            k = hkdf(Base64.decode(raw, Base64.DEFAULT), "nash-chat-v1".getBytes(StandardCharsets.UTF_8), "enc".getBytes(StandardCharsets.UTF_8));
            encKeys.put(id + raw.hashCode(), k);
            return k;
        } catch (Exception e) {
            return null;
        }
    }

    /** Что показать в уведомлении. null — не показывать (реакция, правка). */
    static String snippet(JSONObject p) {
        String t = p.optString("t");
        switch (t) {
            case "text": return p.optString("text").replaceAll("\\s+", " ").trim();
            case "image": { String cap = p.optString("caption", ""); return "📷 Фото" + (cap.isEmpty() ? "" : ": " + cap); }
            case "video": return "🎬 Видео";
            case "voice": return "🎤 Голосовое сообщение";
            case "circle": return "⭕ Видеосообщение";
            case "sticker": return "🧸 Стикер";
            case "gift": return "🎁 Подарок";
            case "watch": return "📺 Приглашает смотреть вместе";
            case "call": return p.optBoolean("video") ? "🎥 Видеозвонок" : "📞 Звонок";
            case "file": { JSONObject f = p.optJSONObject("file"); String n = f != null ? f.optString("name", "") : ""; return "📎 " + (n.isEmpty() ? "Файл" : n); }
            case "think": return "💗 Думает о тебе";
            case "tree": return "💧 Полил(а) наше дерево";
            case "game": return "🎮 Приглашает сыграть";
            case "react": case "edit": case "gm": return null;
        }
        return "Новое сообщение";
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel msg = new NotificationChannel(CH_MSG, "Новые сообщения", NotificationManager.IMPORTANCE_HIGH);
        msg.enableVibration(true);
        msg.setShowBadge(true);
        nm.createNotificationChannel(msg);
        NotificationChannel svc = new NotificationChannel(CH_SVC, "Работа в фоне", NotificationManager.IMPORTANCE_MIN);
        svc.setDescription("Это уведомление можно скрыть в настройках — чат продолжит работать");
        svc.setShowBadge(false);
        nm.createNotificationChannel(svc);
        NotificationChannel call = new NotificationChannel(CH_CALL, "Входящие звонки", NotificationManager.IMPORTANCE_HIGH);
        Uri tone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        call.setSound(tone, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        call.enableVibration(true);
        call.setVibrationPattern(new long[]{0, 800, 600, 800, 600});
        call.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        call.setBypassDnd(false);
        nm.createNotificationChannel(call);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACT_CALL_ON.equals(act)) callMode = true;
        else if (ACT_CALL_OFF.equals(act)) callMode = false;
        Notification n = new NotificationCompat.Builder(this, CH_SVC)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Наш чат")
                .setContentText(callMode ? "Идёт звонок" : "Ожидаю новые сообщения")
                .setPriority(callMode ? NotificationCompat.PRIORITY_DEFAULT : NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .setContentIntent(openApp(null))
                .build();
        boolean started = false;
        if (callMode) {
            try {
                int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                if (Build.VERSION.SDK_INT >= 34) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
                startForeground(NOTIF_SERVICE, n, type);
                started = true;
            } catch (Exception e) {
                callMode = false;
            }
        }
        if (!started) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(NOTIF_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                } else {
                    startForeground(NOTIF_SERVICE, n);
                }
            } catch (Exception e) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        if (!running) {
            running = true;
            worker = new Thread(this::loop, "chat-poll");
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /** уведомление смахнули — забываем его строки, чтобы они не всплыли снова со следующим сообщением */
    private PendingIntent dismissIntent(String room) {
        Intent i = new Intent(this, NotifDismissReceiver.class).putExtra("room", room);
        return PendingIntent.getBroadcast(this, 500 + (room.hashCode() & 0x7fff), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent openApp(String room) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (room != null) i.putExtra("open_chat", room);
        int code = room == null ? 0 : 100 + (room.hashCode() & 0x7fff);
        return PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void loop() {
        long backoff = 2000;
        while (running) {
            SharedPreferences p = prefs(this);
            JSONArray rooms = loadRooms(this);
            try {
                if (rooms != null && rooms.length() > 0 && System.currentTimeMillis() > oldServerUntil) multiOnce(rooms, p);
                else if (!legacyOnce(p)) return;
                backoff = 2000;
            } catch (OldServerException e) {
                // сервер ещё не обновлён — работаем по-старому с главным чатом
                oldServerUntil = System.currentTimeMillis() + 10 * 60 * 1000;
            } catch (UnauthorizedException e) {
                sleep(5 * 60 * 1000);
            } catch (Exception e) {
                sleep(backoff);
                backoff = Math.min(backoff * 2, 15000);
            }
        }
    }

    // ---------- несколько чатов ----------
    private void multiOnce(JSONArray rooms, SharedPreferences p) throws Exception {
        LinkedHashMap<String, List<JSONObject>> byUrl = new LinkedHashMap<>();
        for (int i = 0; i < rooms.length(); i++) {
            JSONObject r = rooms.optJSONObject(i);
            if (r == null || r.optString("url").isEmpty() || r.optString("token").isEmpty()) continue;
            String u = r.optString("url");
            if (!byUrl.containsKey(u)) byUrl.put(u, new ArrayList<>());
            byUrl.get(u).add(r);
        }
        boolean primary = true;
        for (Map.Entry<String, List<JSONObject>> e : byUrl.entrySet()) {
            List<JSONObject> list = e.getValue();
            JSONArray body = new JSONArray();
            boolean allKnown = true;
            String dev = "";
            for (JSONObject r : list) {
                String id = r.optString("id");
                dev = r.optString("dev", dev);
                if (!p.contains("pos_" + id)) allKnown = false;
                JSONObject x = new JSONObject();
                x.put("t", r.optString("token"));
                x.put("a", p.getLong("pos_" + id, 0));
                x.put("rs", id.equals(ringRoom) ? ringShown : "");
                body.put(x);
            }
            JSONObject req = new JSONObject();
            req.put("dev", dev);
            req.put("wait", primary && allKnown ? 25 : 0);
            req.put("rooms", body);
            JSONObject res = post(e.getKey() + "/api/multi", req, 40000);
            JSONArray out = res.optJSONArray("rooms");
            if (out == null) continue;
            for (int i = 0; i < list.size() && i < out.length(); i++) handleRoom(list.get(i), out.optJSONObject(i), p);
            if (!primary || byUrl.size() > 1) sleep(primary ? 0 : 3000);
            primary = false;
        }
    }

    private void handleRoom(JSONObject room, JSONObject x, SharedPreferences p) {
        if (x == null || x.has("err")) return;
        String id = room.optString("id"), dev = room.optString("dev");
        boolean known = p.contains("pos_" + id);
        long pos = p.getLong("pos_" + id, 0), last = x.optLong("last", 0);
        long seen = p.getLong("seen_" + id, 0);
        JSONArray msgs = x.optJSONArray("msgs");
        if (known && msgs != null) {
            byte[] key = encKey(room);
            List<Object[]> fresh = new ArrayList<>();
            int count = 0;
            for (int i = 0; i < msgs.length(); i++) {
                JSONObject m = msgs.optJSONObject(i);
                if (m == null) continue;
                long mid = m.optLong("id", 0);
                if (mid <= pos || mid <= seen || m.optBoolean("del", false) || dev.equals(m.optString("dev"))) continue;
                String who = "", text = "Новое сообщение";
                if (key != null) {
                    try {
                        JSONObject pl = new JSONObject(open(key, m.optString("ct")));
                        text = snippet(pl);
                        who = pl.optString("n", "");
                    } catch (Exception ignored) {
                        text = "Новое сообщение";
                    }
                    if (text == null) continue;
                }
                count++;
                fresh.add(new Object[]{who, text, m.optLong("ts", System.currentTimeMillis()), mid});
            }
            if (count > 0 && !MainActivity.inForeground) notifyRoom(room, fresh, key != null);
        }
        if (last != pos || !known) p.edit().putLong("pos_" + id, last).apply();
        // звонки
        JSONObject ring = x.optJSONObject("ring");
        if (ring != null) {
            String rid = ring.optString("id", "");
            if (!rid.isEmpty() && !rid.equals(ringShown)) {
                ringShown = rid;
                ringRoom = id;
                if (!MainActivity.inForeground) showCall(rid, ring.optBoolean("video", false), id, room.optString("title", ""));
            }
        } else if (id.equals(ringRoom) && !ringShown.isEmpty()) {
            ringShown = "";
            ringRoom = "";
            cancelCall(this);
        }
    }

    private void notifyRoom(JSONObject room, List<Object[]> fresh, boolean withText) {
        String id = room.optString("id"), title = room.optString("title", "");
        boolean group = "group".equals(room.optString("kind"));
        if (title.isEmpty()) title = "Наш чат";
        List<Object[]> l = lines.get(id);
        if (l == null) { l = new ArrayList<>(); lines.put(id, l); }
        l.addAll(fresh);
        // в уведомлении — только то, что ещё не прочитано (прочитанное на телефоне убираем)
        long seen = prefs(this).getLong("seen_" + id, 0);
        long dayAgo = System.currentTimeMillis() - 24L * 3600 * 1000;
        for (int i = l.size() - 1; i >= 0; i--) {
            Object[] o = l.get(i);
            if ((o.length > 3 && (Long) o[3] <= seen) || (Long) o[2] < dayAgo) l.remove(i);
        }
        if (l.isEmpty()) return;
        while (l.size() > 8) l.remove(0);
        int total = 0;
        for (Object[] o : l) total++;
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_MSG)
                .setSmallIcon(R.drawable.ic_stat)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(openApp(id))
                .setDeleteIntent(dismissIntent(id))
                .setWhen((Long) l.get(l.size() - 1)[2])
                .setShowWhen(true)
                .setNumber(total);
        if (withText) {
            Person me = new Person.Builder().setName("Вы").build();
            NotificationCompat.MessagingStyle st = new NotificationCompat.MessagingStyle(me);
            if (group) { st.setConversationTitle(title); st.setGroupConversation(true); }
            for (Object[] o : l) {
                String who = (String) o[0];
                if (who.isEmpty()) who = group ? "Участник" : title;
                st.addMessage((String) o[1], (Long) o[2], new Person.Builder().setName(who).build());
            }
            Object[] lastLine = l.get(l.size() - 1);
            b.setStyle(st).setContentTitle(title).setContentText((group ? lastLine[0] + ": " : "") + lastLine[1]);
        } else {
            b.setContentTitle(title).setContentText(total == 1 ? "Новое сообщение" : total + " " + plural(total));
        }
        try {
            getSystemService(NotificationManager.class).notify(notifId(id), b.build());
        } catch (SecurityException ignored) {
        }
    }

    // ---------- старый режим: один чат, без ключа ----------
    private boolean legacyOnce(SharedPreferences p) throws Exception {
        String url = p.getString("url", ""), token = p.getString("token", ""), dev = p.getString("dev", "");
        if (url.isEmpty() || token.isEmpty()) {
            stopSelf();
            return false;
        }
        long pos = Math.max(p.getLong("pos", 0), p.getLong("seen", 0));
        if (pos == 0) {
            JSONObject r = get(url + "/api/messages?last=1&limit=1", token, 20000);
            long last = r.optLong("last", 0);
            if (last > 0) p.edit().putLong("pos", last).apply();
            else {
                JSONObject w = get(url + "/api/messages?after=0&wait=25&limit=50", token, 40000);
                handle(w, dev, p, 0);
            }
        } else {
            JSONObject r = get(url + "/api/messages?after=" + pos + "&wait=25&limit=100&sdev=" + dev + "&rs=" + ringShown, token, 40000);
            handle(r, dev, p, pos);
            handleRing(r);
        }
        return true;
    }

    private void handle(JSONObject r, String dev, SharedPreferences p, long pos) {
        JSONArray arr = r.optJSONArray("messages");
        if (arr == null) return;
        long max = pos;
        int fresh = 0;
        long seen = p.getLong("seen", 0);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.optJSONObject(i);
            if (m == null) continue;
            long id = m.optLong("id", 0);
            if (id > max) max = id;
            if (id > seen && !m.optBoolean("del", false) && !dev.equals(m.optString("dev"))) fresh++;
        }
        if (max > pos) p.edit().putLong("pos", max).apply();
        if (fresh > 0 && !MainActivity.inForeground) notifyNew(fresh);
    }

    private void handleRing(JSONObject r) {
        JSONObject ring = r.optJSONObject("ring");
        if (ring != null) {
            String id = ring.optString("id", "");
            if (!id.isEmpty() && !id.equals(ringShown)) {
                ringShown = id;
                ringRoom = "main";
                if (!MainActivity.inForeground) showCall(id, ring.optBoolean("video", false), "main", "");
            }
        } else if (!ringShown.isEmpty()) {
            ringShown = "";
            cancelCall(this);
        }
    }

    private PendingIntent callIntent(String id, String act, int code, String room) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("call_id", id);
        i.putExtra("call_act", act);
        i.putExtra("call_room", room);
        return PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void showCall(String id, boolean video, String room, String title) {
        String who = title;
        if (who == null || who.isEmpty()) who = prefs(this).getString("partner", "");
        Intent d = new Intent(this, CallActionReceiver.class).putExtra("call_id", id).putExtra("call_room", room);
        PendingIntent decline = PendingIntent.getBroadcast(this, 31, d, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_CALL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(video ? "Входящий видеозвонок" : "Входящий звонок")
                .setContentText(who.isEmpty() ? "Наш чат" : who)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setTimeoutAfter(45000)
                .setContentIntent(callIntent(id, "open", 32, room))
                .setFullScreenIntent(callIntent(id, "open", 33, room), true)
                .addAction(0, "Отклонить", decline)
                .addAction(0, "Принять", callIntent(id, "accept", 34, room));
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_CALL, n);
        } catch (SecurityException ignored) {
        }
    }

    /** «Отклонить» из уведомления: сообщаем серверу, приложение открывать не нужно. */
    static void declineRing(Context c, String id, String room) {
        SharedPreferences p = prefs(c);
        String url = p.getString("url", ""), token = p.getString("token", ""), dev = p.getString("dev", "");
        if (room != null && !room.isEmpty()) {
            JSONObject r = roomById(c, room);
            if (r != null) { url = r.optString("url", url); token = r.optString("token", token); dev = r.optString("dev", dev); }
        }
        if (url.isEmpty() || token.isEmpty() || dev.isEmpty()) return;
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url + "/api/ring").openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setRequestProperty("Content-Type", "application/json");
            JSONObject b = new JSONObject();
            b.put("dev", dev);
            b.put("id", id);
            b.put("act", "decline");
            conn.getOutputStream().write(b.toString().getBytes("UTF-8"));
            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception ignored) {
        }
    }

    private void notifyNew(int count) {
        unread += count;
        String text = unread == 1 ? "Новое сообщение" : unread + " " + plural(unread);
        Notification n = new NotificationCompat.Builder(this, CH_MSG)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Наш чат")
                .setContentText(text)
                .setNumber(unread)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(openApp(null))
                .build();
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_MESSAGE, n);
        } catch (SecurityException ignored) {
        }
    }

    private static String plural(int n) {
        int a = n % 10, b = n % 100;
        if (a == 1 && b != 11) return "новое сообщение";
        if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return "новых сообщения";
        return "новых сообщений";
    }

    private static class UnauthorizedException extends Exception {
    }

    private static class OldServerException extends Exception {
    }

    private long oldServerUntil = 0;

    private String readAll(HttpURLConnection c) throws Exception {
        InputStream in = c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private JSONObject get(String u, String token, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(readTimeout);
            c.setRequestProperty("Authorization", "Bearer " + token);
            int code = c.getResponseCode();
            if (code == 401) throw new UnauthorizedException();
            if (code != 200) throw new Exception("HTTP " + code);
            String s = readAll(c);
            if (MainActivity.inForeground) unread = 0;
            return new JSONObject(s);
        } finally {
            c.disconnect();
        }
    }

    private JSONObject post(String u, JSONObject body, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(readTimeout);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.getOutputStream().write(body.toString().getBytes(StandardCharsets.UTF_8));
            int code = c.getResponseCode();
            if (code == 401) throw new UnauthorizedException();
            if (code == 404) throw new OldServerException();
            if (code != 200) throw new Exception("HTTP " + code);
            return new JSONObject(readAll(c));
        } finally {
            c.disconnect();
        }
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
