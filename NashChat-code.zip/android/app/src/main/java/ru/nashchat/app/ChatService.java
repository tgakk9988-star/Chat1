package ru.nashchat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Фоновая служба: держит соединение с сервером и показывает уведомление,
 * когда приходит новое сообщение. Содержимое сообщений ей недоступно —
 * у неё нет ключа шифрования, только пропуск на сервер.
 */
public class ChatService extends Service {

    static final int NOTIF_SERVICE = 1, NOTIF_MESSAGE = 2, NOTIF_CALL = 3;
    private static final String CH_MSG = "messages", CH_SVC = "service", CH_CALL = "calls";
    static final String ACT_CALL_ON = "ru.nashchat.CALL_ON", ACT_CALL_OFF = "ru.nashchat.CALL_OFF";
    static volatile String ringShown = "";
    static volatile boolean callMode = false;

    private volatile boolean running = false;
    private Thread worker;
    private int unread = 0;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("chat", Context.MODE_PRIVATE);
    }

    static boolean isConfigured(Context c) {
        SharedPreferences p = prefs(c);
        return !p.getString("url", "").isEmpty() && !p.getString("token", "").isEmpty();
    }

    static void start(Context c) {
        if (!isConfigured(c)) return;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, ChatService.class));
        } catch (Exception ignored) {
        }
    }

    /** Во время звонка служба получает право на микрофон, чтобы звук не пропадал, если свернуть приложение. */
    static void setCallMode(Context c, boolean on) {
        if (!isConfigured(c)) return;
        try {
            Intent i = new Intent(c, ChatService.class).setAction(on ? ACT_CALL_ON : ACT_CALL_OFF);
            ContextCompat.startForegroundService(c, i);
        } catch (Exception ignored) {
        }
    }

    static void cancelCall(Context c) {
        try {
            c.getSystemService(NotificationManager.class).cancel(NOTIF_CALL);
        } catch (Exception ignored) {
        }
    }

    static synchronized void markSeen(Context c, long id) {
        SharedPreferences p = prefs(c);
        if (id > p.getLong("seen", 0)) p.edit().putLong("seen", id).apply();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel msg = new NotificationChannel(CH_MSG, "Новые сообщения", NotificationManager.IMPORTANCE_HIGH);
        msg.enableVibration(true);
        msg.setShowBadge(true);
        nm.createNotificationChannel(msg);
        NotificationChannel svc = new NotificationChannel(CH_SVC, "Работа в фоне", NotificationManager.IMPORTANCE_MIN);
        svc.setDescription("Это уведомление можно скрыть в настройках — чат продолжит работать");
        svc.setShowBadge(false);
        nm.createNotificationChannel(svc);
        NotificationChannel call = new NotificationChannel(CH_CALL, "Входящие звонки", NotificationManager.IMPORTANCE_HIGH);
        Uri tone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        call.setSound(tone, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        call.enableVibration(true);
        call.setVibrationPattern(new long[]{0, 800, 600, 800, 600});
        call.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        call.setBypassDnd(false);
        nm.createNotificationChannel(call);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACT_CALL_ON.equals(act)) callMode = true;
        else if (ACT_CALL_OFF.equals(act)) callMode = false;
        Notification n = new NotificationCompat.Builder(this, CH_SVC)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Наш чат")
                .setContentText(callMode ? "Идёт звонок" : "Ожидаю новые сообщения")
                .setPriority(callMode ? NotificationCompat.PRIORITY_DEFAULT : NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .setContentIntent(openApp())
                .build();
        boolean started = false;
        if (callMode) {
            try {
                int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                if (Build.VERSION.SDK_INT >= 34) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
                startForeground(NOTIF_SERVICE, n, type);
                started = true;
            } catch (Exception e) {
                callMode = false;
            }
        }
        if (!started) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(NOTIF_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                } else {
                    startForeground(NOTIF_SERVICE, n);
                }
            } catch (Exception e) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        if (!running) {
            running = true;
            worker = new Thread(this::loop, "chat-poll");
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void loop() {
        long backoff = 2000;
        while (running) {
            SharedPreferences p = prefs(this);
            String url = p.getString("url", ""), token = p.getString("token", ""), dev = p.getString("dev", "");
            if (url.isEmpty() || token.isEmpty()) {
                stopSelf();
                return;
            }
            try {
                long pos = Math.max(p.getLong("pos", 0), p.getLong("seen", 0));
                if (pos == 0) {
                    // первый запуск: узнаём, где конец переписки, не показывая старое
                    JSONObject r = get(url + "/api/messages?last=1&limit=1", token, 20000);
                    long last = r.optLong("last", 0);
                    if (last > 0) {
                        p.edit().putLong("pos", last).apply();
                    } else {
                        // пустой чат — ждём первое сообщение
                        JSONObject w = get(url + "/api/messages?after=0&wait=25&limit=50", token, 40000);
                        handle(w, dev, p, 0);
                    }
                } else {
                    JSONObject r = get(url + "/api/messages?after=" + pos + "&wait=25&limit=100&sdev=" + dev + "&rs=" + ringShown, token, 40000);
                    handle(r, dev, p, pos);
                    handleRing(r);
                }
                backoff = 2000;
            } catch (UnauthorizedException e) {
                sleep(5 * 60 * 1000);
            } catch (Exception e) {
                sleep(backoff);
                backoff = Math.min(backoff * 2, 60000);
            }
        }
    }

    private void handle(JSONObject r, String dev, SharedPreferences p, long pos) {
        JSONArray arr = r.optJSONArray("messages");
        if (arr == null) return;
        long max = pos;
        int fresh = 0;
        long seen = p.getLong("seen", 0);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.optJSONObject(i);
            if (m == null) continue;
            long id = m.optLong("id", 0);
            if (id > max) max = id;
            if (id > seen && !m.optBoolean("del", false) && !dev.equals(m.optString("dev"))) fresh++;
        }
        if (max > pos) p.edit().putLong("pos", max).apply();
        if (fresh > 0 && !MainActivity.inForeground) notifyNew(fresh);
    }

    private void handleRing(JSONObject r) {
        JSONObject ring = r.optJSONObject("ring");
        if (ring != null) {
            String id = ring.optString("id", "");
            if (!id.isEmpty() && !id.equals(ringShown)) {
                ringShown = id;
                if (!MainActivity.inForeground) showCall(id, ring.optBoolean("video", false));
            }
        } else if (!ringShown.isEmpty()) {
            ringShown = "";
            cancelCall(this);
        }
    }

    private PendingIntent callIntent(String id, String act, int code) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("call_id", id);
        i.putExtra("call_act", act);
        return PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void showCall(String id, boolean video) {
        String who = prefs(this).getString("partner", "");
        Intent d = new Intent(this, CallActionReceiver.class).putExtra("call_id", id);
        PendingIntent decline = PendingIntent.getBroadcast(this, 31, d, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_CALL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(video ? "Входящий видеозвонок" : "Входящий звонок")
                .setContentText(who.isEmpty() ? "Наш чат" : who)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setTimeoutAfter(45000)
                .setContentIntent(callIntent(id, "open", 32))
                .setFullScreenIntent(callIntent(id, "open", 33), true)
                .addAction(0, "Отклонить", decline)
                .addAction(0, "Принять", callIntent(id, "accept", 34));
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_CALL, n);
        } catch (SecurityException ignored) {
        }
    }

    /** «Отклонить» из уведомления: сообщаем серверу, приложение открывать не нужно. */
    static void declineRing(Context c, String id) {
        SharedPreferences p = prefs(c);
        String url = p.getString("url", ""), token = p.getString("token", ""), dev = p.getString("dev", "");
        if (url.isEmpty() || token.isEmpty() || dev.isEmpty()) return;
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url + "/api/ring").openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setRequestProperty("Content-Type", "application/json");
            JSONObject b = new JSONObject();
            b.put("dev", dev);
            b.put("id", id);
            b.put("act", "decline");
            conn.getOutputStream().write(b.toString().getBytes("UTF-8"));
            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception ignored) {
        }
    }

    private void notifyNew(int count) {
        unread += count;
        String text = unread == 1 ? "Новое сообщение" : unread + " " + plural(unread);
        Notification n = new NotificationCompat.Builder(this, CH_MSG)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Наш чат")
                .setContentText(text)
                .setNumber(unread)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(openApp())
                .setDeleteIntent(null)
                .build();
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_MESSAGE, n);
        } catch (SecurityException ignored) {
        }
    }

    private static String plural(int n) {
        int a = n % 10, b = n % 100;
        if (a == 1 && b != 11) return "новое сообщение";
        if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return "новых сообщения";
        return "новых сообщений";
    }

    private static class UnauthorizedException extends Exception {
    }

    private JSONObject get(String u, String token, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(readTimeout);
            c.setRequestProperty("Authorization", "Bearer " + token);
            int code = c.getResponseCode();
            if (code == 401) throw new UnauthorizedException();
            if (code != 200) throw new Exception("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            if (MainActivity.inForeground) unread = 0;
            return new JSONObject(bo.toString("UTF-8"));
        } finally {
            c.disconnect();
        }
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
