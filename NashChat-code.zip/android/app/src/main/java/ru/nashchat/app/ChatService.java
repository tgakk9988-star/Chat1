package ru.nashchat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Фоновая служба: держит соединение с сервером и показывает уведомление,
 * когда приходит новое сообщение. Содержимое сообщений ей недоступно —
 * у неё нет ключа шифрования, только пропуск на сервер.
 */
public class ChatService extends Service {

    static final int NOTIF_SERVICE = 1, NOTIF_MESSAGE = 2;
    private static final String CH_MSG = "messages", CH_SVC = "service";

    private volatile boolean running = false;
    private Thread worker;
    private int unread = 0;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("chat", Context.MODE_PRIVATE);
    }

    static boolean isConfigured(Context c) {
        SharedPreferences p = prefs(c);
        return !p.getString("url", "").isEmpty() && !p.getString("token", "").isEmpty();
    }

    static void start(Context c) {
        if (!isConfigured(c)) return;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, ChatService.class));
        } catch (Exception ignored) {
        }
    }

    static synchronized void markSeen(Context c, long id) {
        SharedPreferences p = prefs(c);
        if (id > p.getLong("seen", 0)) p.edit().putLong("seen", id).apply();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel msg = new NotificationChannel(CH_MSG, "Новые сообщения", NotificationManager.IMPORTANCE_HIGH);
        msg.enableVibration(true);
        msg.setShowBadge(true);
        nm.createNotificationChannel(msg);
        NotificationChannel svc = new NotificationChannel(CH_SVC, "Работа в фоне", NotificationManager.IMPORTANCE_MIN);
        svc.setDescription("Это уведомление можно скрыть в настройках — чат продолжит работать");
        svc.setShowBadge(false);
        nm.createNotificationChannel(svc);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = new NotificationCompat.Builder(this, CH_SVC)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Наш чат")
                .setContentText("Ожидаю новые сообщения")
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .setContentIntent(openApp())
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIF_SERVICE, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            worker = new Thread(this::loop, "chat-poll");
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void loop() {
        long backoff = 2000;
        while (running) {
            SharedPreferences p = prefs(this);
            String url = p.getString("url", ""), token = p.getString("token", ""), dev = p.getString("dev", "");
            if (url.isEmpty() || token.isEmpty()) {
                stopSelf();
                return;
            }
            try {
                long pos = Math.max(p.getLong("pos", 0), p.getLong("seen", 0));
                if (pos == 0) {
                    // первый запуск: узнаём, где конец переписки, не показывая старое
                    JSONObject r = get(url + "/api/messages?last=1&limit=1", token, 20000);
                    long last = r.optLong("last", 0);
                    if (last > 0) {
                        p.edit().putLong("pos", last).apply();
                    } else {
                        // пустой чат — ждём первое сообщение
                        JSONObject w = get(url + "/api/messages?after=0&wait=25&limit=50", token, 40000);
                        handle(w, dev, p, 0);
                    }
                } else {
                    JSONObject r = get(url + "/api/messages?after=" + pos + "&wait=25&limit=100", token, 40000);
                    handle(r, dev, p, pos);
                }
                backoff = 2000;
            } catch (UnauthorizedException e) {
                sleep(5 * 60 * 1000);
            } catch (Exception e) {
                sleep(backoff);
                backoff = Math.min(backoff * 2, 60000);
            }
        }
    }

    private void handle(JSONObject r, String dev, SharedPreferences p, long pos) {
        JSONArray arr = r.optJSONArray("messages");
        if (arr == null) return;
        long max = pos;
        int fresh = 0;
        long seen = p.getLong("seen", 0);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.optJSONObject(i);
            if (m == null) continue;
            long id = m.optLong("id", 0);
            if (id > max) max = id;
            if (id > seen && !m.optBoolean("del", false) && !dev.equals(m.optString("dev"))) fresh++;
        }
        if (max > pos) p.edit().putLong("pos", max).apply();
        if (fresh > 0 && !MainActivity.inForeground) notifyNew(fresh);
    }

    private void notifyNew(int count) {
        unread += count;
        String text = unread == 1 ? "Новое сообщение" : unread + " " + plural(unread);
        Notification n = new NotificationCompat.Builder(this, CH_MSG)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Наш чат")
                .setContentText(text)
                .setNumber(unread)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(openApp())
                .setDeleteIntent(null)
                .build();
        try {
            getSystemService(NotificationManager.class).notify(NOTIF_MESSAGE, n);
        } catch (SecurityException ignored) {
        }
    }

    private static String plural(int n) {
        int a = n % 10, b = n % 100;
        if (a == 1 && b != 11) return "новое сообщение";
        if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return "новых сообщения";
        return "новых сообщений";
    }

    private static class UnauthorizedException extends Exception {
    }

    private JSONObject get(String u, String token, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(readTimeout);
            c.setRequestProperty("Authorization", "Bearer " + token);
            int code = c.getResponseCode();
            if (code == 401) throw new UnauthorizedException();
            if (code != 200) throw new Exception("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            if (MainActivity.inForeground) unread = 0;
            return new JSONObject(bo.toString("UTF-8"));
        } finally {
            c.disconnect();
        }
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
