'use strict';
/* «Наш чат» — редактор фото: обрезка и поворот, размер, рисование, размытие, стикеры, текст, фильтры.
   Всё делается на телефоне; на сервер уходит только готовая (зашифрованная) картинка. */

const PE_COLORS = ['#ffffff', '#111111', '#ff3b30', '#ff9500', '#ffcc00', '#34c759', '#32ade6', '#5856d6', '#ff2d92'];
const PE_FILTERS = [
  { id: 'none', t: 'Оригинал', f: '' },
  { id: 'bright', t: 'Ярче', f: 'brightness(1.15) contrast(1.05)' },
  { id: 'warm', t: 'Тепло', f: 'sepia(.25) saturate(1.25) brightness(1.05)' },
  { id: 'cold', t: 'Холод', f: 'saturate(1.1) hue-rotate(-12deg) brightness(1.03)' },
  { id: 'bw', t: 'Ч/Б', f: 'grayscale(1) contrast(1.1)' },
  { id: 'vintage', t: 'Винтаж', f: 'sepia(.45) contrast(.95) saturate(.85) brightness(1.05)' },
  { id: 'vivid', t: 'Сочно', f: 'saturate(1.6) contrast(1.1)' },
  { id: 'soft', t: 'Мягко', f: 'brightness(1.08) contrast(.88) saturate(1.05)' },
  { id: 'drama', t: 'Драма', f: 'contrast(1.35) saturate(.9) brightness(.95)' },
];

const PE = {
  open_: false, src: null, ori: null, W0: 0, H0: 0, st: null, hist: [], tool: '', sel: -1, onDone: null,
  color: '#ff3b30', size: 0.012, blurSize: 0.05, aspect: 0,
  // ---------- запуск ----------
  async open(blob, onDone, sendLabel) {
    const img = await loadImage(blob);
    const W = img.naturalWidth || img.width, H = img.naturalHeight || img.height;
    const k = Math.min(1, 2560 / Math.max(W, H));
    const c = document.createElement('canvas'); c.width = Math.round(W * k); c.height = Math.round(H * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    this.src = c; this.onDone = onDone;
    this.st = { rot: 0, flip: false, crop: { x: 0, y: 0, w: 1, h: 1 }, filter: 'none', adj: { b: 0, c: 0, s: 0 }, scale: 1, strokes: [], objs: [] };
    this.hist = []; this.sel = -1; this.tool = '';
    this.orient();
    $('#pe-send').textContent = sendLabel || 'Отправить';
    $('#pedit').classList.remove('hidden'); this.open_ = true;
    Panel.close(); try { ta.blur(); } catch (_) { }
    this.setTool('');
    requestAnimationFrame(() => this.fit());
  },
  close() { this.open_ = false; $('#pedit').classList.add('hidden'); this.src = this.ori = null; $('#pe-stk').classList.add('hidden'); },
  // повёрнутая/отражённая копия исходника
  orient() {
    const s = this.src, r = this.st.rot % 360, swap = r === 90 || r === 270;
    const c = document.createElement('canvas'); c.width = swap ? s.height : s.width; c.height = swap ? s.width : s.height;
    const g = c.getContext('2d');
    g.translate(c.width / 2, c.height / 2); if (this.st.flip) g.scale(-1, 1); g.rotate(r * Math.PI / 180);
    g.drawImage(s, -s.width / 2, -s.height / 2);
    this.ori = c; this.W0 = c.width; this.H0 = c.height;
  },
  snap() { this.hist.push(JSON.stringify(this.st, (k, v) => (k === 'img' ? undefined : v))); this.imgs = this.imgs || new Map(); if (this.hist.length > 40) this.hist.shift(); this.drawUndo(); },
  undo() {
    const j = this.hist.pop(); if (!j) return;
    const prev = this.st, st = JSON.parse(j);
    st.objs.forEach((o, i) => { const same = prev.objs.find(p => p.uid === o.uid); if (same) o.img = same.img; else if (o.src) this.loadObjImg(o); });
    const reorient = prev.rot !== st.rot || prev.flip !== st.flip;
    this.st = st; if (reorient) this.orient();
    this.sel = -1; this.drawUndo(); this.drawOpts(); this.fit();
  },
  drawUndo() { $('#pe-undo').classList.toggle('off', !this.hist.length); },
  // ---------- инструменты ----------
  setTool(t) {
    if (this.tool === 'crop' && t !== 'crop') this.fitMode = 'out';
    this.tool = this.tool === t ? '' : t; this.sel = -1;
    document.querySelectorAll('#pe-tools [data-t]').forEach(b => b.classList.toggle('on', b.dataset.t === this.tool));
    if (this.tool === 'sticker') this.pickSticker();
    if (this.tool === 'text') { this.addText(); }
    this.drawOpts(); this.fit();
  },
  drawOpts() {
    const o = $('#pe-opts'), t = this.tool;
    let h = '';
    if (t === 'crop') {
      h = `<div class="pe-row">${[[0, 'Свободно'], [1, '1:1'], [4 / 3, '4:3'], [3 / 4, '3:4'], [16 / 9, '16:9']].map(([v, l]) => `<button data-asp="${v}" class="${this.aspect === v ? 'on' : ''}">${l}</button>`).join('')}</div>
        <div class="pe-row"><button data-op="rot">⟳ Повернуть</button><button data-op="flip">⇋ Отразить</button><button data-op="reset">Сброс</button></div>
        <div class="pe-row"><span class="pe-l">Размер:</span>${[[1, '100%'], [0.75, '75%'], [0.5, '50%'], [0.3, '30%']].map(([v, l]) => `<button data-scale="${v}" class="${this.st.scale === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    } else if (t === 'draw') {
      h = `<div class="pe-row pe-cols">${PE_COLORS.map(c => `<button data-col="${c}" class="pe-col ${this.color === c ? 'on' : ''}" style="background:${c}"></button>`).join('')}</div>
        <div class="pe-row"><span class="pe-l">Толщина</span><input type="range" id="pe-size" min="3" max="60" value="${Math.round(this.size * 1000)}"></div>`;
    } else if (t === 'blur') {
      h = `<div class="pe-row"><span class="pe-l">Кисть размытия</span><input type="range" id="pe-bsize" min="15" max="150" value="${Math.round(this.blurSize * 1000)}"></div><div class="pe-hint">Проведите пальцем по месту, которое нужно скрыть</div>`;
    } else if (t === 'filter') {
      h = `<div class="pe-row pe-filters">${PE_FILTERS.map(f => `<button data-flt="${f.id}" class="${this.st.filter === f.id ? 'on' : ''}">${f.t}</button>`).join('')}</div>
        <div class="pe-row"><span class="pe-l">Яркость</span><input type="range" data-adj="b" min="-50" max="50" value="${this.st.adj.b}"></div>
        <div class="pe-row"><span class="pe-l">Контраст</span><input type="range" data-adj="c" min="-50" max="50" value="${this.st.adj.c}"></div>
        <div class="pe-row"><span class="pe-l">Насыщенность</span><input type="range" data-adj="s" min="-100" max="100" value="${this.st.adj.s}"></div>`;
    } else if (this.sel >= 0) {
      const ob = this.st.objs[this.sel];
      h = `<div class="pe-row">${ob.type === 'text' ? '<button data-op="tedit">✏️ Изменить текст</button>' : ''}<button data-op="front">⬆ Вперёд</button><button data-op="del" class="pe-del">🗑 Удалить</button></div><div class="pe-hint">Двигайте пальцем, двумя пальцами — размер и поворот</div>`;
    } else h = `<div class="pe-hint">Выберите инструмент внизу. Наклейки и текст можно двигать, двумя пальцами — увеличивать и поворачивать</div>`;
    o.innerHTML = h;
  },
  filterStr() {
    const f = (PE_FILTERS.find(x => x.id === this.st.filter) || PE_FILTERS[0]).f, a = this.st.adj;
    const extra = `brightness(${1 + a.b / 100}) contrast(${1 + a.c / 100}) saturate(${1 + a.s / 100})`;
    return ((f || '') + ' ' + (a.b || a.c || a.s ? extra : '')).trim() || 'none';
  },
  // ---------- отрисовка ----------
  // рисуем область обрезки в холст out (w×h)
  render(out, opts = {}) {
    const g = out.getContext('2d'), st = this.st, W0 = this.W0, H0 = this.H0;
    const cr = opts.full ? { x: 0, y: 0, w: 1, h: 1 } : st.crop;
    const k = out.width / (cr.w * W0);
    const toPx = () => g.setTransform(k, 0, 0, k, -cr.x * W0 * k, -cr.y * H0 * k);
    g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, out.width, out.height);
    toPx(); g.filter = this.filterStr(); g.drawImage(this.ori, 0, 0); g.filter = 'none';
    // размытие: размытая копия только там, где провели кистью
    const blurs = st.strokes.filter(s => s.k === 'blur');
    if (blurs.length) {
      const b = document.createElement('canvas'); b.width = out.width; b.height = out.height;
      const bg = b.getContext('2d');
      bg.filter = `blur(${Math.max(4, out.width * 0.018)}px)`; bg.drawImage(out, 0, 0); bg.filter = 'none';
      const m = document.createElement('canvas'); m.width = out.width; m.height = out.height;
      const mg = m.getContext('2d'); mg.setTransform(k, 0, 0, k, -cr.x * W0 * k, -cr.y * H0 * k);
      for (const s of blurs) this.path(mg, s, '#fff');
      bg.globalCompositeOperation = 'destination-in'; bg.setTransform(1, 0, 0, 1, 0, 0); bg.drawImage(m, 0, 0);
      g.setTransform(1, 0, 0, 1, 0, 0); g.drawImage(b, 0, 0); toPx();
    }
    for (const s of st.strokes) if (s.k === 'draw') this.path(g, s, s.c);
    st.objs.forEach((o, i) => this.drawObj(g, o, !opts.clean && i === this.sel));
    g.setTransform(1, 0, 0, 1, 0, 0);
  },
  path(g, s, color) {
    const W0 = this.W0, H0 = this.H0, p = s.p;
    g.strokeStyle = color; g.fillStyle = color; g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = s.w * W0;
    if (p.length === 1) { g.beginPath(); g.arc(p[0][0] * W0, p[0][1] * H0, s.w * W0 / 2, 0, Math.PI * 2); g.fill(); return; }
    g.beginPath(); g.moveTo(p[0][0] * W0, p[0][1] * H0);
    for (let i = 1; i < p.length - 1; i++) { const mx = (p[i][0] + p[i + 1][0]) / 2 * W0, my = (p[i][1] + p[i + 1][1]) / 2 * H0; g.quadraticCurveTo(p[i][0] * W0, p[i][1] * H0, mx, my); }
    const l = p[p.length - 1]; g.lineTo(l[0] * W0, l[1] * H0); g.stroke();
  },
  objSize(o) { // ширина и высота объекта в пикселях исходника
    const W0 = this.W0, w = o.s * W0;
    if (o.type === 'text') { const lines = o.text.split('\n'); return { w, h: w * 0.62 * lines.length / Math.max(1, Math.max(...lines.map(l => l.length)) * 0.55) }; }
    const r = o.img && o.img.width ? o.img.height / o.img.width : 1; return { w, h: w * r };
  },
  drawObj(g, o, selected) {
    const W0 = this.W0, H0 = this.H0;
    g.save(); g.translate(o.x * W0, o.y * H0); g.rotate(o.r || 0);
    let bw, bh;
    if (o.type === 'emoji') {
      const fs = o.s * W0 * 0.9;
      g.font = `${fs}px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(o.e, 0, fs * 0.06); bw = bh = o.s * W0;
    } else if (o.type === 'img') {
      const { w, h } = this.objSize(o); if (o.img && o.img.width) g.drawImage(o.img, -w / 2, -h / 2, w, h); bw = w; bh = h;
    } else {
      const lines = o.text.split('\n'), longest = Math.max(...lines.map(l => l.length), 1);
      const fs = o.s * W0 / (longest * 0.56); g.font = `800 ${fs}px "Nunito","Segoe UI",system-ui,sans-serif`;
      g.textAlign = 'center'; g.textBaseline = 'middle';
      const lh = fs * 1.18, widths = lines.map(l => g.measureText(l).width), mw = Math.max(...widths, 10);
      bw = mw + fs * 0.7; bh = lh * lines.length + fs * 0.4;
      if (o.bg) { g.fillStyle = o.c === '#ffffff' ? 'rgba(0,0,0,.6)' : '#ffffff'; this.rr(g, -bw / 2, -bh / 2, bw, bh, fs * 0.35); g.fill(); }
      g.fillStyle = o.c; if (!o.bg) { g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = fs * 0.12; }
      lines.forEach((l, i) => g.fillText(l, 0, (i - (lines.length - 1) / 2) * lh));
      g.shadowBlur = 0;
    }
    o._bw = bw; o._bh = bh;
    if (selected) { g.setLineDash([W0 * 0.012, W0 * 0.008]); g.lineWidth = Math.max(2, W0 * 0.003); g.strokeStyle = '#fff'; g.strokeRect(-bw / 2 - 6, -bh / 2 - 6, bw + 12, bh + 12); g.setLineDash([]); }
    g.restore();
  },
  rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); },
  // вписываем картинку в экран
  fit() {
    if (!this.open_) return;
    const area = $('#pe-area'), cv = $('#pe-cv'), dpr = Math.min(2, window.devicePixelRatio || 1);
    const full = this.tool === 'crop', cr = full ? { x: 0, y: 0, w: 1, h: 1 } : this.st.crop;
    const iw = cr.w * this.W0, ih = cr.h * this.H0, aw = area.clientWidth - 24, ah = area.clientHeight - 24;
    const k = Math.min(aw / iw, ah / ih);
    const w = Math.max(1, Math.round(iw * k)), h = Math.max(1, Math.round(ih * k));
    cv.style.width = w + 'px'; cv.style.height = h + 'px'; cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    this.view = { k: k, full, cr };
    this.redraw();
  },
  redraw() {
    if (!this.open_) return;
    const cv = $('#pe-cv');
    this.render(cv, { full: this.view.full });
    const box = $('#pe-crop');
    box.classList.toggle('hidden', !this.view.full);
    if (this.view.full) {
      const c = this.st.crop, r = cv.getBoundingClientRect(), a = $('#pe-area').getBoundingClientRect();
      Object.assign(box.style, { left: (r.left - a.left + c.x * r.width) + 'px', top: (r.top - a.top + c.y * r.height) + 'px', width: (c.w * r.width) + 'px', height: (c.h * r.height) + 'px' });
    }
  },
  // экранная точка → нормированные координаты исходника
  pt(e) {
    const r = $('#pe-cv').getBoundingClientRect(), cr = this.view.cr;
    return [cr.x + (e.clientX - r.left) / r.width * cr.w, cr.y + (e.clientY - r.top) / r.height * cr.h];
  },
  hit(p) {
    for (let i = this.st.objs.length - 1; i >= 0; i--) {
      const o = this.st.objs[i], W0 = this.W0, H0 = this.H0;
      const dx = (p[0] - o.x) * W0, dy = (p[1] - o.y) * H0, c = Math.cos(-(o.r || 0)), s = Math.sin(-(o.r || 0));
      const lx = dx * c - dy * s, ly = dx * s + dy * c, bw = (o._bw || o.s * W0) / 2 + 20, bh = (o._bh || o.s * W0) / 2 + 20;
      if (Math.abs(lx) <= bw && Math.abs(ly) <= bh) return i;
    }
    return -1;
  },
  // ---------- наклейки и текст ----------
  addObj(o) {
    this.snap();
    const cr = this.st.crop;
    o.uid = Math.random().toString(36).slice(2);
    o.x = cr.x + cr.w / 2; o.y = cr.y + cr.h / 2; o.r = 0; o.s = o.s || cr.w * 0.35;
    this.st.objs.push(o); this.sel = this.st.objs.length - 1;
    this.tool = ''; document.querySelectorAll('#pe-tools [data-t]').forEach(b => b.classList.remove('on'));
    this.drawOpts(); this.redraw();
  },
  loadObjImg(o) { const im = new Image(); im.onload = () => this.redraw(); im.src = o.src; o.img = im; },
  pickSticker() {
    const box = $('#pe-stk'); box.classList.remove('hidden');
    const emo = [].concat(...EMOJI.map(c => { const l = c.list || c[2]; return Array.isArray(l) ? l : (l ? String(l).split(' ') : []); })).filter(Boolean).slice(0, 240);
    const packs = STICKER_PACKS.filter(p => Kiss.owns(p.id));
    const mine = (typeof MyStk !== 'undefined' ? MyStk.list : []);
    box.innerHTML = `<div class="pe-stk-h"><b>Наклейки</b><button id="pe-stk-x">✕</button></div><div class="pe-stk-b">
      ${mine.length ? `<div class="ep-h">Мои стикеры</div><div class="pe-sg">${mine.map(r => `<button data-src="${MyStk.url(r)}"><img src="${MyStk.url(r)}"></button>`).join('')}</div>` : ''}
      ${packs.map(p => `<div class="ep-h">${esc(p.t)}</div><div class="pe-sg">${Array.from({ length: p.n }, (_, i) => `<button data-src="${stickerSrc(p.id, i + 1)}"><img src="${stickerSrc(p.id, i + 1)}" loading="lazy"></button>`).join('')}</div>`).join('')}
      <div class="ep-h">Смайлики</div><div class="pe-eg">${emo.map(e => `<button data-emo="${e}">${e}</button>`).join('')}</div></div>`;
    box.querySelector('#pe-stk-x').onclick = () => { box.classList.add('hidden'); this.setTool(''); };
    box.querySelector('.pe-stk-b').onclick = e => {
      const s = e.target.closest('[data-src]'), m = e.target.closest('[data-emo]');
      if (!s && !m) return;
      box.classList.add('hidden');
      if (m) this.addObj({ type: 'emoji', e: m.dataset.emo });
      else { const o = { type: 'img', src: s.dataset.src }; this.loadObjImg(o); this.addObj(o); }
      vibrate(8);
    };
  },
  addText(edit) {
    const ob = edit != null ? this.st.objs[edit] : null;
    Form.open({
      title: ob ? 'Изменить текст' : 'Текст на фото', saveLabel: 'Готово',
      values: { text: ob ? ob.text : '', c: ob ? ob.c : '#ffffff', bg: ob ? !!ob.bg : false },
      fields: [
        { k: 'text', label: 'Текст', type: 'textarea', ph: 'Напишите что-нибудь…' },
        { k: 'c', label: 'Цвет', type: 'chips', wrap: true, opts: PE_COLORS.map(c => ({ v: c, t: ({ '#ffffff': '⚪ Белый', '#111111': '⚫ Чёрный', '#ff3b30': '🔴 Красный', '#ff9500': '🟠 Оранжевый', '#ffcc00': '🟡 Жёлтый', '#34c759': '🟢 Зелёный', '#32ade6': '🔵 Голубой', '#5856d6': '🟣 Синий', '#ff2d92': '🩷 Розовый' })[c] })) },
        { k: 'bg', label: 'С подложкой', type: 'toggle' },
      ],
      onSave: v => {
        const t = String(v.text || '').trim(); if (!t) return 'Введите текст';
        if (ob) { this.snap(); ob.text = t; ob.c = v.c; ob.bg = !!v.bg; this.redraw(); }
        else this.addObj({ type: 'text', text: t, c: v.c, bg: !!v.bg, s: this.st.crop.w * 0.5 });
      },
    });
    if (!ob) { this.tool = ''; document.querySelectorAll('#pe-tools [data-t]').forEach(b => b.classList.remove('on')); }
  },
  // ---------- готово ----------
  async done() {
    const cr = this.st.crop, k = this.st.scale;
    let w = Math.round(cr.w * this.W0 * k), h = Math.round(cr.h * this.H0 * k);
    const m = Math.min(1, 2560 / Math.max(w, h)); w = Math.max(1, Math.round(w * m)); h = Math.max(1, Math.round(h * m));
    const out = document.createElement('canvas'); out.width = w; out.height = h;
    this.sel = -1; this.render(out, { clean: true });
    const blob = await new Promise(r => out.toBlob(r, 'image/jpeg', 0.92));
    const file = new File([blob], 'photo_' + stamp() + '.jpg', { type: 'image/jpeg' });
    const cb = this.onDone; this.close();
    cb && cb(file);
  },
};

/* ---------- кнопки и жесты ---------- */
$('#pe-cancel').onclick = () => { if (PE.hist.length) sheet([{ icon: 'trash', label: 'Не отправлять, выйти', danger: true, fn: () => PE.close() }], 'Изменения пропадут.'); else PE.close(); };
$('#pe-undo').onclick = () => PE.undo();
$('#pe-send').onclick = () => PE.done();
$('#pe-tools').onclick = e => { const b = e.target.closest('[data-t]'); if (b) PE.setTool(b.dataset.t); };
$('#pe-opts').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const st = PE.st;
  if (b.dataset.asp != null) {
    PE.aspect = +b.dataset.asp;
    if (PE.aspect) { PE.snap(); const c = st.crop, cx = c.x + c.w / 2, cy = c.y + c.h / 2; let w = c.w, h = w * PE.W0 / PE.aspect / PE.H0; if (h > 1) { h = 1; w = h * PE.H0 * PE.aspect / PE.W0; } if (w > 1) { w = 1; h = w * PE.W0 / PE.aspect / PE.H0; } st.crop = { x: Math.min(1 - w, Math.max(0, cx - w / 2)), y: Math.min(1 - h, Math.max(0, cy - h / 2)), w, h }; }
    PE.drawOpts(); PE.redraw(); return;
  }
  if (b.dataset.scale) { PE.snap(); st.scale = +b.dataset.scale; PE.drawOpts(); return; }
  if (b.dataset.col) { PE.color = b.dataset.col; PE.drawOpts(); return; }
  if (b.dataset.flt) { PE.snap(); st.filter = b.dataset.flt; PE.drawOpts(); PE.redraw(); return; }
  const op = b.dataset.op;
  if (op === 'rot' || op === 'flip') {
    PE.snap();
    // поворачиваем всё вместе с картинкой: рисунки, наклейки и рамку обрезки
    const tf = op === 'rot' ? (x, y) => [1 - y, x] : (x, y) => [1 - x, y];
    for (const s of st.strokes) s.p = s.p.map(([x, y]) => tf(x, y));
    const W0 = PE.W0, H0 = PE.H0;
    for (const o of st.objs) { [o.x, o.y] = tf(o.x, o.y); if (op === 'rot') { o.r = (o.r || 0) + Math.PI / 2; o.s = o.s * W0 / H0; } else o.r = -(o.r || 0); }
    for (const s of st.strokes) if (op === 'rot') s.w = s.w * W0 / H0;
    const c = st.crop;
    st.crop = op === 'rot' ? { x: 1 - c.y - c.h, y: c.x, w: c.h, h: c.w } : { x: 1 - c.x - c.w, y: c.y, w: c.w, h: c.h };
    // у отражённой картинки поворот «по часовой» на экране — это обратный поворот исходника
    if (op === 'rot') st.rot = (st.rot + (st.flip ? 270 : 90)) % 360; else st.flip = !st.flip;
    PE.orient(); PE.fit(); return;
  }
  if (op === 'reset') { PE.snap(); st.crop = { x: 0, y: 0, w: 1, h: 1 }; PE.aspect = 0; PE.drawOpts(); PE.redraw(); return; }
  if (op === 'del' && PE.sel >= 0) { PE.snap(); st.objs.splice(PE.sel, 1); PE.sel = -1; PE.drawOpts(); PE.redraw(); return; }
  if (op === 'front' && PE.sel >= 0) { PE.snap(); const [o] = st.objs.splice(PE.sel, 1); st.objs.push(o); PE.sel = st.objs.length - 1; PE.redraw(); return; }
  if (op === 'tedit' && PE.sel >= 0) { PE.addText(PE.sel); return; }
});
$('#pe-opts').addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'pe-size') PE.size = +t.value / 1000;
  else if (t.id === 'pe-bsize') PE.blurSize = +t.value / 1000;
  else if (t.dataset.adj) { if (!PE.adjSnap) { PE.snap(); PE.adjSnap = true; } PE.st.adj[t.dataset.adj] = +t.value; PE.redraw(); }
});
$('#pe-opts').addEventListener('change', () => { PE.adjSnap = false; });

// рисование, размытие, перемещение наклеек
(() => {
  const area = $('#pe-area');
  let g = null;
  const touches = e => [...e.touches].map(t => ({ clientX: t.clientX, clientY: t.clientY }));
  area.addEventListener('touchstart', e => {
    if (!PE.open_ || e.target.closest('#pe-crop')) return;
    const t = touches(e);
    if (PE.tool === 'draw' || PE.tool === 'blur') {
      if (t.length > 1) { if (g && g.stroke) { PE.st.strokes.pop(); PE.hist.pop(); PE.drawUndo(); PE.redraw(); } g = null; return; }
      PE.snap();
      const s = { k: PE.tool, c: PE.color, w: PE.tool === 'draw' ? PE.size : PE.blurSize, p: [PE.pt(t[0])] };
      PE.st.strokes.push(s); g = { stroke: s }; PE.redraw(); return;
    }
    if (t.length === 2 && PE.sel >= 0) {
      const o = PE.st.objs[PE.sel], d = Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY), a = Math.atan2(t[1].clientY - t[0].clientY, t[1].clientX - t[0].clientX);
      g = { pinch: true, d, a, s: o.s, r: o.r || 0 }; return;
    }
    if (t.length === 1) {
      const p = PE.pt(t[0]), i = PE.hit(p);
      if (i >= 0) { PE.snap(); PE.sel = i; const o = PE.st.objs[i]; g = { move: true, p0: p, x: o.x, y: o.y, moved: false }; PE.drawOpts(); PE.redraw(); }
      else if (PE.sel >= 0) { PE.sel = -1; PE.drawOpts(); PE.redraw(); g = null; }
    }
  }, { passive: true });
  area.addEventListener('touchmove', e => {
    if (!g || !PE.open_) return;
    e.preventDefault();
    const t = touches(e);
    if (g.stroke && t.length === 1) { g.stroke.p.push(PE.pt(t[0])); PE.redraw(); return; }
    if (g.move && t.length === 1) { const p = PE.pt(t[0]), o = PE.st.objs[PE.sel]; o.x = g.x + p[0] - g.p0[0]; o.y = g.y + p[1] - g.p0[1]; g.moved = true; PE.redraw(); return; }
    if (t.length === 2 && PE.sel >= 0) {
      const o = PE.st.objs[PE.sel];
      if (!g.pinch) { g = { pinch: true, d: Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY), a: Math.atan2(t[1].clientY - t[0].clientY, t[1].clientX - t[0].clientX), s: o.s, r: o.r || 0 }; return; }
      const d = Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY), a = Math.atan2(t[1].clientY - t[0].clientY, t[1].clientX - t[0].clientX);
      o.s = Math.max(0.03, Math.min(3, g.s * d / g.d)); o.r = g.r + (a - g.a); PE.redraw();
    }
  }, { passive: false });
  area.addEventListener('touchend', e => {
    if (g && g.move && !g.moved) { PE.hist.pop(); PE.drawUndo(); }
    if (!e.touches.length) g = null;
  });
  // мышь (для проверки на компьютере)
  let mdown = null;
  area.addEventListener('mousedown', e => {
    if (!PE.open_ || e.target.closest('#pe-crop')) return;
    if (PE.tool === 'draw' || PE.tool === 'blur') { PE.snap(); const s = { k: PE.tool, c: PE.color, w: PE.tool === 'draw' ? PE.size : PE.blurSize, p: [PE.pt(e)] }; PE.st.strokes.push(s); mdown = { stroke: s }; PE.redraw(); return; }
    const p = PE.pt(e), i = PE.hit(p);
    if (i >= 0) { PE.snap(); PE.sel = i; const o = PE.st.objs[i]; mdown = { move: true, p0: p, x: o.x, y: o.y }; PE.drawOpts(); PE.redraw(); }
    else if (PE.sel >= 0) { PE.sel = -1; PE.drawOpts(); PE.redraw(); }
  });
  window.addEventListener('mousemove', e => {
    if (!mdown) return;
    if (mdown.stroke) { mdown.stroke.p.push(PE.pt(e)); PE.redraw(); }
    else if (mdown.move) { const p = PE.pt(e), o = PE.st.objs[PE.sel]; o.x = mdown.x + p[0] - mdown.p0[0]; o.y = mdown.y + p[1] - mdown.p0[1]; PE.redraw(); }
  });
  window.addEventListener('mouseup', () => { mdown = null; });
})();

// рамка обрезки: тянем углы или всю рамку
(() => {
  const box = $('#pe-crop'); let d = null;
  box.addEventListener('pointerdown', e => {
    e.preventDefault(); box.setPointerCapture(e.pointerId);
    const h = e.target.closest('[data-h]'); PE.snap();
    d = { h: h ? h.dataset.h : 'move', x: e.clientX, y: e.clientY, c: Object.assign({}, PE.st.crop) };
  });
  box.addEventListener('pointermove', e => {
    if (!d) return;
    const r = $('#pe-cv').getBoundingClientRect(), dx = (e.clientX - d.x) / r.width, dy = (e.clientY - d.y) / r.height, c0 = d.c, MIN = 0.06;
    let { x, y, w, h } = c0;
    if (d.h === 'move') { x = Math.max(0, Math.min(1 - w, x + dx)); y = Math.max(0, Math.min(1 - h, y + dy)); }
    else {
      if (d.h.includes('l')) { const nx = Math.max(0, Math.min(x + w - MIN, x + dx)); w += x - nx; x = nx; }
      if (d.h.includes('r')) w = Math.max(MIN, Math.min(1 - x, w + dx));
      if (d.h.includes('t')) { const ny = Math.max(0, Math.min(y + h - MIN, y + dy)); h += y - ny; y = ny; }
      if (d.h.includes('b')) h = Math.max(MIN, Math.min(1 - y, h + dy));
      if (PE.aspect) {
        const ar = PE.W0 / PE.aspect / PE.H0; // h = w * ar
        h = w * ar; if (d.h.includes('t')) y = c0.y + c0.h - h;
        if (y < 0) { y = 0; h = c0.y + c0.h; w = h / ar; }
        if (y + h > 1) { h = 1 - y; w = h / ar; }
        if (d.h.includes('l')) x = c0.x + c0.w - w;
      }
    }
    PE.st.crop = { x, y, w, h }; PE.redraw();
  });
  const up = () => { d = null; };
  box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
})();
window.addEventListener('resize', () => { if (PE.open_) PE.fit(); });

/* ---------- откуда открывается редактор ---------- */
// выбрали одно фото для отправки → сначала редактор
function editThenSend(file, mode) {
  PE.open(file, f => sendOneFile(f, mode === 'orig' ? 'orig' : 'media').catch(() => { })).catch(() => sendOneFile(file, mode));
}
// фото из переписки (своё или собеседника) → изменить и отправить новым сообщением
async function editFromMessage(m) {
  try {
    toast('Открываю фото…', 30000);
    const blob = await getMedia(m.p.file);
    $('#toast').classList.add('hidden');
    closeViewer();
    await PE.open(blob, f => sendOneFile(f, 'media').catch(() => { }));
  } catch (_) { toast('Не удалось открыть фото'); }
}
