'use strict';
/* «Наш чат» — починка записанных видео (кружков) перед сохранением в галерею.
   Запись с телефона идёт «кусочками» (фрагментированный MP4 или WebM без длительности):
   галерея не знает длину и не может перематывать. Здесь мы пересобираем файл в обычный вид —
   с полной длительностью и таблицей перемотки. Сами кадры и звук не перекодируются. */
const VidFix = {
  async fix(blob, durSec) {
    try {
      const u = new Uint8Array(await blob.arrayBuffer());
      let parts = null, type = blob.type;
      if (u[4] === 0x66 && u[5] === 0x74 && u[6] === 0x79 && u[7] === 0x70) { parts = this.mp4(u); type = 'video/mp4'; }
      else if (u[0] === 0x1A && u[1] === 0x45 && u[2] === 0xDF && u[3] === 0xA3) { parts = this.webm(u, durSec); type = 'video/webm'; }
      return parts ? new Blob(parts, { type }) : blob;
    } catch (e) { console.warn('vidfix', e); return blob; }
  },

  // ---------- MP4: фрагменты (moof+mdat) → обычный файл (moov с таблицами + один mdat) ----------
  mp4(u) {
    const r32 = o => (u[o] << 24 | u[o + 1] << 16 | u[o + 2] << 8 | u[o + 3]) >>> 0;
    const r64 = o => r32(o) * 4294967296 + r32(o + 4);
    const boxes = (s, e) => {
      const out = []; let o = s;
      while (o + 8 <= e) {
        let size = r32(o), h = 8;
        const type = String.fromCharCode(u[o + 4], u[o + 5], u[o + 6], u[o + 7]);
        if (size === 1) { size = r64(o + 8); h = 16; } else if (size === 0) size = e - o;
        if (size < h || o + size > e) break;
        out.push({ type, s: o, e: o + size, h }); o += size;
      }
      return out;
    };
    const kids = b => boxes(b.s + b.h, b.e), kid = (b, t) => kids(b).find(x => x.type === t);
    const top = boxes(0, u.length), moov = top.find(b => b.type === 'moov');
    if (!moov || !top.some(b => b.type === 'moof')) return null; // уже обычный файл
    const mvhd = kid(moov, 'mvhd'), movieTs = r32(mvhd.s + (u[mvhd.s + 8] === 1 ? 28 : 20));
    const trex = {}, mvex = kid(moov, 'mvex');
    if (mvex) for (const t of kids(mvex)) if (t.type === 'trex') trex[r32(t.s + 12)] = { dur: r32(t.s + 20), size: r32(t.s + 24), flags: r32(t.s + 28) };
    const tracks = {};
    for (const tk of kids(moov)) {
      if (tk.type !== 'trak') continue;
      const tkhd = kid(tk, 'tkhd'), id = r32(tkhd.s + (u[tkhd.s + 8] === 1 ? 28 : 20));
      const mdia = kid(tk, 'mdia'), mdhd = kid(mdia, 'mdhd'), hdlr = kid(mdia, 'hdlr');
      tracks[id] = { tk, ts: r32(mdhd.s + (u[mdhd.s + 8] === 1 ? 28 : 20)), vide: String.fromCharCode(u[hdlr.s + 16], u[hdlr.s + 17], u[hdlr.s + 18], u[hdlr.s + 19]) === 'vide', smp: [] };
    }
    // читаем все кусочки
    for (const moof of top) {
      if (moof.type !== 'moof') continue;
      for (const traf of kids(moof)) {
        if (traf.type !== 'traf') continue;
        const tfhd = kid(traf, 'tfhd'), ff = r32(tfhd.s + 8) & 0xffffff, tid = r32(tfhd.s + 12), T = tracks[tid], X = trex[tid] || { dur: 0, size: 0, flags: 0 };
        if (!T) continue;
        let p = tfhd.s + 16, base = moof.s;
        if (ff & 1) { base = r64(p); p += 8; }
        if (ff & 2) p += 4;
        let dDur = X.dur, dSize = X.size, dFlags = X.flags;
        if (ff & 8) { dDur = r32(p); p += 4; }
        if (ff & 0x10) { dSize = r32(p); p += 4; }
        if (ff & 0x20) { dFlags = r32(p); p += 4; }
        let cur = base;
        for (const tr of kids(traf)) {
          if (tr.type !== 'trun') continue;
          const v = u[tr.s + 8], tf = r32(tr.s + 8) & 0xffffff, n = r32(tr.s + 12);
          let q = tr.s + 16, first = null;
          if (tf & 1) { cur = base + (r32(q) | 0); q += 4; }
          if (tf & 4) { first = r32(q); q += 4; }
          for (let i = 0; i < n; i++) {
            const dur = tf & 0x100 ? r32((q += 4) - 4) : dDur;
            const size = tf & 0x200 ? r32((q += 4) - 4) : dSize;
            let fl = tf & 0x400 ? r32((q += 4) - 4) : dFlags;
            if (i === 0 && first !== null) fl = first;
            const cto = tf & 0x800 ? (v ? r32((q += 4) - 4) | 0 : r32((q += 4) - 4)) : 0;
            T.smp.push({ off: cur, size, dur, cto, sync: !((fl >>> 16) & 1) });
            cur += size;
          }
        }
      }
    }
    const list = Object.keys(tracks).map(k => tracks[k]).filter(t => t.smp.length);
    if (!list.length) return null;
    // последний кадр часто без длительности — берём как у соседнего
    for (const t of list) { const s = t.smp; if (s.length > 1 && !s[s.length - 1].dur) s[s.length - 1].dur = s[s.length - 2].dur; }
    // ---- запись ----
    const be = (n, bytes) => { const a = new Uint8Array(bytes); for (let i = bytes - 1; i >= 0; i--) { a[i] = n % 256; n = Math.floor(n / 256); } return a; };
    const cat = arr => { let L = 0; for (const a of arr) L += a.length; const o = new Uint8Array(L); let p = 0; for (const a of arr) { o.set(a, p); p += a.length; } return o; };
    const box = (type, ...parts) => { const body = cat(parts); return cat([be(body.length + 8, 4), new TextEncoder().encode(type), body]); };
    const full = (type, ver, flags, ...parts) => box(type, new Uint8Array([ver, flags >> 16 & 255, flags >> 8 & 255, flags & 255]), ...parts);
    const u32s = arr => { const o = new Uint8Array(arr.length * 4); let p = 0; for (const n of arr) { o[p++] = n >>> 24 & 255; o[p++] = n >>> 16 & 255; o[p++] = n >>> 8 & 255; o[p++] = n & 255; } return o; };
    const setDur = (copy, off, v1, val) => copy.set(v1 ? be(val, 8) : be(Math.min(val, 0xffffffff), 4), off);
    // новый порядок данных: как в исходном файле
    const all = []; for (const t of list) for (const s of t.smp) all.push(s);
    all.sort((a, b) => a.off - b.off);
    const ranges = []; let pos = 0;
    for (const s of all) {
      s.nOff = pos; pos += s.size;
      const last = ranges[ranges.length - 1];
      if (last && last.e === s.off) last.e += s.size; else ranges.push({ s: s.off, e: s.off + s.size });
    }
    const mdatLen = pos, big = mdatLen + 16 > 0xffffffff;
    let movieDur = 0;
    for (const t of list) { t.dur = t.smp.reduce((a, s) => a + s.dur, 0); movieDur = Math.max(movieDur, Math.round(t.dur / t.ts * movieTs)); }
    const stbl = (t, mdatStart) => {
      const S = t.smp, stts = [];
      for (const s of S) { const l = stts[stts.length - 1]; if (l && l[1] === s.dur) l[0]++; else stts.push([1, s.dur]); }
      const parts = [kid(kid(kid(kid(t.tk, 'mdia'), 'minf'), 'stbl'), 'stsd')].map(b => u.slice(b.s, b.e));
      parts.push(full('stts', 0, 0, u32s([stts.length]), u32s(stts.flat())));
      if (S.some(s => s.cto)) {
        const neg = S.some(s => s.cto < 0), c = [];
        for (const s of S) { const l = c[c.length - 1]; if (l && l[1] === s.cto) l[0]++; else c.push([1, s.cto]); }
        parts.push(full('ctts', neg ? 1 : 0, 0, u32s([c.length]), u32s(c.map(x => [x[0], x[1] >>> 0]).flat())));
      }
      if (t.vide && S.some(s => !s.sync)) { const k = []; S.forEach((s, i) => s.sync && k.push(i + 1)); parts.push(full('stss', 0, 0, u32s([k.length]), u32s(k))); }
      parts.push(full('stsc', 0, 0, u32s([1, 1, 1, 1])));
      parts.push(full('stsz', 0, 0, u32s([0, S.length]), u32s(S.map(s => s.size))));
      const offs = S.map(s => mdatStart + s.nOff);
      if (offs[offs.length - 1] > 0xffffffff) { const o = new Uint8Array(offs.length * 8); offs.forEach((x, i) => o.set(be(x, 8), i * 8)); parts.push(full('co64', 0, 0, u32s([offs.length]), o)); }
      else parts.push(full('stco', 0, 0, u32s([offs.length]), u32s(offs)));
      return box('stbl', ...parts);
    };
    const rebuild = (b, t, mdatStart) => box(b.type, ...kids(b).filter(c => c.type !== 'edts').map(c => {
      if (c.type === 'stbl') return stbl(t, mdatStart);
      if (c.type === 'mdia' || c.type === 'minf') return rebuild(c, t, mdatStart);
      const copy = u.slice(c.s, c.e), v1 = copy[8] === 1;
      if (c.type === 'tkhd') setDur(copy, v1 ? 36 : 28, v1, Math.round(t.dur / t.ts * movieTs));
      if (c.type === 'mdhd') setDur(copy, v1 ? 32 : 24, v1, t.dur);
      return copy;
    }));
    const ftyp = box('ftyp', new TextEncoder().encode('isom'), be(512, 4), new TextEncoder().encode('isomiso2avc1mp41'));
    const mkMoov = mdatStart => {
      const mv = u.slice(mvhd.s, mvhd.e), v1 = mv[8] === 1; setDur(mv, v1 ? 32 : 24, v1, movieDur);
      return box('moov', mv, ...list.map(t => rebuild(t.tk, t, mdatStart)));
    };
    const hdrLen = big ? 16 : 8;
    const probe = mkMoov(0), mdatStart = ftyp.length + probe.length + hdrLen;
    const moov2 = mkMoov(mdatStart);
    const mdatHdr = big ? cat([be(1, 4), new TextEncoder().encode('mdat'), be(mdatLen + 16, 8)]) : cat([be(mdatLen + 8, 4), new TextEncoder().encode('mdat')]);
    return [ftyp, moov2, mdatHdr, ...ranges.map(r => u.subarray(r.s, r.e))];
  },

  // ---------- WebM: дописываем длительность и таблицу перемотки (Cues), кластеры — с известным размером ----------
  webm(u, durSec) {
    const idAt = o => { const b = u[o]; const L = b >= 0x80 ? 1 : b >= 0x40 ? 2 : b >= 0x20 ? 3 : b >= 0x10 ? 4 : 0; if (!L) throw new Error('bad id'); let v = 0; for (let i = 0; i < L; i++) v = v * 256 + u[o + i]; return { id: v, L }; };
    const sizeAt = o => {
      const b = u[o]; let L = 1; while (L <= 8 && !(b & (0x80 >> (L - 1)))) L++;
      if (L > 8) throw new Error('bad size');
      let v = b & (0xff >> L), ones = v === (0xff >> L);
      for (let i = 1; i < L; i++) { v = v * 256 + u[o + i]; if (u[o + i] !== 255) ones = false; }
      return { v: ones ? -1 : v, L };
    };
    const el = o => { const a = idAt(o), b = sizeAt(o + a.L); return { id: a.id, s: o, d: o + a.L + b.L, size: b.v }; };
    const TOP = new Set([0x1F43B675, 0x1C53BB6B, 0x1254C367, 0x1043A770, 0x1941A469, 0x114D9B74, 0x1549A966, 0x1654AE6B]);
    const uint = (o, e) => { let v = 0; for (let i = o; i < e; i++) v = v * 256 + u[i]; return v; };
    const hdr = el(0); if (hdr.id !== 0x1A45DFA3) return null;
    const seg = el(hdr.d + hdr.size); if (seg.id !== 0x18538067) return null;
    const segEnd = seg.size < 0 ? u.length : Math.min(u.length, seg.d + seg.size);
    let info = null, tracks = null, tcScale = 1e6, vTrack = 1, maxT = 0;
    const clusters = [];
    let o = seg.d;
    while (o < segEnd - 2) {
      let e; try { e = el(o); } catch (_) { break; }
      if (e.id === 0x1F43B675) {
        // кластер может быть «без размера» — тогда идём по детям до следующего элемента верхнего уровня
        const ch = []; let p = e.d, end = e.size < 0 ? segEnd : Math.min(segEnd, e.d + e.size), tc = 0, key = null;
        while (p < end - 1) {
          let c; try { c = el(p); } catch (_) { p = end; break; }
          if (e.size < 0 && TOP.has(c.id)) break;
          if (c.size < 0 || c.d + c.size > u.length) { p = end; break; }
          const ce = c.d + c.size;
          if (c.id === 0xE7) tc = uint(c.d, ce);
          if (c.id === 0xA3) { // SimpleBlock: номер дорожки, время (int16), флаги
            const tn = sizeAt(c.d), rt = (u[c.d + tn.L] << 8 | u[c.d + tn.L + 1]) << 16 >> 16, fl = u[c.d + tn.L + 2];
            maxT = Math.max(maxT, tc + rt);
            if (key === null && tn.v === vTrack && (fl & 0x80)) key = tc + rt;
          }
          ch.push([c.s, ce]); p = ce;
        }
        clusters.push({ ch, key });
        o = p; continue;
      }
      if (e.size < 0) break;
      const end = e.d + e.size;
      if (e.id === 0x1549A966) {
        info = [];
        for (let p = e.d; p < end;) { const c = el(p), ce = c.d + c.size; if (c.id === 0x2AD7B1) tcScale = uint(c.d, ce); if (c.id !== 0x4489) info.push([c.s, ce]); p = ce; }
      } else if (e.id === 0x1654AE6B) {
        tracks = [e.s, end];
        for (let p = e.d; p < end;) { const t = el(p), te = t.d + t.size; if (t.id === 0xAE) { let num = 0, type = 0; for (let q = t.d; q < te;) { const c = el(q), ce = c.d + c.size; if (c.id === 0xD7) num = uint(c.d, ce); if (c.id === 0x83) type = uint(c.d, ce); q = ce; } if (type === 1) vTrack = num; } p = te; }
      }
      o = end;
    }
    if (!info || !tracks || !clusters.length) return null;
    // ---- запись ----
    const be = (n, bytes) => { const a = new Uint8Array(bytes); for (let i = bytes - 1; i >= 0; i--) { a[i] = n % 256; n = Math.floor(n / 256); } return a; };
    const idB = id => be(id, id < 0x100 ? 1 : id < 0x10000 ? 2 : id < 0x1000000 ? 3 : 4);
    const sz8 = n => { const a = be(n, 8); a[0] = 1; return a; };
    const uintB = n => { let L = 1; while (L < 8 && n >= Math.pow(256, L)) L++; return be(n, L); };
    const cat = arr => { let L = 0; for (const a of arr) L += a.length; const r = new Uint8Array(L); let p = 0; for (const a of arr) { r.set(a, p); p += a.length; } return r; };
    const E = (id, ...parts) => { const b = cat(parts); return cat([idB(id), sz8(b.length), b]); };
    const durMs = Math.max(maxT + 33, (durSec || 0) * 1000 * 1e6 / tcScale);
    const f64 = new Uint8Array(8); new DataView(f64.buffer).setFloat64(0, durMs);
    const infoB = E(0x1549A966, ...info.map(([a, b]) => u.subarray(a, b)), E(0x4489, f64));
    const tracksB = u.slice(tracks[0], tracks[1]);
    const clHdr = cl => { let L = 0; for (const [a, b] of cl.ch) L += b - a; return { L, h: cat([idB(0x1F43B675), sz8(L)]) }; };
    const seekLen = E(0x114D9B74, ...[0, 0, 0].map(() => E(0x4DBB, E(0x53AB, idB(0x1549A966)), E(0x53AC, be(0, 8))))).length;
    let pos = seekLen + infoB.length + tracksB.length;
    const parts = [], cues = [];
    for (const cl of clusters) {
      const { L, h } = clHdr(cl);
      if (cl.key !== null) cues.push(E(0xBB, E(0xB3, uintB(cl.key)), E(0xB7, E(0xF7, uintB(vTrack)), E(0xF1, uintB(pos)))));
      parts.push(h, ...cl.ch.map(([a, b]) => u.subarray(a, b)));
      pos += h.length + L;
    }
    const cuesB = E(0x1C53BB6B, ...cues), cuesPos = pos;
    const seek = E(0x114D9B74,
      E(0x4DBB, E(0x53AB, idB(0x1549A966)), E(0x53AC, be(seekLen, 8))),
      E(0x4DBB, E(0x53AB, idB(0x1654AE6B)), E(0x53AC, be(seekLen + infoB.length, 8))),
      E(0x4DBB, E(0x53AB, idB(0x1C53BB6B)), E(0x53AC, be(cuesPos, 8))));
    const segLen = cuesPos + cuesB.length;
    return [u.subarray(hdr.s, hdr.d + hdr.size), idB(0x18538067), sz8(segLen), seek, infoB, tracksB, ...parts, cuesB];
  },
};
