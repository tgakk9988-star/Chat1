'use strict';
/* «Наш чат» — окно чата: фото, видео, ссылки и файлы за всё время + приближение фото в просмотре. */

/* ================= перейти к сообщению (подгружая историю, если нужно) ================= */
async function goToMsg(id) {
  show('chat');
  let tries = 0;
  while (!document.querySelector(`.msg[data-id="${id}"]`) && tries++ < 80 && S.order.length && S.order[0] > id && !$('#older').classList.contains('hidden')) {
    const before = S.order[0];
    await loadOlder();
    if (S.order[0] === before) await sleep(300);
  }
  if (document.querySelector(`.msg[data-id="${id}"]`)) setTimeout(() => Reply.jump(id), 60);
  else toast('Это сообщение больше недоступно');
}

/* ================= индекс медиа ================= */
const MediaIdx = {
  items: new Map(),   // id -> { id, ts, mine, dev, p }
  top: 0,             // всё до этого сообщения уже просмотрено
  busy: null,
  add(id, ts, dev, p) {
    if (!p) return;
    if (p.t === 'image' || p.t === 'video' || p.t === 'file' || (p.t === 'text' && findLinks(p.text).length) || (p.caption && findLinks(p.caption).length)) {
      this.items.set(id, { id, ts, dev, mine: dev === S.dev, p });
    }
  },
  async ingestRaw(list) {
    for (const r of list) {
      if (this.items.has(r.id)) { if (r.del) this.items.delete(r.id); continue; }
      if (r.del || !r.ct) continue;
      const known = S.msgs.get(r.id);
      if (known) { if (!known.del) this.add(r.id, r.ts, r.dev, known.p); continue; }
      try { this.add(r.id, r.ts, r.dev, JSON.parse(dec.decode(await Crypto.open(S.key, unb64(r.ct))))); } catch (_) { }
    }
  },
  // проходим всю переписку с сервера (только один раз; дальше — лишь новое)
  scan(onProg) {
    if (this.busy) return this.busy;
    this.busy = (async () => {
      try {
        // уже загруженное в чат
        for (const m of S.msgs.values()) if (!m.del) this.add(m.id, m.ts, m.dev, m.p);
        for (const [id] of this.items) { const m = S.msgs.get(id); if (m && m.del) this.items.delete(id); }
        // новое сверху (до того места, где уже всё просмотрено)
        let cursor = S.last + 1, total = 0;
        const stop = this.top;
        while (cursor > stop + 1) {
          const res = await api(`/api/messages?before=${cursor}&limit=200`, { timeout: 30000 });
          const list = res.messages || [];
          if (!list.length) break;
          await this.ingestRaw(list);
          total += list.length; onProg && onProg(total);
          cursor = list[0].id;
          if (cursor <= 1) break;
        }
        this.top = Math.max(this.top, S.last);
      } finally { this.busy = null; }
    })();
    return this.busy;
  },
  list(kind) {
    const out = [];
    for (const x of this.items.values()) {
      const p = x.p;
      if (kind === 'photo' && p.t === 'image') out.push(x);
      else if (kind === 'video' && p.t === 'video') out.push(x);
      else if (kind === 'file' && p.t === 'file') out.push(x);
      else if (kind === 'link') { for (const l of findLinks(p.t === 'text' ? p.text : (p.caption || ''))) out.push(Object.assign({}, x, { link: l })); }
    }
    return out.sort((a, b) => b.id - a.id);
  },
};

/* ================= чёткие миниатюры ================= */
// в сообщении хранится крошечное превью; для галереи берём само фото и делаем чёткую миниатюру
const CIThumb = {
  urls: new Map(), queue: [], active: 0, io: null,
  watch(root) {
    if (this.io) this.io.disconnect();
    this.queue = [];
    this.io = new IntersectionObserver(es => {
      for (const e of es) if (e.isIntersecting) { this.io.unobserve(e.target); this.want(e.target); }
    }, { root, rootMargin: '300px' });
    root.querySelectorAll('.ci-th[data-fid]').forEach(el => {
      const u = this.urls.get(el.dataset.fid);
      if (u) this.set(el, u); else this.io.observe(el);
    });
  },
  set(el, u) { const img = el.querySelector('img'); if (img) { img.src = u; img.classList.add('sharp'); } },
  want(el) { this.queue.push(el); this.pump(); },
  pump() {
    while (this.active < 3 && this.queue.length) {
      const el = this.queue.shift(); this.active++;
      this.make(el).finally(() => { this.active--; this.pump(); });
    }
  },
  async make(el) {
    const fid = el.dataset.fid, x = MediaIdx.items.get(+el.dataset.id); if (!x || !x.p.file) return;
    if (this.urls.has(fid)) { this.set(el, this.urls.get(fid)); return; }
    try {
      let th = await DB.getMedia('th_' + fid);
      if (!th) {
        const blob = await getMedia(x.p.file);
        const img = await loadImage(blob);
        const W = img.width, H = img.height, s = Math.min(W, H), size = 360;
        const cv = document.createElement('canvas'); cv.width = cv.height = size;
        cv.getContext('2d').drawImage(img, (W - s) / 2, (H - s) / 2, s, s, 0, 0, size, size);
        th = await new Promise(r => cv.toBlob(r, 'image/jpeg', 0.85));
        if (th) DB.putMedia('th_' + fid, th);
      }
      if (!th) return;
      const u = URL.createObjectURL(th); this.urls.set(fid, u); this.set(el, u);
    } catch (_) { }
  },
};

/* ================= окно чата ================= */
const CInfo = {
  tab: 'photo',
  open() {
    Panel.close(); RxBar.close(); try { ta.blur(); } catch (_) { }
    const av = $('#partner-av'), big = $('#ci-av');
    big.className = 'ci-av' + (av.classList.contains('photo') ? ' photo' : '');
    big.style.backgroundImage = av.style.backgroundImage; big.style.background = av.classList.contains('photo') ? '' : (CHAT.isGroup() ? colorOf(CHAT.id) : '');
    if (av.classList.contains('photo')) big.style.backgroundImage = av.style.backgroundImage;
    big.textContent = av.classList.contains('photo') ? '' : av.textContent;
    $('#ci-name').innerHTML = $('#partner-name').innerHTML;
    $('#ci-sub').innerHTML = $('#net').innerHTML;
    $('#ci-call').classList.toggle('hidden', CHAT.isGroup());
    $('#ci-vcall').classList.toggle('hidden', CHAT.isGroup());
    show('cinfo');
    this.draw(true);
    $('#ci-body').innerHTML = '<div class="ci-load">⏳ Собираю фото, видео, ссылки и файлы…</div>';
    MediaIdx.scan(n => { const l = $('#ci-body .ci-load'); if (l) l.textContent = `⏳ Просматриваю переписку… ${n}`; })
      .then(() => this.draw()).catch(() => { this.draw(); toast('Не всё удалось загрузить — нет связи?'); });
  },
  draw(onlyTabs) {
    const counts = { photo: MediaIdx.list('photo').length, video: MediaIdx.list('video').length, link: MediaIdx.list('link').length, file: MediaIdx.list('file').length };
    document.querySelectorAll('#ci-tabs [data-tab]').forEach(b => {
      b.classList.toggle('on', b.dataset.tab === this.tab);
      const n = counts[b.dataset.tab]; b.querySelector('i').textContent = n ? String(n) : '';
    });
    if (onlyTabs) return;
    const list = MediaIdx.list(this.tab), body = $('#ci-body');
    if (!list.length) {
      body.innerHTML = `<div class="ci-empty">${{ photo: '📷 Фото пока нет', video: '🎬 Видео пока нет', link: '🔗 Ссылок пока нет', file: '📎 Файлов пока нет' }[this.tab]}</div>`;
      return;
    }
    let html = '', month = '';
    const grid = this.tab === 'photo' || this.tab === 'video';
    for (const x of list) {
      const d = new Date(x.ts), mk = d.getFullYear() + '-' + d.getMonth();
      if (mk !== month) {
        if (month && grid) html += '</div>';
        month = mk;
        html += `<div class="ci-month">${MONTHS_NOM[d.getMonth()]}${d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : ''}</div>`;
        if (grid) html += '<div class="ci-grid">';
      }
      const p = x.p;
      if (this.tab === 'photo') html += `<button class="ci-th" data-id="${x.id}" data-fid="${esc(p.file ? p.file.id : '')}">${p.thumb ? `<img src="${p.thumb}" alt="" loading="lazy">` : '📷'}</button>`;
      else if (this.tab === 'video') html += `<button class="ci-th" data-id="${x.id}">${p.thumb ? `<img src="${p.thumb}" alt="" loading="lazy">` : '🎬'}<span class="ci-dur">▶ ${fmtDur(p.dur)}</span></button>`;
      else if (this.tab === 'link') html += `<button class="ci-row" data-id="${x.id}" data-href="${esc(x.link.href)}"><span class="ci-ic">🔗</span><span class="ci-t"><b>${esc(x.link.text)}</b><small>${esc((x.mine ? 'Вы' : (p.n || S.partner || '')) + ' · ' + fmtDay(x.ts) + ', ' + fmtTime(x.ts))}</small></span></button>`;
      else html += `<button class="ci-row" data-id="${x.id}"><span class="ci-ic">📎</span><span class="ci-t"><b>${esc((p.file && p.file.name) || 'Файл')}</b><small>${esc(fmtSize((p.file && p.file.size) || 0) + ' · ' + (x.mine ? 'Вы' : (p.n || S.partner || '')) + ' · ' + fmtDay(x.ts))}</small></span></button>`;
    }
    if (grid) html += '</div>';
    html += '<p class="ci-tip muted">Подержите, чтобы перейти к сообщению</p>';
    body.innerHTML = html;
    body.querySelectorAll('[data-id]').forEach(el => attachLongPress(el, () => this.menu(+el.dataset.id, el.dataset.href)));
    if (this.tab === 'photo') CIThumb.watch(body);
  },
  menu(id, href) {
    const x = MediaIdx.items.get(id); if (!x) return;
    const m = { id: x.id, ts: x.ts, dev: x.dev, mine: x.mine, p: x.p };
    const items = [{ icon: 'reply', label: 'Перейти к сообщению', fn: () => goToMsg(id) }];
    if (href) items.push({ icon: 'copy', label: 'Скопировать ссылку', fn: () => copyText(href.replace(/^(?!https?:|mailto:|tel:)/, ''), 'Ссылка скопирована') });
    if (x.p.file) items.push({ icon: 'save', label: 'Сохранить на телефон', fn: () => saveMessageMedia(m) });
    sheet(items);
  },
  async tap(el) {
    const id = +el.dataset.id, x = MediaIdx.items.get(id); if (!x) return;
    if (Date.now() - (window.__lpAt || 0) < 700) return;
    const m = { id: x.id, ts: x.ts, dev: x.dev, mine: x.mine, p: x.p };
    if (el.dataset.href) { openLink(el.dataset.href); return; }
    if (x.p.t === 'file') { saveMessageMedia(m); return; }
    try {
      toast('Загрузка…', 60000);
      const blob = await getMedia(x.p.file, fr => toast('Загрузка ' + Math.round(fr * 100) + '%', 60000));
      $('#toast').classList.add('hidden');
      openViewer(m, blob);
    } catch (_) { toast('Не удалось загрузить'); }
  },
};
$('#ci-tabs').onclick = e => { const b = e.target.closest('[data-tab]'); if (!b) return; CInfo.tab = b.dataset.tab; CInfo.draw(); $('#ci-body').scrollTop = 0; };
$('#ci-body').addEventListener('click', e => { const el = e.target.closest('[data-id]'); if (el) CInfo.tap(el); });
$('#ci-back').onclick = () => show('chat');
$('#ci-call').onclick = () => { show('chat'); Call.start(false); };
$('#ci-vcall').onclick = () => { show('chat'); Call.start(true); };
$('#ci-more').onclick = () => { show('chat'); Drawer.openChat(); };
$('#ci-av').onclick = () => { if (!CHAT.isGroup()) Profile.showPartnerPhoto(); };

/* ================= приближение фото в просмотре ================= */
const VZoom = {
  s: 1, x: 0, y: 0, img: null,
  attach(img) {
    this.img = img; this.s = 1; this.x = 0; this.y = 0; this.apply(false);
  },
  apply(anim) {
    if (!this.img) return;
    this.img.style.transition = anim ? 'transform .22s ease-out' : 'none';
    this.img.style.transform = `translate(${this.x}px, ${this.y}px) scale(${this.s})`;
  },
  clamp() {
    const r = this.img.getBoundingClientRect(), b = $('#v-body').getBoundingClientRect();
    const w = r.width / 1, h = r.height / 1; // уже с учётом масштаба
    const maxX = Math.max(0, (w - b.width) / 2), maxY = Math.max(0, (h - b.height) / 2);
    this.x = Math.max(-maxX, Math.min(maxX, this.x)); this.y = Math.max(-maxY, Math.min(maxY, this.y));
  },
  // увеличиваем вокруг точки (cx, cy) экрана
  zoomAt(ns, cx, cy) {
    const b = $('#v-body').getBoundingClientRect(), ox = cx - (b.left + b.width / 2), oy = cy - (b.top + b.height / 2);
    ns = Math.max(1, Math.min(6, ns));
    const k = ns / this.s;
    this.x = ox - (ox - this.x) * k; this.y = oy - (oy - this.y) * k; this.s = ns;
    if (ns === 1) { this.x = 0; this.y = 0; }
  },
};
(() => {
  const body = $('#v-body');
  let st = null, lastTap = 0;
  const pts = e => [...e.touches].map(t => ({ x: t.clientX, y: t.clientY }));
  body.addEventListener('touchstart', e => {
    if (!VZoom.img || !body.contains(VZoom.img)) return;
    const p = pts(e);
    if (p.length === 2) st = { mode: 'pinch', d: Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y), s: VZoom.s, cx: (p[0].x + p[1].x) / 2, cy: (p[0].y + p[1].y) / 2, x: VZoom.x, y: VZoom.y };
    else if (p.length === 1) {
      const now = Date.now();
      if (now - lastTap < 300) { // двойное касание
        if (VZoom.s > 1.05) { VZoom.s = 1; VZoom.x = 0; VZoom.y = 0; } else VZoom.zoomAt(2.5, p[0].x, p[0].y);
        VZoom.clamp(); VZoom.apply(true); lastTap = 0; st = null; return;
      }
      lastTap = now;
      st = { mode: 'pan', sx: p[0].x, sy: p[0].y, x: VZoom.x, y: VZoom.y };
    }
  }, { passive: true });
  body.addEventListener('touchmove', e => {
    if (!st || !VZoom.img) return;
    const p = pts(e);
    if (st.mode === 'pinch' && p.length === 2) {
      e.preventDefault();
      const d = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y), cx = (p[0].x + p[1].x) / 2, cy = (p[0].y + p[1].y) / 2;
      VZoom.s = st.s; VZoom.x = st.x + (cx - st.cx); VZoom.y = st.y + (cy - st.cy);
      VZoom.zoomAt(st.s * d / st.d, cx, cy); VZoom.apply(false);
    } else if (st.mode === 'pan' && p.length === 1 && VZoom.s > 1.01) {
      e.preventDefault();
      VZoom.x = st.x + p[0].x - st.sx; VZoom.y = st.y + p[0].y - st.sy; VZoom.apply(false);
    }
  }, { passive: false });
  body.addEventListener('touchend', e => {
    if (e.touches.length === 1 && st && st.mode === 'pinch') { const t = e.touches[0]; st = { mode: 'pan', sx: t.clientX, sy: t.clientY, x: VZoom.x, y: VZoom.y }; return; }
    if (!e.touches.length) { if (VZoom.img) { if (VZoom.s < 1.02) { VZoom.s = 1; VZoom.x = 0; VZoom.y = 0; } VZoom.clamp(); VZoom.apply(true); } st = null; }
  });
  // колесо мыши (на компьютере)
  body.addEventListener('wheel', e => { if (!VZoom.img) return; e.preventDefault(); VZoom.zoomAt(VZoom.s * (e.deltaY < 0 ? 1.2 : 1 / 1.2), e.clientX, e.clientY); VZoom.clamp(); VZoom.apply(false); }, { passive: false });
})();
