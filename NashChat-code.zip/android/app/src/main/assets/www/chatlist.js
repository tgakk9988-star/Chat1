'use strict';
/* «Наш чат» — несколько чатов: список, личные чаты, группы, приглашения, закреплённые сообщения.
   Ключи всех чатов хранятся зашифрованными ключом главного чата, а он — PIN-кодом (или отпечатком). */

const Chats = {
  keys: new Map(),   // id -> { id, url, kind, title, raw, key, token }
  vault: null, mainRaw: null,
  extra() { try { return JSON.parse(localStorage.getItem('nc_chats') || '[]') || []; } catch (_) { return []; } },
  saveExtra(a) { localStorage.setItem('nc_chats', JSON.stringify(a)); document.body.classList.toggle('multi', a.length > 0); },
  async vaultKey(raw) {
    const base = await crypto.subtle.importKey('raw', raw, 'HKDF', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: enc.encode('nash-chat-v1'), info: enc.encode('vault') }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  },
  async unlock(mainRaw) {
    this.mainRaw = mainRaw; this.vault = await this.vaultKey(mainRaw);
    const st = Store.get() || {}, m = await Crypto.derive(mainRaw);
    this.keys.set('main', { id: 'main', url: st.url, kind: st.kind || 'pair', title: this.meta('main').title || '', raw: mainRaw, key: m.key, token: m.token });
    for (const c of this.extra()) {
      try { const raw = await Crypto.open(this.vault, unb64(c.vct)); const d = await Crypto.derive(raw); this.keys.set(c.id, Object.assign({}, c, { raw, key: d.key, token: d.token })); }
      catch (_) { }
    }
  },
  cur() { return this.keys.get(CHAT.id) || this.keys.get('main'); },
  all() { return [...this.keys.values()]; },
  // ---------- заголовки и кэш для списка (без текста сообщений: только шифр последнего) ----------
  metaAll() { try { return JSON.parse(localStorage.getItem('nc_list') || '{}') || {}; } catch (_) { return {}; } },
  meta(id) { return this.metaAll()[id] || {}; },
  setMeta(id, patch) {
    const a = this.metaAll(), was = JSON.stringify(a[id] || {});
    a[id] = Object.assign({}, a[id] || {}, patch);
    if (JSON.stringify(a[id]) === was) return;
    try { localStorage.setItem('nc_list', JSON.stringify(a)); } catch (_) { }
    if (patch.title !== undefined) {
      const k = this.keys.get(id); if (k) k.title = patch.title;
      if (id !== 'main') { const ex = this.extra(), c = ex.find(x => x.id === id); if (c && c.title !== patch.title) { c.title = patch.title; this.saveExtra(ex); } }
      this.syncNative();
    }
  },
  seenAll() { try { return JSON.parse(localStorage.getItem('nc_seen') || '{}') || {}; } catch (_) { return {}; } },
  setSeen(id, last) {
    const a = this.seenAll(); if ((a[id] || 0) >= last) return;
    a[id] = last; try { localStorage.setItem('nc_seen', JSON.stringify(a)); } catch (_) { }
    if (ChatList.st[id]) { ChatList.st[id].unread = 0; ChatList.badge(); }
  },
  titleOf(c) {
    const t = (c && c.title) || this.meta(c.id).title;
    if (t) return t;
    return c.kind === 'group' ? 'Группа' : c.kind === 'pair' ? 'Наш чат' : 'Новый чат';
  },
  // ---------- коды приглашения ----------
  code(raw, url, kind, title) {
    if (kind === 'pair') return 'NC1.' + b64url(raw) + '.' + b64url(enc.encode(url));
    return 'NC2.' + b64url(raw) + '.' + b64url(enc.encode(url)) + '.' + (kind === 'group' ? 'g' : 'd') + (title ? '.' + b64url(enc.encode(title.slice(0, 60))) : '');
  },
  parse(code) {
    code = String(code || '').replace(/\s+/g, '');
    let m = code.match(/^NC1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/);
    if (m) return { raw: unb64url(m[1]), url: dec.decode(unb64url(m[2])), kind: 'pair', title: '' };
    m = code.match(/^NC2\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)\.([dg])(?:\.([A-Za-z0-9_-]+))?$/);
    if (m) return { raw: unb64url(m[1]), url: dec.decode(unb64url(m[2])), kind: m[3] === 'g' ? 'group' : 'dm', title: m[4] ? dec.decode(unb64url(m[4])) : '' };
    return null;
  },
  inviteCode() { const c = this.cur(); return this.code(c.raw, c.url, c.kind, c.kind === 'group' ? Group.title() : ''); },
  async roomId(token) { return hex(await crypto.subtle.digest('SHA-256', enc.encode(token))).slice(0, 24); },
  // ---------- новый чат ----------
  async add(c, raw) {
    const vct = b64(await Crypto.seal(this.vault, raw));
    const ex = this.extra().filter(x => x.id !== c.id);
    ex.push({ id: c.id, url: c.url, kind: c.kind, title: c.title || '', vct, at: Date.now() });
    this.saveExtra(ex);
    const d = await Crypto.derive(raw);
    this.keys.set(c.id, Object.assign({}, c, { raw, key: d.key, token: d.token }));
    if (c.title) this.setMeta(c.id, { title: c.title });
    this.syncNative();
  },
  async create(kind, title) {
    const m = this.keys.get('main');
    const raw = crypto.getRandomValues(new Uint8Array(32)), d = await Crypto.derive(raw);
    let r;
    try { r = await fetch(m.url + '/api/rooms', { method: 'POST', headers: { Authorization: 'Bearer ' + m.token, 'Content-Type': 'application/json' }, body: JSON.stringify({ token: d.token, kind }) }); }
    catch (_) { throw new Error('Нет связи с сервером. Проверьте интернет.'); }
    if (r.status === 404) throw new Error('Сервер ещё не обновлён. Выполните команду обновления сервера и попробуйте снова.');
    if (!r.ok) throw new Error('Сервер отказал (' + r.status + ').');
    const id = await this.roomId(d.token);
    await this.add({ id, url: m.url, kind, title: title || '' }, raw);
    return id;
  },
  async join(code) {
    const c = this.parse(code);
    if (!c || c.raw.length !== 32) throw new Error('Код приглашения неверный. Скопируйте его целиком.');
    const d = await Crypto.derive(c.raw);
    for (const k of this.keys.values()) if (k.token === d.token) return k.id; // уже есть
    let r;
    try { r = await fetch(c.url + '/api/messages?last=1&limit=1', { headers: { Authorization: 'Bearer ' + d.token } }); }
    catch (_) { throw new Error('Сервер не отвечает. Проверьте интернет.'); }
    if (r.status === 401) throw new Error('Сервер не принял код. Попросите прислать его ещё раз.');
    if (!r.ok) throw new Error('Сервер ответил ошибкой (' + r.status + ').');
    const id = await this.roomId(d.token);
    await this.add({ id, url: c.url, kind: c.kind === 'pair' ? 'dm' : c.kind, title: c.title }, c.raw);
    return id;
  },
  // ---------- переход между чатами ----------
  open(id, view) {
    if (id === CHAT.id) { show('chat'); scrollBottom(true); markSeen(); return; }
    try {
      sessionStorage.setItem('nc_cur', id); sessionStorage.setItem('nc_view', view || 'chat');
      if (this.mainRaw) sessionStorage.setItem('nc_sess', b64(this.mainRaw));
    } catch (_) { }
    S.syncGen++; Presence.set('away', true);
    document.body.classList.add('switching');
    location.reload();
  },
  showList() { Panel.close(); RxBar.close(); try { ta.blur(); } catch (_) { } ChatList.draw(); show('chats'); ChatList.start(); },
  leave(id) {
    try { sessionStorage.setItem('nc_leave', id); } catch (_) { }
    this.open('main', 'list');
  },
  // удаление чата делаем из главного (там нет разделения хранилища)
  cleanupLeft() {
    let id = ''; try { id = sessionStorage.getItem('nc_leave') || ''; sessionStorage.removeItem('nc_leave'); } catch (_) { }
    if (!id || id === 'main' || CHAT.id !== 'main') return;
    this.saveExtra(this.extra().filter(x => x.id !== id));
    this.keys.delete(id);
    try { indexedDB.deleteDatabase('nashchat_' + id); } catch (_) { }
    const pre = 'c' + id + ':', del = [];
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(pre)) del.push(k); }
    del.forEach(k => localStorage.removeItem(k));
    const a = this.metaAll(); delete a[id]; try { localStorage.setItem('nc_list', JSON.stringify(a)); } catch (_) { }
    delete ChatList.st[id];
    this.syncNative();
    toast('Чат удалён с этого телефона');
  },
  // ---------- фоновая служба: какие чаты слушать и (по желанию) ключи для текста уведомлений ----------
  notifText() { try { return localStorage.getItem('nc_notif') !== 'off'; } catch (_) { return true; } },
  syncNative() {
    if (!Native || !Native.setRooms || !this.keys.size) return;
    const text = this.notifText();
    const list = this.all().map(c => ({ id: c.id, url: c.url, token: c.token, dev: S.dev, kind: c.kind, title: this.titleOf(c), key: text ? b64(c.raw) : '' }));
    try { Native.setRooms(JSON.stringify(list)); } catch (_) { }
  },
};

/* ================= список чатов ================= */
const COLORS = ['#e17076', '#7bc862', '#e5ca77', '#65aadd', '#a695e7', '#ee7aae', '#6ec9cb', '#faa774'];
const colorOf = s => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
const ChatList = {
  st: {},          // id -> { last, known, unread, top, prev, ring }
  gen: 0, running: false, ringShown: {},
  async preview(c, top) {
    if (!top) return '';
    if (top.del) return 'Сообщение удалено';
    try {
      const p = JSON.parse(dec.decode(await Crypto.open(c.key, unb64(top.ct))));
      if (p.t === 'react' || p.t === 'edit') return null;
      const who = top.dev === S.dev ? 'Вы: ' : (c.kind === 'group' && p.n ? p.n + ': ' : '');
      if (top.dev !== S.dev && p.n && c.kind !== 'group' && !Chats.meta(c.id).title && c.id !== 'main') Chats.setMeta(c.id, { title: p.n });
      if (top.dev !== S.dev && p.n && c.id === 'main' && !Chats.meta('main').title && c.kind !== 'group') Chats.setMeta('main', { title: p.n });
      return who + snippetOf({ p });
    } catch (_) { return '🔒 Сообщение'; }
  },
  async countNew(c, msgs) {
    let n = 0;
    for (const m of msgs) {
      if (m.dev === S.dev || m.del) continue;
      try { const p = JSON.parse(dec.decode(await Crypto.open(c.key, unb64(m.ct)))); if (p.t !== 'react' && p.t !== 'edit') n++; } catch (_) { n++; }
    }
    return n;
  },
  start() {
    if (this.running || !Chats.keys.size) return;
    this.running = true; this.loop(++this.gen);
  },
  async loop(gen) {
    const first = {};
    let backoff = 2000;
    while (gen === this.gen) {
      const chats = Chats.all();
      const byUrl = new Map();
      for (const c of chats) { if (!byUrl.has(c.url)) byUrl.set(c.url, []); byUrl.get(c.url).push(c); }
      try {
        // обычно все чаты на одном сервере; если нет — опрашиваем остальные без ожидания
        let i = 0;
        for (const [url, list] of byUrl) {
          const seen = Chats.seenAll(), primary = i++ === 0;
          const rooms = list.map(c => {
            const s = this.st[c.id];
            return { t: c.token, a: s && s.known != null ? s.known : (seen[c.id] || 0), rs: this.ringShown[c.id] || '' };
          });
          const wait = primary && list.every(c => this.st[c.id] && this.st[c.id].known != null) ? 25 : 0;
          const ctl = new AbortController(), tm = setTimeout(() => ctl.abort(), 40000);
          let r;
          try { r = await fetch(url + '/api/multi', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, wait, rooms }), signal: ctl.signal }); }
          finally { clearTimeout(tm); }
          if (r.status === 404) { this.old = true; await sleep(60000); continue; }
          if (!r.ok) throw new Error('HTTP ' + r.status);
          const j = await r.json();
          if (gen !== this.gen) return;
          for (let k = 0; k < list.length; k++) await this.apply(list[k], j.rooms[k], !first[list[k].id]);
          list.forEach(c => { first[c.id] = true; });
        }
        this.draw(); this.badge(); backoff = 2000;
        if (byUrl.size > 1) await sleep(4000);
      } catch (_) {
        await sleep(backoff); backoff = Math.min(backoff * 2, 30000);
      }
    }
  },
  async apply(c, x, isFirst) {
    if (!x || x.err) return;
    const s = this.st[c.id] || (this.st[c.id] = { unread: 0 });
    const viewing = c.id === CHAT.id && !document.hidden && !$('#chat').classList.contains('hidden');
    const fresh = (x.msgs || []).filter(m => s.known == null || m.id > s.known);
    if (viewing) s.unread = 0;
    else if (isFirst) s.unread = await this.countNew(c, x.msgs || []);
    else if (fresh.length) {
      const n = await this.countNew(c, fresh);
      s.unread += n;
      if (n && c.id !== CHAT.id && !document.hidden) this.notify(c, fresh.filter(m => m.dev !== S.dev).pop());
    }
    s.last = x.last; s.known = x.last;
    if (x.top) {
      if (!s.top || s.top.id !== x.top.id || s.top.del !== x.top.del) {
        const pv = await this.preview(c, x.top);
        if (pv !== null) s.prev = pv; else if (s.prev == null) s.prev = '';
        s.top = x.top;
        Chats.setMeta(c.id, { ts: x.top.ts });
      }
    }
    // звонок из другого чата, пока приложение открыто
    if (c.id !== CHAT.id) {
      if (x.ring && this.ringShown[c.id] !== x.ring.id) { this.ringShown[c.id] = x.ring.id; this.ringBanner(c, x.ring); }
      else if (!x.ring && this.ringShown[c.id]) { this.ringShown[c.id] = ''; this.ringBanner(null); }
    }
  },
  total() { let n = 0; for (const [id, s] of Object.entries(this.st)) if (id !== CHAT.id) n += s.unread || 0; return n; },
  badge() {
    const n = this.total(), b = $('#back-badge');
    if (b) { b.textContent = n > 99 ? '99+' : String(n); b.classList.toggle('hidden', !n); }
  },
  order() {
    const meta = Chats.metaAll();
    return Chats.all().sort((a, b) => {
      if (a.kind === 'pair' && b.kind !== 'pair') return -1;
      if (b.kind === 'pair' && a.kind !== 'pair') return 1;
      const ta = (this.st[a.id] && this.st[a.id].top && this.st[a.id].top.ts) || (meta[a.id] && meta[a.id].ts) || a.at || 0;
      const tb = (this.st[b.id] && this.st[b.id].top && this.st[b.id].top.ts) || (meta[b.id] && meta[b.id].ts) || b.at || 0;
      return tb - ta;
    });
  },
  draw() {
    const box = $('#cl-list'); if (!box) return;
    const meta = Chats.metaAll();
    box.innerHTML = this.order().map(c => {
      const s = this.st[c.id] || {}, title = Chats.titleOf(c), m = meta[c.id] || {};
      const ts = (s.top && s.top.ts) || m.ts;
      const av = m.avatar ? `<div class="cl-av photo" style="background-image:url('${esc(m.avatar)}')"></div>`
        : `<div class="cl-av" style="background:${c.kind === 'pair' ? 'var(--accent)' : colorOf(c.id)}">${c.kind === 'group' ? '👥' : c.kind === 'pair' ? '♥' : esc((title.trim()[0] || '?').toUpperCase())}</div>`;
      const unread = c.id === CHAT.id && !$('#chats').classList.contains('hidden') ? (s.unread || 0) : (s.unread || 0);
      return `<button class="cl-item" data-chat="${esc(c.id)}">${av}
        <div class="cl-mid"><div class="cl-top"><b>${c.kind === 'pair' ? '❤️ ' : ''}${esc(title)}</b><small>${ts ? this.when(ts) : ''}</small></div>
        <div class="cl-bot"><span>${s.prev != null ? esc(s.prev || 'Нет сообщений') : (s.known != null ? 'Нет сообщений' : '…')}</span>${unread ? `<i class="cl-n">${unread > 99 ? '99+' : unread}</i>` : ''}</div></div></button>`;
    }).join('');
  },
  when(ts) {
    const d = new Date(ts), now = new Date();
    if (d.toDateString() === now.toDateString()) return fmtTime(ts);
    const y = new Date(now); y.setDate(now.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return 'вчера';
    return d.getDate() + ' ' + MONTHS[d.getMonth()].slice(0, 3);
  },
  // всплывашка о сообщении из другого чата
  async notify(c, m) {
    if (!m) return;
    let text = 'Новое сообщение';
    try { const p = JSON.parse(dec.decode(await Crypto.open(c.key, unb64(m.ct)))); text = (c.kind === 'group' && p.n ? p.n + ': ' : '') + snippetOf({ p }); } catch (_) { }
    const b = $('#cl-pop');
    b.innerHTML = `<b>${esc(Chats.titleOf(c))}</b><span>${esc(text)}</span>`;
    b.onclick = () => { b.classList.add('hidden'); Chats.open(c.id); };
    b.classList.remove('hidden'); b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
    clearTimeout(this.popT); this.popT = setTimeout(() => b.classList.add('hidden'), 4000);
    vibrate(15);
  },
  ringBanner(c, ring) {
    const b = $('#cl-ring');
    if (!c) { b.classList.add('hidden'); Tone.stop(); return; }
    if (Call.st !== 'idle') return;
    b.innerHTML = `<div><b>${ring.video ? '🎥' : '📞'} ${esc(Chats.titleOf(c))}</b><span>звонит вам</span></div>
      <button class="cr-no">Отклонить</button><button class="cr-yes">Ответить</button>`;
    b.classList.remove('hidden'); Tone.loop('ring'); vibrate(200);
    b.querySelector('.cr-yes').onclick = () => { Tone.stop(); b.classList.add('hidden'); try { sessionStorage.setItem('nc_autoacc', ring.id); } catch (_) { } Chats.open(c.id); };
    b.querySelector('.cr-no').onclick = () => {
      Tone.stop(); b.classList.add('hidden');
      fetch(c.url + '/api/ring', { method: 'POST', headers: { Authorization: 'Bearer ' + c.token, 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, id: ring.id, act: 'decline' }) }).catch(() => { });
    };
  },
};
$('#cl-list').addEventListener('click', e => { const b = e.target.closest('[data-chat]'); if (b) Chats.open(b.dataset.chat); });
$('#chat-back').onclick = () => Chats.showList();
$('#cl-new').onclick = () => NewChat.menu();
$('#cl-menu').onclick = () => { show('chat'); Drawer.open(); };

/* ================= новый чат ================= */
const NewChat = {
  menu() {
    sheet([
      { icon: 'reply', label: '👤 Личный чат', fn: () => this.make('dm') },
      { icon: 'reply', label: '👥 Новая группа', fn: () => this.group() },
      { icon: 'link', label: '🔑 Вступить по коду приглашения', fn: () => this.joinForm() },
    ], 'Новый чат появится у вас, а второму человеку нужно отправить код приглашения.');
  },
  group() {
    Form.open({
      title: 'Новая группа', saveLabel: 'Создать',
      fields: [{ k: 'title', label: 'Название группы', ph: 'Например: Семья', focus: true, max: 60 }],
      onSave: v => { const t = String(v.title || '').trim(); if (!t) return 'Введите название'; this.make('group', t); },
    });
  },
  async make(kind, title) {
    toast('Создаю чат…', 1500);
    try {
      const id = await Chats.create(kind, title);
      const c = Chats.keys.get(id);
      this.showCode(Chats.code(c.raw, c.url, kind, title), id, true);
    } catch (e) { toast(e.message, 5000); }
  },
  showCode(code, id, isNew) {
    $('#inv-code').textContent = code;
    $('#inv-title').textContent = isNew ? 'Чат создан! Отправьте код' : 'Код приглашения';
    $('#inv-text').textContent = 'Перешлите этот код тому, кого хотите позвать. Он ставит «Наш чат» и вводит код при первом запуске (или в списке чатов: «＋» → «Вступить по коду»). Приглашать может любой участник чата.';
    $('#inv-share').classList.toggle('hidden', !(Native && Native.shareText));
    $('#inv-done').textContent = isNew ? 'Перейти в чат' : 'Готово';
    $('#inv-done').onclick = () => { if (isNew) Chats.open(id); else show('chat'); };
    show('invite');
  },
  joinForm() {
    Form.open({
      title: 'Вступить по коду', saveLabel: 'Вступить',
      fields: [{ k: 'code', label: 'Код приглашения', type: 'textarea', ph: 'NC2.…' }],
      onSave: v => {
        const code = String(v.code || '').trim(); if (!code) return 'Вставьте код';
        Chats.join(code).then(id => { toast('Готово! Вы в чате 🎉'); setTimeout(() => Chats.open(id), 400); }).catch(e => toast(e.message, 5000));
      },
    });
  },
};
$('#inv-share').onclick = () => { try { Native.shareText($('#inv-code').textContent); } catch (_) { } };

/* ================= группа ================= */
const Group = {
  ID: 'grp_info',
  info() { return Docs.get(this.ID); },
  title() { const i = this.info(); return (i && i.title) || Chats.titleOf(Chats.cur()); },
  ensure() {
    if (!CHAT.isGroup() || !Docs.ready) return;
    if (!this.info() && Chats.cur().title) Docs.put(this.ID, { c: 'grp', title: Chats.cur().title, avatar: '' });
  },
  members() {
    const out = new Map();
    for (const [dev, n] of Object.entries(S.names || {})) out.set(dev, n);
    for (const p of Docs.list('prof')) if (p.dev) out.set(p.dev, p.name || out.get(p.dev) || 'Участник');
    out.set(S.dev, S.name);
    return out;
  },
  drawHeader() {
    const i = this.info(), t = this.title();
    $('#partner-name').textContent = t;
    const av = $('#partner-av');
    if (i && i.avatar) { av.style.backgroundImage = `url("${i.avatar}")`; av.classList.add('photo'); av.textContent = ''; }
    else { av.style.backgroundImage = ''; av.classList.remove('photo'); av.textContent = '👥'; av.style.background = colorOf(CHAT.id); }
    Chats.setMeta(CHAT.id, { title: t, avatar: (i && i.avatar) || '' });
  },
  edit() {
    const i = this.info() || {};
    Form.open({
      title: 'Группа', fields: [{ k: 'title', label: 'Название', max: 60, focus: true }],
      values: { title: this.title() },
      onSave: v => { const t = String(v.title || '').trim(); if (!t) return 'Введите название'; Docs.put(this.ID, { c: 'grp', title: t, avatar: i.avatar || '' }); },
    });
  },
  pickPhoto() {
    const inp = $('#pick-gav');
    inp.onchange = async () => {
      const f = inp.files[0]; inp.value = ''; if (!f) return;
      try {
        const img = await loadImage(f), s = Math.min(img.width, img.height), c = document.createElement('canvas'); c.width = c.height = 256;
        c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 256, 256);
        const i = this.info() || {};
        Docs.put(this.ID, { c: 'grp', title: this.title(), avatar: c.toDataURL('image/jpeg', 0.82) }); toast('Фото группы обновлено');
      } catch (_) { toast('Не удалось открыть фото'); }
    };
    inp.click();
  },
  showMembers() {
    const pres = Presence.raw || {}, list = [...this.members()].map(([dev, n]) => {
      const p = pres[dev], on = p && (p.s === 'online' || p.s === 'typing' || p.s === 'voice' || p.s === 'circle');
      return { dev, n, on };
    }).sort((a, b) => (b.dev === S.dev) - (a.dev === S.dev) || b.on - a.on || a.n.localeCompare(b.n));
    sheet(list.map(x => ({ icon: 'smile', label: (x.on ? '🟢 ' : '⚪ ') + x.n + (x.dev === S.dev ? ' (вы)' : ''), fn: () => { } })), `В группе ${list.length} ${plural(list.length, 'участник', 'участника', 'участников')}`);
  },
};

/* ================= закреплённые сообщения ================= */
const Pins = {
  idx: 0,
  idOf(mid) { return 'pin_' + String(mid).padStart(6, '0'); },
  list() { return Docs.list('pin').sort((a, b) => b.at - a.at); },
  has(mid) { return !!Docs.get(this.idOf(mid)); },
  toggle(m) {
    const id = this.idOf(m.id);
    if (Docs.get(id)) { Docs.del(id); toast('Сообщение откреплено'); }
    else { Docs.put(id, { c: 'pin', mid: m.id, snip: snippetOf(m), who: m.mine ? S.name : (m.p && m.p.n) || S.partner || '', at: Date.now() }); toast('📌 Сообщение закреплено'); this.idx = 0; }
  },
  draw() {
    const l = this.list(), bar = $('#pinbar'), ids = new Set(l.map(p => p.mid));
    document.querySelectorAll('.msg[data-id]').forEach(el => el.classList.toggle('pinned', ids.has(+el.dataset.id)));
    if (!l.length) { bar.classList.add('hidden'); return; }
    if (this.idx >= l.length) this.idx = 0;
    const p = l[this.idx];
    bar.classList.remove('hidden');
    $('#pb-title').textContent = l.length > 1 ? `Закреплено ${this.idx + 1} из ${l.length}` : 'Закреплённое сообщение';
    $('#pb-text').textContent = p.snip || 'Сообщение';
    $('#pb-lines').innerHTML = l.length > 1 ? l.map((_, i) => `<i class="${i === this.idx ? 'on' : ''}"></i>`).join('') : '<i class="on"></i>';
  },
  async jump() {
    const l = this.list(); if (!l.length) return;
    const p = l[this.idx % l.length];
    this.idx = (this.idx + 1) % l.length; this.draw();
    let tries = 0;
    while (!document.querySelector(`.msg[data-id="${p.mid}"]`) && !S.noMoreOlder && tries++ < 25 && (S.oldestLoaded || 0) > p.mid) { await loadOlder(); }
    if (!document.querySelector(`.msg[data-id="${p.mid}"]`)) { toast('Это сообщение больше недоступно'); return; }
    Reply.jump(p.mid);
  },
  list_() {
    const l = this.list();
    sheet(l.map(p => ({ icon: 'reply', label: '📌 ' + (p.snip || 'Сообщение').slice(0, 60), fn: () => { this.idx = l.indexOf(p); this.jump(); } })), 'Закреплённые сообщения');
  },
};
$('#pinbar').addEventListener('click', e => {
  if (e.target.closest('#pb-x')) {
    const l = Pins.list(); const p = l[(Pins.idx + l.length - 1) % l.length] || l[0];
    if (p) sheet([{ icon: 'x', label: 'Открепить это сообщение', danger: true, fn: () => { Docs.del(Pins.idOf(p.mid)); } }, ...(l.length > 1 ? [{ icon: 'reply', label: 'Все закреплённые (' + l.length + ')', fn: () => Pins.list_() }] : [])]);
    return;
  }
  Pins.jump();
});
Docs.on(() => {
  Pins.draw();
  if (CHAT.isGroup()) { Group.ensure(); Group.drawHeader(); }
});
