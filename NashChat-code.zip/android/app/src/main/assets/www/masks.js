'use strict';
/* «Наш чат» — маски и фильтры для видеозвонка.
   Кадры с камеры рисуются на холсте, поверх — маска по положению лица.
   Лицо ищет небольшая нейросеть прямо на телефоне (face-api.js, лицензия MIT): видео никуда не уходит. */

const MASKS = [
  { id: 'none', e: '🚫', t: 'Без маски' },
  { id: 'cat', e: '🐱', t: 'Котик', face: true },
  { id: 'bunny', e: '🐰', t: 'Зайка', face: true },
  { id: 'bear', e: '🐻', t: 'Мишка', face: true },
  { id: 'dog', e: '🐶', t: 'Щенок', face: true },
  { id: 'fox', e: '🦊', t: 'Лисичка', face: true },
  { id: 'unicorn', e: '🦄', t: 'Единорог', face: true },
  { id: 'bow', e: '🎀', t: 'Бантик', face: true },
  { id: 'tiara', e: '👸', t: 'Принцесса', face: true },
  { id: 'wreath', e: '🌸', t: 'Веночек', face: true },
  { id: 'hglass', e: '😍', t: 'Очки-сердца', face: true },
  { id: 'cutie', e: '☺️', t: 'Милашка', face: true },
  { id: 'hearts', e: '💕', t: 'Сердечки', face: true },
  { id: 'bw', e: '⚫', t: 'Ч/Б', filter: 'grayscale(1) contrast(1.1)' },
  { id: 'sepia', e: '🟤', t: 'Сепия', filter: 'sepia(.85) contrast(1.05)' },
  { id: 'warm', e: '🌅', t: 'Тёплый', filter: 'saturate(1.3) sepia(.22) brightness(1.05)' },
  { id: 'cold', e: '❄️', t: 'Холодный', filter: 'saturate(1.1) hue-rotate(12deg) brightness(1.03) contrast(1.05)' },
  { id: 'retro', e: '📼', t: 'Ретро', filter: 'contrast(1.2) saturate(.7) sepia(.35)' },
  { id: 'soft', e: '✨', t: 'Мягкий', filter: 'brightness(1.08) contrast(.92) saturate(1.12) blur(.6px)' },
];

const Masks = {
  cur: 'none', running: false, video: null, canvas: null, ctx: null, out: null, raf: 0, cam: null,
  model: 'none', // none | loading | ready | fail
  face: null, faceAt: 0, detBusy: false, detT: 0, small: null, sctx: null, hintT: 0, startAt: 0,
  get(id) { return MASKS.find(m => m.id === id) || MASKS[0]; },
  // ---------- модель лица ----------
  loadModel() {
    if (this.model !== 'none') return;
    this.model = 'loading';
    const s = document.createElement('script');
    s.src = 'vendor/faceapi/face-api.min.js';
    s.onload = async () => {
      try {
        await faceapi.nets.tinyFaceDetector.loadFromUri('vendor/faceapi');
        await faceapi.nets.faceLandmark68TinyNet.loadFromUri('vendor/faceapi');
        this.opts = new faceapi.TinyFaceDetectorOptions({ inputSize: 256, scoreThreshold: 0.3 });
        this.model = 'ready';
      } catch (e) { console.error(e); this.model = 'fail'; }
    };
    s.onerror = () => { this.model = 'fail'; };
    document.head.appendChild(s);
  },
  // ---------- конвейер ----------
  start(camTrack) {
    if (this.running) { this.setCam(camTrack); return this.out; }
    this.running = true; this.startAt = Date.now();
    this.video = document.createElement('video'); this.video.muted = true; this.video.playsInline = true; this.video.setAttribute('playsinline', '');
    this.canvas = document.createElement('canvas'); this.canvas.width = 480; this.canvas.height = 640;
    this.ctx = this.canvas.getContext('2d');
    this.small = document.createElement('canvas'); this.sctx = this.small.getContext('2d', { willReadFrequently: true });
    this.setCam(camTrack);
    this.out = this.canvas.captureStream(24).getVideoTracks()[0];
    const loop = () => { if (!this.running) return; this.draw(); this.raf = requestAnimationFrame(loop); };
    // requestAnimationFrame замирает в свёрнутом окне — подстраховываемся таймером
    this.tick = setInterval(() => { if (this.running && document.hidden) this.draw(); }, 50);
    loop();
    return this.out;
  },
  setCam(track) {
    this.cam = track;
    if (!this.video) return;
    this.video.srcObject = new MediaStream([track]);
    this.video.play().catch(() => { });
    this.face = null;
  },
  stop() {
    this.running = false; cancelAnimationFrame(this.raf); clearInterval(this.tick);
    if (this.out) { try { this.out.stop(); } catch (_) { } }
    if (this.video) this.video.srcObject = null;
    this.video = this.canvas = this.ctx = this.out = this.small = this.sctx = null; this.face = null;
    this.hint('');
  },
  set(id) {
    this.cur = id; this.face = null; this.startAt = Date.now();
    const m = this.get(id);
    if (m.face) this.loadModel(); else this.hint('');
  },
  hint(t) { const el = document.getElementById('cu-mhint'); if (el && el.textContent !== t) el.textContent = t; },
  // ---------- кадр ----------
  draw() {
    const v = this.video, c = this.canvas, g = this.ctx;
    if (!v || v.readyState < 2 || !v.videoWidth) return;
    if (v.paused) v.play().catch(() => { });
    if (c.width !== v.videoWidth || c.height !== v.videoHeight) { c.width = v.videoWidth; c.height = v.videoHeight; }
    const m = this.get(this.cur);
    g.filter = m.filter || 'none';
    g.drawImage(v, 0, 0, c.width, c.height);
    g.filter = 'none';
    if (m.face) {
      this.detect();
      const age = Date.now() - this.faceAt;
      if (this.face && age < 2500) {
        g.save(); g.globalAlpha = age < 1200 ? 1 : Math.max(0, 1 - (age - 1200) / 1300);
        try { this.overlay(m.id, this.face); } catch (e) { console.error(e); }
        g.restore();
      }
      // подсказка, если маска не появляется
      if (Date.now() - this.hintT > 400) {
        this.hintT = Date.now();
        this.hint(this.model === 'loading' || this.model === 'none' ? '⏳ Загружаю маски…' : this.model === 'fail' ? 'Маски не загрузились — перезапустите приложение' : (age > 1500 && Date.now() - this.startAt > 1500) ? '🙂 Покажите лицо в камеру' : '');
      }
    }
  },
  async detect() {
    if (this.model !== 'ready' || this.detBusy || Date.now() - this.detT < 80) return;
    this.detBusy = true; this.detT = Date.now();
    try {
      // ищем лицо на уменьшенной копии кадра — так быстрее и стабильнее
      const v = this.video, W = v.videoWidth, H = v.videoHeight, sc = Math.min(1, 320 / Math.max(W, H));
      const sw = Math.round(W * sc), sh = Math.round(H * sc);
      if (this.small.width !== sw || this.small.height !== sh) { this.small.width = sw; this.small.height = sh; }
      this.sctx.drawImage(v, 0, 0, sw, sh);
      const r = await faceapi.detectSingleFace(this.small, this.opts).withFaceLandmarks(true);
      if (r && this.running) {
        const k = 1 / sc, p = r.landmarks.positions.map(q => ({ x: q.x * k, y: q.y * k }));
        const avg = (a, b) => { let x = 0, y = 0; for (let i = a; i <= b; i++) { x += p[i].x; y += p[i].y; } const n = b - a + 1; return { x: x / n, y: y / n }; };
        const eL = avg(36, 41), eR = avg(42, 47), nose = p[30], mouth = avg(48, 59);
        const f = { cx: (eL.x + eR.x) / 2, cy: (eL.y + eR.y) / 2, ang: Math.atan2(eR.y - eL.y, eR.x - eL.x), u: Math.hypot(eR.x - eL.x, eR.y - eL.y), nx: 0, ny: 0.8, mx: 0, my: 1.35 };
        // нос и рот — в координатах лица (единица — расстояние между глаз)
        const loc = pt => { const dx = pt.x - f.cx, dy = pt.y - f.cy, c = Math.cos(-f.ang), s = Math.sin(-f.ang); return { x: (dx * c - dy * s) / f.u, y: (dx * s + dy * c) / f.u }; };
        const n = loc(nose), mo = loc(mouth); f.nx = n.x; f.ny = n.y; f.mx = mo.x; f.my = mo.y;
        // сглаживание, чтобы маска не дрожала
        const o = this.face, sm = 0.5;
        if (o && Date.now() - this.faceAt < 700) for (const key of ['cx', 'cy', 'u', 'ang', 'nx', 'ny', 'mx', 'my']) f[key] = o[key] + (f[key] - o[key]) * sm;
        this.face = f; this.faceAt = Date.now();
      }
    } catch (_) { }
    this.detBusy = false;
  },
  // ---------- рисовалки ----------
  ell(x, y, rx, ry, rot) { const g = this.ctx; g.beginPath(); g.ellipse(x, y, Math.abs(rx), Math.abs(ry), rot || 0, 0, Math.PI * 2); },
  heart(x, y, s, rot) {
    const g = this.ctx; g.save(); g.translate(x, y); if (rot) g.rotate(rot); g.scale(s, s);
    g.beginPath(); g.moveTo(0, 0.35);
    g.bezierCurveTo(-0.15, 0.22, -0.55, 0.02, -0.5, -0.22); g.bezierCurveTo(-0.45, -0.48, -0.1, -0.5, 0, -0.25);
    g.bezierCurveTo(0.1, -0.5, 0.45, -0.48, 0.5, -0.22); g.bezierCurveTo(0.55, 0.02, 0.15, 0.22, 0, 0.35);
    g.closePath(); g.restore();
  },
  fillHeart(x, y, s, color, rot) {
    const g = this.ctx; this.heart(x, y, s, rot); g.fillStyle = color; g.fill();
    g.fillStyle = 'rgba(255,255,255,.55)'; this.ell(x - s * 0.22, y - s * 0.22, s * 0.09, s * 0.06, -0.6); g.fill();
  },
  sparkle(x, y, s, color) {
    const g = this.ctx; g.save(); g.translate(x, y); g.fillStyle = color || '#fff8d6';
    g.shadowColor = 'rgba(255,255,255,.9)'; g.shadowBlur = 0; g.beginPath();
    g.moveTo(0, -s); g.quadraticCurveTo(0, 0, s, 0); g.quadraticCurveTo(0, 0, 0, s); g.quadraticCurveTo(0, 0, -s, 0); g.quadraticCurveTo(0, 0, 0, -s);
    g.fill(); g.restore();
  },
  blush(x, y, r, a) {
    const g = this.ctx, gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, `rgba(255,110,150,${a || .5})`); gr.addColorStop(1, 'rgba(255,110,150,0)');
    g.fillStyle = gr; this.ell(x, y, r, r * 0.75); g.fill();
  },
  cheeks(a) { this.blush(-0.85, 0.75, 0.45, a); this.blush(0.85, 0.75, 0.45, a); },
  // заострённое ушко: основание (x, y), ширина w, высота h
  ear(x, y, w, h, rot, c1, c2, inner, tip) {
    const g = this.ctx; g.save(); g.translate(x, y); g.rotate(rot);
    const path = (W, H) => { g.beginPath(); g.moveTo(-W / 2, 0); g.bezierCurveTo(-W * 0.48, -H * 0.55, -W * 0.18, -H, 0, -H); g.bezierCurveTo(W * 0.18, -H, W * 0.48, -H * 0.55, W / 2, 0); g.quadraticCurveTo(0, H * 0.12, -W / 2, 0); g.closePath(); };
    const gr = g.createLinearGradient(0, -h, 0, 0); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
    path(w, h); g.fillStyle = gr; g.fill();
    g.lineWidth = 0.04; g.strokeStyle = 'rgba(80,40,30,.25)'; g.stroke();
    if (tip) { g.save(); path(w, h); g.clip(); g.fillStyle = tip; g.fillRect(-w, -h * 1.1, w * 2, h * 0.3); g.restore(); }
    g.translate(0, -h * 0.06); path(w * 0.55, h * 0.72);
    const gi = g.createLinearGradient(0, -h * 0.7, 0, 0); gi.addColorStop(0, inner); gi.addColorStop(1, 'rgba(255,255,255,.85)');
    g.fillStyle = gi; g.fill();
    g.restore();
  },
  roundEar(x, y, r, c, inner) {
    const g = this.ctx; g.fillStyle = c; this.ell(x, y, r, r); g.fill();
    g.lineWidth = 0.04; g.strokeStyle = 'rgba(60,30,10,.25)'; g.stroke();
    g.fillStyle = inner; this.ell(x, y + r * 0.08, r * 0.6, r * 0.58); g.fill();
  },
  flower(x, y, r, petal, center, rot) {
    const g = this.ctx; g.save(); g.translate(x, y); g.rotate(rot || 0);
    g.fillStyle = petal;
    for (let i = 0; i < 5; i++) { g.save(); g.rotate(i * Math.PI * 2 / 5); this.ell(0, -r * 0.55, r * 0.42, r * 0.58); g.fill(); g.restore(); }
    g.fillStyle = 'rgba(255,255,255,.35)';
    for (let i = 0; i < 5; i++) { g.save(); g.rotate(i * Math.PI * 2 / 5); this.ell(0, -r * 0.62, r * 0.14, r * 0.28); g.fill(); g.restore(); }
    g.fillStyle = center; this.ell(0, 0, r * 0.3, r * 0.3); g.fill();
    g.restore();
  },
  leaf(x, y, s, rot) {
    const g = this.ctx; g.save(); g.translate(x, y); g.rotate(rot); g.fillStyle = '#7cc97a';
    g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(s * 0.5, -s * 0.5, 0, -s); g.quadraticCurveTo(-s * 0.5, -s * 0.5, 0, 0); g.fill(); g.restore();
  },
  bowShape(x, y, s, c1, c2) {
    const g = this.ctx; g.save(); g.translate(x, y); g.scale(s, s);
    for (const sx of [-1, 1]) {
      const gr = g.createLinearGradient(0, -0.5, 0, 0.5); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
      g.fillStyle = gr; g.beginPath(); g.moveTo(0, 0);
      g.bezierCurveTo(sx * 0.35, -0.65, sx * 1.15, -0.6, sx * 1.05, 0); g.bezierCurveTo(sx * 1.15, 0.6, sx * 0.35, 0.65, 0, 0); g.fill();
      g.strokeStyle = 'rgba(160,30,80,.25)'; g.lineWidth = 0.05; g.stroke();
      g.fillStyle = 'rgba(255,255,255,.35)'; this.ell(sx * 0.62, -0.22, 0.22, 0.08, sx * -0.3); g.fill();
      // хвостики ленты
      g.fillStyle = c2; g.beginPath(); g.moveTo(sx * 0.08, 0.1); g.lineTo(sx * 0.55, 0.95); g.lineTo(sx * 0.4, 0.82); g.lineTo(sx * 0.3, 1.0); g.lineTo(sx * -0.05, 0.15); g.fill();
    }
    g.fillStyle = c1; this.ell(0, 0, 0.24, 0.27); g.fill();
    g.fillStyle = 'rgba(255,255,255,.4)'; this.ell(-0.06, -0.08, 0.08, 0.06); g.fill();
    g.restore();
  },
  nosePink(x, y, s) { const g = this.ctx; this.heart(x, y, s, Math.PI); g.fillStyle = '#ff7fa3'; g.fill(); g.fillStyle = 'rgba(255,255,255,.6)'; this.ell(x - s * 0.15, y - s * 0.12, s * 0.08, s * 0.05); g.fill(); },
  emoji(ch, x, y, size) {
    const g = this.ctx; g.save(); g.translate(x, y);
    g.font = `${Math.round(size * 100)}px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif`;
    g.scale(0.01, 0.01); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(ch, 0, 0); g.restore();
  },
  // ---------- маски ----------
  // координаты: центр между глаз, ось X вдоль глаз, единица — расстояние между глаз.
  // брови ≈ −0.4, линия волос ≈ −1.3, макушка ≈ −2, нос ≈ f.ny, рот ≈ f.my
  overlay(id, f) {
    const g = this.ctx, t = Date.now() / 1000;
    g.save(); g.translate(f.cx, f.cy); g.rotate(f.ang); g.scale(f.u, f.u);
    g.lineCap = 'round'; g.lineJoin = 'round';
    const nx = f.nx, ny = f.ny, mx = f.mx, my = f.my, wob = Math.sin(t * 2.2) * 0.04;
    switch (id) {
      case 'cat': {
        this.ear(-1.05, -1.45, 1.05, 1.15, -0.32 + wob, '#ffcf9e', '#f5a55e', '#ffb3c8');
        this.ear(1.05, -1.45, 1.05, 1.15, 0.32 - wob, '#ffcf9e', '#f5a55e', '#ffb3c8');
        this.cheeks(.45);
        this.nosePink(nx, ny - 0.02, 0.36);
        g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 0.045;
        for (const sx of [-1, 1]) for (const d of [-0.14, 0.02, 0.18]) { g.beginPath(); g.moveTo(nx + sx * 0.38, ny + 0.1 + d * 0.3); g.quadraticCurveTo(nx + sx * 0.8, ny + 0.05 + d, nx + sx * 1.2, ny + 0.02 + d * 2); g.stroke(); }
        break;
      }
      case 'bunny': {
        const sw = Math.sin(t * 1.6) * 0.06;
        this.ear(-0.5, -1.35, 0.62, 2.0, -0.16 + sw, '#ffffff', '#f3eef0', '#ffb3c8');
        this.ear(0.5, -1.35, 0.62, 2.0, 0.16 - sw, '#ffffff', '#f3eef0', '#ffb3c8');
        this.bowShape(0.62, -1.42, 0.28, '#ff9ec0', '#ff6f9f');
        this.cheeks(.5);
        this.nosePink(nx, ny - 0.02, 0.3);
        g.fillStyle = '#fff'; g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 0.025;
        for (const sx of [-1, 1]) { g.beginPath(); g.roundRect ? g.roundRect(mx + (sx < 0 ? -0.15 : 0.01), my - 0.08, 0.14, 0.24, 0.04) : g.rect(mx + (sx < 0 ? -0.15 : 0.01), my - 0.08, 0.14, 0.24); g.fill(); g.stroke(); }
        break;
      }
      case 'bear': {
        this.roundEar(-1.15, -1.45, 0.5, '#a5703f', '#e9c39b');
        this.roundEar(1.15, -1.45, 0.5, '#a5703f', '#e9c39b');
        this.cheeks(.45);
        g.fillStyle = 'rgba(240,210,170,.92)'; this.ell(nx, ny + 0.12, 0.48, 0.36); g.fill();
        g.fillStyle = '#4a2c1a'; this.ell(nx, ny - 0.02, 0.2, 0.14); g.fill();
        g.fillStyle = 'rgba(255,255,255,.6)'; this.ell(nx - 0.07, ny - 0.07, 0.06, 0.035); g.fill();
        g.strokeStyle = '#4a2c1a'; g.lineWidth = 0.04; g.beginPath(); g.moveTo(nx, ny + 0.12); g.lineTo(nx, ny + 0.24); g.stroke();
        break;
      }
      case 'dog': {
        for (const sx of [-1, 1]) {
          g.save(); g.translate(sx * 1.25, -1.05); g.rotate(sx * (0.28 + wob));
          const gr = g.createLinearGradient(0, 0, 0, 1.6); gr.addColorStop(0, '#b07a4a'); gr.addColorStop(1, '#8a5a32');
          g.fillStyle = gr; g.beginPath(); g.moveTo(-0.25, 0); g.bezierCurveTo(-0.7, 0.2, -0.55, 1.5, 0.05, 1.55); g.bezierCurveTo(0.5, 1.5, 0.45, 0.3, 0.25, 0); g.closePath(); g.fill();
          g.restore();
        }
        this.cheeks(.4);
        g.fillStyle = '#2b1d14'; this.ell(nx, ny - 0.02, 0.27, 0.18); g.fill();
        g.fillStyle = 'rgba(255,255,255,.65)'; this.ell(nx - 0.09, ny - 0.08, 0.07, 0.04); g.fill();
        g.fillStyle = '#ff7f9c'; g.beginPath(); g.ellipse(mx, my + 0.22 + Math.sin(t * 5) * 0.03, 0.17, 0.26, 0, 0, Math.PI); g.fill();
        g.strokeStyle = '#e0607e'; g.lineWidth = 0.025; g.beginPath(); g.moveTo(mx, my + 0.24); g.lineTo(mx, my + 0.42); g.stroke();
        break;
      }
      case 'fox': {
        this.ear(-1.0, -1.4, 0.95, 1.25, -0.3 + wob, '#ff9a4d', '#f2782a', '#fff1e3', '#5a3524');
        this.ear(1.0, -1.4, 0.95, 1.25, 0.3 - wob, '#ff9a4d', '#f2782a', '#fff1e3', '#5a3524');
        this.cheeks(.42);
        g.fillStyle = '#2b1d14'; this.ell(nx, ny - 0.03, 0.17, 0.12); g.fill();
        g.fillStyle = 'rgba(255,255,255,.6)'; this.ell(nx - 0.05, ny - 0.07, 0.05, 0.03); g.fill();
        g.strokeStyle = 'rgba(60,35,20,.8)'; g.lineWidth = 0.03;
        for (const sx of [-1, 1]) for (const d of [-0.06, 0.08]) { g.beginPath(); g.moveTo(nx + sx * 0.3, ny + 0.08 + d * 0.3); g.lineTo(nx + sx * 0.85, ny + d * 1.6); g.stroke(); }
        break;
      }
      case 'unicorn': {
        // цветочки у основания рога
        const cols = ['#ffb3d1', '#c9b6ff', '#a8e6ff', '#fff3a8', '#ffc8a8'];
        [-1.15, -0.75, 0.75, 1.15].forEach((x, i) => this.flower(x, -1.42 - (Math.abs(x) < 1 ? 0.08 : 0), 0.32, cols[i], '#fff6c2', t * 0.3 + i));
        // рог
        g.save(); g.translate(0, -1.45);
        const gr = g.createLinearGradient(-0.3, 0, 0.3, -1.6); gr.addColorStop(0, '#fff3c4'); gr.addColorStop(.5, '#ffd6f0'); gr.addColorStop(1, '#d6c4ff');
        g.fillStyle = gr; g.beginPath(); g.moveTo(-0.3, 0); g.quadraticCurveTo(-0.08, -0.9, 0, -1.65); g.quadraticCurveTo(0.08, -0.9, 0.3, 0); g.closePath(); g.fill();
        g.strokeStyle = 'rgba(200,150,220,.7)'; g.lineWidth = 0.035;
        for (let i = 1; i <= 4; i++) { const yy = -i * 0.32, w = 0.3 * (1 - i / 5.2); g.beginPath(); g.moveTo(-w, yy + 0.08); g.quadraticCurveTo(0, yy - 0.04, w, yy - 0.06); g.stroke(); }
        g.restore();
        this.cheeks(.42);
        for (let i = 0; i < 4; i++) { const a = t * 1.2 + i * 1.6; this.sparkle(Math.cos(a) * 1.5, -2.2 + Math.sin(a * 1.3) * 0.4, 0.13 + Math.abs(Math.sin(t * 3 + i)) * 0.09); }
        break;
      }
      case 'bow': {
        this.bowShape(0, -1.75, 0.95 + Math.sin(t * 2) * 0.02, '#ff9ec7', '#ff5f9e');
        this.cheeks(.5);
        this.fillHeart(1.35, -1.0 + Math.sin(t * 2.5) * 0.08, 0.32, '#ff6f9f', 0.2);
        this.fillHeart(-1.4, -0.75 + Math.cos(t * 2.5) * 0.08, 0.24, '#ff9ec7', -0.2);
        break;
      }
      case 'tiara': {
        g.save(); g.translate(0, -1.4); g.scale(1.3, 1.3);
        const gr = g.createLinearGradient(0, -0.8, 0, 0.1); gr.addColorStop(0, '#fff2a8'); gr.addColorStop(1, '#e6b33c');
        g.fillStyle = gr; g.strokeStyle = 'rgba(150,100,20,.5)'; g.lineWidth = 0.035;
        g.beginPath(); g.moveTo(-1.05, 0.12); g.quadraticCurveTo(0, -0.12, 1.05, 0.12);
        const pts = [[0.9, -0.25], [0.68, -0.05], [0.45, -0.5], [0.22, -0.12], [0, -0.85], [-0.22, -0.12], [-0.45, -0.5], [-0.68, -0.05], [-0.9, -0.25]];
        g.lineTo(1.0, -0.02); pts.forEach(([x, y]) => g.lineTo(x, y)); g.lineTo(-1.0, -0.02); g.closePath(); g.fill(); g.stroke();
        const gem = (x, y, r, c) => { g.fillStyle = c; this.ell(x, y, r, r * 1.15); g.fill(); g.fillStyle = 'rgba(255,255,255,.7)'; this.ell(x - r * 0.3, y - r * 0.35, r * 0.3, r * 0.22); g.fill(); };
        gem(0, -0.38, 0.14, '#ff6fa8'); gem(-0.45, -0.18, 0.09, '#9fd8ff'); gem(0.45, -0.18, 0.09, '#9fd8ff');
        g.fillStyle = '#fff'; [[0, -0.85], [-0.45, -0.5], [0.45, -0.5], [-0.9, -0.25], [0.9, -0.25]].forEach(([x, y]) => { this.ell(x, y, 0.06, 0.06); g.fill(); });
        g.restore();
        this.cheeks(.35);
        for (let i = 0; i < 5; i++) { const ph = (t * 0.8 + i * 0.37) % 1; this.sparkle(-1.2 + i * 0.6, -2.0 - ph * 0.6, 0.16 * Math.sin(ph * Math.PI)); }
        break;
      }
      case 'wreath': {
        const cols = [['#ffb3cf', '#ffe066'], ['#ffffff', '#ffd43b'], ['#c9b3ff', '#fff3b0'], ['#ff8fab', '#ffe066'], ['#ffd8a8', '#ff9f43']];
        const N = 11;
        for (let i = 0; i < N; i++) { const a = Math.PI * 1.08 + (i / (N - 1)) * Math.PI * 0.84; this.leaf(Math.cos(a) * 1.55, -0.95 + Math.sin(a) * 0.95, 0.42, a + Math.PI / 2 + 0.6); }
        for (let i = 0; i < N; i++) {
          const a = Math.PI * 1.05 + (i / (N - 1)) * Math.PI * 0.9, c = cols[i % cols.length];
          this.flower(Math.cos(a) * 1.5, -0.95 + Math.sin(a) * 0.92, i % 2 ? 0.27 : 0.34, c[0], c[1], a + t * 0.2);
        }
        this.cheeks(.35);
        break;
      }
      case 'hglass': {
        for (const sx of [-1, 1]) {
          this.heart(sx * 0.52, 0.05, 1.0, 0);
          g.fillStyle = 'rgba(255,90,150,.45)'; g.fill();
          g.strokeStyle = '#ff4f93'; g.lineWidth = 0.09; g.stroke();
          g.fillStyle = 'rgba(255,255,255,.55)'; this.ell(sx * 0.52 - 0.2, -0.12, 0.08, 0.05, -0.5); g.fill();
        }
        g.strokeStyle = '#ff4f93'; g.lineWidth = 0.08; g.beginPath(); g.moveTo(-0.12, -0.08); g.quadraticCurveTo(0, -0.16, 0.12, -0.08); g.stroke();
        g.beginPath(); g.moveTo(-1.0, -0.12); g.lineTo(-1.25, -0.2); g.moveTo(1.0, -0.12); g.lineTo(1.25, -0.2); g.stroke();
        for (let i = 0; i < 3; i++) { const ph = (t * 0.6 + i / 3) % 1; this.fillHeart(1.5 + Math.sin(ph * 6 + i) * 0.15, -0.6 - ph * 1.6, 0.28 * (1 - ph * 0.5), `rgba(255,95,155,${1 - ph})`); }
        break;
      }
      case 'cutie': {
        this.cheeks(.6);
        g.fillStyle = 'rgba(150,85,55,.55)';
        [[-0.75, 0.5], [-0.6, 0.62], [-0.88, 0.66], [-0.7, 0.78], [0.75, 0.5], [0.6, 0.62], [0.88, 0.66], [0.7, 0.78]].forEach(([x, y]) => { this.ell(x, y, 0.035, 0.03); g.fill(); });
        this.sparkle(1.25, -0.55, 0.2 + Math.abs(Math.sin(t * 3)) * 0.1);
        this.sparkle(-1.3, -0.9, 0.15 + Math.abs(Math.cos(t * 3)) * 0.08);
        this.sparkle(1.05, -1.25, 0.1 + Math.abs(Math.sin(t * 4 + 1)) * 0.06);
        this.fillHeart(-1.15, 1.2, 0.25 + Math.sin(t * 3) * 0.03, '#ff6f9f', -0.3);
        break;
      }
      case 'hearts': {
        const cols = ['#ff5f9e', '#ff9ec7', '#ff3d6e', '#ffb3d1'];
        for (let i = 0; i < 7; i++) { const a = t * 1.1 + i * Math.PI * 2 / 7, depth = (Math.sin(a) + 1) / 2; this.fillHeart(Math.cos(a) * 1.75, -1.75 + Math.sin(a) * 0.4, 0.3 + depth * 0.18, cols[i % 4], Math.cos(a) * 0.3); }
        this.cheeks(.4);
        break;
      }
    }
    g.restore();
  },
};
