'use strict';
/* «Наш чат» — маски и фильтры для видеозвонка.
   Кадры с камеры рисуются на холсте, поверх — маска по положению лица.
   Лицо ищет небольшая нейросеть прямо на телефоне (face-api.js, лицензия MIT): видео никуда не уходит. */

const MASKS = [
  { id: 'none', e: '🚫', t: 'Без маски' },
  { id: 'cat', e: '🐱', t: 'Котик', face: true },
  { id: 'bunny', e: '🐰', t: 'Зайка', face: true },
  { id: 'dog', e: '🐶', t: 'Щенок', face: true },
  { id: 'crown', e: '👑', t: 'Корона', face: true },
  { id: 'glasses', e: '😎', t: 'Очки', face: true },
  { id: 'wreath', e: '🌸', t: 'Венок', face: true },
  { id: 'blush', e: '😊', t: 'Румянец', face: true },
  { id: 'hearts', e: '💕', t: 'Сердечки', face: true },
  { id: 'hat', e: '🎩', t: 'Шляпа', face: true },
  { id: 'bw', e: '⚫', t: 'Ч/Б', filter: 'grayscale(1) contrast(1.1)' },
  { id: 'sepia', e: '🟤', t: 'Сепия', filter: 'sepia(.85) contrast(1.05)' },
  { id: 'warm', e: '🌅', t: 'Тёплый', filter: 'saturate(1.3) sepia(.22) brightness(1.05)' },
  { id: 'cold', e: '❄️', t: 'Холодный', filter: 'saturate(1.1) hue-rotate(12deg) brightness(1.03) contrast(1.05)' },
  { id: 'retro', e: '📼', t: 'Ретро', filter: 'contrast(1.2) saturate(.7) sepia(.35)' },
  { id: 'soft', e: '✨', t: 'Мягкий', filter: 'brightness(1.08) contrast(.92) saturate(1.12) blur(.6px)' },
];

const Masks = {
  cur: 'none', running: false, video: null, canvas: null, ctx: null, out: null, raf: 0, cam: null,
  model: 'none', // none | loading | ready | fail
  face: null, faceAt: 0, detBusy: false, detT: 0, mirror: true,
  get(id) { return MASKS.find(m => m.id === id) || MASKS[0]; },
  // ---------- модель лица (грузим только при первой маске) ----------
  loadModel() {
    if (this.model !== 'none') return;
    this.model = 'loading';
    const s = document.createElement('script');
    s.src = 'vendor/faceapi/face-api.min.js';
    s.onload = async () => {
      try {
        await faceapi.nets.tinyFaceDetector.loadFromUri('vendor/faceapi');
        await faceapi.nets.faceLandmark68TinyNet.loadFromUri('vendor/faceapi');
        this.opts = new faceapi.TinyFaceDetectorOptions({ inputSize: 224, scoreThreshold: 0.35 });
        this.model = 'ready';
      } catch (e) { console.error(e); this.model = 'fail'; }
    };
    s.onerror = () => { this.model = 'fail'; };
    document.head.appendChild(s);
  },
  // ---------- конвейер ----------
  start(camTrack) {
    if (this.running) { this.setCam(camTrack); return this.out; }
    this.running = true;
    this.video = document.createElement('video'); this.video.muted = true; this.video.playsInline = true; this.video.setAttribute('playsinline', '');
    this.canvas = document.createElement('canvas'); this.canvas.width = 480; this.canvas.height = 640;
    this.ctx = this.canvas.getContext('2d');
    this.setCam(camTrack);
    this.out = this.canvas.captureStream(24).getVideoTracks()[0];
    const loop = () => { if (!this.running) return; this.draw(); this.raf = requestAnimationFrame(loop); };
    // requestAnimationFrame замирает в свёрнутом окне — подстраховываемся таймером
    this.tick = setInterval(() => { if (this.running && document.hidden) this.draw(); }, 50);
    loop();
    return this.out;
  },
  setCam(track) {
    this.cam = track;
    if (!this.video) return;
    this.video.srcObject = new MediaStream([track]);
    this.video.play().catch(() => { });
    this.face = null;
  },
  stop() {
    this.running = false; cancelAnimationFrame(this.raf); clearInterval(this.tick);
    if (this.out) { try { this.out.stop(); } catch (_) { } }
    if (this.video) this.video.srcObject = null;
    this.video = this.canvas = this.ctx = this.out = null; this.face = null;
  },
  set(id) {
    this.cur = id;
    const m = this.get(id);
    if (m.face) this.loadModel();
  },
  // ---------- кадр ----------
  draw() {
    const v = this.video, c = this.canvas, g = this.ctx;
    if (!v || v.readyState < 2 || !v.videoWidth) return;
    if (c.width !== v.videoWidth || c.height !== v.videoHeight) { c.width = v.videoWidth; c.height = v.videoHeight; }
    const m = this.get(this.cur);
    g.filter = m.filter || 'none';
    g.drawImage(v, 0, 0, c.width, c.height);
    g.filter = 'none';
    if (m.face) {
      this.detect();
      if (this.face && Date.now() - this.faceAt < 1200) this.overlay(m.id, this.face);
    }
  },
  async detect() {
    if (this.model !== 'ready' || this.detBusy || Date.now() - this.detT < 90) return;
    this.detBusy = true; this.detT = Date.now();
    try {
      const r = await faceapi.detectSingleFace(this.video, this.opts).withFaceLandmarks(true);
      if (r) {
        const p = r.landmarks.positions, avg = (a, b) => { let x = 0, y = 0; for (let i = a; i <= b; i++) { x += p[i].x; y += p[i].y; } const n = b - a + 1; return { x: x / n, y: y / n }; };
        const eL = avg(36, 41), eR = avg(42, 47), brow = avg(17, 26), nose = p[30], mouth = avg(48, 59), chin = p[8];
        const f = {
          cx: (eL.x + eR.x) / 2, cy: (eL.y + eR.y) / 2, ang: Math.atan2(eR.y - eL.y, eR.x - eL.x),
          u: Math.hypot(eR.x - eL.x, eR.y - eL.y), brow, nose, mouth, chin, cheekL: { x: p[2].x * .55 + nose.x * .45, y: p[2].y * .5 + nose.y * .5 }, cheekR: { x: p[14].x * .55 + nose.x * .45, y: p[14].y * .5 + nose.y * .5 },
        };
        // сглаживание, чтобы маска не дрожала
        const o = this.face, k = 0.55;
        if (o && Date.now() - this.faceAt < 600) {
          for (const key of ['cx', 'cy', 'u']) f[key] = o[key] + (f[key] - o[key]) * k;
          f.ang = o.ang + (f.ang - o.ang) * k;
        }
        this.face = f; this.faceAt = Date.now();
      }
    } catch (_) { }
    this.detBusy = false;
  },
  // ---------- маски ----------
  emoji(g, ch, x, y, size, rot) {
    g.save(); g.translate(x, y); if (rot) g.rotate(rot);
    g.font = `${Math.round(size)}px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif`;
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(ch, 0, 0); g.restore();
  },
  overlay(id, f) {
    const g = this.ctx, u = f.u, t = Date.now() / 1000;
    // локальные координаты: центр между глаз, ось X вдоль глаз, единица — расстояние между глаз
    const toLocal = pt => { const dx = pt.x - f.cx, dy = pt.y - f.cy, c = Math.cos(-f.ang), s = Math.sin(-f.ang); return { x: (dx * c - dy * s) / u, y: (dx * s + dy * c) / u }; };
    g.save(); g.translate(f.cx, f.cy); g.rotate(f.ang); g.scale(u, u);
    const nose = toLocal(f.nose), mouth = toLocal(f.mouth);
    const ear = (x, y, w, h, rot, outer, inner) => {
      g.save(); g.translate(x, y); g.rotate(rot);
      g.fillStyle = outer; g.beginPath(); g.moveTo(-w / 2, 0); g.quadraticCurveTo(0, -h * 1.15, w / 2, 0); g.closePath(); g.fill();
      g.fillStyle = inner; g.beginPath(); g.moveTo(-w / 3.2, -0.05); g.quadraticCurveTo(0, -h * 0.85, w / 3.2, -0.05); g.closePath(); g.fill();
      g.restore();
    };
    switch (id) {
      case 'cat':
        ear(-1.15, -1.75, 1.0, 1.25, -0.35, '#f2a65a', '#ffc8d7'); ear(1.15, -1.75, 1.0, 1.25, 0.35, '#f2a65a', '#ffc8d7');
        g.fillStyle = '#ff7aa0'; g.beginPath(); g.ellipse(nose.x, nose.y - 0.05, 0.2, 0.14, 0, 0, Math.PI * 2); g.fill();
        g.strokeStyle = 'rgba(40,30,30,.85)'; g.lineWidth = 0.035; g.lineCap = 'round';
        for (const sx of [-1, 1]) for (const dy of [-0.12, 0.02, 0.16]) { g.beginPath(); g.moveTo(nose.x + sx * 0.32, nose.y + 0.12); g.lineTo(nose.x + sx * 1.15, nose.y + 0.12 + dy * 2); g.stroke(); }
        break;
      case 'bunny':
        ear(-0.55, -1.7, 0.62, 2.3, -0.18, '#ffffff', '#ffb6c9'); ear(0.55, -1.7, 0.62, 2.3, 0.18, '#ffffff', '#ffb6c9');
        g.fillStyle = '#ff8fb1'; g.beginPath(); g.moveTo(nose.x - 0.16, nose.y - 0.08); g.lineTo(nose.x + 0.16, nose.y - 0.08); g.lineTo(nose.x, nose.y + 0.1); g.closePath(); g.fill();
        g.fillStyle = '#fff'; g.strokeStyle = '#ddd'; g.lineWidth = 0.02;
        g.fillRect(mouth.x - 0.13, mouth.y - 0.05, 0.12, 0.2); g.strokeRect(mouth.x - 0.13, mouth.y - 0.05, 0.12, 0.2);
        g.fillRect(mouth.x + 0.01, mouth.y - 0.05, 0.12, 0.2); g.strokeRect(mouth.x + 0.01, mouth.y - 0.05, 0.12, 0.2);
        break;
      case 'dog':
        for (const sx of [-1, 1]) { g.save(); g.translate(sx * 1.55, -0.9); g.rotate(sx * 0.35); g.fillStyle = '#8b5a2b'; g.beginPath(); g.ellipse(0, 0.55, 0.42, 0.95, 0, 0, Math.PI * 2); g.fill(); g.fillStyle = '#6b4220'; g.beginPath(); g.ellipse(0, 0.65, 0.25, 0.7, 0, 0, Math.PI * 2); g.fill(); g.restore(); }
        g.fillStyle = '#2b1d14'; g.beginPath(); g.ellipse(nose.x, nose.y - 0.02, 0.3, 0.2, 0, 0, Math.PI * 2); g.fill();
        g.fillStyle = 'rgba(255,255,255,.6)'; g.beginPath(); g.ellipse(nose.x - 0.09, nose.y - 0.08, 0.07, 0.04, 0, 0, Math.PI * 2); g.fill();
        g.fillStyle = '#ff6f8f'; g.beginPath(); g.ellipse(mouth.x, mouth.y + 0.35 + Math.sin(t * 6) * 0.03, 0.2, 0.32, 0, 0, Math.PI * 2); g.fill();
        break;
      case 'crown': this.emoji(g, '👑', 0, -2.05, 2.1, 0); break;
      case 'hat': this.emoji(g, '🎩', 0, -2.25, 2.5, 0); break;
      case 'glasses': this.emoji(g, '🕶️', 0, 0.12, 2.45, 0); break;
      case 'wreath': {
        const fl = ['🌸', '🌼', '🌺', '🌷', '🌸', '🌼', '🌺', '🌸', '🌷'];
        fl.forEach((e, i) => { const a = Math.PI + (i / (fl.length - 1)) * Math.PI; this.emoji(g, e, Math.cos(a) * 1.85, -1.05 + Math.sin(a) * 1.05, 0.72, a + Math.PI / 2); });
        break;
      }
      case 'blush': {
        const cl = toLocal(f.cheekL), cr = toLocal(f.cheekR);
        for (const c of [cl, cr]) { const gr = g.createRadialGradient(c.x, c.y, 0, c.x, c.y, 0.5); gr.addColorStop(0, 'rgba(255,105,140,.5)'); gr.addColorStop(1, 'rgba(255,105,140,0)'); g.fillStyle = gr; g.beginPath(); g.arc(c.x, c.y, 0.5, 0, Math.PI * 2); g.fill(); }
        this.emoji(g, '✨', cr.x + 0.55, cr.y - 0.6, 0.45 + Math.sin(t * 4) * 0.08, 0);
        this.emoji(g, '✨', cl.x - 0.6, cl.y - 0.9, 0.35 + Math.cos(t * 4) * 0.06, 0);
        break;
      }
      case 'hearts':
        for (let i = 0; i < 6; i++) { const a = t * 1.4 + i * Math.PI / 3; this.emoji(g, i % 2 ? '💖' : '💕', Math.cos(a) * 2.0, -1.9 + Math.sin(a) * 0.55, 0.62 + (Math.sin(a) + 1) * 0.12, 0); }
        break;
    }
    g.restore();
  },
};
