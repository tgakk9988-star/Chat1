'use strict';
/* «Наш чат» — звонки. Голос идёт напрямую между телефонами (WebRTC, шифрование DTLS-SRTP),
   а если напрямую нельзя — через посредника TURN на вашем сервере (он тоже не может расшифровать звук). */

/* ---------- звуки: гудки и мелодия звонка (без файлов, синтезом) ---------- */
const Tone = {
  ctx: null, stopFn: null,
  ac() { if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)(); if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => { }); return this.ctx; },
  beep(f, t0, dur, vol, type) {
    const c = this.ac(), o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(vol, t0 + 0.02);
    g.gain.setValueAtTime(vol, t0 + dur - 0.05); g.gain.linearRampToValueAtTime(0, t0 + dur);
    o.connect(g); g.connect(c.destination); o.start(t0); o.stop(t0 + dur + 0.02);
  },
  loop(kind) {
    this.stop();
    let alive = true, timer = null;
    const once = () => {
      if (!alive) return;
      try {
        const c = this.ac(), t = c.currentTime + 0.05;
        if (kind === 'ringback') { this.beep(425, t, 1.0, 0.08); timer = setTimeout(once, 4000); }
        else if (kind === 'ring') {
          [659, 784, 988, 784, 1319].forEach((f, i) => this.beep(f, t + i * 0.16, 0.15, 0.13, 'triangle'));
          [659, 784, 988, 784, 1319].forEach((f, i) => this.beep(f, t + 1.0 + i * 0.16, 0.15, 0.13, 'triangle'));
          vibrate([400, 200, 400]);
          timer = setTimeout(once, 3000);
        } else if (kind === 'end') { this.beep(480, t, 0.18, 0.08); this.beep(480, t + 0.3, 0.18, 0.08); this.beep(480, t + 0.6, 0.18, 0.08); alive = false; }
        else if (kind === 'busy') { for (let i = 0; i < 4; i++) this.beep(425, t + i * 0.7, 0.35, 0.08); alive = false; }
      } catch (_) { }
    };
    once();
    this.stopFn = () => { alive = false; clearTimeout(timer); try { navigator.vibrate && navigator.vibrate(0); } catch (_) { } };
  },
  stop() { if (this.stopFn) { this.stopFn(); this.stopFn = null; } },
};

/* ---------- звонок ---------- */
const CALL_WHY = {
  hangup: 'Звонок завершён', decline: 'Отклонено', declined: 'Вы отклонили звонок', busy: 'Занято', noanswer: 'Нет ответа',
  failed: 'Не удалось соединиться', lost: 'Связь потеряна', cancel: 'Звонок отменён', missed: 'Пропущенный звонок', nomic: 'Нет доступа к микрофону',
};
const Call = {
  st: 'idle', id: '', autoAcceptId: '', mine: false, video: false, pc: null, local: null, offer: null,
  t0: 0, tick: null, noAnsT: null, lostT: null, muted: false, speaker: false, ended: false, autoAccept: false,

  // ---------- исходящий ----------
  async start(video) {
    if (this.st !== 'idle') { this.showUI(); return; }
    if (!S.online) { toast('Нет связи с сервером — позвонить не получится'); return; }
    this.reset(); this.id = hex(crypto.getRandomValues(new Uint8Array(8))); this.mine = true; this.video = !!video; this.st = 'outgoing';
    this.showUI(); this.status('Подключаем микрофон…');
    if (!(await this.getMic())) return;
    this.status('Звоним…');
    try {
      const pc = await this.makePc();
      if (this.ended) return;
      this.local.getTracks().forEach(t => pc.addTrack(t, this.local));
      await pc.setLocalDescription(await pc.createOffer());
      await this.gathered(pc);
      if (this.ended) return;
      await this.ring('start');
      await Sig.send({ k: 'c', a: 'offer', id: this.id, sdp: pc.localDescription.sdp, video: this.video });
      Tone.loop('ringback');
      this.noAnsT = setTimeout(() => { if (this.st === 'outgoing') this.end('noanswer'); }, 45000);
    } catch (e) { console.error(e); this.end('failed'); }
  },
  // ---------- входящий ----------
  incoming(o) {
    const auto = this.autoAcceptId === o.id; this.autoAcceptId = '';
    this.reset(); this.id = o.id; this.mine = false; this.video = !!o.video; this.offer = o; this.st = 'incoming';
    this.showUI(); this.status('Входящий звонок…');
    Native && Native.cancelCallNotif && Native.cancelCallNotif();
    const act = Native && Native.takeCallIntent ? Native.takeCallIntent() : '';
    if (act === 'accept:' + o.id || auto) { this.accept(); return; }
    Tone.loop('ring');
  },
  async accept() {
    if (this.st !== 'incoming') return;
    Tone.stop(); this.st = 'connecting'; this.drawButtons(); this.status('Соединение…');
    if (!(await this.getMic())) return;
    try {
      const pc = await this.makePc();
      if (this.ended) return;
      this.local.getTracks().forEach(t => pc.addTrack(t, this.local));
      await pc.setRemoteDescription({ type: 'offer', sdp: this.offer.sdp });
      await pc.setLocalDescription(await pc.createAnswer());
      await this.gathered(pc);
      if (this.ended) return;
      await Sig.send({ k: 'c', a: 'answer', id: this.id, sdp: pc.localDescription.sdp });
      this.ring('stop');
      this.lostT = setTimeout(() => { if (this.st === 'connecting') this.end('failed'); }, 25000);
    } catch (e) { console.error(e); this.end('failed'); }
  },
  decline() {
    if (this.st !== 'incoming') return;
    Sig.send({ k: 'c', a: 'decline', id: this.id });
    this.ring('decline');
    this.end('declined');
  },
  hangup() {
    if (this.st === 'idle') return;
    if (this.st === 'incoming') { this.decline(); return; }
    Sig.send({ k: 'c', a: 'hangup', id: this.id, why: this.st === 'outgoing' ? 'cancel' : 'hangup' });
    if (this.st === 'outgoing') this.ring('stop');
    this.end(this.st === 'outgoing' ? 'cancel' : 'hangup');
  },
  async onAnswer(o) {
    clearTimeout(this.noAnsT); Tone.stop();
    this.st = 'connecting'; this.drawButtons(); this.status('Соединение…');
    try { await this.pc.setRemoteDescription({ type: 'answer', sdp: o.sdp }); }
    catch (e) { console.error(e); this.end('failed'); return; }
    this.ring('stop');
    this.lostT = setTimeout(() => { if (this.st === 'connecting') this.end('failed'); }, 25000);
  },
  onSignal(o, ts) {
    switch (o.a) {
      case 'offer':
        if (this.st !== 'idle') { if (o.id !== this.id) Sig.send({ k: 'c', a: 'busy', id: o.id }); return; }
        // старое приглашение (звонок уже закончился) не показываем
        if (!(S.ring && S.ring.id === o.id)) return;
        this.incoming(o); break;
      case 'answer': if (o.id === this.id && this.st === 'outgoing') this.onAnswer(o); break;
      case 'hangup': if (o.id === this.id) this.end(this.st === 'incoming' ? 'missed' : (o.why === 'cancel' ? 'missed' : 'hangup')); break;
      case 'decline': if (o.id === this.id && this.st === 'outgoing') this.end('decline'); break;
      case 'busy': if (o.id === this.id && this.st === 'outgoing') this.end('busy'); break;
    }
  },
  // данные о звонке от сервера (фоновая служба могла отклонить, звонок мог истечь)
  onRing(ring, ringEnd) {
    S.ring = ring;
    if (ringEnd && ringEnd.id === this.id) {
      if (this.st === 'outgoing' && ringEnd.why === 'decline') this.end('decline');
      if (this.st === 'incoming' && (ringEnd.why === 'stop' || ringEnd.why === 'timeout')) this.end('missed');
    }
  },
  // ---------- техника ----------
  async getMic() {
    try {
      this.local = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
      if (this.ended) { this.local.getTracks().forEach(t => t.stop()); return false; }
      Native && Native.callAudio && Native.callAudio(true);
      this.setSpeaker(this.video);
      return true;
    } catch (_) { this.end('nomic'); return false; }
  },
  async makePc() {
    let ice;
    try { ice = (await api('/api/turn', { timeout: 8000 })).ice; } catch (_) { ice = [{ urls: ['stun:stun.l.google.com:19302'] }]; }
    const pc = new RTCPeerConnection({ iceServers: ice, bundlePolicy: 'max-bundle' });
    this.pc = pc;
    pc.ontrack = e => { const a = $('#cu-audio'); a.srcObject = e.streams[0]; a.play().catch(() => { }); };
    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      if (s === 'connected') {
        clearTimeout(this.lostT); this.lostT = null;
        if (this.st !== 'active') { this.st = 'active'; this.t0 = Date.now(); this.drawButtons(); vibrate(40); this.timer(); }
        else this.timer();
      } else if (s === 'disconnected' && this.st === 'active') {
        this.status('Связь прерывается…');
        clearTimeout(this.lostT); this.lostT = setTimeout(() => { if (this.pc && this.pc.connectionState !== 'connected') this.end('lost'); }, 15000);
      } else if (s === 'failed') this.end(this.st === 'active' ? 'lost' : 'failed');
    };
    return pc;
  },
  gathered(pc) {
    return new Promise(res => {
      if (pc.iceGatheringState === 'complete') return res();
      const t = setTimeout(res, 4000);
      pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } });
    });
  },
  ring(act) {
    return api('/api/ring', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, id: this.id, act, video: this.video }), timeout: 8000 }).catch(() => { });
  },
  timer() {
    clearInterval(this.tick);
    const draw = () => { const s = Math.floor((Date.now() - this.t0) / 1000); this.status(fmtDur(s)); };
    draw(); this.tick = setInterval(draw, 1000);
  },
  setSpeaker(on) {
    this.speaker = on;
    Native && Native.callSpeaker && Native.callSpeaker(on);
    const b = $('#cu-spk'); if (b) b.classList.toggle('on', on);
  },
  toggleMute() {
    this.muted = !this.muted;
    if (this.local) this.local.getAudioTracks().forEach(t => { t.enabled = !this.muted; });
    $('#cu-mute').classList.toggle('on', this.muted);
    $('#cu-mute').innerHTML = this.muted ? '🔇' : '🎤';
  },
  end(why) {
    if (this.ended || this.st === 'idle') return;
    this.ended = true;
    const wasActive = this.st === 'active', dur = wasActive ? Math.round((Date.now() - this.t0) / 1000) : 0;
    const mine = this.mine, video = this.video;
    clearTimeout(this.noAnsT); clearTimeout(this.lostT); clearInterval(this.tick);
    Tone.stop();
    if (why === 'busy') Tone.loop('busy'); else if (wasActive || why === 'decline' || why === 'noanswer' || why === 'lost') Tone.loop('end');
    try { if (this.local) this.local.getTracks().forEach(t => t.stop()); } catch (_) { }
    try { if (this.pc) this.pc.close(); } catch (_) { }
    $('#cu-audio').srcObject = null;
    Native && Native.callAudio && Native.callAudio(false);
    Native && Native.cancelCallNotif && Native.cancelCallNotif();
    if (mine && (why === 'noanswer' || why === 'cancel')) this.ring('stop');
    this.st = 'ended'; this.drawButtons();
    this.status((CALL_WHY[why] || 'Звонок завершён') + (dur ? ' · ' + fmtDur(dur) : ''));
    // запись в чате делает тот, кто звонил
    if (mine && why !== 'nomic') {
      const res = wasActive ? 'ok' : why === 'decline' ? 'declined' : why === 'busy' ? 'busy' : (why === 'failed' || why === 'lost') ? 'failed' : 'missed';
      sendPayload({ t: 'call', dur, res, video }).catch(() => { });
    }
    setTimeout(() => { if (this.st === 'ended') { this.st = 'idle'; this.hideUI(); } }, 1600);
  },
  reset() {
    this.ended = false; this.muted = false; this.offer = null; this.pc = null; this.local = null; this.t0 = 0;
  },
  // ---------- экран ----------
  showUI() {
    const p = typeof Profile !== 'undefined' ? Profile.partner() : null, name = (p && p.name) || S.partner || 'Собеседник';
    const av = $('#cu-av'); if (typeof Profile !== 'undefined') Profile.avatarSet(av, p, name); else av.textContent = name[0];
    $('#cu-bg').style.backgroundImage = p && p.avatar ? `url("${p.avatar}")` : '';
    $('#cu-name').innerHTML = typeof Profile !== 'undefined' ? Profile.nameHtml(p, name) : esc(name);
    $('#cu-kind').textContent = this.video ? 'Видеозвонок' : 'Аудиозвонок';
    $('#callui').classList.remove('hidden');
    this.drawButtons(); Panel.close(); RxBar.close();
    try { ta.blur(); } catch (_) { }
  },
  hideUI() { $('#callui').classList.add('hidden'); if (this.st === 'idle') $('#call-return').classList.add('hidden'); },
  drawButtons() {
    const st = this.st;
    $('#cu-in').classList.toggle('hidden', st !== 'incoming');
    $('#cu-on').classList.toggle('hidden', !(st === 'outgoing' || st === 'connecting' || st === 'active'));
    $('#callui').dataset.st = st;
  },
  status(t) { $('#cu-st').textContent = t; },
};

// запись о звонке в переписке
function callBubble(m) {
  const p = m.p, d = document.createElement('div'); d.className = 'bubble call-bubble';
  const out = m.mine, ok = p.res === 'ok';
  const title = ok ? (out ? 'Исходящий звонок' : 'Входящий звонок')
    : p.res === 'declined' ? (out ? 'Звонок отклонён' : 'Вы отклонили звонок')
      : p.res === 'busy' ? 'Было занято'
        : p.res === 'failed' ? 'Не удалось дозвониться'
          : (out ? 'Отменённый звонок' : 'Пропущенный звонок');
  const missed = !ok && !out;
  d.innerHTML = `<div class="cb"><span class="cb-ic${missed ? ' missed' : ''}">${p.video ? '🎥' : '📞'}</span><span class="cb-t"><b>${title}</b><small>${ok ? fmtDur(p.dur) : (out ? '↗' : '↙') + ' ' + fmtTime(m.ts)}</small></span><button class="cb-again" aria-label="Перезвонить">📞</button></div>${metaHtml(m)}`;
  d.querySelector('.cb-again').onclick = e => { e.stopPropagation(); Call.start(false); };
  return d;
}

$('#call-btn').onclick = () => Call.start(false);
$('#cu-accept').onclick = () => Call.accept();
$('#cu-decline').onclick = () => Call.decline();
$('#cu-hang').onclick = () => Call.hangup();
$('#cu-mute').onclick = () => Call.toggleMute();
$('#cu-spk').onclick = () => Call.setSpeaker(!Call.speaker);
$('#cu-min').onclick = () => { if (Call.st === 'incoming') return; Call.hideUI(); $('#call-return').classList.remove('hidden'); };
$('#call-return').onclick = () => { $('#call-return').classList.add('hidden'); Call.showUI(); };
// приложение открыли кнопкой «Принять» из уведомления — звонок примем сразу, как придёт приглашение
window.nativeCallIntent = function (act) { if (act && act.startsWith('accept:') && Call.st === 'incoming' && act === 'accept:' + Call.id) Call.accept(); else if (act && act.startsWith('accept:')) Call.autoAcceptId = act.slice(7); };
