'use strict';
/* «Наш чат» — звонки. Голос идёт напрямую между телефонами (WebRTC, шифрование DTLS-SRTP),
   а если напрямую нельзя — через посредника TURN на вашем сервере (он тоже не может расшифровать звук). */

/* ---------- звуки: гудки и мелодия звонка (без файлов, синтезом) ---------- */
const Tone = {
  ctx: null, stopFn: null,
  ac() { if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)(); if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => { }); return this.ctx; },
  beep(f, t0, dur, vol, type) {
    const c = this.ac(), o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(vol, t0 + 0.02);
    g.gain.setValueAtTime(vol, t0 + dur - 0.05); g.gain.linearRampToValueAtTime(0, t0 + dur);
    o.connect(g); g.connect(c.destination); o.start(t0); o.stop(t0 + dur + 0.02);
  },
  loop(kind) {
    this.stop();
    let alive = true, timer = null;
    const once = () => {
      if (!alive) return;
      try {
        const c = this.ac(), t = c.currentTime + 0.05;
        if (kind === 'ringback') { this.beep(425, t, 1.0, 0.08); timer = setTimeout(once, 4000); }
        else if (kind === 'ring') {
          [659, 784, 988, 784, 1319].forEach((f, i) => this.beep(f, t + i * 0.16, 0.15, 0.13, 'triangle'));
          [659, 784, 988, 784, 1319].forEach((f, i) => this.beep(f, t + 1.0 + i * 0.16, 0.15, 0.13, 'triangle'));
          vibrate([400, 200, 400]);
          timer = setTimeout(once, 3000);
        } else if (kind === 'end') { this.beep(480, t, 0.18, 0.08); this.beep(480, t + 0.3, 0.18, 0.08); this.beep(480, t + 0.6, 0.18, 0.08); alive = false; }
        else if (kind === 'busy') { for (let i = 0; i < 4; i++) this.beep(425, t + i * 0.7, 0.35, 0.08); alive = false; }
      } catch (_) { }
    };
    once();
    this.stopFn = () => { alive = false; clearTimeout(timer); try { navigator.vibrate && navigator.vibrate(0); } catch (_) { } };
  },
  stop() { if (this.stopFn) { this.stopFn(); this.stopFn = null; } },
};

/* ---------- звонок ---------- */
const CALL_WHY = {
  hangup: 'Звонок завершён', decline: 'Отклонено', declined: 'Вы отклонили звонок', busy: 'Занято', noanswer: 'Нет ответа',
  failed: 'Не удалось соединиться', lost: 'Связь потеряна', cancel: 'Звонок отменён', missed: 'Пропущенный звонок', nomic: 'Нет доступа к микрофону',
};
const Call = {
  st: 'idle', id: '', autoAcceptId: '', mine: false, video: false, pc: null, local: null, offer: null,
  t0: 0, tick: null, noAnsT: null, lostT: null, muted: false, speaker: false, ended: false, autoAccept: false,

  // ---------- исходящий ----------
  async start(video) {
    if (this.st !== 'idle') { this.showUI(); return; }
    if (!S.online) { toast('Нет связи с сервером — позвонить не получится'); return; }
    this.reset(); this.id = hex(crypto.getRandomValues(new Uint8Array(8))); this.mine = true; this.video = !!video; this.st = 'outgoing';
    this.showUI(); this.status(this.video ? 'Включаем камеру…' : 'Подключаем микрофон…');
    if (!(await this.getMic())) return;
    this.status('Звоним…');
    try {
      const pc = await this.makePc();
      if (this.ended) return;
      this.addTracks(pc);
      const offer = await pc.createOffer(); offer.sdp = opusTune(offer.sdp);
      await pc.setLocalDescription(offer);
      await this.gathered(pc);
      if (this.ended) return;
      await this.ring('start');
      await Sig.send({ k: 'c', a: 'offer', id: this.id, sdp: pc.localDescription.sdp, video: this.video });
      this.descSent = true; this.flushLocal();
      Tone.loop('ringback');
      this.noAnsT = setTimeout(() => { if (this.st === 'outgoing') this.end('noanswer'); }, 45000);
    } catch (e) { console.error(e); this.end('failed'); }
  },
  // ---------- входящий ----------
  incoming(o) {
    const auto = this.autoAcceptId === o.id; this.autoAcceptId = '';
    this.reset(); this.id = o.id; this.mine = false; this.video = !!o.video; this.offer = o; this.st = 'incoming';
    this.showUI(); this.status('Входящий звонок…');
    Native && Native.cancelCallNotif && Native.cancelCallNotif();
    const act = Native && Native.takeCallIntent ? Native.takeCallIntent() : '';
    if (act === 'accept:' + o.id || auto) { this.accept(); return; }
    Tone.loop('ring');
  },
  async accept() {
    if (this.st !== 'incoming') return;
    Tone.stop(); this.st = 'connecting'; this.drawButtons(); this.status('Соединение…');
    if (!(await this.getMic())) return;
    try {
      const pc = await this.makePc();
      if (this.ended) return;
      this.addTracks(pc);
      await pc.setRemoteDescription({ type: 'offer', sdp: this.offer.sdp });
      this.noteRemote(this.offer.sdp); await this.flushRemote();
      const answer = await pc.createAnswer(); answer.sdp = opusTune(answer.sdp);
      await pc.setLocalDescription(answer);
      await this.gathered(pc);
      if (this.ended) return;
      await Sig.send({ k: 'c', a: 'answer', id: this.id, sdp: pc.localDescription.sdp });
      this.descSent = true; this.flushLocal();
      this.ring('stop');
      this.watchConnect();
    } catch (e) { console.error(e); this.end('failed'); }
  },
  decline() {
    if (this.st !== 'incoming') return;
    Sig.send({ k: 'c', a: 'decline', id: this.id });
    this.ring('decline');
    this.end('declined');
  },
  hangup() {
    if (this.st === 'idle') return;
    if (this.st === 'incoming') { this.decline(); return; }
    Sig.send({ k: 'c', a: 'hangup', id: this.id, why: this.st === 'outgoing' ? 'cancel' : 'hangup' });
    if (this.st === 'outgoing') this.ring('stop');
    this.end(this.st === 'outgoing' ? 'cancel' : 'hangup');
  },
  async onAnswer(o) {
    clearTimeout(this.noAnsT); Tone.stop();
    this.st = 'connecting'; this.drawButtons(); this.status('Соединение…');
    try { await this.pc.setRemoteDescription({ type: 'answer', sdp: o.sdp }); this.noteRemote(o.sdp); await this.flushRemote(); }
    catch (e) { console.error(e); this.end('failed'); return; }
    this.ring('stop');
    this.watchConnect();
  },
  watchConnect() {
    clearTimeout(this.lostT); clearTimeout(this.diagT);
    this.diagT = setTimeout(() => { if (this.st === 'connecting') { const el = $('#cu-net'); el.textContent = this.diagText(); el.classList.add('bad'); } }, 6000);
    this.lostT = setTimeout(() => { if (this.st === 'connecting') this.end('failed'); }, 30000);
  },
  onSignal(o, ts) {
    switch (o.a) {
      case 'offer':
        if (this.st !== 'idle') { if (o.id !== this.id) Sig.send({ k: 'c', a: 'busy', id: o.id }); return; }
        // старое приглашение (звонок уже закончился) не показываем
        if (!(S.ring && S.ring.id === o.id)) return;
        this.incoming(o); break;
      case 'answer': if (o.id === this.id && this.st === 'outgoing') this.onAnswer(o); break;
      case 'hangup': if (o.id === this.id) this.end(this.st === 'incoming' ? 'missed' : (o.why === 'cancel' ? 'missed' : 'hangup')); break;
      case 'decline': if (o.id === this.id && this.st === 'outgoing') this.end('decline'); break;
      case 'busy': if (o.id === this.id && this.st === 'outgoing') this.end('busy'); break;
      case 'cam': if (o.id === this.id) $('#callui').classList.toggle('rcam-off', !o.on); break;
      case 'ice':
        if (o.id !== this.id || !o.c || this.st === 'idle' || this.st === 'ended') return;
        this.noteRemote('a=' + (o.c.candidate || ''));
        if (this.pc && this.pc.remoteDescription) this.pc.addIceCandidate(o.c).catch(() => { });
        else this.remoteQ.push(o.c);
        break;
    }
  },
  // данные о звонке от сервера (фоновая служба могла отклонить, звонок мог истечь)
  onRing(ring, ringEnd) {
    S.ring = ring;
    if (ringEnd && ringEnd.id === this.id) {
      if (this.st === 'outgoing' && ringEnd.why === 'decline') this.end('decline');
      if (this.st === 'incoming' && (ringEnd.why === 'stop' || ringEnd.why === 'timeout')) this.end('missed');
    }
  },
  // ---------- техника ----------
  async getMic() {
    const audio = { echoCancellation: true, noiseSuppression: true, autoGainControl: true };
    try {
      if (this.video) {
        try { this.local = await navigator.mediaDevices.getUserMedia({ audio, video: CAM_OPTS('user') }); }
        catch (_) { this.local = await navigator.mediaDevices.getUserMedia({ audio, video: false }); toast('Камера недоступна — звонок без видео'); }
      } else this.local = await navigator.mediaDevices.getUserMedia({ audio, video: false });
      if (this.ended) { this.local.getTracks().forEach(t => t.stop()); return false; }
      this.camTrack = this.local.getVideoTracks()[0] || null; this.facing = 'user'; this.camOn = !!this.camTrack;
      if (this.camTrack) { if (Masks.cur !== 'none') Masks.start(this.camTrack); this.showLocal(); }
      Native && Native.callAudio && Native.callAudio(true);
      this.setSpeaker(this.video);
      return true;
    } catch (_) { this.end('nomic'); return false; }
  },
  async makePc() {
    let ice;
    try { const r = await api('/api/turn', { timeout: 8000 }); ice = r.ice; this.turn = r.turn ? 'ok' : 'off'; }
    catch (e) { ice = [{ urls: ['stun:stun.l.google.com:19302'] }]; this.turn = e.status === 404 ? 'old' : 'err'; }
    const pc = new RTCPeerConnection({ iceServers: ice, bundlePolicy: 'max-bundle' });
    this.pc = pc;
    pc.onicecandidate = e => {
      if (!e.candidate) { this.gatherDone = true; return; }
      const m = / typ (\w+)/.exec(e.candidate.candidate || ''); if (m) this.localTypes[m[1]] = (this.localTypes[m[1]] || 0) + 1;
      const c = e.candidate.toJSON();
      if (this.descSent) Sig.send({ k: 'c', a: 'ice', id: this.id, c }); else this.localQ.push(c);
    };
    pc.ontrack = e => {
      try { e.receiver.jitterBufferTarget = e.track.kind === 'audio' ? 120 : 200; } catch (_) { }
      const stream = e.streams[0] || new MediaStream([e.track]);
      if (e.track.kind === 'video') {
        for (const id of ['#cu-rv', '#cu-fv']) { const v = $(id); v.srcObject = stream; v.play().catch(() => { }); }
        $('#callui').classList.add('has-rv');
      } else { const a = $('#cu-audio'); a.srcObject = stream; a.play().catch(() => { }); }
    };
    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      if (s === 'connected') {
        clearTimeout(this.lostT); this.lostT = null;
        if (this.st !== 'active') { this.st = 'active'; this.t0 = Date.now(); this.drawButtons(); vibrate(40); this.timer(); this.statsLoop(); if (this.video) { Native && Native.pipEnable && Native.pipEnable(true); Calm.poke(); setTimeout(() => { if (this.st === 'active') Masks.loadModel(); }, 2500); } }
        else this.timer();
      } else if (s === 'disconnected' && this.st === 'active') {
        this.status('Связь прерывается…');
        clearTimeout(this.lostT); this.lostT = setTimeout(() => { if (this.pc && this.pc.connectionState !== 'connected') this.end('lost'); }, 15000);
      } else if (s === 'failed') this.end(this.st === 'active' ? 'lost' : 'failed');
    };
    return pc;
  },
  addTracks(pc) {
    this.local.getAudioTracks().forEach(t => {
      const snd = pc.addTrack(t, this.local);
      try { const prm = snd.getParameters(); (prm.encodings || []).forEach(en => { en.priority = 'high'; en.networkPriority = 'high'; }); snd.setParameters(prm).catch(() => { }); } catch (_) { }
    });
    if (this.camTrack) {
      const snd = pc.addTrack(this.sendTrack(), this.local); this.vSender = snd;
      try { const prm = snd.getParameters(); if (!prm.encodings || !prm.encodings.length) prm.encodings = [{}]; prm.encodings.forEach(en => { en.maxBitrate = 900000; en.maxFramerate = 24; }); prm.degradationPreference = 'balanced'; snd.setParameters(prm).catch(() => { }); } catch (_) { }
    } else if (this.video) pc.addTransceiver('video', { direction: 'recvonly' });
  },
  sendTrack() { return Masks.running && Masks.out ? Masks.out : this.camTrack; },
  showLocal() {
    const lv = $('#cu-lv');
    lv.srcObject = this.camTrack ? new MediaStream([this.sendTrack()]) : null;
    lv.classList.toggle('mirror', this.facing === 'user');
    lv.classList.toggle('hidden', !this.camTrack || !this.camOn);
    lv.play().catch(() => { });
  },
  async flip() {
    if (!this.camTrack) return;
    const want = this.facing === 'user' ? 'environment' : 'user', old = this.camTrack;
    old.stop(); this.local.removeTrack(old);
    let nt = null;
    try { nt = (await navigator.mediaDevices.getUserMedia({ video: CAM_OPTS({ exact: want }) })).getVideoTracks()[0]; this.facing = want; }
    catch (_) { try { nt = (await navigator.mediaDevices.getUserMedia({ video: CAM_OPTS(this.facing) })).getVideoTracks()[0]; } catch (_) { } toast('Не удалось переключить камеру'); }
    if (!nt) { this.camTrack = null; this.showLocal(); return; }
    if (this.ended) { nt.stop(); return; }
    this.local.addTrack(nt); this.camTrack = nt; nt.enabled = this.camOn;
    if (Masks.running) Masks.setCam(nt);
    else if (this.vSender) await this.vSender.replaceTrack(this.camOn ? nt : null).catch(() => { });
    this.showLocal(); vibrate(10);
  },
  toggleCam() {
    if (!this.camTrack) { toast('Камера недоступна'); return; }
    this.camOn = !this.camOn; this.camTrack.enabled = this.camOn;
    if (this.vSender) this.vSender.replaceTrack(this.camOn ? this.sendTrack() : null).catch(() => { });
    Sig.send({ k: 'c', a: 'cam', id: this.id, on: this.camOn });
    $('#cu-cam').classList.toggle('on', !this.camOn); $('#cu-cam').innerHTML = this.camOn ? '📷' : '🚫';
    this.showLocal();
  },
  async setMask(id) {
    Masks.set(id);
    if (!this.camTrack) return;
    if (id === 'none') { if (Masks.running) { Masks.stop(); if (this.vSender) await this.vSender.replaceTrack(this.camOn ? this.camTrack : null).catch(() => { }); } }
    else if (!Masks.running) { const out = Masks.start(this.camTrack); if (this.vSender) await this.vSender.replaceTrack(this.camOn ? out : null).catch(() => { }); }
    this.showLocal(); this.drawMasks();
  },
  drawMasks() {
    $('#cu-masks').innerHTML = MASKS.map(m => `<button data-mask="${m.id}" class="${Masks.cur === m.id ? 'on' : ''}"><span>${m.e}</span><small>${m.t}</small></button>`).join('');
  },
  flushLocal() { const q = this.localQ; this.localQ = []; q.forEach(c => Sig.send({ k: 'c', a: 'ice', id: this.id, c })); },
  async flushRemote() { const q = this.remoteQ; this.remoteQ = []; for (const c of q) { try { await this.pc.addIceCandidate(c); } catch (_) { } } },
  noteRemote(text) { const re = / typ (\w+)/g; let m; while ((m = re.exec(text))) this.remoteTypes[m[1]] = (this.remoteTypes[m[1]] || 0) + 1; },
  // подсказка, почему долго соединяется
  diagText() {
    if (this.turn === 'old') return '⚠️ Сервер не обновлён — выполните команду обновления сервера, иначе звонки через мобильный интернет не пройдут';
    if (this.turn === 'off') return '⚠️ Посредник для звонков на сервере не настроен — повторите команду обновления сервера';
    if (this.gatherDone && !this.localTypes.relay) return '⚠️ Посредник на сервере не отвечает (порт 3478). Пришлите скриншот Claude';
    const mine = this.localTypes.relay ? 'есть' : 'ищем', theirs = this.remoteTypes.relay ? 'есть' : (Object.keys(this.remoteTypes).length ? 'нет' : 'ждём');
    return `Путь через сервер: у вас — ${mine}, у собеседника — ${theirs}`;
  },
  async statsLoop() {
    clearInterval(this.statT);
    let prevLost = 0, prevRecv = 0;
    const tick = async () => {
      if (!this.pc || this.st !== 'active') return;
      try {
        const st = await this.pc.getStats(); let pair = null, route = '', rtt = null, lost = 0, recv = 0;
        st.forEach(r => { if (r.type === 'transport' && r.selectedCandidatePairId) pair = st.get(r.selectedCandidatePairId); });
        if (!pair) st.forEach(r => { if (r.type === 'candidate-pair' && r.nominated && r.state === 'succeeded') pair = r; });
        if (pair) {
          const lc = st.get(pair.localCandidateId), rc = st.get(pair.remoteCandidateId);
          route = (lc && lc.candidateType === 'relay') || (rc && rc.candidateType === 'relay') ? 'через сервер' : 'напрямую';
          if (pair.currentRoundTripTime != null) rtt = Math.round(pair.currentRoundTripTime * 1000);
        }
        st.forEach(r => { if (r.type === 'inbound-rtp' && r.kind === 'audio') { lost = r.packetsLost || 0; recv = r.packetsReceived || 0; } });
        const dl = lost - prevLost, dr = recv - prevRecv; prevLost = lost; prevRecv = recv;
        const loss = dl + dr > 0 ? Math.round(dl / (dl + dr) * 100) : 0;
        const el = $('#cu-net');
        el.textContent = `📶 ${route || '…'}${rtt != null ? ' · ' + rtt + ' мс' : ''} · потери ${Math.max(0, loss)}%`;
        el.classList.toggle('bad', loss >= 5 || (rtt != null && rtt > 400));
      } catch (_) { }
    };
    tick(); this.statT = setInterval(tick, 2000);
  },
  gathered(pc) {
    return new Promise(res => {
      if (pc.iceGatheringState === 'complete') return res();
      const t = setTimeout(res, 1500);
      pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } });
    });
  },
  ring(act) {
    return api('/api/ring', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, id: this.id, act, video: this.video }), timeout: 8000 }).catch(() => { });
  },
  timer() {
    clearInterval(this.tick);
    const draw = () => { const s = Math.floor((Date.now() - this.t0) / 1000); this.status(fmtDur(s)); };
    draw(); this.tick = setInterval(draw, 1000);
  },
  setSpeaker(on) {
    this.speaker = on;
    Native && Native.callSpeaker && Native.callSpeaker(on);
    const b = $('#cu-spk'); if (b) b.classList.toggle('on', on);
  },
  toggleMute() {
    this.muted = !this.muted;
    if (this.local) this.local.getAudioTracks().forEach(t => { t.enabled = !this.muted; });
    $('#cu-mute').classList.toggle('on', this.muted);
    $('#cu-mute').innerHTML = this.muted ? '🔇' : '🎤';
  },
  end(why) {
    if (this.ended || this.st === 'idle') return;
    this.ended = true;
    const wasActive = this.st === 'active', dur = wasActive ? Math.round((Date.now() - this.t0) / 1000) : 0;
    const mine = this.mine, video = this.video;
    clearTimeout(this.noAnsT); clearTimeout(this.lostT); clearTimeout(this.diagT); clearInterval(this.tick); clearInterval(this.statT);
    Tone.stop();
    if (why === 'busy') Tone.loop('busy'); else if (wasActive || why === 'decline' || why === 'noanswer' || why === 'lost') Tone.loop('end');
    try { if (this.local) this.local.getTracks().forEach(t => t.stop()); } catch (_) { }
    try { if (this.pc) this.pc.close(); } catch (_) { }
    if (Masks.running) Masks.stop();
    Masks.cur = 'none'; Calm.off();
    $('#cu-audio').srcObject = null;
    for (const id of ['#cu-rv', '#cu-fv', '#cu-lv']) $(id).srcObject = null;
    $('#cu-float').classList.add('hidden'); $('#cu-masks').classList.add('hidden');
    Native && Native.pipEnable && Native.pipEnable(false);
    Native && Native.callAudio && Native.callAudio(false);
    Native && Native.cancelCallNotif && Native.cancelCallNotif();
    if (mine && (why === 'noanswer' || why === 'cancel')) this.ring('stop');
    this.st = 'ended'; this.drawButtons();
    this.status((CALL_WHY[why] || 'Звонок завершён') + (dur ? ' · ' + fmtDur(dur) : ''));
    // запись в чате делает тот, кто звонил
    if (mine && why !== 'nomic') {
      const res = wasActive ? 'ok' : why === 'decline' ? 'declined' : why === 'busy' ? 'busy' : (why === 'failed' || why === 'lost') ? 'failed' : 'missed';
      sendPayload({ t: 'call', dur, res, video }).catch(() => { });
    }
    setTimeout(() => { if (this.st === 'ended') { this.st = 'idle'; this.hideUI(); } }, 1600);
  },
  reset() {
    this.localQ = []; this.remoteQ = []; this.localTypes = {}; this.remoteTypes = {}; this.descSent = false; this.gatherDone = false; this.turn = '';
    const n = document.getElementById('cu-net'); if (n) { n.textContent = ''; n.classList.remove('bad'); }
    this.ended = false; this.muted = false; this.offer = null; this.pc = null; this.local = null; this.t0 = 0;
    this.camTrack = null; this.vSender = null; this.camOn = false; this.facing = 'user';
    const ui = document.getElementById('callui'); if (ui) ui.classList.remove('has-rv', 'rcam-off');
    const cb = document.getElementById('cu-cam'); if (cb) { cb.classList.remove('on'); cb.innerHTML = '📷'; }
    const mb = document.getElementById('cu-mute'); if (mb) { mb.classList.remove('on'); mb.innerHTML = '🎤'; }
  },
  // ---------- экран ----------
  showUI() {
    const p = typeof Profile !== 'undefined' ? Profile.partner() : null, name = (p && p.name) || S.partner || 'Собеседник';
    const av = $('#cu-av'); if (typeof Profile !== 'undefined') Profile.avatarSet(av, p, name); else av.textContent = name[0];
    $('#cu-bg').style.backgroundImage = p && p.avatar ? `url("${p.avatar}")` : '';
    $('#cu-name').innerHTML = typeof Profile !== 'undefined' ? Profile.nameHtml(p, name) : esc(name);
    $('#cu-kind').textContent = this.video ? 'Видеозвонок' : 'Аудиозвонок';
    $('#callui').dataset.video = this.video ? '1' : '';
    $('#callui').classList.remove('hidden'); $('#cu-float').classList.add('hidden'); $('#call-return').classList.add('hidden');
    this.drawButtons(); Panel.close(); RxBar.close(); if (this.st === 'active' && this.video) Calm.poke();
    try { ta.blur(); } catch (_) { }
  },
  hideUI() { $('#callui').classList.add('hidden'); if (this.st === 'idle') $('#call-return').classList.add('hidden'); },
  drawButtons() {
    const st = this.st;
    $('#cu-in').classList.toggle('hidden', st !== 'incoming');
    $('#cu-on').classList.toggle('hidden', !(st === 'outgoing' || st === 'connecting' || st === 'active'));
    $('#callui').dataset.st = st;
  },
  status(t) { $('#cu-st').textContent = t; },
};

// запись о звонке в переписке
function callBubble(m) {
  const p = m.p, d = document.createElement('div'); d.className = 'bubble call-bubble';
  const out = m.mine, ok = p.res === 'ok';
  const title = ok ? (out ? 'Исходящий звонок' : 'Входящий звонок')
    : p.res === 'declined' ? (out ? 'Звонок отклонён' : 'Вы отклонили звонок')
      : p.res === 'busy' ? 'Было занято'
        : p.res === 'failed' ? 'Не удалось дозвониться'
          : (out ? 'Отменённый звонок' : 'Пропущенный звонок');
  const missed = !ok && !out;
  d.innerHTML = `<div class="cb"><span class="cb-ic${missed ? ' missed' : ''}">${p.video ? '🎥' : '📞'}</span><span class="cb-t"><b>${title}</b><small>${ok ? fmtDur(p.dur) : (out ? '↗' : '↙') + ' ' + fmtTime(m.ts)}</small></span><button class="cb-again" aria-label="Перезвонить">📞</button></div>${metaHtml(m)}`;
  d.querySelector('.cb-again').onclick = e => { e.stopPropagation(); Call.start(!!p.video); };
  return d;
}

$('#call-btn').onclick = () => Call.start(false);
$('#cu-accept').onclick = () => Call.accept();
$('#cu-decline').onclick = () => Call.decline();
$('#cu-hang').onclick = () => Call.hangup();
$('#cu-mute').onclick = () => Call.toggleMute();
$('#cu-spk').onclick = () => Call.setSpeaker(!Call.speaker);
$('#cu-min').onclick = () => {
  if (Call.st === 'incoming') return;
  Call.hideUI();
  if (Call.video && Call.st === 'active') $('#cu-float').classList.remove('hidden');
  else $('#call-return').classList.remove('hidden');
};
$('#call-return').onclick = () => { $('#call-return').classList.add('hidden'); Call.showUI(); };
$('#vcall-btn').onclick = () => Call.start(true);
$('#cu-cam').onclick = () => Call.toggleCam();
$('#cu-flip').onclick = () => Call.flip();
$('#cu-mask').onclick = () => { const p = $('#cu-masks'); p.classList.toggle('hidden'); if (!p.classList.contains('hidden')) Call.drawMasks(); };
$('#cu-masks').onclick = e => { const b = e.target.closest('[data-mask]'); if (b) { Call.setMask(b.dataset.mask); setTimeout(() => { $('#cu-masks').classList.add('hidden'); Calm.poke(); }, 250); } };
// спокойный режим: кнопки и надписи прячутся, чтобы не мешать смотреть
const Calm = {
  t: null,
  can() { const u = $('#callui'); return Call.video && Call.st === 'active' && u.classList.contains('has-rv') && !u.classList.contains('rcam-off') && $('#cu-masks').classList.contains('hidden'); },
  poke() { clearTimeout(this.t); $('#callui').classList.remove('calm'); this.t = setTimeout(() => { if (this.can()) $('#callui').classList.add('calm'); }, 5000); },
  off() { clearTimeout(this.t); $('#callui').classList.remove('calm'); },
};
$('#cu-rv').addEventListener('click', () => {
  if (!$('#cu-masks').classList.contains('hidden')) { $('#cu-masks').classList.add('hidden'); Calm.poke(); return; }
  if ($('#callui').classList.contains('calm')) Calm.poke(); else if (Calm.can()) { clearTimeout(Calm.t); $('#callui').classList.add('calm'); }
});
$('#cu-on').addEventListener('click', () => Calm.poke(), true);
// перетаскиваемые окошки: своё видео и мини-окно звонка
function draggable(el, onTap) {
  let sx, sy, ox, oy, moved = false;
  el.addEventListener('pointerdown', e => { sx = e.clientX; sy = e.clientY; const r = el.getBoundingClientRect(); ox = r.left; oy = r.top; moved = false; el.setPointerCapture(e.pointerId); });
  el.addEventListener('pointermove', e => {
    if (sx == null) return;
    const dx = e.clientX - sx, dy = e.clientY - sy; if (Math.abs(dx) + Math.abs(dy) > 6) moved = true; if (!moved) return;
    const r = el.getBoundingClientRect();
    el.style.left = Math.max(6, Math.min(innerWidth - r.width - 6, ox + dx)) + 'px'; el.style.top = Math.max(6, Math.min(innerHeight - r.height - 6, oy + dy)) + 'px'; el.style.right = 'auto';
  });
  el.addEventListener('pointerup', () => { if (!moved && onTap) onTap(); sx = null; });
}
draggable($('#cu-lv'));
draggable($('#cu-float'), () => Call.showUI());
// картинка в картинке (Android): свернули приложение во время видеозвонка
window.nativePip = function (on) {
  document.body.classList.toggle('pip', !!on);
  if (on && Call.st !== 'idle') { $('#callui').classList.remove('hidden'); $('#cu-float').classList.add('hidden'); $('#cu-masks').classList.add('hidden'); }
};
// приложение открыли кнопкой «Принять» из уведомления — звонок примем сразу, как придёт приглашение
window.nativeCallIntent = function (act) { if (act && act.startsWith('accept:') && Call.st === 'incoming' && act === 'accept:' + Call.id) Call.accept(); else if (act && act.startsWith('accept:')) Call.autoAcceptId = act.slice(7); };

// Opus: коррекция потерь (FEC) и стабильный битрейт — меньше «кусков» при плохой сети
function opusTune(sdp) {
  const m = /a=rtpmap:(\d+) opus\/48000/i.exec(sdp); if (!m) return sdp;
  const pt = m[1], re = new RegExp('a=fmtp:' + pt + ' ([^\\r\\n]*)');
  const add = { useinbandfec: '1', usedtx: '0', stereo: '0', maxaveragebitrate: '40000', minptime: '10' };
  if (re.test(sdp)) return sdp.replace(re, (all, params) => {
    const kv = {}; params.split(';').forEach(x => { const [k, v] = x.split('='); if (k) kv[k.trim()] = (v || '').trim(); });
    Object.assign(kv, add);
    return 'a=fmtp:' + pt + ' ' + Object.entries(kv).map(([k, v]) => k + '=' + v).join(';');
  });
  return sdp.replace(m[0], m[0] + '\r\na=fmtp:' + pt + ' ' + Object.entries(add).map(([k, v]) => k + '=' + v).join(';'));
}

function CAM_OPTS(facing) { return { facingMode: facing, width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 } }; }
