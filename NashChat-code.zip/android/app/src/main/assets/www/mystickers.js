'use strict';
/* «Наш чат» — «Мои стикеры»: свои картинки и GIF как стикеры.
   Хранятся только на этом телефоне (одни на все чаты). Отправляются зашифрованным файлом,
   поэтому собеседник видит стикер, даже если у него такого нет, и может сохранить его к себе. */

const MyStk = {
  db: null, list: [], urls: new Map(), ready: null,
  init() {
    if (this.ready) return this.ready;
    this.ready = new Promise(res => {
      try {
        const r = indexedDB.open('nashchat_stickers', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('st', { keyPath: 'id' });
        r.onsuccess = () => { this.db = r.result; this.load().then(res); };
        r.onerror = () => res();
      } catch (_) { res(); }
    });
    return this.ready;
  },
  tx(mode, fn) {
    return new Promise((res, rej) => {
      if (!this.db) return res();
      const t = this.db.transaction('st', mode); let out; const rq = fn(t.objectStore('st'));
      if (rq) rq.onsuccess = () => { out = rq.result; };
      t.oncomplete = () => res(out); t.onerror = () => rej(t.error);
    });
  },
  async load() { this.list = ((await this.tx('readonly', s => s.getAll()).catch(() => [])) || []).sort((a, b) => b.at - a.at); },
  url(rec) { if (!this.urls.has(rec.id)) this.urls.set(rec.id, URL.createObjectURL(rec.blob)); return this.urls.get(rec.id); },
  get(id) { return this.list.find(x => x.id === id); },
  // картинка → стикер: до 512 точек, WebP с прозрачностью; GIF оставляем как есть (анимация)
  async prepare(blob) {
    const type = (blob.type || '').toLowerCase();
    if (type === 'image/gif' && blob.size <= 3 * 1024 * 1024) {
      const img = await loadImage(blob); return { blob, mime: 'image/gif', w: img.naturalWidth || img.width, h: img.naturalHeight || img.height };
    }
    const img = await loadImage(blob);
    const W = img.naturalWidth || img.width, H = img.naturalHeight || img.height, k = Math.min(1, 512 / Math.max(W, H));
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(W * k)); c.height = Math.max(1, Math.round(H * k));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    let out = await new Promise(r => c.toBlob(r, 'image/webp', 0.86));
    if (!out || out.type !== 'image/webp') out = await new Promise(r => c.toBlob(r, 'image/png'));
    return { blob: out, mime: out.type, w: c.width, h: c.height };
  },
  async add(blob) {
    await this.init();
    const p = await this.prepare(blob);
    const id = hex(await crypto.subtle.digest('SHA-256', await p.blob.arrayBuffer())).slice(0, 24);
    if (this.get(id)) return { id, dup: true };
    const rec = { id, blob: p.blob, mime: p.mime, w: p.w, h: p.h, at: Date.now(), up: {} };
    await this.tx('readwrite', s => s.put(rec));
    this.list.unshift(rec);
    return { id };
  },
  async addFiles(files) {
    let ok = 0, dup = 0, bad = 0;
    for (const f of files) {
      if (!/^image\//.test(f.type || '')) { bad++; continue; }
      try { const r = await this.add(f); if (r.dup) dup++; else ok++; } catch (_) { bad++; }
    }
    toast(ok ? `Добавлено стикеров: ${ok} ⭐` + (dup ? ` (${dup} уже были)` : '') : dup ? 'Такие стикеры уже есть' : 'Не получилось — выберите картинку или GIF', 3000);
    if (Panel.open_ && Panel.pack === 'mine') Panel.drawStickers('mine');
  },
  async del(id) {
    await this.tx('readwrite', s => s.delete(id)).catch(() => { });
    this.list = this.list.filter(x => x.id !== id);
    const u = this.urls.get(id); if (u) { URL.revokeObjectURL(u); this.urls.delete(id); }
  },
  async send(id) {
    const rec = this.get(id); if (!rec) return;
    // файл загружается в каждый чат один раз, дальше отправляется ссылка на него
    let f = rec.up && rec.up[CHAT.id];
    if (!f) {
      f = await uploadBlob(rec.blob, rec.mime);
      rec.up = Object.assign({}, rec.up || {}, { [CHAT.id]: f });
      this.tx('readwrite', s => s.put(rec)).catch(() => { });
    } else DB.putMedia(f.id, rec.blob);
    await sendPayload({ t: 'sticker', cs: { file: f, w: rec.w, h: rec.h } });
  },
  async saveFrom(m) {
    const f = m.p && (m.p.cs ? m.p.cs.file : m.p.file);
    if (!f) return;
    try {
      const blob = await getMedia(f);
      const r = await this.add(blob);
      toast(r.dup ? 'Этот стикер уже есть у вас' : '⭐ Сохранено в «Мои стикеры»');
    } catch (_) { toast('Не удалось сохранить стикер'); }
  },
  // как стикер выглядит в переписке
  bubble(m, el) {
    const cs = m.p.cs, box = document.createElement('div'); box.className = 'sticker-box my-st';
    const img = document.createElement('img'); img.alt = 'стикер';
    const r = Math.min(1, 180 / Math.max(cs.w || 180, cs.h || 180));
    img.style.width = Math.round((cs.w || 180) * r) + 'px'; img.style.height = Math.round((cs.h || 180) * r) + 'px';
    box.appendChild(img); box.insertAdjacentHTML('beforeend', metaHtml(m));
    getMedia(cs.file).then(b => mediaUrl(cs.file.id, b)).then(u => { img.src = u; }).catch(() => { img.replaceWith(Object.assign(document.createElement('div'), { className: 'st-miss', textContent: '🧸' })); });
    el.appendChild(box);
  },
  // вкладка в панели стикеров
  async draw(box) {
    await this.init();
    const tiles = this.list.map(r => `<button data-mst="${r.id}"><img src="${this.url(r)}" alt=""></button>`).join('');
    box.innerHTML = `<div class="ep-h">Мои стикеры</div><div class="st-grid">
      <button class="st-add" data-madd="1"><span>＋</span><small>Добавить</small></button>${tiles}</div>
      ${this.list.length ? '<p class="st-tip muted">Подержите стикер, чтобы удалить.</p>' : `<p class="st-tip muted">Добавьте любые картинки или GIF с телефона — они станут вашими стикерами.
      Понравился стикер собеседника? Подержите его в чате → «Сохранить в мои стикеры».<br><br>
      Свои стикеры из Telegram можно сохранить картинками через бота @Stickerdownloadbot и добавить сюда.</p>`}`;
    box.scrollTop = 0;
    box.querySelectorAll('[data-mst]').forEach(b => attachLongPress(b, () => { this.lp = Date.now(); sheet([
      { icon: 'trash', label: 'Удалить из моих стикеров', danger: true, fn: async () => { await this.del(b.dataset.mst); Panel.drawStickers('mine'); } },
    ]); }));
  },
};
$('#pick-stk').onchange = () => { const fs = [...$('#pick-stk').files]; $('#pick-stk').value = ''; if (fs.length) MyStk.addFiles(fs); };
MyStk.init();
