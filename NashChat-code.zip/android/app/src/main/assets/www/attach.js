'use strict';
/* «Наш чат» — выбор вложений как в Telegram: галерея телефона (фото и видео) с отметками,
   внизу — Галерея / Файл / Камера / Подарок. В «⋮»: скрыть под размытием, со сжатием или без. */

const Attach = {
  sel: [], items: [], loaded: 0, done: false, loading: false, spoiler: false, orig: false,
  open() {
    Panel.close(); RxBar.close(); try { ta.blur(); } catch (_) { }
    this.sel = []; this.spoiler = false; this.orig = false;
    $('#attach-sheet').classList.remove('hidden');
    requestAnimationFrame(() => $('#attach-sheet').classList.add('open'));
    this.drawBar(); this.show();
  },
  close() {
    const s = $('#attach-sheet'); s.classList.remove('open');
    setTimeout(() => s.classList.add('hidden'), 220);
  },
  isOpen() { return !$('#attach-sheet').classList.contains('hidden'); },
  state() { try { return Native && Native.galleryState ? Native.galleryState() : 'nonative'; } catch (_) { return 'nonative'; } },
  // ---------- сетка ----------
  show() {
    const st = this.state(), box = $('#at-grid');
    if (st === 'nonative' || st === 'none') {
      box.innerHTML = `<div class="at-perm"><div class="at-perm-ic">🖼</div>
        <b>${st === 'none' ? 'Покажем ваши фото и видео прямо здесь' : 'Фото и видео с телефона'}</b>
        <p>${st === 'none' ? 'Разрешите доступ к галерее — фото никуда не загружаются, пока вы сами их не отправите.' : 'Выберите фото или видео в галерее телефона.'}</p>
        ${st === 'none' ? '<button class="btn primary" id="at-ask">Разрешить доступ</button>' : ''}
        <button class="btn" id="at-sys">Открыть галерею телефона</button></div>`;
      const a = $('#at-ask'); if (a) a.onclick = () => Native.galleryAsk();
      $('#at-sys').onclick = () => this.system();
      return;
    }
    if (!this.items.length) this.more(true); else this.drawGrid();
  },
  more(reset) {
    if (reset) { this.items = []; this.loaded = 0; this.done = false; }
    if (this.loading || this.done) return;
    this.loading = true;
    let list = [];
    try { list = JSON.parse(Native.galleryList(this.loaded, 90) || '[]'); } catch (_) { }
    this.loading = false;
    this.items.push(...list); this.loaded += list.length;
    if (list.length < 90) this.done = true;
    this.drawGrid();
  },
  drawGrid() {
    const box = $('#at-grid'), st = this.state();
    if (!this.items.length) { box.innerHTML = '<div class="at-perm"><div class="at-perm-ic">📭</div><b>В галерее пока пусто</b><button class="btn" id="at-sys">Открыть галерею телефона</button></div>'; $('#at-sys').onclick = () => this.system(); return; }
    box.innerHTML = (st === 'partial' ? '<button class="at-partial" id="at-more-perm">Видны только выбранные фото — <b>выбрать ещё</b></button>' : '') +
      '<div class="at-g">' + this.items.map(x => {
        const n = this.sel.findIndex(s => s.id === x.id && s.t === x.t);
        return `<button class="at-it${n >= 0 ? ' on' : ''}" data-k="${x.t}:${x.id}"><img src="/gallery/thumb/${x.t}/${x.id}" loading="lazy" alt="">${x.t === 'v' ? `<span class="at-dur">▶ ${fmtDur(x.dur / 1000)}</span>` : ''}<i class="at-c">${n >= 0 ? n + 1 : ''}</i></button>`;
      }).join('') + '</div>';
    const mp = $('#at-more-perm'); if (mp) mp.onclick = () => Native.galleryAsk();
  },
  toggle(k) {
    const [t, id] = k.split(':'), x = this.items.find(i => i.t === t && String(i.id) === id); if (!x) return;
    const n = this.sel.findIndex(s => s.id === x.id && s.t === x.t);
    if (n >= 0) this.sel.splice(n, 1); else { if (this.sel.length >= 20) { toast('Не больше 20 за раз'); return; } this.sel.push(x); }
    vibrate(8);
    // обновляем номера без перерисовки всей сетки
    document.querySelectorAll('#at-grid .at-it').forEach(el => {
      const [tt, ii] = el.dataset.k.split(':'), j = this.sel.findIndex(s => s.t === tt && String(s.id) === ii);
      el.classList.toggle('on', j >= 0); el.querySelector('.at-c').textContent = j >= 0 ? j + 1 : '';
    });
    this.drawBar();
  },
  drawBar() {
    const n = this.sel.length;
    $('#at-tabs').classList.toggle('hidden', n > 0);
    $('#at-send-bar').classList.toggle('hidden', n === 0);
    $('#at-send').textContent = 'Отправить' + (n > 1 ? ' ' + n : '');
    $('#at-flags').textContent = [this.spoiler ? '🌫 скрыто' : '', this.orig ? '🖼 без сжатия' : ''].filter(Boolean).join(' · ');
  },
  menu() {
    const onePhoto = this.sel.length === 1 && this.sel[0].t === 'i';
    const items = [
      { icon: 'image', label: this.spoiler ? '👁 Не скрывать' : '🌫 Скрыть под размытием', fn: () => { this.spoiler = !this.spoiler; this.drawBar(); } },
      { icon: 'image', label: this.orig ? '📦 Отправить со сжатием' : '🖼 Отправить без сжатия', fn: () => { this.orig = !this.orig; this.drawBar(); } },
    ];
    if (onePhoto) items.push({ icon: 'edit', label: '🎨 Редактировать', fn: () => this.send(true) });
    sheet(items, 'Скрытое фото или видео будет размыто, пока собеседник не нажмёт на него. Видео всегда уходят в исходном качестве.');
  },
  async file(x) {
    const r = await fetch(`/gallery/file/${x.t}/${x.id}`);
    if (!r.ok) throw new Error('нет доступа к файлу');
    const blob = await r.blob();
    return new File([blob], x.name || ((x.t === 'v' ? 'video_' : 'photo_') + x.id + (x.t === 'v' ? '.mp4' : '.jpg')), { type: x.mime || blob.type });
  },
  async send(edit) {
    const list = this.sel.slice(), mode = this.orig ? 'orig' : 'media', opts = { spoiler: this.spoiler };
    this.close();
    if (edit && list.length === 1) {
      try { const f = await this.file(list[0]); editThenSend(f, mode, opts); } catch (e) { toast('Не удалось открыть фото'); }
      return;
    }
    for (const x of list) {
      try { const f = await this.file(x); await sendOneFile(f, mode, opts); }
      catch (e) { toast('Не удалось отправить: ' + (x.name || 'файл')); }
    }
  },
  // запасной путь — системный выбор файлов
  system() { S.pickOrig = this.orig; S.pickSpoiler = this.spoiler; this.close(); $('#pick-media').click(); },
};
$('#at-grid').addEventListener('click', e => { const it = e.target.closest('.at-it'); if (it) Attach.toggle(it.dataset.k); });
$('#at-grid').addEventListener('scroll', () => { const g = $('#at-grid'); if (g.scrollTop + g.clientHeight > g.scrollHeight - 600) Attach.more(); });
$('#attach-sheet').addEventListener('click', e => { if (e.target.id === 'attach-sheet') Attach.close(); });
$('#at-more').onclick = () => Attach.menu();
$('#at-send').onclick = () => Attach.send(false);
$('#at-tabs').addEventListener('click', e => {
  const b = e.target.closest('[data-at]'); if (!b) return;
  const a = b.dataset.at;
  if (a === 'gallery') { Attach.show(); return; }
  Attach.close();
  setTimeout(() => {
    if (a === 'file') $('#pick-file').click();
    else if (a === 'camera') $('#pick-cam').click();
    else if (a === 'gift') Gifts.openShop();
  }, 120);
});
// свайп вниз по ручке — закрыть
(() => {
  const h = $('#at-grip'); let y0 = null;
  h.addEventListener('touchstart', e => { y0 = e.touches[0].clientY; }, { passive: true });
  h.addEventListener('touchend', e => { if (y0 != null && e.changedTouches[0].clientY - y0 > 60) Attach.close(); y0 = null; });
  h.addEventListener('click', () => Attach.close());
})();
window.onGalleryPerm = st => { if (Attach.isOpen()) { Attach.items = []; Attach.show(); } if (st === 'none') toast('Без доступа к галерее можно выбрать фото через «Открыть галерею телефона»', 4000); };
$('#pick-cam').onchange = e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (/^image\//.test(f.type)) editThenSend(f, 'media'); else sendOneFile(f, 'media').catch(() => { });
};
