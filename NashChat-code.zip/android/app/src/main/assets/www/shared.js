'use strict';
/* «Наш чат» — общие разделы: календарь, заметки, банк.
   Каждая запись шифруется на телефоне тем же ключом, что и переписка; сервер хранит только шифр. */

/* ================= общее хранилище ================= */
const Docs = {
  map: new Map(),           // id -> { id, v, ct, data }
  dv: 0, fetching: false, again: false, ready: false, listeners: new Set(), saveT: null,
  KEY: 'nc_docs',
  async init() {
    let c = null;
    try { c = JSON.parse(localStorage.getItem(this.KEY) || 'null'); } catch (_) { }
    if (c && Array.isArray(c.docs)) {
      this.dv = c.dv || 0;
      for (const x of c.docs) await this.ingest(x, true);
    }
    this.emit([]);
  },
  saveCache() {
    clearTimeout(this.saveT);
    this.saveT = setTimeout(() => {
      try { localStorage.setItem(this.KEY, JSON.stringify({ dv: this.dv, docs: [...this.map.values()].map(x => ({ id: x.id, v: x.v, ct: x.ct })) })); } catch (_) { }
    }, 400);
  },
  async ingest(x, force) {
    if (x.del) { const had = this.map.has(x.id); this.map.delete(x.id); return had; }
    const cur = this.map.get(x.id);
    if (cur && !force && cur.v >= x.v) return false;
    try {
      const data = JSON.parse(dec.decode(await Crypto.open(S.key, unb64(x.ct), 'doc:' + x.id)));
      this.map.set(x.id, { id: x.id, v: x.v, ct: x.ct, data });
      return true;
    } catch (_) { return false; }
  },
  check(dv, first) { if (dv > this.dv) this.fetch(first); else if (first) this.ready = true; },
  async fetch(first) {
    if (this.fetching) { this.again = true; return; }
    this.fetching = true;
    try {
      do {
        this.again = false;
        const r = await api('/api/docs?since=' + this.dv, { timeout: 30000 });
        const changes = [];
        for (const x of r.docs) {
          const before = this.map.get(x.id);
          if (await this.ingest(x)) changes.push({ id: x.id, before: before && before.data, after: this.map.has(x.id) ? this.map.get(x.id).data : null });
        }
        this.dv = Math.max(this.dv, r.dv);
        this.saveCache();
        if (changes.length) this.emit(changes, !this.ready || first);
      } while (this.again);
      this.ready = true;
    } catch (_) { }
    finally { this.fetching = false; }
  },
  list(c) { const out = []; for (const x of this.map.values()) if (x.data.c === c) out.push(Object.assign({ id: x.id }, x.data)); return out; },
  get(id) { const x = this.map.get(id); return x ? Object.assign({ id }, x.data) : null; },
  newId(p) { return p + '_' + hex(crypto.getRandomValues(new Uint8Array(8))); },
  async put(id, data) {
    data = Object.assign({}, data, { upd: Date.now(), by: S.name, dev: S.dev });
    delete data.id;
    const ct = b64(await Crypto.seal(S.key, enc.encode(JSON.stringify(data)), 'doc:' + id));
    const prev = this.map.get(id);
    this.map.set(id, { id, v: prev ? prev.v : 0, ct, data });
    this.emit([{ id, local: true, after: data }]);
    try {
      const r = await api('/api/doc', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, ct, dev: S.dev }), timeout: 20000 });
      const cur = this.map.get(id); if (cur && cur.ct === ct) cur.v = r.v;
      this.saveCache();
      return true;
    } catch (e) {
      toast(e.status === 404 ? 'Обновите сервер, чтобы работали календарь, заметки и банк' : 'Не удалось сохранить — нет связи');
      return false;
    }
  },
  async del(id) {
    this.map.delete(id);
    this.emit([{ id, local: true, after: null }]);
    try { await api('/api/doc', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, ct: null, dev: S.dev }), timeout: 20000 }); this.saveCache(); }
    catch (_) { toast('Не удалось удалить — нет связи'); }
  },
  on(fn) { this.listeners.add(fn); },
  emit(ch, quiet) { for (const f of this.listeners) { try { f(ch, quiet); } catch (e) { console.error(e); } } },
  clear() { try { localStorage.removeItem(this.KEY); } catch (_) { } this.map.clear(); this.dv = 0; },
};

/* ================= утилиты ================= */
const pad = n => String(n).padStart(2, '0');
const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const parseYmd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const todayYmd = () => ymd(new Date());
const MONTHS_NOM = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const WDAYS = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
function dayTitle(s) { const d = parseYmd(s); return d.getDate() + ' ' + MONTHS[d.getMonth()] + ', ' + WDAYS[d.getDay()]; }
function daysBetween(a, b) { return Math.round((parseYmd(b) - parseYmd(a)) / 86400000); }
function inDays(n) { return n === 0 ? 'сегодня' : n === 1 ? 'завтра' : n === 2 ? 'послезавтра' : 'через ' + n + ' ' + plural(n, 'день', 'дня', 'дней'); }
const moneyFmt = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });
const money = n => moneyFmt.format(Math.round((n || 0) * 100) / 100) + ' ₽';
function agoShort(ts) {
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return 'только что'; if (m < 60) return m + ' мин назад';
  const h = Math.round(m / 60); if (h < 24) return h + ' ч назад';
  const d = new Date(ts); return d.getDate() + ' ' + MONTHS[d.getMonth()];
}
const whoName = x => x && x.dev === S.dev ? 'вы' : ((x && x.by) || S.partner || 'собеседник');

/* ================= форма в нижней шторке ================= */
const Form = {
  cfg: null, vals: null,
  open(cfg) {
    this.cfg = cfg; this.vals = Object.assign({}, cfg.values || {});
    for (const f of cfg.fields) if (this.vals[f.k] === undefined && f.def !== undefined) this.vals[f.k] = typeof f.def === 'function' ? f.def() : f.def;
    this.draw();
    $('#formsheet').classList.remove('hidden');
    const first = $('#form-box').querySelector('[data-autofocus]'); if (first) setTimeout(() => first.focus(), 80);
  },
  close() { $('#formsheet').classList.add('hidden'); this.cfg = null; },
  isOpen() { return !!this.cfg; },
  collect() {
    $('#form-box').querySelectorAll('[data-k]').forEach(el => {
      const k = el.dataset.k, f = this.cfg.fields.find(x => x.k === k); if (!f) return;
      if (f.type === 'toggle') return;
      if (f.type === 'chips') return;
      if (f.type === 'number') { const v = el.value.replace(/\s/g, '').replace(',', '.'); this.vals[k] = v === '' ? '' : Number(v); }
      else this.vals[k] = el.value;
    });
  },
  draw() {
    const c = this.cfg, v = this.vals;
    let h = `<div class="fm-h"><b>${esc(c.title)}</b><button class="icon" data-fm="close">✕</button></div>`;
    for (const f of c.fields) {
      if (f.show && !f.show(v)) continue;
      const val = v[f.k] == null ? '' : v[f.k];
      h += `<div class="fm-f">`;
      if (f.label && f.type !== 'toggle') h += `<div class="fm-l">${esc(f.label)}</div>`;
      switch (f.type) {
        case 'textarea': h += `<textarea data-k="${f.k}" rows="3" placeholder="${esc(f.ph || '')}">${esc(val)}</textarea>`; break;
        case 'number': h += `<input data-k="${f.k}" inputmode="decimal" placeholder="${esc(f.ph || '0')}" value="${esc(val)}" ${f.focus ? 'data-autofocus' : ''} class="${f.big ? 'fm-big' : ''}">`; break;
        case 'date': h += `<input data-k="${f.k}" type="date" value="${esc(val)}">`; break;
        case 'time': h += `<input data-k="${f.k}" type="time" value="${esc(val)}">`; break;
        case 'select': h += `<select data-k="${f.k}">${f.opts(v).map(o => `<option value="${esc(o.v)}" ${o.v === val ? 'selected' : ''}>${esc(o.t)}</option>`).join('')}</select>`; break;
        case 'chips': h += `<div class="fm-chips ${f.wrap ? 'wrap' : ''}">${(typeof f.opts === 'function' ? f.opts(v) : f.opts).map(o => `<button data-chip="${f.k}" data-v="${esc(o.v)}" class="${o.v === val ? 'on' : ''}">${esc(o.t)}</button>`).join('')}</div>`; break;
        case 'toggle': h += `<button class="fm-tog" data-tog="${f.k}"><span>${esc(f.label)}</span><span class="switch ${val ? 'on' : ''}"></span></button>`; break;
        default: h += `<input data-k="${f.k}" maxlength="${f.max || 120}" placeholder="${esc(f.ph || '')}" value="${esc(val)}" ${f.focus ? 'data-autofocus' : ''}>`;
      }
      h += `</div>`;
    }
    h += `<p class="err" id="fm-err"></p><div class="fm-btns">`;
    if (c.onDelete) h += `<button class="btn danger-btn" data-fm="del">Удалить</button>`;
    h += `<button class="btn primary" data-fm="save">${esc(c.saveLabel || 'Сохранить')}</button></div>`;
    $('#form-box').innerHTML = h;
  },
};
$('#formsheet').addEventListener('click', async e => {
  if (e.target.id === 'formsheet') { Form.close(); return; }
  const c = Form.cfg; if (!c) return;
  const chip = e.target.closest('[data-chip]');
  if (chip) { Form.collect(); Form.vals[chip.dataset.chip] = chip.dataset.v; Form.draw(); return; }
  const tog = e.target.closest('[data-tog]');
  if (tog) { Form.collect(); Form.vals[tog.dataset.tog] = !Form.vals[tog.dataset.tog]; Form.draw(); return; }
  const b = e.target.closest('[data-fm]'); if (!b) return;
  if (b.dataset.fm === 'close') { Form.close(); return; }
  if (b.dataset.fm === 'del') {
    if (b.dataset.sure) { const fn = c.onDelete; Form.close(); fn(); }
    else { b.dataset.sure = '1'; b.textContent = 'Точно удалить?'; }
    return;
  }
  if (b.dataset.fm === 'save') {
    Form.collect();
    const err = c.onSave(Form.vals);
    if (err) { $('#fm-err').textContent = err; return; }
    Form.close();
  }
});

/* ================= календарь ================= */
const KINDS = [
  { v: 'love', e: '❤️', t: 'Наше' }, { v: 'bday', e: '🎂', t: 'День рождения' }, { v: 'trip', e: '✈️', t: 'Поездка' },
  { v: 'party', e: '🎉', t: 'Праздник' }, { v: 'health', e: '🩺', t: 'Здоровье' }, { v: 'work', e: '💼', t: 'Дела' }, { v: 'pin', e: '📌', t: 'Другое' },
];
const kindOf = v => KINDS.find(k => k.v === v) || KINDS[KINDS.length - 1];
const Cal = {
  y: 0, m: 0, sel: '',
  events() { return Docs.list('cal'); },
  occurs(ev, ds) { return ev.date === ds || (ev.yearly && ds > ev.date && ev.date.slice(5) === ds.slice(5)); },
  on(ds) { return this.events().filter(ev => this.occurs(ev, ds)).sort((a, b) => (a.time || '99').localeCompare(b.time || '99')); },
  next(ev, from) {
    if (!ev.yearly) return ev.date >= from ? ev.date : null;
    if (from <= ev.date) return ev.date;
    const y = +from.slice(0, 4); let d = y + ev.date.slice(4);
    if (d < from) d = (y + 1) + ev.date.slice(4);
    return d;
  },
  upcoming(n) {
    const t = todayYmd();
    return this.events().map(ev => ({ ev, d: this.next(ev, t) })).filter(x => x.d).sort((a, b) => a.d.localeCompare(b.d) || (a.ev.time || '').localeCompare(b.ev.time || '')).slice(0, n);
  },
  years(ev, d) { const n = +d.slice(0, 4) - +ev.date.slice(0, 4); return ev.yearly && n > 0 ? n : 0; },
  soonLabel() { const u = this.upcoming(1)[0]; if (!u) return ''; const n = daysBetween(todayYmd(), u.d); return n <= 7 ? kindOf(u.ev.kind).e + ' ' + inDays(n) : ''; },
  open(date) {
    const d = date ? parseYmd(date) : new Date();
    this.y = d.getFullYear(); this.m = d.getMonth(); this.sel = date || todayYmd();
    this.draw(); show('cal'); $('#cal').scrollTop = 0;
  },
  draw() {
    const t = todayYmd();
    // ближайшие
    const up = this.upcoming(3);
    $('#cal-up').innerHTML = up.length ? `<div class="cu-h">Ближайшие</div>` + up.map(({ ev, d }) => {
      const n = daysBetween(t, d), yrs = this.years(ev, d);
      return `<button class="cu-item" data-open="${ev.id}" data-date="${d}"><span class="cu-e">${kindOf(ev.kind).e}</span><span class="cu-t"><b>${esc(ev.title)}</b><small>${dayTitle(d)}${ev.time ? ', ' + esc(ev.time) : ''}${yrs ? ' · ' + yrs + ' ' + plural(yrs, 'год', 'года', 'лет') : ''}</small></span><span class="cu-n ${n <= 1 ? 'hot' : ''}">${inDays(n)}</span></button>`;
    }).join('') : `<div class="cu-empty">Добавьте важные даты — годовщины, дни рождения, поездки. Их увидите вы оба 💞</div>`;
    // месяц
    $('#cal-title').textContent = MONTHS_NOM[this.m] + ' ' + this.y;
    const first = new Date(this.y, this.m, 1), start = (first.getDay() + 6) % 7, days = new Date(this.y, this.m + 1, 0).getDate();
    const evs = this.events();
    let g = '';
    for (let i = 0; i < start; i++) g += '<span class="cd cd-blank"></span>';
    for (let d = 1; d <= days; d++) {
      const ds = this.y + '-' + pad(this.m + 1) + '-' + pad(d);
      const list = evs.filter(ev => this.occurs(ev, ds));
      const marks = list.slice(0, 3).map(ev => kindOf(ev.kind).e).join('');
      g += `<button class="cd${ds === t ? ' today' : ''}${ds === this.sel ? ' sel' : ''}${list.length ? ' has' : ''}" data-d="${ds}"><span class="cd-n">${d}</span>${marks ? `<span class="cd-m">${marks}</span>` : ''}</button>`;
    }
    $('#cal-grid').innerHTML = g;
    // выбранный день
    $('#cal-day-title').textContent = dayTitle(this.sel);
    const list = this.on(this.sel);
    $('#cal-day-list').innerHTML = list.length ? list.map(ev => {
      const yrs = this.years(ev, this.sel);
      return `<button class="ev" data-open="${ev.id}"><span class="ev-e">${kindOf(ev.kind).e}</span><span class="ev-t"><b>${esc(ev.title)}</b>${ev.time ? `<span class="ev-time">${esc(ev.time)}</span>` : ''}${yrs ? `<span class="ev-yrs">${yrs} ${plural(yrs, 'год', 'года', 'лет')}</span>` : ''}${ev.note ? `<small>${esc(ev.note)}</small>` : ''}<i class="ev-by">${ev.yearly ? '🔁 каждый год · ' : ''}${ev.dev === S.dev ? 'добавили вы' : 'добавил(а) ' + esc(whoName(ev))}</i></span></button>`;
    }).join('') : `<div class="cu-empty">В этот день ничего не запланировано</div>`;
  },
  edit(ev, date) {
    Form.open({
      title: ev ? 'Событие' : 'Новое событие',
      values: ev ? Object.assign({}, ev) : { date: date || this.sel, kind: 'pin', yearly: false },
      fields: [
        { k: 'title', label: 'Название', ph: 'Например: Годовщина свадьбы', focus: !ev },
        { k: 'kind', label: 'Тип', type: 'chips', wrap: true, opts: KINDS.map(k => ({ v: k.v, t: k.e + ' ' + k.t })) },
        { k: 'date', label: 'Дата', type: 'date' },
        { k: 'time', label: 'Время (необязательно)', type: 'time' },
        { k: 'yearly', label: '🔁 Повторять каждый год', type: 'toggle' },
        { k: 'note', label: 'Заметка', type: 'textarea', ph: 'Подробности, адрес, идеи подарка…' },
      ],
      onSave: v => {
        if (!String(v.title || '').trim()) return 'Введите название';
        if (!/^\d{4}-\d{2}-\d{2}$/.test(v.date || '')) return 'Выберите дату';
        const id = ev ? ev.id : Docs.newId('cal');
        Docs.put(id, { c: 'cal', title: v.title.trim(), kind: v.kind, date: v.date, time: v.time || '', yearly: !!v.yearly, note: String(v.note || '').trim() });
        this.sel = v.date; const d = parseYmd(v.date); this.y = d.getFullYear(); this.m = d.getMonth();
      },
      onDelete: ev ? () => Docs.del(ev.id) : null,
    });
  },
  todayCheck() {
    const t = todayYmd();
    let seen = {}; try { seen = JSON.parse(localStorage.getItem('nc_cal_seen') || '{}'); } catch (_) { }
    if (seen.d !== t) seen = { d: t, ids: [] };
    const list = this.on(t).filter(ev => !seen.ids.includes(ev.id));
    if (!list.length) return;
    const ev = list[0], yrs = this.years(ev, t);
    seen.ids.push(...list.map(x => x.id));
    try { localStorage.setItem('nc_cal_seen', JSON.stringify(seen)); } catch (_) { }
    Shared.banner(`${kindOf(ev.kind).e} Сегодня: ${ev.title}${yrs ? ' — ' + yrs + ' ' + plural(yrs, 'год', 'года', 'лет') : ''}${list.length > 1 ? ' и ещё ' + (list.length - 1) : ''}`, () => this.open(t));
    if (ev.kind === 'love' || ev.kind === 'bday') setTimeout(() => FX.play(ev.kind === 'bday' ? 'birthday' : 'love'), 600);
  },
};
$('#cal-prev').onclick = () => { Cal.m--; if (Cal.m < 0) { Cal.m = 11; Cal.y--; } Cal.draw(); };
$('#cal-next').onclick = () => { Cal.m++; if (Cal.m > 11) { Cal.m = 0; Cal.y++; } Cal.draw(); };
$('#cal-grid').onclick = e => { const b = e.target.closest('[data-d]'); if (!b) return; if (Cal.sel === b.dataset.d && !Cal.on(Cal.sel).length) { Cal.edit(null, Cal.sel); return; } Cal.sel = b.dataset.d; Cal.draw(); };
$('#cal-add').onclick = () => Cal.edit(null, Cal.sel);
$('#cal').addEventListener('click', e => {
  const b = e.target.closest('[data-open]'); if (!b) return;
  const ev = Docs.get(b.dataset.open); if (!ev) return;
  if (b.classList.contains('cu-item')) { Cal.sel = b.dataset.date; const d = parseYmd(Cal.sel); Cal.y = d.getFullYear(); Cal.m = d.getMonth(); Cal.draw(); }
  Cal.edit(ev);
});

/* ================= заметки ================= */
const NOTE_COLORS = ['', '#ffe9a8', '#ffd2dc', '#d4f1df', '#d6e8ff', '#e8dcff', '#ffdcc2'];
const Notes = {
  cur: null, dirty: false, saveT: null,
  open() { this.draw(); show('notes'); },
  draw() {
    const list = Docs.list('note').sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || b.upd - a.upd);
    $('#notes-grid').innerHTML = list.length ? list.map(n => {
      let body = '';
      if (n.kind === 'list') {
        const items = (n.items || []).filter(i => String(i.t).trim()), done = items.filter(i => i.d).length;
        body = items.slice(0, 6).map(i => `<div class="nc-li${i.d ? ' d' : ''}">${i.d ? '☑' : '☐'} ${esc(i.t)}</div>`).join('') + (items.length ? `<div class="nc-cnt">${done} из ${items.length}</div>` : '');
      } else body = `<div class="nc-txt">${esc((n.body || '').slice(0, 220))}</div>`;
      return `<button class="ncard" data-id="${n.id}" style="${n.color ? '--nc:' + n.color : ''}">${n.pin ? '<span class="nc-pin">📌</span>' : ''}${n.title ? `<b>${esc(n.title)}</b>` : ''}${body}<i>${esc(whoName(n))} · ${agoShort(n.upd)}</i></button>`;
    }).join('') : `<div class="empty"><div>📝</div>Здесь будут общие заметки и списки — например, список покупок или идеи на выходные</div>`;
  },
  create() {
    sheet([
      { icon: 'edit', label: 'Заметка', fn: () => this.edit({ id: Docs.newId('note'), c: 'note', kind: 'text', title: '', body: '', color: '', pin: false }, true) },
      { icon: 'check', label: 'Список с галочками', fn: () => this.edit({ id: Docs.newId('note'), c: 'note', kind: 'list', title: '', items: [{ t: '', d: false }], color: '', pin: false }, true) },
    ], 'Что создать?');
  },
  edit(n, fresh) {
    this.cur = JSON.parse(JSON.stringify(n)); this.dirty = false; this.fresh = !!fresh;
    this.fill(); show('noteed');
    if (fresh) setTimeout(() => (n.kind === 'list' ? $('#ne-list input.ni-t') : $('#ne-body')).focus(), 80);
  },
  fill() {
    const n = this.cur;
    $('#ne-title').value = n.title || '';
    $('#ne-colors').innerHTML = NOTE_COLORS.map(c => `<button data-c="${c}" class="${(n.color || '') === c ? 'on' : ''}" style="background:${c || 'var(--panel)'}"></button>`).join('');
    $('#ne-pin').classList.toggle('on', !!n.pin);
    $('#noteed').style.setProperty('--nc', n.color || 'var(--bg)');
    $('#noteed').classList.toggle('tinted', !!n.color);
    const isList = n.kind === 'list';
    $('#ne-body').classList.toggle('hidden', isList); $('#ne-list').classList.toggle('hidden', !isList);
    if (isList) this.drawList(); else { $('#ne-body').value = n.body || ''; this.grow(); }
    $('#ne-info').textContent = n.upd ? 'Изменено: ' + whoName(n) + ', ' + agoShort(n.upd) : '';
  },
  drawList(focusIdx) {
    const items = this.cur.items || (this.cur.items = []);
    const open = items.map((it, i) => ({ it, i })).filter(x => !x.it.d), done = items.map((it, i) => ({ it, i })).filter(x => x.it.d);
    const row = ({ it, i }) => `<div class="ni${it.d ? ' d' : ''}" data-i="${i}"><button class="ni-cb">${it.d ? '☑' : '☐'}</button><input class="ni-t" value="${esc(it.t)}" placeholder="Пункт списка"><button class="ni-x" aria-label="Удалить">✕</button></div>`;
    $('#ne-list').innerHTML = open.map(row).join('') + `<button class="ni-add">＋ Добавить пункт</button>` + (done.length ? `<div class="ni-done-h">Готово (${done.length})</div>` + done.map(row).join('') : '');
    if (focusIdx != null) { const el = $(`#ne-list .ni[data-i="${focusIdx}"] .ni-t`); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } }
  },
  grow() { const t = $('#ne-body'); t.style.height = 'auto'; t.style.height = Math.max(220, t.scrollHeight) + 'px'; },
  touch() { this.dirty = true; clearTimeout(this.saveT); this.saveT = setTimeout(() => this.save(), 1200); },
  empty(n) { return !String(n.title || '').trim() && (n.kind === 'list' ? !(n.items || []).some(i => String(i.t).trim()) : !String(n.body || '').trim()); },
  save() {
    clearTimeout(this.saveT);
    const n = this.cur; if (!n || !this.dirty) return;
    this.dirty = false;
    if (this.empty(n)) return;
    const data = Object.assign({}, n);
    if (data.kind === 'list') data.items = (data.items || []).filter(i => String(i.t).trim() || i === data.items[data.items.length - 1]).map(i => ({ t: String(i.t), d: !!i.d }));
    Docs.put(n.id, data);
    this.fresh = false;
  },
  close() {
    const n = this.cur;
    if (n && n.kind === 'list') { const before = (n.items || []).length; n.items = (n.items || []).filter(i => String(i.t).trim()); if (n.items.length !== before) this.dirty = true; }
    this.save();
    if (n && this.fresh && this.empty(n)) { /* пустая новая заметка — не сохраняем */ }
    this.cur = null; this.draw(); show('notes');
  },
  remote(changes) {
    if (!this.cur || this.dirty) return;
    const ch = changes.find(c => c.id === this.cur.id && !c.local);
    if (!ch) return;
    if (!ch.after) { toast('Эту заметку удалили'); this.cur = null; this.draw(); show('notes'); return; }
    const focusedTitle = document.activeElement === $('#ne-title');
    this.cur = Object.assign({ id: this.cur.id }, JSON.parse(JSON.stringify(ch.after)));
    if (!focusedTitle) this.fill();
  },
};
$('#notes-add').onclick = () => Notes.create();
$('#notes-grid').onclick = e => { const b = e.target.closest('.ncard'); if (!b) return; const n = Docs.get(b.dataset.id); if (n) Notes.edit(n); };
$('#ne-back').onclick = () => Notes.close();
$('#ne-title').oninput = e => { Notes.cur.title = e.target.value; Notes.touch(); };
$('#ne-body').oninput = e => { Notes.cur.body = e.target.value; Notes.grow(); Notes.touch(); };
$('#ne-colors').onclick = e => { const b = e.target.closest('[data-c]'); if (!b) return; Notes.cur.color = b.dataset.c; Notes.touch(); Notes.fill(); };
$('#ne-pin').onclick = () => { Notes.cur.pin = !Notes.cur.pin; Notes.touch(); $('#ne-pin').classList.toggle('on', Notes.cur.pin); toast(Notes.cur.pin ? 'Заметка закреплена' : 'Откреплено', 1200); };
$('#ne-del').onclick = () => sheet([{ icon: 'trash', label: 'Удалить заметку', danger: true, fn: () => { const id = Notes.cur.id; Notes.dirty = false; Notes.cur = null; if (Docs.get(id)) Docs.del(id); Notes.draw(); show('notes'); } }], 'Заметка удалится у вас обоих.');
$('#ne-list').addEventListener('input', e => {
  const row = e.target.closest('.ni'); if (!row) return;
  Notes.cur.items[+row.dataset.i].t = e.target.value; Notes.touch();
});
$('#ne-list').addEventListener('keydown', e => {
  if (e.key !== 'Enter') return;
  const row = e.target.closest('.ni'); if (!row) return;
  e.preventDefault();
  const i = +row.dataset.i; Notes.cur.items.splice(i + 1, 0, { t: '', d: false }); Notes.touch(); Notes.drawList(i + 1);
});
$('#ne-list').addEventListener('click', e => {
  const items = Notes.cur.items;
  if (e.target.closest('.ni-add')) { items.push({ t: '', d: false }); Notes.touch(); Notes.drawList(items.length - 1); return; }
  const row = e.target.closest('.ni'); if (!row) return;
  const i = +row.dataset.i;
  if (e.target.closest('.ni-cb')) { items[i].d = !items[i].d; Notes.touch(); Notes.drawList(); vibrate(8); }
  else if (e.target.closest('.ni-x')) { items.splice(i, 1); Notes.touch(); Notes.drawList(); }
});

/* ================= банк ================= */
const EXP_CATS = [['food', '🛒', 'Продукты'], ['cafe', '🍽', 'Кафе'], ['transport', '🚕', 'Транспорт'], ['home', '🏠', 'Дом'], ['bills', '💡', 'Коммуналка'],
  ['phone', '📱', 'Связь'], ['health', '💊', 'Здоровье'], ['clothes', '👕', 'Одежда'], ['gifts', '🎁', 'Подарки'], ['fun', '🎬', 'Развлечения'],
  ['travel', '✈️', 'Путешествия'], ['beauty', '💅', 'Красота'], ['kids', '🧸', 'Дети'], ['pets', '🐾', 'Питомцы'], ['other', '📦', 'Другое']];
const INC_CATS = [['salary', '💼', 'Зарплата'], ['side', '💸', 'Подработка'], ['gift', '🎁', 'Подарок'], ['cashback', '💰', 'Кэшбэк'], ['other', '📦', 'Другое']];
const catOf = (type, id) => { const c = (type === 'inc' ? INC_CATS : EXP_CATS).find(x => x[0] === id) || ['other', '📦', 'Другое']; return { id: c[0], e: c[1], t: c[2] }; };
const ACC_EMOJI = ['👛', '💳', '💵', '🏦', '🐷', '💎'];
const Bank = {
  tab: 'sum', y: 0, m: 0,
  accs() { return Docs.list('acc').sort((a, b) => (a.order || a.upd) - (b.order || b.upd)); },
  txs() { return Docs.list('tx'); },
  goals() { return Docs.list('goal').sort((a, b) => a.upd - b.upd); },
  accBal(id) {
    const a = Docs.get(id); let s = a ? (+a.init || 0) : 0;
    for (const t of this.txs()) {
      const v = +t.amount || 0;
      if (t.type === 'inc' && t.acc === id) s += v;
      else if (t.type === 'exp' && t.acc === id) s -= v;
      else if (t.type === 'tr') { if (t.acc === id) s -= v; if (t.to === id) s += v; }
      else if (t.type === 'save' && t.acc === id) s -= v;
    }
    return s;
  },
  goalSaved(id) { let s = 0; for (const t of this.txs()) if (t.type === 'save' && t.to === id) s += +t.amount || 0; return s; },
  monthKey() { return this.y + '-' + pad(this.m + 1); },
  open() { const d = new Date(); if (!this.y) { this.y = d.getFullYear(); this.m = d.getMonth(); } this.draw(); show('bank'); },
  draw() {
    document.querySelectorAll('#bank-tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === this.tab));
    $('#bank-month').classList.toggle('hidden', this.tab === 'goals');
    $('#bank-mtitle').textContent = MONTHS_NOM[this.m] + ' ' + this.y;
    $('#bank-add').classList.toggle('hidden', this.tab === 'goals');
    if (this.tab === 'sum') this.drawSum(); else if (this.tab === 'ops') this.drawOps(); else this.drawGoals();
  },
  drawSum() {
    const accs = this.accs(), mk = this.monthKey();
    const total = accs.reduce((s, a) => s + this.accBal(a.id), 0);
    const inGoals = this.goals().reduce((s, g) => s + this.goalSaved(g.id), 0);
    let inc = 0, exp = 0; const cats = {};
    for (const t of this.txs()) {
      if (!t.date || t.date.slice(0, 7) !== mk) continue;
      if (t.type === 'inc') inc += +t.amount || 0;
      if (t.type === 'exp') { exp += +t.amount || 0; cats[t.cat] = (cats[t.cat] || 0) + (+t.amount || 0); }
    }
    const top = Object.entries(cats).sort((a, b) => b[1] - a[1]), max = top.length ? top[0][1] : 1;
    let h = `<div class="bk-card"><small>Всего на счетах</small><b>${money(total)}</b>${inGoals ? `<span>🐷 ещё в копилках: ${money(inGoals)}</span>` : ''}</div>
      <div class="bk-row"><div class="bk-mini inc"><small>Доходы за месяц</small><b>+${money(inc)}</b></div><div class="bk-mini exp"><small>Расходы за месяц</small><b>−${money(exp)}</b></div></div>`;
    if (top.length) {
      h += `<h3 class="sec">На что ушли деньги</h3><div class="bk-cats">` + top.map(([c, v]) => {
        const k = catOf('exp', c);
        return `<div class="bk-cat"><span class="bk-ce">${k.e}</span><span class="bk-cb"><span class="bk-ct"><b>${k.t}</b><i>${money(v)} · ${Math.round(v / exp * 100)}%</i></span><span class="bk-bar"><i style="width:${Math.max(3, v / max * 100)}%"></i></span></span></div>`;
      }).join('') + `</div>`;
    }
    h += `<h3 class="sec">Счета</h3><div class="bk-accs">` + accs.map(a => `<button class="bk-acc" data-acc="${a.id}"><span class="bk-ae">${esc(a.emoji || '👛')}</span><span class="bk-an">${esc(a.name)}</span><b>${money(this.accBal(a.id))}</b></button>`).join('') +
      `<button class="bk-acc add" data-acc="">＋ Добавить счёт</button></div>`;
    if (!accs.length && !this.txs().length) h += `<p class="muted small" style="text-align:center;margin-top:14px">Нажмите ＋ внизу, чтобы записать первую трату или доход. Общий кошелёк создастся сам.</p>`;
    $('#bank-body').innerHTML = h;
  },
  drawOps() {
    const mk = this.monthKey();
    const list = this.txs().filter(t => t.date && t.date.slice(0, 7) === mk).sort((a, b) => b.date.localeCompare(a.date) || b.upd - a.upd);
    if (!list.length) { $('#bank-body').innerHTML = `<div class="empty"><div>🧾</div>В этом месяце пока нет операций</div>`; return; }
    let h = '', day = '';
    for (const t of list) {
      if (t.date !== day) { day = t.date; h += `<div class="bk-day">${dayTitle(day)}</div>`; }
      const acc = Docs.get(t.acc), v = +t.amount || 0;
      let e, title, sign, cls, sub = acc ? acc.name : '';
      if (t.type === 'tr') { const to = Docs.get(t.to); e = '🔁'; title = 'Перевод'; sub = (acc ? acc.name : '?') + ' → ' + (to ? to.name : '?'); sign = ''; cls = ''; }
      else if (t.type === 'save') { const g = Docs.get(t.to); e = (g && g.emoji) || '🐷'; title = (v >= 0 ? 'В копилку ' : 'Из копилки ') + (g ? '«' + g.name + '»' : ''); sign = v >= 0 ? '−' : '+'; cls = v >= 0 ? 'exp' : 'inc'; }
      else { const k = catOf(t.type, t.cat); e = k.e; title = k.t; sign = t.type === 'inc' ? '+' : '−'; cls = t.type; }
      h += `<button class="bk-tx" data-tx="${t.id}"><span class="bk-te">${e}</span><span class="bk-tt"><b>${esc(t.note || title)}</b><small>${t.note ? esc(title) + ' · ' : ''}${esc(sub)} · ${esc(whoName(t))}</small></span><span class="bk-tv ${cls}">${sign}${money(Math.abs(v))}</span></button>`;
    }
    $('#bank-body').innerHTML = h;
  },
  drawGoals() {
    const gs = this.goals();
    let h = gs.map(g => {
      const saved = this.goalSaved(g.id), tgt = +g.target || 0, pct = tgt ? Math.min(100, Math.round(saved / tgt * 100)) : 0;
      const left = g.deadline ? daysBetween(todayYmd(), g.deadline) : null;
      return `<div class="bk-goal" data-goal="${g.id}"><div class="bg-h"><span class="bg-e">${esc(g.emoji || '🐷')}</span><span class="bg-n"><b>${esc(g.name)}</b><small>${money(saved)} из ${money(tgt)}${left != null ? ' · ' + (left >= 0 ? 'до ' + dayTitle(g.deadline).split(',')[0] : 'срок прошёл') : ''}</small></span><b class="bg-p">${pct}%</b></div>
        <div class="bg-bar"><i style="width:${pct}%"></i></div>
        ${pct >= 100 ? '<div class="bg-done">🎉 Цель достигнута!</div>' : (tgt > saved && left > 0 ? `<div class="bg-hint">Откладывать ≈ ${money(Math.ceil((tgt - saved) / Math.max(1, Math.ceil(left / 30))))} в месяц</div>` : '')}
        <div class="bg-btns"><button class="btn" data-gact="out">Снять</button><button class="btn primary" data-gact="in">Пополнить</button></div></div>`;
    }).join('');
    h += `<button class="bk-acc add bg-new" data-newgoal="1">＋ Новая копилка</button>`;
    if (!gs.length) h = `<div class="empty"><div>🐷</div>Копилки помогают копить на общую цель: отпуск, ремонт, подарок</div>` + h;
    $('#bank-body').innerHTML = h;
  },
  async ensureAcc() {
    let a = this.accs();
    if (a.length) return a[0].id;
    const id = Docs.newId('acc');
    await Docs.put(id, { c: 'acc', name: 'Общий кошелёк', emoji: '👛', init: 0, order: Date.now() });
    return id;
  },
  async editTx(t, preset) {
    if (!t) await this.ensureAcc();
    const accOpts = () => this.accs().map(a => ({ v: a.id, t: (a.emoji || '👛') + ' ' + a.name + ' — ' + money(this.accBal(a.id)) }));
    Form.open({
      title: t ? 'Операция' : 'Новая запись',
      values: t ? Object.assign({}, t) : Object.assign({ type: 'exp', cat: 'food', acc: this.accs()[0].id, date: todayYmd() }, preset || {}),
      fields: [
        { k: 'type', type: 'chips', opts: [{ v: 'exp', t: '➖ Расход' }, { v: 'inc', t: '➕ Доход' }, { v: 'tr', t: '🔁 Перевод' }], show: v => v.type !== 'save' },
        { k: 'amount', label: 'Сумма, ₽', type: 'number', big: true, focus: !t },
        { k: 'cat', label: 'Категория', type: 'chips', wrap: true, show: v => v.type === 'exp' || v.type === 'inc', opts: v => (v.type === 'inc' ? INC_CATS : EXP_CATS).map(c => ({ v: c[0], t: c[1] + ' ' + c[2] })) },
        { k: 'acc', label: 'Счёт', type: 'select', opts: accOpts, show: v => true },
        { k: 'to', label: 'На счёт', type: 'select', opts: v => this.accs().filter(a => a.id !== v.acc).map(a => ({ v: a.id, t: (a.emoji || '👛') + ' ' + a.name })), show: v => v.type === 'tr' },
        { k: 'date', label: 'Дата', type: 'date' },
        { k: 'note', label: 'Комментарий', ph: 'Например: продукты на неделю' },
      ],
      onSave: v => {
        const amount = +v.amount;
        if (!amount || amount <= 0 || !isFinite(amount)) return 'Введите сумму';
        if (!v.acc) return 'Выберите счёт';
        if (v.type === 'tr') { if (!v.to) v.to = (this.accs().find(a => a.id !== v.acc) || {}).id; if (!v.to) return 'Для перевода нужен второй счёт — добавьте его в «Обзоре»'; if (v.to === v.acc) return 'Выберите другой счёт'; }
        if ((v.type === 'exp' || v.type === 'inc') && !(v.type === 'inc' ? INC_CATS : EXP_CATS).some(c => c[0] === v.cat)) v.cat = 'other';
        const id = t ? t.id : Docs.newId('tx');
        const data = { c: 'tx', type: v.type, amount: Math.round(amount * 100) / 100, acc: v.acc, date: v.date || todayYmd(), note: String(v.note || '').trim() };
        if (v.type === 'exp' || v.type === 'inc') data.cat = v.cat;
        if (v.type === 'tr' || v.type === 'save') data.to = v.to;
        Docs.put(id, data);
        const d = parseYmd(data.date); this.y = d.getFullYear(); this.m = d.getMonth();
      },
      onDelete: t ? () => Docs.del(t.id) : null,
    });
  },
  editAcc(a) {
    Form.open({
      title: a ? 'Счёт' : 'Новый счёт',
      values: a ? Object.assign({}, a) : { emoji: '💳', init: '' },
      fields: [
        { k: 'name', label: 'Название', ph: 'Например: Карта Саши', focus: !a },
        { k: 'emoji', label: 'Значок', type: 'chips', opts: ACC_EMOJI.map(e => ({ v: e, t: e })) },
        { k: 'init', label: a ? 'Начальный остаток, ₽' : 'Сколько сейчас на счёте, ₽', type: 'number' },
      ],
      onSave: v => {
        if (!String(v.name || '').trim()) return 'Введите название';
        const id = a ? a.id : Docs.newId('acc');
        Docs.put(id, { c: 'acc', name: v.name.trim(), emoji: v.emoji || '💳', init: +v.init || 0, order: a ? a.order : Date.now() });
      },
      onDelete: a ? () => { if (this.txs().some(t => t.acc === a.id || t.to === a.id)) { toast('На этом счёте есть операции — сначала удалите их'); return; } Docs.del(a.id); } : null,
    });
  },
  editGoal(g) {
    Form.open({
      title: g ? 'Копилка' : 'Новая копилка',
      values: g ? Object.assign({}, g) : { emoji: '✈️' },
      fields: [
        { k: 'name', label: 'На что копим', ph: 'Например: Отпуск на море', focus: !g },
        { k: 'emoji', label: 'Значок', type: 'chips', wrap: true, opts: ['✈️', '🏖', '🏠', '🚗', '💍', '🎁', '📱', '👶', '🛋', '🐷'].map(e => ({ v: e, t: e })) },
        { k: 'target', label: 'Цель, ₽', type: 'number' },
        { k: 'deadline', label: 'К какой дате (необязательно)', type: 'date' },
      ],
      onSave: v => {
        if (!String(v.name || '').trim()) return 'Введите название';
        if (!(+v.target > 0)) return 'Введите сумму цели';
        const id = g ? g.id : Docs.newId('goal');
        Docs.put(id, { c: 'goal', name: v.name.trim(), emoji: v.emoji || '🐷', target: +v.target, deadline: v.deadline || '' });
      },
      onDelete: g ? () => { if (this.goalSaved(g.id) > 0) { toast('Сначала снимите деньги из копилки'); return; } for (const t of this.txs()) if (t.type === 'save' && t.to === g.id) Docs.del(t.id); Docs.del(g.id); } : null,
    });
  },
  async moveGoal(g, dir) {
    await this.ensureAcc();
    const saved = this.goalSaved(g.id);
    Form.open({
      title: (dir > 0 ? 'Пополнить «' : 'Снять из «') + g.name + '»',
      values: { acc: this.accs()[0].id, date: todayYmd() },
      fields: [
        { k: 'amount', label: 'Сумма, ₽' + (dir < 0 ? ' (в копилке ' + money(saved) + ')' : ''), type: 'number', big: true, focus: true },
        { k: 'acc', label: dir > 0 ? 'С какого счёта' : 'На какой счёт', type: 'select', opts: () => this.accs().map(a => ({ v: a.id, t: (a.emoji || '👛') + ' ' + a.name + ' — ' + money(this.accBal(a.id)) })) },
      ],
      saveLabel: dir > 0 ? 'Положить' : 'Снять',
      onSave: v => {
        const amount = +v.amount;
        if (!(amount > 0)) return 'Введите сумму';
        if (dir < 0 && amount > saved + 0.001) return 'В копилке только ' + money(saved);
        Docs.put(Docs.newId('tx'), { c: 'tx', type: 'save', amount: dir * Math.round(amount * 100) / 100, acc: v.acc, to: g.id, date: todayYmd(), note: '' });
        if (dir > 0 && saved + amount >= (+g.target || 0) && saved < (+g.target || 0)) setTimeout(() => { FX.play('party'); toast('🎉 Цель «' + g.name + '» достигнута!'); }, 300);
      },
    });
  },
};
$('#bank-tabs').onclick = e => { const b = e.target.closest('[data-t]'); if (b) { Bank.tab = b.dataset.t; Bank.draw(); } };
$('#bank-prev').onclick = () => { Bank.m--; if (Bank.m < 0) { Bank.m = 11; Bank.y--; } Bank.draw(); };
$('#bank-next').onclick = () => { Bank.m++; if (Bank.m > 11) { Bank.m = 0; Bank.y++; } Bank.draw(); };
$('#bank-add').onclick = () => Bank.editTx(null);
$('#bank-body').onclick = e => {
  const acc = e.target.closest('[data-acc]'); if (acc) { Bank.editAcc(acc.dataset.acc ? Docs.get(acc.dataset.acc) : null); return; }
  const tx = e.target.closest('[data-tx]'); if (tx) { const t = Docs.get(tx.dataset.tx); if (t && t.type === 'save') { sheet([{ icon: 'trash', label: 'Удалить операцию', danger: true, fn: () => Docs.del(t.id) }], 'Операция с копилкой'); } else if (t) Bank.editTx(t); return; }
  if (e.target.closest('[data-newgoal]')) { Bank.editGoal(null); return; }
  const g = e.target.closest('[data-goal]'); if (!g) return;
  const goal = Docs.get(g.dataset.goal); if (!goal) return;
  const act = e.target.closest('[data-gact]');
  if (act) Bank.moveGoal(goal, act.dataset.gact === 'in' ? 1 : -1); else Bank.editGoal(goal);
};

/* ================= профиль: фото и цвет имени ================= */
const NAME_COLORS = ['', '#c8553d', '#e0457b', '#f27aa6', '#b05cd6', '#7a6ff0', '#4b6fe0', '#1f95d1', '#12a39a', '#2fa66b', '#e0a019', '#ef7d3c', '#5f6b7a'];
const NAME_GRADS = [
  { id: 'sunset', t: 'Закат', c: ['#ff5f6d', '#ffc371'] }, { id: 'flamingo', t: 'Фламинго', c: ['#f857a6', '#ff9a8b'] },
  { id: 'lavender', t: 'Лаванда', c: ['#a18cd1', '#fbc2eb'] }, { id: 'ocean', t: 'Океан', c: ['#2193b0', '#6dd5ed'] },
  { id: 'mint', t: 'Мята', c: ['#11998e', '#38ef7d'] }, { id: 'fire', t: 'Огонь', c: ['#f12711', '#f5af19'] },
  { id: 'gold', t: 'Золото', c: ['#b8860b', '#ffd86f', '#b8860b'] }, { id: 'night', t: 'Ночь', c: ['#4b6cb7', '#c471ed'] },
  { id: 'rainbow', t: 'Радуга', c: ['#ff3b3b', '#ff9f1c', '#ffe23b', '#2fd16b', '#2fa8ff', '#9b5cff', '#ff3b3b'] },
];
const Profile = {
  draft: null,
  mine() { return Docs.get('prof_' + S.dev) || { name: S.name }; },
  partner() {
    let best = null;
    for (const p of Docs.list('prof')) if (p.dev !== S.dev && (!best || p.upd > best.upd)) best = p;
    return best;
  },
  // имя с выбранным цветом / градиентом / переливанием
  nameHtml(p, fallback, extra) {
    const name = esc((p && p.name) || fallback || ''), st = (p && p.style) || {};
    const g = NAME_GRADS.find(x => x.id === st.grad);
    let css = '', cls = 'pname' + (extra ? ' ' + extra : '');
    if (g) {
      const cols = g.c.length > 2 ? g.c : [g.c[0], g.c[1], g.c[0]];
      css = `background-image:linear-gradient(90deg,${cols.join(',')});`;
      cls += ' grad' + (st.anim ? ' anim' : '');
    } else if (st.color) {
      css = `color:${st.color};`;
      if (st.anim) { css += `background-image:linear-gradient(90deg,${st.color},#ffffff,${st.color});`; cls += ' grad shine anim'; }
    }
    return `<span class="${cls}" style="${css}">${name}</span>`;
  },
  avatarSet(el, p, fallbackName) {
    if (p && p.avatar) { el.style.backgroundImage = `url("${p.avatar}")`; el.classList.add('photo'); el.textContent = ''; }
    else { el.style.backgroundImage = ''; el.classList.remove('photo'); el.textContent = (((p && p.name) || fallbackName || '♥').trim()[0] || '♥').toUpperCase(); }
  },
  // мой профиль один на все чаты: переносим его в каждый чат, где он устарел
  syncMine() {
    let g = null; try { g = JSON.parse(localStorage.getItem('nc_myprof') || 'null'); } catch (_) { }
    const cur = Docs.get('prof_' + S.dev);
    if (g && (!cur || (cur.upd || 0) < g.at - 1000 || cur.name !== S.name)) Docs.put('prof_' + S.dev, { c: 'prof', name: S.name, avatar: g.avatar || '', style: g.style || {} });
    else if (!g && cur) { try { localStorage.setItem('nc_myprof', JSON.stringify({ avatar: cur.avatar || '', style: cur.style || {}, at: cur.upd || Date.now() })); } catch (_) { } }
  },
  drawHeader() {
    if (CHAT.isGroup()) { Group.drawHeader(); return; }
    const p = this.partner(), name = (p && p.name) || S.partner;
    if (p && p.avatar) Chats.setMeta(CHAT.id, { avatar: p.avatar });
    if (name) $('#partner-name').innerHTML = this.nameHtml(p, name);
    if (p || S.partner) this.avatarSet($('#partner-av'), p, name);
  },
  drawDrawer() {
    const me = Object.assign({}, this.mine(), { name: S.name });
    $('#dr-name').innerHTML = this.nameHtml(me, S.name);
    this.avatarSet($('#dr-av'), me, S.name);
  },
  // ----- редактор в настройках -----
  drawEditor() {
    const me = this.mine();
    if (!this.draft) this.draft = { avatar: me.avatar || '', style: Object.assign({}, me.style || {}) };
    const d = this.draft;
    const av = $('#s-av-in'); this.avatarSet(av, { avatar: d.avatar, name: $('#s-name').value || S.name }, S.name);
    $('#s-name-prev').innerHTML = this.nameHtml({ name: $('#s-name').value || S.name, style: d.style }, S.name, 'big');
    $('#s-name-colors').innerHTML = NAME_COLORS.map(c => `<button data-nc="${c}" class="${!d.style.grad && (d.style.color || '') === c ? 'on' : ''}" style="background:${c || 'var(--text)'}" aria-label="${c ? 'цвет' : 'обычный'}">${c ? '' : 'Aa'}</button>`).join('');
    $('#s-name-grads').innerHTML = NAME_GRADS.map(g => `<button data-ng="${g.id}" class="${d.style.grad === g.id ? 'on' : ''}" style="background:linear-gradient(90deg,${g.c.join(',')})"><span>${g.t}</span></button>`).join('');
    $('#s-name-anim .switch').classList.toggle('on', !!d.style.anim);
  },
  async pickAvatar(file) {
    try {
      const img = await loadImage(file);
      const s = Math.min(img.width, img.height), c = document.createElement('canvas'); c.width = c.height = 320;
      c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 320, 320);
      this.draft.avatar = c.toDataURL('image/jpeg', 0.84);
      this.drawEditor(); this.save(); toast('Фото обновлено 📸');
    } catch (_) { toast('Не удалось открыть фото'); }
  },
  save() {
    const d = this.draft || { avatar: (this.mine().avatar || ''), style: (this.mine().style || {}) };
    Docs.put('prof_' + S.dev, { c: 'prof', name: S.name, avatar: d.avatar || '', style: d.style || {} });
    try { localStorage.setItem('nc_myprof', JSON.stringify({ avatar: d.avatar || '', style: d.style || {}, at: Date.now() })); } catch (_) { }
    this.drawDrawer();
  },
  showPartnerPhoto() {
    const p = this.partner(); if (!p || !p.avatar) return;
    viewerMsg = null;
    $('#v-body').innerHTML = `<img src="${p.avatar}" alt="">`;
    $('#v-info').innerHTML = this.nameHtml(p, S.partner);
    $('#viewer').classList.remove('hidden');
  },
};
$('#s-av').onclick = () => {
  const items = [{ icon: 'image', label: 'Выбрать фото из галереи', fn: () => $('#pick-avatar').click() }];
  if (Profile.draft && Profile.draft.avatar) items.push({ icon: 'trash', label: 'Удалить фото', danger: true, fn: () => { Profile.draft.avatar = ''; Profile.drawEditor(); Profile.save(); } });
  sheet(items, 'Фото профиля видит собеседник');
};
$('#pick-avatar').onchange = e => { const f = e.target.files[0]; e.target.value = ''; if (f) Profile.pickAvatar(f); };
$('#s-name').addEventListener('input', () => Profile.drawEditor());
$('#s-name-colors').onclick = e => { const b = e.target.closest('[data-nc]'); if (!b) return; Profile.draft.style.color = b.dataset.nc; delete Profile.draft.style.grad; Profile.drawEditor(); vibrate(6); };
$('#s-name-grads').onclick = e => { const b = e.target.closest('[data-ng]'); if (!b) return; Profile.draft.style.grad = b.dataset.ng; delete Profile.draft.style.color; Profile.drawEditor(); vibrate(6); };
$('#s-name-anim').onclick = () => { Profile.draft.style.anim = !Profile.draft.style.anim; Profile.drawEditor(); };
// фото собеседника открывается из окна чата (нажатие на имя → аватарка)
Docs.on(() => { Profile.drawHeader(); });

/* ================= оплата сервера ================= */
const Srv = {
  ID: 'srv_main',
  info() {
    const d = Docs.get(this.ID); if (!d || !(+d.price > 0)) return null;
    const price = +d.price, passed = Math.max(0, (Date.now() - d.at) / 86400000);
    const remain = Math.max(0, (+d.bal || 0) - price * passed);
    const days = Math.floor(remain / price + 1e-9);
    const until = new Date(d.at + (+d.bal || 0) / price * 86400000);
    return { d, price, remain, days, until, pct: d.bal > 0 ? Math.max(0, Math.min(100, remain / d.bal * 100)) : 0 };
  },
  untilText(dt) { return dt.getDate() + ' ' + MONTHS[dt.getMonth()] + (dt.getFullYear() !== new Date().getFullYear() ? ' ' + dt.getFullYear() : ''); },
  drawerNote() {
    const i = this.info(), el = $('#dr-srv');
    if (!i) { el.textContent = 'настроить'; el.classList.remove('warn'); return; }
    el.textContent = i.days + ' ' + plural(i.days, 'день', 'дня', 'дней');
    el.classList.toggle('warn', i.days <= 5);
  },
  open() { this.draw(); show('srv'); },
  draw() {
    const i = this.info();
    if (!i) {
      $('#srv-body').innerHTML = `<div class="srv-card"><div class="srv-big">❔</div><b>Сколько ещё оплачен сервер?</b><p class="muted">Введите баланс из личного кабинета VDSina — приложение будет считать дни по 20 ₽ в день и напомнит вам обоим за 5 дней до конца.</p><button class="btn primary" id="srv-set">Ввести баланс</button></div>`;
    } else {
      const hot = i.days <= 5;
      $('#srv-body').innerHTML = `<div class="srv-card ${hot ? 'hot' : ''}">
        <small>Сервер оплачен ещё на</small>
        <div class="srv-days">${i.days} <span>${plural(i.days, 'день', 'дня', 'дней')}</span></div>
        <div class="srv-until">до ${this.untilText(i.until)}</div>
        <div class="bg-bar srv-bar"><i style="width:${i.pct}%"></i></div>
        <div class="srv-row"><span>Остаток сейчас ≈ <b>${money(Math.round(i.remain))}</b></span><span>${money(i.price)} в день</span></div>
        ${hot ? `<p class="srv-warn">${i.days <= 0 ? '⚠️ Деньги закончились — пополните баланс, иначе сервер отключат и переписка может пропасть.' : '⏰ Скоро нужно пополнить баланс в VDSina.'}</p>` : ''}
        <button class="btn primary" id="srv-set">💳 Я пополнил — ввести баланс</button>
        <p class="muted small">Обновлено: ${esc(whoName(i.d))}, ${agoShort(i.d.upd)} · баланс был ${money(i.d.bal)}</p>
      </div>
      <p class="muted small srv-tip">Баланс смотрите в личном кабинете VDSina (слева, «Баланс»). Оплата ежедневная, поэтому вводить его нужно только после пополнения.</p>`;
    }
    $('#srv-set').onclick = () => this.edit();
  },
  edit() {
    const d = Docs.get(this.ID);
    Form.open({
      title: 'Баланс сервера',
      values: { bal: '', price: d ? d.price : 20 },
      fields: [
        { k: 'bal', label: 'Баланс в VDSina сейчас, ₽', type: 'number', big: true, focus: true, ph: 'Например: 480' },
        { k: 'price', label: 'Стоимость в день, ₽', type: 'number' },
      ],
      onSave: v => {
        if (!(+v.bal >= 0) || v.bal === '') return 'Введите баланс';
        if (!(+v.price > 0)) return 'Введите стоимость в день';
        Docs.put(this.ID, { c: 'srv', bal: +v.bal, price: +v.price, at: Date.now() });
        const days = Math.floor(+v.bal / +v.price);
        toast(`Готово: хватит на ${days} ${plural(days, 'день', 'дня', 'дней')} 👍`);
        setTimeout(() => { if (!$('#srv').classList.contains('hidden')) this.draw(); }, 50);
      },
    });
  },
  check() {
    const i = this.info(); if (!i || i.days > 5) return;
    const key = 'nc_srv_warn_' + todayYmd();
    try { if (localStorage.getItem(key)) return; localStorage.setItem(key, '1'); } catch (_) { }
    Shared.banner(i.days <= 0 ? '⚠️ Деньги на сервере закончились — пополните VDSina' : `🖥 Сервер оплачен ещё на ${i.days} ${plural(i.days, 'день', 'дня', 'дней')} — пора пополнить`, () => this.open());
  },
};
Docs.on(() => { if (!$('#srv').classList.contains('hidden')) Srv.draw(); });

/* ================= общее ================= */
const Shared = {
  back() {
    if (Form.isOpen()) { Form.close(); return true; }
    if (!$('#noteed').classList.contains('hidden')) { Notes.close(); return true; }
    for (const id of ['cal', 'notes', 'bank', 'srv']) if (!$('#' + id).classList.contains('hidden')) { show('chat'); return true; }
    return false;
  },
  banner(text, onClick) {
    const b = document.createElement('button'); b.className = 'hello sh-banner';
    b.textContent = text;
    b.onclick = () => { b.remove(); onClick && onClick(); };
    $('#chat').appendChild(b); setTimeout(() => b.remove(), 6000);
  },
  redraw() {
    if (!$('#cal').classList.contains('hidden')) Cal.draw();
    if (!$('#notes').classList.contains('hidden')) Notes.draw();
    if (!$('#bank').classList.contains('hidden')) Bank.draw();
  },
};
Docs.on((changes, quiet) => {
  Shared.redraw();
  Notes.remote(changes);
  if (quiet || document.hidden) return;
  // подсказка, что собеседник что-то добавил
  const fresh = changes.filter(c => !c.local && !c.before && c.after && c.after.dev !== S.dev);
  if (!fresh.length || fresh.length > 3) return;
  const x = fresh[0].after, who = x.by || S.partner || 'Собеседник';
  if (x.c === 'cal') toast(`📅 ${who} добавил(а) событие: «${x.title}» — ${dayTitle(x.date)}`, 3500);
  else if (x.c === 'note') toast(`📝 ${who} создал(а) заметку${x.title ? ' «' + x.title + '»' : ''}`, 3000);
  else if (x.c === 'tx' && (x.type === 'exp' || x.type === 'inc')) toast(`💰 ${who}: ${x.type === 'inc' ? '+' : '−'}${money(x.amount)} · ${catOf(x.type, x.cat).t}`, 3000);
  else if (x.c === 'pin') toast(`📌 ${who} закрепил(а) сообщение`, 3000);
  else if (x.c === 'srv') toast(`🖥 ${who} обновил(а) баланс сервера: ${money(x.bal)}`, 3000);
  else if (x.c === 'goal') toast(`🐷 ${who} создал(а) копилку «${x.name}»`, 3000);
});
