'use strict';
/* «Наш чат» — только для пары: 🌳 дерево любви, 💗 «думаю о тебе», 🎮 игры на двоих. */

/* ================= 💗 думаю о тебе ================= */
const Think = {
  last: 0,
  async send() {
    if (Date.now() - this.last < 8000) { toast('Сердечко уже летит 💗'); return; }
    this.last = Date.now();
    this.burst(true); vibrate([30, 60, 30]);
    try { await sendPayload({ t: 'think' }); } catch (_) { toast('Не удалось отправить'); }
  },
  bubble(m, el) {
    el.classList.add('think');
    el.innerHTML = `<div class="think-pill"><span class="tp-h">💗</span><span>${m.mine ? 'Вы думаете о ' + esc(S.partner || 'ней') : esc(m.p.n || S.partner || 'Собеседник') + ' думает о вас'}</span>${metaHtml(m)}</div>`;
  },
  // большое сердце и «сердцебиение» у того, кому отправили
  play(name) {
    vibrate([60, 120, 60, 400, 60, 120, 60]);
    this.burst(false);
    const t = document.createElement('div'); t.className = 'think-big';
    t.innerHTML = `<div class="tb-heart">💗</div><div class="tb-text">${esc(name || S.partner || 'Любимый человек')}<br><small>думает о тебе</small></div>`;
    document.body.appendChild(t); setTimeout(() => t.remove(), 3200);
  },
  burst(mine) {
    for (let i = 0; i < (mine ? 8 : 18); i++) {
      const h = document.createElement('div'); h.className = 'think-fly'; h.textContent = ['💗', '💖', '💕', '❤️'][i % 4];
      h.style.left = (mine ? 70 + Math.random() * 20 : 10 + Math.random() * 80) + 'vw';
      h.style.animationDelay = (Math.random() * 0.6) + 's'; h.style.fontSize = (18 + Math.random() * 22) + 'px';
      document.body.appendChild(h); setTimeout(() => h.remove(), 3200);
    }
  },
};

/* ================= 🌳 дерево любви ================= */
const TREE_LEVELS = [
  [0, 'Семечко'], [60, 'Росток'], [200, 'Саженец'], [450, 'Молодое деревце'], [900, 'Деревце'],
  [1600, 'Цветущее дерево'], [2800, 'Дерево с плодами'], [4500, 'Могучее дерево'], [7000, 'Волшебное дерево'], [10000, 'Дерево вечной любви'],
];
const LOVE_WORDS = /(^|[^а-яё])(люблю|любимая|любимый|скучаю|доброе утро|спокойной ночи|солнышко|котик|зайка|родная|родной|целую|обнимаю)/i;
const Tree = {
  KEY: 'nc_tree',
  st: null,
  load() {
    if (!this.st) { try { this.st = JSON.parse(localStorage.getItem(this.KEY) || 'null'); } catch (_) { } }
    if (!this.st || this.st.v !== 2) this.st = { v: 2, upto: 0, days: {}, by: {}, last: 0, seenLevel: 0 };
    return this.st;
  },
  save() { try { localStorage.setItem(this.KEY, JSON.stringify(this.st)); } catch (_) { } },
  // очки за одно сообщение
  count(id, ts, dev, p) {
    const st = this.load(); if (id <= st.upto && st.counted && st.counted[id]) return;
    const day = ymd(new Date(ts)), d = st.days[day] || (st.days[day] = { pts: {}, love: {}, w: {} });
    let pts = 0;
    switch (p.t) {
      case 'text': pts = 1 + (p.text.includes('💋') ? 2 : 0); if (LOVE_WORDS.test(p.text) && !d.love[dev]) { d.love[dev] = 1; pts += 5; } break;
      case 'voice': pts = 3; break;
      case 'circle': pts = 5; break;
      case 'image': case 'video': pts = 2; break;
      case 'sticker': pts = 1; break;
      case 'gift': pts = 12; break;
      case 'call': pts = p.res === 'ok' ? 6 : 0; break;
      case 'think': pts = 3; break;
      case 'tree': if (!d.w[dev]) { d.w[dev] = 1; pts = 15; } break;
      case 'game': pts = 4; break;
      default: pts = 0;
    }
    if (!pts) return;
    d.pts[dev] = Math.min(60, (d.pts[dev] || 0) + pts);   // не больше 60 очков в день от одного
    if (ts > st.last) st.last = ts;
  },
  total() {
    const st = this.load(); let t = 0; const by = {};
    for (const d of Object.values(st.days)) {
      const devs = Object.keys(d.pts);
      for (const dv of devs) { t += d.pts[dv]; by[dv] = (by[dv] || 0) + d.pts[dv]; }
      if (devs.length >= 2) t += 10; // в этот день писали оба
    }
    return { t, by };
  },
  streak() {
    const st = this.load(); let n = 0; const d = new Date();
    const both = k => st.days[k] && Object.keys(st.days[k].pts).length >= 2;
    if (!both(ymd(d))) d.setDate(d.getDate() - 1);
    while (both(ymd(d))) { n++; d.setDate(d.getDate() - 1); }
    return n;
  },
  level(t) { let i = 0; while (i + 1 < TREE_LEVELS.length && t >= TREE_LEVELS[i + 1][0]) i++; return i; },
  // проходим переписку с сервера (только то, что ещё не считали)
  async sync(onProg) {
    const st = this.load();
    let cursor = S.last + 1, n = 0;
    const fresh = [];
    while (cursor > st.upto + 1) {
      const res = await api(`/api/messages?before=${cursor}&limit=200`, { timeout: 30000 });
      const list = res.messages || []; if (!list.length) break;
      fresh.push(...list); n += list.length; onProg && onProg(n);
      cursor = list[0].id; if (cursor <= 1) break;
    }
    fresh.sort((a, b) => a.id - b.id);
    for (const r of fresh) {
      if (r.id <= st.upto || r.del || !r.ct) continue;
      const k = S.msgs.get(r.id);
      let p = k ? k.p : null;
      if (!p) { try { p = JSON.parse(dec.decode(await Crypto.open(S.key, unb64(r.ct)))); } catch (_) { continue; } }
      if (p) this.count(r.id, r.ts, r.dev, p);
    }
    st.upto = Math.max(st.upto, S.last);
    this.save();
  },
  sad() { const st = this.load(); return st.last && Date.now() - st.last > 2 * 86400000; },
  wateredToday() { const d = this.load().days[ymd(new Date())]; return !!(d && d.w && d.w[S.dev]); },
  async open() {
    show('tree');
    $('#tr-info').innerHTML = '<div class="tr-load">🌱 Считаю, сколько любви накопилось…</div>';
    this.draw();
    try { await this.sync(n => { const l = $('#tr-info .tr-load'); if (l) l.textContent = `🌱 Считаю… ${n} сообщений`; }); } catch (_) { }
    this.draw(true);
  },
  draw(final) {
    const { t, by } = this.total(), lv = this.level(t), st = this.load();
    const next = TREE_LEVELS[lv + 1], cur = TREE_LEVELS[lv];
    const pct = next ? Math.round((t - cur[0]) / (next[0] - cur[0]) * 100) : 100;
    $('#tr-art').innerHTML = this.svg(lv, next ? (t - cur[0]) / (next[0] - cur[0]) : 1, this.sad());
    const hr = new Date().getHours(); $('#tree').dataset.time = hr >= 21 || hr < 6 ? 'night' : hr < 9 ? 'morning' : hr >= 18 ? 'evening' : 'day';
    if (!final) return;
    const me = by[S.dev] || 0, all = Object.values(by).reduce((a, b) => a + b, 0) || 1;
    const today = st.days[ymd(new Date())], todayPts = today ? Object.values(today.pts).reduce((a, b) => a + b, 0) + (Object.keys(today.pts).length >= 2 ? 10 : 0) : 0;
    const streak = this.streak();
    $('#tr-info').innerHTML = `
      <div class="tr-name">${esc(cur[1])}</div>
      <div class="tr-lv">Уровень ${lv + 1} из ${TREE_LEVELS.length}${this.sad() ? ' · 🥀 дерево скучает — напишите друг другу!' : ''}</div>
      <div class="tr-bar"><i style="width:${pct}%"></i></div>
      <div class="tr-next">${next ? `До «${esc(next[1])}» — ещё ${next[0] - t} 💧` : 'Это самое большое дерево! 🌟'}</div>
      <div class="tr-stats">
        <div><b>${t}</b><small>всего любви</small></div>
        <div><b>+${todayPts}</b><small>сегодня</small></div>
        <div><b>${streak}</b><small>${plural(streak, 'день', 'дня', 'дней')} подряд</small></div>
      </div>
      <div class="tr-who"><span>Вы — ${Math.round(me / all * 100)}%</span><span>${esc(S.partner || 'Собеседник')} — ${100 - Math.round(me / all * 100)}%</span></div>
      <button class="btn primary" id="tr-water" ${this.wateredToday() ? 'disabled' : ''}>${this.wateredToday() ? '💧 Сегодня вы уже полили' : '💧 Полить дерево (+15)'}</button>
      <details class="tr-how"><summary>Что растит дерево?</summary>
        <p>💬 сообщения · 💋 поцелуи · ⭕ кружки · 🎤 голосовые · 📷 фото · 🎁 подарки · 📞 звонки · 💗 «думаю о тебе» · 🎮 игры · «люблю», «скучаю», «доброе утро» — особенно ценятся. Если в день писали оба — ещё +10. Каждый может полить дерево раз в день. Если два дня не общаться, дерево начнёт грустить.</p>
      </details>`;
    $('#tr-water').onclick = async () => {
      if (this.wateredToday()) return;
      $('#tr-water').disabled = true;
      try { await sendPayload({ t: 'tree', a: 'water' }); this.rain(); await this.sync().catch(() => { }); this.draw(true); } catch (_) { toast('Не удалось — нет связи'); $('#tr-water').disabled = false; }
    };
    if (lv > (st.seenLevel || 0)) { st.seenLevel = lv; this.save(); if (lv > 0) setTimeout(() => this.levelUp(cur[1]), 400); }
  },
  rain() {
    const art = $('#tr-art');
    for (let i = 0; i < 26; i++) { const d = document.createElement('i'); d.className = 'tr-drop'; d.style.left = (15 + Math.random() * 70) + '%'; d.style.animationDelay = (Math.random() * .7) + 's'; art.appendChild(d); setTimeout(() => d.remove(), 1800); }
    vibrate(20);
  },
  levelUp(name) {
    const b = document.createElement('div'); b.className = 'tr-up'; b.innerHTML = `🎉<b>Дерево выросло!</b><span>${esc(name)}</span>`;
    $('#tree').appendChild(b); setTimeout(() => b.remove(), 3500); vibrate([30, 50, 30]);
  },
  // ---------- рисуем дерево ----------
  svg(lv, prog, sad) {
    let seed = 0; for (const ch of String(CHAT.id + 'tree')) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
    const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
    const L = lv + Math.min(0.95, prog);           // плавный рост внутри уровня
    const leafC = sad ? ['#b8a06a', '#a98d55', '#c4ad78'] : ['#4caf50', '#66bb6a', '#2e9d4f', '#81c784'];
    let g = '';
    const ground = `<ellipse cx="150" cy="338" rx="135" ry="20" fill="url(#gr)"/>`;
    if (L < 1) { // семечко → росток
      const h = 12 + L * 40;
      g += `<path d="M150 336 Q148 ${336 - h / 2} 150 ${336 - h}" stroke="#6d4c2f" stroke-width="3" fill="none" stroke-linecap="round"/>`;
      g += `<ellipse cx="${141}" cy="${336 - h}" rx="${7 + L * 6}" ry="${4 + L * 3}" fill="${leafC[0]}" transform="rotate(-25 141 ${336 - h})"/>`;
      g += `<ellipse cx="${159}" cy="${336 - h - 2}" rx="${7 + L * 6}" ry="${4 + L * 3}" fill="${leafC[1]}" transform="rotate(25 159 ${336 - h - 2})"/>`;
      return this.wrap(ground + `<g class="tr-sway">${g}</g>`);
    }
    const H = Math.min(250, 60 + L * 22), W = Math.min(26, 5 + L * 2.2);
    const depth = Math.min(6, 2 + Math.floor(L / 1.5));
    const tips = [];
    let minX = 150, maxX = 150, minY = 336;
    const grow = (x, y, r) => { minX = Math.min(minX, x - r); maxX = Math.max(maxX, x + r); minY = Math.min(minY, y - r); };
    const branch = (x, y, len, ang, w, d) => {
      const x2 = x + Math.cos(ang) * len, y2 = y + Math.sin(ang) * len, cx = (x + x2) / 2 + (rnd() - .5) * len * .25, cy = (y + y2) / 2 + (rnd() - .5) * len * .25;
      g += `<path d="M${x.toFixed(1)} ${y.toFixed(1)} Q${cx.toFixed(1)} ${cy.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}" stroke="url(#bark)" stroke-width="${w.toFixed(1)}" fill="none" stroke-linecap="round"/>`;
      grow(x2, y2, w);
      if (d <= 0) { tips.push([x2, y2]); return; }
      const n = 2 + (rnd() < .35 ? 1 : 0);
      for (let i = 0; i < n; i++) {
        const spread = .5 + rnd() * .35, a = ang + (i - (n - 1) / 2) * spread + (rnd() - .5) * .2;
        branch(x2, y2, len * (.62 + rnd() * .15), a, Math.max(1.2, w * .66), d - 1);
      }
      if (d < depth - 1 && rnd() < .5) tips.push([x2, y2]);
    };
    branch(150, 336, H * .45, -Math.PI / 2 + (rnd() - .5) * .08, W, depth);
    // листва
    let leaves = '';
    const crowns = Math.min(tips.length, 8 + Math.floor(L * 9));
    for (let i = 0; i < tips.length; i++) {
      if (i > crowns) break;
      const [x, y] = tips[i], r = 9 + Math.min(16, L * 2.2) * (.6 + rnd() * .6);
      grow(x, y, r * 1.2);
      leaves += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${r.toFixed(1)}" fill="${leafC[Math.floor(rnd() * leafC.length)]}" opacity="${(.85 + rnd() * .15).toFixed(2)}"/>`;
      if (rnd() < .6) leaves += `<circle cx="${(x + (rnd() - .5) * r * 1.4).toFixed(1)}" cy="${(y - r * .5).toFixed(1)}" r="${(r * .7).toFixed(1)}" fill="${leafC[Math.floor(rnd() * leafC.length)]}" opacity=".9"/>`;
    }
    // цветы и плоды-сердечки
    let extra = '';
    if (L >= 5 && !sad) for (let i = 0; i < tips.length; i += 2) { const [x, y] = tips[i]; extra += `<g transform="translate(${(x + (rnd() - .5) * 18).toFixed(1)} ${(y + (rnd() - .5) * 14).toFixed(1)})"><circle r="4.2" fill="#ffc1d9"/><circle r="1.8" fill="#fff6b0"/></g>`; }
    if (L >= 6 && !sad) for (let i = 1; i < tips.length; i += 3) { const [x, y] = tips[i]; extra += `<text x="${(x + (rnd() - .5) * 16).toFixed(1)}" y="${(y + 10).toFixed(1)}" font-size="${(11 + Math.min(6, L - 6) * 1.5).toFixed(0)}" text-anchor="middle" class="tr-fruit">❤️</text>`; }
    if (L >= 8) for (let i = 0; i < 10; i++) extra += `<circle class="tr-spark" cx="${(40 + rnd() * 220).toFixed(0)}" cy="${(40 + rnd() * 200).toFixed(0)}" r="${(1 + rnd() * 1.8).toFixed(1)}" fill="#fff8c4" style="animation-delay:${(rnd() * 3).toFixed(1)}s"/>`;
    if (sad) for (let i = 0; i < 5; i++) extra += `<ellipse class="tr-fall" cx="${(80 + rnd() * 140).toFixed(0)}" cy="${(120 + rnd() * 60).toFixed(0)}" rx="5" ry="3" fill="#b8a06a" style="animation-delay:${(rnd() * 4).toFixed(1)}s"/>`;
    // вписываем крону в картинку, не сдвигая ствол
    const k = Math.min(1, 128 / Math.max(150 - minX, maxX - 150, 1), 318 / Math.max(336 - minY, 1));
    return this.wrap(ground + `<g class="tr-sway"><g transform="translate(150 336) scale(${k.toFixed(3)}) translate(-150 -336)">${g}${leaves}${extra}</g></g>`);
  },
  wrap(inner) {
    return `<svg viewBox="0 0 300 360" class="tr-svg"><defs>
      <linearGradient id="bark" x1="0" x2="1"><stop offset="0" stop-color="#7a5236"/><stop offset="1" stop-color="#5a3a24"/></linearGradient>
      <radialGradient id="gr" cx=".5" cy=".3"><stop offset="0" stop-color="#8bd17c"/><stop offset="1" stop-color="#4e9b48"/></radialGradient>
      </defs>${inner}</svg>`;
  },
  bubble(m, el) {
    el.classList.add('think');
    el.innerHTML = `<div class="think-pill tree-pill"><span class="tp-h">💧</span><span>${m.mine ? 'Вы полили наше дерево' : esc(m.p.n || S.partner || 'Собеседник') + ' полил(а) наше дерево'}</span>${metaHtml(m)}</div>`;
    el.querySelector('.think-pill').onclick = () => Tree.open();
  },
};
$('#tr-back').onclick = () => show('chat');

/* ================= 🎮 игры на двоих ================= */
const QUIZ = [
  ['Что я выберу на ужин?', ['Пиццу', 'Суши', 'Домашнюю еду', 'Бургер']],
  ['Идеальный выходной для меня — это…', ['Весь день дома', 'Прогулка на природе', 'Кафе и кино', 'Поездка куда-нибудь']],
  ['Что я больше люблю?', ['Кофе', 'Чай', 'Какао', 'Сок']],
  ['Какое время года мне ближе?', ['Весна', 'Лето', 'Осень', 'Зима']],
  ['Что меня быстрее всего развеселит?', ['Обнимашки', 'Вкусняшка', 'Смешное видео', 'Комплимент']],
  ['Где бы я хотел(а) провести отпуск?', ['На море', 'В горах', 'В большом городе', 'В деревне']],
  ['Что я делаю, когда мне грустно?', ['Сплю', 'Ем сладкое', 'Звоню близким', 'Ухожу гулять']],
  ['Мой любимый жанр фильмов?', ['Комедия', 'Ужасы', 'Мелодрама', 'Фантастика']],
  ['Я скорее…', ['Сова', 'Жаворонок', 'И то и другое', 'Вечно не высыпаюсь']],
  ['Что для меня лучший подарок?', ['Сделанный своими руками', 'Нужная вещь', 'Впечатления', 'Цветы']],
  ['Какое животное мне ближе?', ['Кошка', 'Собака', 'Хомячок', 'Попугай']],
  ['На свидании я бы выбрал(а)…', ['Ресторан', 'Пикник', 'Прогулку под звёздами', 'Квест или аттракционы']],
  ['Что я заказываю в кафе чаще всего?', ['Десерт', 'Салат', 'Пасту', 'Мясо']],
  ['Что меня больше всего раздражает?', ['Опоздания', 'Шум', 'Беспорядок', 'Когда не отвечают']],
  ['Как я люблю проводить вечер?', ['Сериал под пледом', 'Готовить вместе', 'Играть в игры', 'Гулять']],
  ['Какой суперспособностью я бы хотел(а) обладать?', ['Телепортация', 'Читать мысли', 'Летать', 'Останавливать время']],
  ['Что я выберу из сладкого?', ['Шоколад', 'Мороженое', 'Торт', 'Фрукты']],
  ['Мой идеальный завтрак — это…', ['Блинчики', 'Яичница', 'Каша', 'Только кофе']],
  ['Кем я мечтал(а) стать в детстве?', ['Врачом', 'Космонавтом', 'Артистом', 'Учителем']],
  ['Чего я боюсь больше?', ['Пауков', 'Высоты', 'Темноты', 'Одиночества']],
  ['Какая музыка мне ближе?', ['Поп', 'Рок', 'Рэп', 'Спокойная, лирика']],
  ['Что я сделаю первым делом, если выиграю миллион?', ['Куплю жильё', 'Поеду путешествовать', 'Порадую родных', 'Положу в копилку']],
  ['Как я выражаю любовь чаще всего?', ['Словами', 'Объятиями', 'Заботой', 'Подарками']],
  ['Что я надену на прогулку?', ['Спортивное и удобное', 'Что-то нарядное', 'Что первое попадётся', 'Всё в одном цвете']],
  ['Какой напиток я выберу летом?', ['Лимонад', 'Холодный чай', 'Квас', 'Молочный коктейль']],
  ['Какая моя черта тебе нравится больше всего — как думаешь, что я отвечу?', ['Доброта', 'Чувство юмора', 'Забота', 'Упорство']],
  ['Чем я люблю заниматься в свободное время?', ['Читать', 'Играть', 'Готовить', 'Смотреть видео']],
  ['Какой праздник для меня самый любимый?', ['Новый год', 'День рождения', '14 февраля', 'Годовщина']],
  ['Если бы мы завели питомца, я бы назвал(а) его…', ['Пушок', 'Бублик', 'Персик', 'Как-нибудь смешно']],
  ['Что я скажу утром первым?', ['Доброе утро ❤️', 'Ещё 5 минуточек', 'Где мой кофе?', 'Сколько времени?']],
];
const TRUTH = [
  'Какой момент с нами ты вспоминаешь чаще всего?', 'Что ты подумал(а) обо мне при первой встрече?', 'Какая моя привычка тебя смешит?',
  'Что бы ты хотел(а), чтобы мы попробовали вместе?', 'Когда ты понял(а), что влюбился(-лась)?', 'Какой мой поступок тронул тебя сильнее всего?',
  'О чём ты мечтаешь в этом году?', 'Какое наше фото у тебя самое любимое и почему?', 'Что тебя во мне удивило?',
  'Какую песню ты связываешь со мной?', 'Если бы мы поехали куда угодно завтра — куда?', 'Чего тебе не хватает, когда мы не рядом?',
  'Какой самый смешной случай был у нас?', 'Какое моё качество ты бы хотел(а) себе?', 'Что тебя сегодня порадовало?',
];
const DARE = [
  'Отправь кружок, где ты строишь самую смешную рожицу 🤪', 'Напиши три комплимента подряд, не повторяясь 💬', 'Отправь голосовое, где поёшь любую песню 🎤',
  'Отправь фото того, что сейчас перед тобой 📷', 'Расскажи в голосовом, за что ты меня любишь ❤️', 'Пришли 10 💋 подряд',
  'Нарисуй меня в редакторе фото и отправь 🎨', 'Придумай мне новое ласковое прозвище 🥰', 'Отправь стикер, который лучше всего описывает твоё настроение',
  'Запиши кружок с воздушным поцелуем 😘', 'Напиши мне маленькое стихотворение из 4 строк ✍️', 'Отправь своё самое милое фото 💕',
  'Позвони мне и скажи «я тебя люблю» самым смешным голосом 📞', 'Опиши наш идеальный вечер в трёх словах', 'Сделай «Думаю о тебе» прямо сейчас 💗',
];
const Games = {
  ev: new Map(),    // gid -> [события]
  menu() {
    sheet([
      { icon: 'smile', label: '🧠 Кто кого лучше знает', fn: () => this.newQuiz() },
      { icon: 'smile', label: '❌⭕ Крестики-нолики', fn: () => this.newTtt() },
      { icon: 'smile', label: '🎲 Правда или действие', fn: () => this.tod() },
    ], 'Игры прямо в чате — у вас обоих появится карточка игры.');
  },
  gid() { return hex(crypto.getRandomValues(new Uint8Array(6))); },
  newQuiz() {
    const order = QUIZ.map((_, i) => i).sort(() => Math.random() - .5).slice(0, 5);
    sendPayload({ t: 'game', g: 'quiz', gid: this.gid(), qs: order }).catch(() => toast('Не удалось начать игру'));
  },
  newTtt() { sendPayload({ t: 'game', g: 'ttt', gid: this.gid(), first: S.dev }).catch(() => toast('Не удалось начать игру')); },
  tod() {
    sheet([
      { icon: 'smile', label: '🙊 Правда', fn: () => sendPayload({ t: 'game', g: 'tod', k: 'truth', i: Math.floor(Math.random() * TRUTH.length) }) },
      { icon: 'smile', label: '🔥 Действие', fn: () => sendPayload({ t: 'game', g: 'tod', k: 'dare', i: Math.floor(Math.random() * DARE.length) }) },
    ], 'Выберите — карточка с заданием придёт в чат для собеседника.');
  },
  // ходы и ответы приходят отдельными скрытыми сообщениями
  apply(m) {
    const p = m.p, l = this.ev.get(p.gid) || [];
    if (l.some(e => e.id === m.id)) return;
    l.push({ id: m.id, dev: m.dev, mine: m.mine, p }); l.sort((a, b) => a.id - b.id);
    this.ev.set(p.gid, l);
    const card = document.querySelector(`.game-card[data-gid="${p.gid}"]`);
    if (card) { const msg = S.msgs.get(+card.closest('.msg').dataset.id); if (msg) this.render(card, msg); }
  },
  move(gid, data) { return sendPayload(Object.assign({ t: 'gm', gid }, data)).catch(() => toast('Нет связи — ход не отправлен')); },
  bubble(m, el) {
    el.classList.add('gift');
    const card = document.createElement('div'); card.className = 'game-card'; card.dataset.gid = m.p.gid || ('tod' + m.id);
    el.appendChild(card); this.render(card, m);
  },
  render(card, m) {
    const p = m.p;
    if (p.g === 'tod') {
      const truth = p.k === 'truth', text = truth ? TRUTH[p.i % TRUTH.length] : DARE[p.i % DARE.length];
      card.className = 'game-card tod ' + (truth ? 'truth' : 'dare');
      card.innerHTML = `<div class="gc-h">${truth ? '🙊 Правда' : '🔥 Действие'}</div><div class="gc-q">${esc(text)}</div><div class="gc-f">${m.mine ? 'Вы выбрали для собеседника' : esc((p.n || S.partner || '') + ' предлагает вам')}${metaHtml(m)}</div>`;
      return;
    }
    if (p.g === 'quiz') return this.renderQuiz(card, m);
    if (p.g === 'ttt') return this.renderTtt(card, m);
  },
  // ---------- кто кого лучше знает ----------
  renderQuiz(card, m) {
    const p = m.p, ev = this.ev.get(p.gid) || [], qs = p.qs || [];
    // ответ каждого: себе (self) и угадывание про другого (guess)
    const ans = {}; for (const e of ev) { const a = ans[e.dev] || (ans[e.dev] = {}); a[e.p.q] = { self: e.p.self, guess: e.p.guess }; }
    const mine = ans[S.dev] || {}, otherDev = Object.keys(ans).find(d => d !== S.dev), other = otherDev ? ans[otherDev] : {};
    const myDone = Object.keys(mine).length, otherDone = Object.keys(other).length;
    const pname = esc(S.partner || 'собеседник');
    let h = `<div class="gc-h">🧠 Кто кого лучше знает</div>`;
    if (myDone < qs.length) {
      const qi = myDone, q = QUIZ[qs[qi]], step = card.dataset.step || 'self';
      h += `<div class="gc-sub">Вопрос ${qi + 1} из ${qs.length}</div><div class="gc-q">${esc(q[0])}</div>`;
      if (step === 'self') h += `<div class="gc-l">Ваш ответ:</div><div class="gc-opts">${q[1].map((o, i) => `<button data-self="${i}">${esc(o)}</button>`).join('')}</div>`;
      else h += `<div class="gc-l">А что ответит ${pname}?</div><div class="gc-opts">${q[1].map((o, i) => `<button data-guess="${i}">${esc(o)}</button>`).join('')}</div>`;
      h += `<div class="gc-f">${otherDone >= qs.length ? `${pname} уже ответил(а) на все вопросы` : otherDone ? `${pname} ответил(а) на ${otherDone}` : `${pname} ещё не начал(а)`}${metaHtml(m)}</div>`;
    } else if (otherDone < qs.length) {
      h += `<div class="gc-q">Вы ответили на все вопросы ✅</div><div class="gc-sub">Ждём, пока ответит ${pname} (${otherDone}/${qs.length})…</div><div class="gc-f">${metaHtml(m)}</div>`;
    } else {
      let myScore = 0, otScore = 0, rows = '';
      qs.forEach((qn, i) => {
        const q = QUIZ[qn], a = mine[i], b = other[i];
        const iGuessed = a.guess === b.self, theyGuessed = b.guess === a.self;
        if (iGuessed) myScore++; if (theyGuessed) otScore++;
        rows += `<div class="gc-r"><b>${esc(q[0])}</b><span>Вы: ${esc(q[1][a.self])} · ${pname}: ${esc(q[1][b.self])}</span><span>${iGuessed ? '✅' : '❌'} вы угадали · ${theyGuessed ? '✅' : '❌'} ${pname} угадал(а)</span></div>`;
      });
      const verdict = myScore === otScore ? 'Ничья — вы знаете друг друга одинаково хорошо! 💞' : myScore > otScore ? 'Вы знаете собеседника лучше! 🏆' : `${pname} знает вас лучше! 🏆`;
      h += `<div class="gc-score"><div><b>${myScore}</b><small>вы</small></div><span>:</span><div><b>${otScore}</b><small>${pname}</small></div></div><div class="gc-v">${verdict}</div><details class="gc-det"><summary>Ответы</summary>${rows}</details><button class="gc-again" data-again="quiz">Сыграть ещё</button><div class="gc-f">${metaHtml(m)}</div>`;
    }
    card.innerHTML = h;
    card.onclick = e => {
      const s = e.target.closest('[data-self]'), g = e.target.closest('[data-guess]'), ag = e.target.closest('[data-again]');
      if (ag) { this.newQuiz(); return; }
      if (s) { card.dataset.pick = s.dataset.self; card.dataset.step = 'guess'; this.renderQuiz(card, m); return; }
      if (g) { const q = Object.keys(mine).length; card.dataset.step = 'self'; this.move(p.gid, { q, self: +card.dataset.pick, guess: +g.dataset.guess }); vibrate(8); }
    };
  },
  // ---------- крестики-нолики ----------
  renderTtt(card, m) {
    const p = m.p, ev = this.ev.get(p.gid) || [], board = Array(9).fill('');
    const first = p.first || m.dev;
    let firstTurn = true; // сейчас ходит тот, кто начал?
    for (const e of ev) {
      const isFirst = e.dev === first;
      if (isFirst !== firstTurn || board[e.p.c] || this.tttWin(board)) continue;
      board[e.p.c] = isFirst ? 'X' : 'O'; firstTurn = !firstTurn;
    }
    const turn = firstTurn ? first : '_other';
    const win = this.tttWin(board), full = board.every(Boolean);
    const myTurn = !win && !full && ((turn === first && S.dev === first) || (turn === '_other' && S.dev !== first));
    const mySym = S.dev === first ? '❌' : '⭕', pname = esc(S.partner || 'собеседник');
    let status;
    if (win) { const w = win.s === 'X' ? first : '_o'; const iWon = (w === first) === (S.dev === first); status = iWon ? '🏆 Вы победили!' : `🏆 Победил(а) ${pname}!`; }
    else if (full) status = '🤝 Ничья!';
    else status = myTurn ? `Ваш ход (${mySym})` : `Ходит ${pname}…`;
    card.innerHTML = `<div class="gc-h">❌⭕ Крестики-нолики</div><div class="ttt">${board.map((v, i) => `<button data-c="${i}" class="${win && win.l.includes(i) ? 'w' : ''}" ${v || !myTurn ? 'disabled' : ''}>${v === 'X' ? '❌' : v === 'O' ? '⭕' : ''}</button>`).join('')}</div><div class="gc-sub">${status}</div>${win || full ? '<button class="gc-again" data-again="ttt">Ещё партию</button>' : ''}<div class="gc-f">${metaHtml(m)}</div>`;
    card.onclick = e => {
      if (e.target.closest('[data-again]')) { this.newTtt(); return; }
      const b = e.target.closest('[data-c]'); if (!b || b.disabled) return;
      b.textContent = mySym; card.querySelectorAll('.ttt button').forEach(x => { x.disabled = true; });
      this.move(p.gid, { c: +b.dataset.c }); vibrate(8);
    };
  },
  tttWin(b) {
    for (const l of [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[1]] === b[l[2]]) return { s: b[l[0]], l };
    return null;
  },
};
$('#think-btn').onclick = () => Think.send();
