'use strict';
/* Наш чат — приложение. Всё шифрование происходит здесь, на телефоне. */

const $ = (s, el = document) => el.querySelector(s);
const Native = window.NativeBridge || null;
const CHUNK = 8 * 1024 * 1024;
const enc = new TextEncoder(), dec = new TextDecoder();
const VERSION = '1.0';

/* ================= иконки ================= */
const I = {
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  clip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.4 11.1-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/></svg>',
  mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4"/></svg>',
  circle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/></svg>',
  send: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.4 20.4 21 12 3.4 3.6 3.4 10l12.6 2-12.6 2z"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
  save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0-5-5m5 5 5-5M4 19h16"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l13-7.5z"/></svg>',
  pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4.5" width="4" height="15" rx="1"/><rect x="14" y="4.5" width="4" height="15" rx="1"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>',
  file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
  flip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 7h-3l-2-3H9L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><path d="M9 13a3 3 0 0 0 5.2 2M15 12a3 3 0 0 0-5.2-2"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 8.5a5 5 0 0 1 0 7" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
};

/* ================= утилиты ================= */
function b64(buf) {
  const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}
function unb64(s) { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
const b64url = b => b64(b).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64url = s => unb64(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4));
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const pad2 = n => String(n).padStart(2, '0');
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + pad2(s % 60); };
const fmtTime = ts => { const d = new Date(ts); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };
function fmtSize(n) {
  if (n < 1024) return n + ' Б';
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' КБ';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1).replace('.', ',') + ' МБ';
  return (n / 1024 / 1024 / 1024).toFixed(2).replace('.', ',') + ' ГБ';
}
const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
function fmtDay(ts) {
  const d = new Date(ts), now = new Date();
  const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((day(now) - day(d)) / 86400000);
  if (diff === 0) return 'Сегодня';
  if (diff === 1) return 'Вчера';
  return d.getDate() + ' ' + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ' ' + d.getFullYear() : '');
}
function stamp() { const d = new Date(); return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '_' + pad2(d.getHours()) + pad2(d.getMinutes()) + pad2(d.getSeconds()); }
function linkify(text) {
  return esc(text).replace(/\bhttps?:\/\/[^\s<]+[^\s<.,:;!?)"'\]]/g, u => `<a href="${u}" data-ext="1">${u}</a>`);
}
let toastT;
function toast(msg, ms = 2500) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.add('hidden'), ms);
}
function vibrate(ms = 20) { try { navigator.vibrate && navigator.vibrate(ms); } catch (_) { } }

/* ================= шифрование ================= */
const Crypto = {
  async derive(raw) {
    const base = await crypto.subtle.importKey('raw', raw, 'HKDF', false, ['deriveKey', 'deriveBits']);
    const salt = enc.encode('nash-chat-v1');
    const key = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt, info: enc.encode('enc') }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
    const tok = await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info: enc.encode('auth') }, base, 256);
    return { key, token: hex(tok) };
  },
  async seal(key, data, aad) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const p = { name: 'AES-GCM', iv }; if (aad) p.additionalData = enc.encode(aad);
    const ct = new Uint8Array(await crypto.subtle.encrypt(p, key, data));
    const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12); return out;
  },
  async open(key, data, aad) {
    data = data instanceof Uint8Array ? data : new Uint8Array(data);
    const p = { name: 'AES-GCM', iv: data.subarray(0, 12) }; if (aad) p.additionalData = enc.encode(aad);
    return new Uint8Array(await crypto.subtle.decrypt(p, key, data.subarray(12)));
  },
  async pinKey(pin, salt) {
    const base = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 250000 }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  },
};

/* ================= хранилище ================= */
const Store = {
  get() { try { return JSON.parse(localStorage.getItem('nc') || 'null'); } catch (_) { return null; } },
  set(v) { localStorage.setItem('nc', JSON.stringify(v)); },
  clear() { localStorage.removeItem('nc'); },
};
const DB = {
  db: null,
  open() {
    return new Promise(res => {
      try {
        const r = indexedDB.open('nashchat', 1);
        r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('msgs', { keyPath: 'id' }); d.createObjectStore('media'); };
        r.onsuccess = () => { this.db = r.result; res(); };
        r.onerror = () => res();
      } catch (_) { res(); }
    });
  },
  run(store, mode, fn) {
    return new Promise((res, rej) => {
      if (!this.db) return res(undefined);
      try {
        const t = this.db.transaction(store, mode); const s = t.objectStore(store);
        let out; const rq = fn(s); if (rq) rq.onsuccess = () => { out = rq.result; };
        t.oncomplete = () => res(out); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
      } catch (e) { rej(e); }
    });
  },
  putMsgs(list) { return this.run('msgs', 'readwrite', s => { for (const m of list) s.put(m); }).catch(() => { }); },
  delMsg(id) { return this.run('msgs', 'readwrite', s => s.delete(id)).catch(() => { }); },
  lastMsgs(n) {
    return new Promise(res => {
      if (!this.db) return res([]);
      const out = [];
      try {
        const t = this.db.transaction('msgs', 'readonly');
        const c = t.objectStore('msgs').openCursor(null, 'prev');
        c.onsuccess = () => { const cur = c.result; if (cur && out.length < n) { out.push(cur.value); cur.continue(); } else res(out.reverse()); };
        c.onerror = () => res([]);
      } catch (_) { res([]); }
    });
  },
  msgsBefore(id, n) {
    return new Promise(res => {
      if (!this.db) return res([]);
      const out = [];
      try {
        const t = this.db.transaction('msgs', 'readonly');
        const c = t.objectStore('msgs').openCursor(IDBKeyRange.upperBound(id, true), 'prev');
        c.onsuccess = () => { const cur = c.result; if (cur && out.length < n) { out.push(cur.value); cur.continue(); } else res(out.reverse()); };
        c.onerror = () => res([]);
      } catch (_) { res([]); }
    });
  },
  getMedia(id) { return this.run('media', 'readonly', s => s.get(id)).catch(() => undefined); },
  putMedia(id, blob) { return this.run('media', 'readwrite', s => s.put(blob, id)).catch(() => { }); },
  delMedia(id) { return this.run('media', 'readwrite', s => s.delete(id)).catch(() => { }); },
  clearMedia() { return this.run('media', 'readwrite', s => s.clear()).catch(() => { }); },
};

/* ================= состояние ================= */
const S = {
  url: '', name: '', dev: '', key: null, token: '', raw: null,
  msgs: new Map(),        // id -> {id, ts, dev, mine, p, del}
  order: [],              // id по возрастанию
  last: 0, v: 0,
  oldestLoaded: Infinity, noMoreOlder: false,
  pending: new Map(),     // nonce -> {el, ...}
  online: false, syncing: false, syncGen: 0,
  locked: false, hiddenAt: 0,
};

/* ================= сеть ================= */
async function api(path, opt = {}) {
  const headers = Object.assign({ Authorization: 'Bearer ' + S.token }, opt.headers || {});
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), opt.timeout || 60000);
  try {
    const r = await fetch(S.url + path, { method: opt.method || 'GET', headers, body: opt.body, signal: ctl.signal });
    if (!r.ok) { const e = new Error('HTTP ' + r.status); e.status = r.status; throw e; }
    return opt.raw ? new Uint8Array(await r.arrayBuffer()) : r.json();
  } finally { clearTimeout(timer); }
}
async function retry(fn, tries = 4) {
  let err;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); } catch (e) { err = e; if (e.status && e.status < 500 && e.status !== 429) break; await sleep(1000 * (i + 1)); }
  }
  throw err;
}
function normUrl(u) {
  u = (u || '').trim().replace(/\/+$/, '');
  if (u && !/^https?:\/\//i.test(u)) u = 'https://' + u;
  return u;
}

/* ================= навигация ================= */
const screens = ['welcome', 'create', 'invite', 'join', 'lock', 'chat', 'settings'];
function show(id) { for (const s of screens) $('#' + s).classList.toggle('hidden', s !== id); }
document.addEventListener('click', e => {
  const go = e.target.closest('[data-go]'); if (go) show(go.dataset.go);
  const a = e.target.closest('a[data-ext]');
  if (a) { e.preventDefault(); if (Native && Native.openUrl) Native.openUrl(a.href); else window.open(a.href, '_blank'); }
});

/* ================= запуск ================= */
async function boot() {
  for (const [id, ic] of [['open-settings', 'gear'], ['attach', 'clip'], ['btn-voice', 'mic'], ['btn-circle', 'circle'], ['btn-send', 'send'], ['rec-cancel', 'trash'], ['rec-send', 'send'], ['down', 'down'], ['v-close', 'x'], ['v-save', 'save'], ['circle-cancel', 'x'], ['circle-send', 'send'], ['circle-flip', 'flip']]) $('#' + id).innerHTML = I[ic];
  if (!window.crypto || !crypto.subtle) { document.body.innerHTML = '<p style="padding:24px">Шифрование недоступно в этом браузере.</p>'; return; }
  await DB.open();
  const st = Store.get();
  if (!st || !st.wrap) { show('welcome'); return; }
  S.url = st.url; S.name = st.name; S.dev = st.dev;
  showLock();
}

/* ---------- создание ---------- */
function checkPin(p1, p2) {
  if (!/^\d{4,8}$/.test(p1)) return 'PIN должен состоять из 4–8 цифр';
  if (p1 !== p2) return 'PIN-коды не совпадают';
  return '';
}
async function saveAll(raw, pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const k = await Crypto.pinKey(pin, salt);
  const wrapped = await Crypto.seal(k, raw);
  Store.set({ url: S.url, name: S.name, dev: S.dev, wrap: { salt: b64(salt), ct: b64(wrapped) } });
}
function inviteCode() { return 'NC1.' + b64url(S.raw) + '.' + b64url(enc.encode(S.url)); }

$('#c-go').onclick = async () => {
  const err = $('#c-err'); err.textContent = '';
  const url = normUrl($('#c-url').value), name = $('#c-name').value.trim(), pin = $('#c-pin').value;
  if (!/^https:\/\/[^\s/]+/.test(url) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url)) return err.textContent = 'Введите адрес сервера, начиная с https://';
  if (!name) return err.textContent = 'Введите имя';
  const pe = checkPin(pin, $('#c-pin2').value); if (pe) return err.textContent = pe;
  const btn = $('#c-go'); btn.disabled = true; btn.textContent = 'Подключаюсь…';
  try {
    let info;
    try { info = await (await fetch(url + '/api/ping')).json(); } catch (_) { throw new Error('Сервер не отвечает. Проверьте адрес и интернет.'); }
    if (!info || info.app !== 'nash-chat') throw new Error('По этому адресу не найден сервер «Нашего чата».');
    if (info.claimed) throw new Error('На этом сервере чат уже создан. Если это ваш сервер — нажмите «Назад» и подключитесь по коду приглашения.');
    const raw = crypto.getRandomValues(new Uint8Array(32));
    const { key, token } = await Crypto.derive(raw);
    const r = await fetch(url + '/api/claim', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
    if (!r.ok) throw new Error('Сервер отказал (' + r.status + ').');
    Object.assign(S, { url, name, dev: hex(crypto.getRandomValues(new Uint8Array(8))), key, token, raw });
    await saveAll(raw, pin);
    $('#inv-code').textContent = inviteCode();
    $('#inv-done').onclick = () => startChat();
    show('invite');
  } catch (e) { err.textContent = e.message; }
  finally { btn.disabled = false; btn.textContent = 'Создать'; }
};
$('#inv-copy').onclick = () => copyText($('#inv-code').textContent, 'Код скопирован');

function copyText(t, msg) {
  if (Native && Native.copyText) { Native.copyText(t); toast(msg || 'Скопировано'); return; }
  (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast(msg || 'Скопировано'), () => toast('Не удалось скопировать'));
}

/* ---------- присоединение ---------- */
$('#j-go').onclick = async () => {
  const err = $('#j-err'); err.textContent = '';
  const code = $('#j-code').value.replace(/\s+/g, ''), name = $('#j-name').value.trim(), pin = $('#j-pin').value;
  const m = code.match(/^NC1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/);
  if (!m) return err.textContent = 'Код приглашения неверный. Скопируйте его целиком.';
  if (!name) return err.textContent = 'Введите имя';
  const pe = checkPin(pin, $('#j-pin2').value); if (pe) return err.textContent = pe;
  const btn = $('#j-go'); btn.disabled = true; btn.textContent = 'Подключаюсь…';
  try {
    const raw = unb64url(m[1]); const url = dec.decode(unb64url(m[2]));
    if (raw.length !== 32) throw new Error('Код приглашения повреждён.');
    const { key, token } = await Crypto.derive(raw);
    Object.assign(S, { url, name, dev: hex(crypto.getRandomValues(new Uint8Array(8))), key, token, raw });
    try { await api('/api/messages?last=1&limit=1', { timeout: 15000 }); }
    catch (e) { throw new Error(e.status === 401 ? 'Сервер не принял код. Попросите прислать его ещё раз.' : 'Сервер не отвечает. Проверьте интернет.'); }
    await saveAll(raw, pin);
    startChat();
  } catch (e) { err.textContent = e.message; }
  finally { btn.disabled = false; btn.textContent = 'Подключиться'; }
};

/* ---------- PIN ---------- */
let pinBuf = '', pinMode = 'unlock', pinNew = '';
function buildKeypad() {
  const kp = $('#keypad'); kp.innerHTML = '';
  for (const k of ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫']) {
    const b = document.createElement('button'); b.textContent = k;
    if (!k) b.style.visibility = 'hidden';
    if (k === '⌫') b.className = 'ghost';
    b.onclick = () => pinKey(k); kp.appendChild(b);
  }
}
function drawDots() { $('#pin-dots').innerHTML = Array.from({ length: Math.max(4, pinBuf.length) }, (_, i) => `<i class="${i < pinBuf.length ? 'on' : ''}"></i>`).join(''); }
function showLock(mode = 'unlock') {
  pinMode = mode; pinBuf = ''; S.locked = mode === 'unlock';
  $('#lock h2').textContent = mode === 'unlock' ? 'Введите PIN' : mode === 'old' ? 'Текущий PIN' : mode === 'new' ? 'Новый PIN' : 'Повторите новый PIN';
  $('#lock-err').textContent = ''; buildKeypad(); drawDots(); show('lock');
}
let pinTimer;
function pinKey(k) {
  if (k === '⌫') pinBuf = pinBuf.slice(0, -1);
  else if (pinBuf.length < 8) pinBuf += k;
  drawDots(); vibrate(8);
  clearTimeout(pinTimer);
  if (pinBuf.length >= 4) pinTimer = setTimeout(tryPin, pinMode === 'new' || pinMode === 'repeat' ? 900 : 350);
}
async function unwrap(pin) {
  const st = Store.get();
  const k = await Crypto.pinKey(pin, unb64(st.wrap.salt));
  return Crypto.open(k, unb64(st.wrap.ct));
}
async function tryPin() {
  const pin = pinBuf;
  if (pinMode === 'new') { pinNew = pin; showLock('repeat'); return; }
  if (pinMode === 'repeat') {
    if (pin !== pinNew) { $('#lock-err').textContent = 'Не совпадает, попробуйте ещё раз'; pinMode = 'new'; pinBuf = ''; drawDots(); $('#lock h2').textContent = 'Новый PIN'; return; }
    await saveAll(S.raw, pin); toast('PIN изменён'); show('settings'); return;
  }
  try {
    const raw = await unwrap(pin);
    if (pinMode === 'old') { showLock('new'); return; }
    if (!S.key) { const d = await Crypto.derive(raw); S.key = d.key; S.token = d.token; S.raw = raw; }
    S.locked = false;
    if (!S.started) startChat(); else show('chat');
  } catch (_) {
    $('#lock-err').textContent = 'Неверный PIN'; pinBuf = ''; drawDots(); vibrate(120);
  }
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { S.hiddenAt = Date.now(); stopVoicePlayback(); }
  else {
    if (S.started && !S.locked && S.hiddenAt && Date.now() - S.hiddenAt > 120000 && !$('#chat').classList.contains('hidden')) showLock();
    if (S.started) { markSeen(); kickSync(); }
  }
});

/* ================= чат ================= */
async function startChat() {
  S.started = true; S.locked = false;
  show('chat');
  if (Native && Native.configure) Native.configure(S.url, S.token, S.dev);
  // сначала — то, что уже есть на телефоне
  const cached = await DB.lastMsgs(80);
  for (const r of cached) await ingest(r, false);
  renderAll(); scrollBottom(true);
  syncLoop();
}

async function ingest(r, persist = true) {
  if (S.msgs.has(r.id)) {
    const old = S.msgs.get(r.id);
    if (r.del && !old.del) { old.del = true; old.p = null; persist && DB.putMsgs([{ id: r.id, ts: r.ts, dev: r.dev, del: true }]); return 'changed'; }
    return null;
  }
  const m = { id: r.id, ts: r.ts, dev: r.dev, mine: r.dev === S.dev, del: !!r.del, p: null };
  if (!m.del) {
    try { m.p = JSON.parse(dec.decode(await Crypto.open(S.key, unb64(r.ct)))); }
    catch (_) { m.p = { t: 'text', text: '⚠️ Не удалось расшифровать сообщение' }; }
  }
  S.msgs.set(m.id, m);
  // упорядоченная вставка
  if (!S.order.length || S.order[S.order.length - 1] < m.id) S.order.push(m.id);
  else { let i = S.order.length; while (i > 0 && S.order[i - 1] > m.id) i--; S.order.splice(i, 0, m.id); }
  if (m.id > S.last) S.last = m.id;
  if (m.id < S.oldestLoaded) S.oldestLoaded = m.id;
  if (!m.mine && m.p && m.p.n) setPartner(m.p.n);
  if (persist) DB.putMsgs([r]);
  return 'new';
}

function setPartner(n) {
  if (S.partner === n) return;
  S.partner = n;
  $('#partner-name').textContent = n;
  $('#partner-av').textContent = (n.trim()[0] || '♥').toUpperCase();
}
function setNet(on, text) {
  S.online = on;
  $('#net').textContent = text || (on ? 'защищённое соединение' : 'нет связи с сервером…');
}

let syncWake = null;
function kickSync() { if (syncWake) syncWake(); }
async function syncLoop() {
  const gen = ++S.syncGen;
  let first = true, backoff = 1000;
  while (gen === S.syncGen) {
    try {
      let res;
      if (first) {
        // догоняем всё, что пришло, пока приложение было закрыто
        res = await api('/api/messages?last=1&limit=100', { timeout: 20000 });
        const known = S.last;
        if (known && res.messages.length && res.messages[0].id > known + 1) {
          // была большая пауза — пролистываем недостающее с конца, не перегружая
        }
        let changed = false;
        // удалённые среди известных
        for (const r of res.messages) { if (await ingest(r)) changed = true; }
        // проверяем, не удалены ли сообщения, которые у нас в кэше
        if (changed || !S.order.length) { renderAll(); scrollBottom(true); }
        S.v = res.v; first = false;
        if (S.order.length && S.order[0] > 1) $('#older').classList.remove('hidden');
      } else {
        res = await api(`/api/messages?after=${S.last}&v=${S.v}&wait=25&limit=200`, { timeout: 40000 });
        let added = [];
        for (const r of res.messages) { const k = await ingest(r); if (k === 'new') added.push(r.id); }
        for (const id of res.deleted || []) markDeleted(id);
        S.v = res.v;
        if (added.length) onNewMessages(added);
      }
      setNet(true); backoff = 1000;
      markSeen();
    } catch (e) {
      if (gen !== S.syncGen) return;
      if (e.status === 401) { setNet(false, 'сервер не принимает ключ'); await sleep(30000); continue; }
      setNet(false);
      await new Promise(r => { syncWake = r; setTimeout(r, backoff); });
      syncWake = null; backoff = Math.min(backoff * 2, 30000);
    }
  }
}

function markSeen() { if (Native && Native.setSeen && !document.hidden) Native.setSeen(String(S.last)); }

async function loadOlder() {
  const btn = $('#older'); if (btn.dataset.busy) return; btn.dataset.busy = '1'; btn.textContent = 'Загрузка…';
  try {
    const first = S.order[0] || (S.last + 1);
    let list = await DB.msgsBefore(first, 60);
    // если в кэше пробел — берём с сервера
    if (list.length < 60 || list[list.length - 1].id !== first - 1) {
      const res = await api(`/api/messages?before=${first}&limit=100`);
      list = res.messages;
    }
    const box = $('#list'), h = box.scrollHeight;
    for (const r of list) await ingest(r);
    renderAll();
    box.scrollTop = box.scrollHeight - h;
    if (!list.length || list[0].id <= 1) btn.classList.add('hidden');
  } catch (_) { toast('Не удалось загрузить'); }
  finally { delete btn.dataset.busy; btn.textContent = 'Загрузить ранние сообщения'; }
}
$('#older').onclick = loadOlder;
$('#list').addEventListener('scroll', () => {
  const box = $('#list');
  if (box.scrollTop < 60 && !$('#older').classList.contains('hidden')) loadOlder();
  if (nearBottom()) { $('#down').classList.add('hidden'); S.unseenBelow = 0; }
});

/* ---------- отрисовка ---------- */
function nearBottom() { const b = $('#list'); return b.scrollHeight - b.scrollTop - b.clientHeight < 150; }
function scrollBottom(force) { const b = $('#list'); if (force || nearBottom()) requestAnimationFrame(() => { b.scrollTop = b.scrollHeight; }); }
$('#down').onclick = () => { const b = $('#list'); b.scrollTo({ top: b.scrollHeight, behavior: 'smooth' }); };

function dayKey(ts) { const d = new Date(ts); return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate(); }
function renderAll() {
  const box = $('#msgs'); box.innerHTML = '';
  let prevDay = '';
  for (const id of S.order) {
    const m = S.msgs.get(id);
    const dk = dayKey(m.ts);
    if (dk !== prevDay) { box.appendChild(dayEl(m.ts)); prevDay = dk; }
    box.appendChild(msgEl(m));
  }
  for (const p of S.pending.values()) box.appendChild(p.el);
}
function dayEl(ts) { const d = document.createElement('div'); d.className = 'day'; d.textContent = fmtDay(ts); d.dataset.day = dayKey(ts); return d; }
function onNewMessages(ids) {
  const wasNear = nearBottom();
  const box = $('#msgs');
  for (const id of ids) {
    const m = S.msgs.get(id);
    // своё сообщение, которое мы только что отправили, заменяет черновик
    if (m.p && m.p.nonce && S.pending.has(m.p.nonce)) { const p = S.pending.get(m.p.nonce); p.el.remove(); S.pending.delete(m.p.nonce); }
    if (document.querySelector(`.msg[data-id="${id}"]`)) continue;
    const idx = S.order.indexOf(id);
    const prev = idx > 0 ? S.msgs.get(S.order[idx - 1]) : null;
    if (idx !== S.order.length - 1) { renderAll(); continue; }
    if (!prev || dayKey(prev.ts) !== dayKey(m.ts)) insertBeforePending(box, dayEl(m.ts));
    insertBeforePending(box, msgEl(m));
  }
  const fromPartner = ids.some(id => !S.msgs.get(id).mine);
  if (wasNear) scrollBottom(true);
  else if (fromPartner) {
    S.unseenBelow = (S.unseenBelow || 0) + ids.length;
    const d = $('#down'); d.classList.remove('hidden'); d.innerHTML = I.down + `<b>${S.unseenBelow}</b>`;
  }
  if (fromPartner && !document.hidden) vibrate(15);
}
function insertBeforePending(box, el) {
  const firstPending = box.querySelector('.msg.pending');
  if (firstPending) box.insertBefore(el, firstPending); else box.appendChild(el);
}
function markDeleted(id) {
  const m = S.msgs.get(id); if (!m) return;
  if (m.p && m.p.file) DB.delMedia(m.p.file.id);
  m.del = true; m.p = null;
  DB.putMsgs([{ id: m.id, ts: m.ts, dev: m.dev, del: true }]);
  const el = document.querySelector(`.msg[data-id="${id}"]`);
  if (el) el.replaceWith(msgEl(m));
}

function metaHtml(m) { return `<span class="meta">${fmtTime(m.ts)}</span>`; }
function msgEl(m) {
  const el = document.createElement('div');
  el.className = 'msg' + (m.mine ? ' mine' : '');
  el.dataset.id = m.id;
  if (m.del || !m.p) { el.classList.add('deleted'); el.innerHTML = `<div class="bubble">Сообщение удалено${metaHtml(m)}</div>`; return el; }
  const p = m.p;
  switch (p.t) {
    case 'text': el.innerHTML = `<div class="bubble">${linkify(p.text)}${metaHtml(m)}</div>`; break;
    case 'image': case 'video': el.appendChild(mediaBubble(m)); break;
    case 'voice': el.appendChild(voiceBubble(m)); break;
    case 'circle': el.appendChild(circleBubble(m)); break;
    default: el.appendChild(fileBubble(m));
  }
  attachLongPress(el, () => messageMenu(m));
  return el;
}

/* --- фото и видео --- */
function boxSize(p) {
  const maxW = Math.min(280, window.innerWidth * 0.72), maxH = 340;
  let w = p.w || 300, h = p.h || 300;
  const k = Math.min(maxW / w, maxH / h, 10); w = Math.round(w * k); h = Math.round(h * k);
  return { w: Math.max(w, 120), h: Math.max(h, 90) };
}
function progSvg() { return `<svg class="prog" viewBox="0 0 56 56"><circle class="bg" cx="28" cy="28" r="24"/><circle class="fg" cx="28" cy="28" r="24" stroke-dasharray="150.8" stroke-dashoffset="150.8"/></svg>`; }
function setProg(el, f) { const c = el && el.querySelector('.prog .fg'); if (c) c.style.strokeDashoffset = String(150.8 * (1 - Math.max(0.02, Math.min(1, f)))); }

function mediaBubble(m) {
  const p = m.p, f = p.file;
  const b = document.createElement('div'); b.className = 'bubble media';
  const { w, h } = boxSize(p);
  const pic = document.createElement('div'); pic.className = 'pic'; pic.style.width = w + 'px'; pic.style.height = h + 'px';
  pic.innerHTML = (p.thumb ? `<img class="blur" src="${p.thumb}" alt="">` : '') +
    (p.orig ? `<span class="badge">Оригинал · ${fmtSize(f.size)}</span>` : p.t === 'video' ? `<span class="badge">${fmtDur(p.dur)} · ${fmtSize(f.size)}</span>` : '') +
    `<div class="center">${p.t === 'video' ? `<div class="play">${I.play}</div>` : ''}</div>`;
  b.appendChild(pic);
  if (p.caption) { const c = document.createElement('div'); c.className = 'caption'; c.innerHTML = linkify(p.caption); b.appendChild(c); }
  b.insertAdjacentHTML('beforeend', metaHtml(m));

  const showFull = async (auto) => {
    const center = pic.querySelector('.center');
    try {
      const blob = await getMedia(f, fr => { if (!center.querySelector('.prog')) center.innerHTML = progSvg(); setProg(center, fr); });
      if (p.t === 'image') {
        const img = document.createElement('img'); img.alt = ''; img.src = await mediaUrl(f.id, blob);
        img.onload = () => { const old = pic.querySelector('img.blur'); if (old) old.remove(); };
        pic.insertBefore(img, pic.firstChild); center.innerHTML = '';
      } else {
        center.innerHTML = `<div class="play">${I.play}</div>`;
        if (!auto) openViewer(m, blob);
      }
      pic.dataset.ready = '1';
    } catch (e) { center.innerHTML = `<div class="play">${I.save}</div>`; if (!auto) toast('Не удалось загрузить: ' + e.message); }
  };
  pic.addEventListener('click', async () => {
    if (pic.dataset.loading) return;
    if (pic.dataset.ready) { const blob = await getMedia(f); return openViewer(m, blob); }
    pic.dataset.loading = '1'; await showFull(false); delete pic.dataset.loading;
  });
  // маленькие сжатые фото загружаем сразу
  if (p.t === 'image' && (!p.orig || f.size < 4e6)) { pic.dataset.loading = '1'; showFull(true).then(() => { delete pic.dataset.loading; }); }
  else if (!p.thumb || p.t === 'image') pic.querySelector('.center').innerHTML = `<div class="play">${I.save}</div>`;
  if (p.t === 'image' && p.orig && f.size >= 4e6) pic.querySelector('.center').innerHTML = `<div class="play">${I.save}</div>`;
  // если уже в кэше — показываем без нажатия
  if (p.t === 'video') DB.getMedia(f.id).then(x => { if (x) pic.dataset.ready = '1'; });
  return b;
}

/* --- голосовые --- */
let voiceAudio = null, voiceCur = null;
function stopVoicePlayback() { if (voiceAudio) { voiceAudio.pause(); } }
function voiceBubble(m) {
  const p = m.p;
  const b = document.createElement('div'); b.className = 'bubble';
  const bars = normWave(p.wave, 40);
  b.innerHTML = `<div class="voice"><button class="pbtn">${I.play}</button><div class="wave">${bars.map(v => `<i style="height:${4 + v * 24}px"></i>`).join('')}</div><span class="dur">${fmtDur(p.dur)}</span></div>${metaHtml(m)}`;
  const btn = b.querySelector('.pbtn'), waveEl = b.querySelector('.wave'), durEl = b.querySelector('.dur');
  const paint = fr => { const n = Math.round(fr * bars.length); waveEl.querySelectorAll('i').forEach((x, i) => x.classList.toggle('on', i < n)); };
  const ctl = {
    set(playing) { btn.innerHTML = playing ? I.pause : I.play; },
    tick(t) { paint(Math.min(1, t / (p.dur || 1))); durEl.textContent = fmtDur(t); },
    reset() { paint(0); durEl.textContent = fmtDur(p.dur); this.set(false); },
  };
  btn.onclick = async () => {
    if (voiceCur === ctl && voiceAudio && !voiceAudio.paused) { voiceAudio.pause(); ctl.set(false); return; }
    if (voiceCur === ctl && voiceAudio && voiceAudio.paused && voiceAudio.src) { voiceAudio.play(); ctl.set(true); return; }
    try {
      btn.innerHTML = '…';
      const blob = await getMedia(p.file);
      playVoice(ctl, await mediaUrl(p.file.id, blob), m.id);
    } catch (e) { ctl.set(false); toast('Не удалось загрузить голосовое'); }
  };
  // seek по волне
  waveEl.addEventListener('click', e => {
    if (voiceCur !== ctl || !voiceAudio) return;
    const r = waveEl.getBoundingClientRect(); voiceAudio.currentTime = (e.clientX - r.left) / r.width * (p.dur || 0);
  });
  return b;
}
function playVoice(ctl, url, id) {
  if (voiceCur && voiceCur !== ctl) voiceCur.reset();
  if (!voiceAudio) voiceAudio = new Audio();
  voiceAudio.onended = voiceAudio.onpause = voiceAudio.ontimeupdate = null;
  voiceCur = ctl; voiceAudio.src = url;
  voiceAudio.ontimeupdate = () => ctl.tick(voiceAudio.currentTime);
  voiceAudio.onpause = () => ctl.set(false);
  voiceAudio.onended = () => {
    ctl.reset(); voiceCur = null;
    // следующее голосовое подряд — играем автоматически
    const idx = S.order.indexOf(id), next = S.msgs.get(S.order[idx + 1]);
    if (next && next.p && next.p.t === 'voice') { const el = document.querySelector(`.msg[data-id="${next.id}"] .pbtn`); el && el.click(); }
  };
  voiceAudio.play().then(() => ctl.set(true)).catch(() => ctl.set(false));
}
function normWave(w, n) {
  if (!w || !w.length) return Array.from({ length: n }, (_, i) => 0.25 + 0.2 * Math.abs(Math.sin(i * 1.7)));
  const out = []; for (let i = 0; i < n; i++) { const a = Math.floor(i * w.length / n), bnd = Math.max(a + 1, Math.floor((i + 1) * w.length / n)); let mx = 0; for (let j = a; j < bnd; j++) mx = Math.max(mx, w[j]); out.push(mx / 31); }
  return out;
}

/* --- кружки --- */
function circleBubble(m) {
  const p = m.p;
  const box = document.createElement('div'); box.className = 'circle-box';
  box.innerHTML = `<div class="round">${p.thumb ? `<img src="${p.thumb}" alt="">` : ''}</div><svg class="cring" viewBox="0 0 228 228"><circle cx="114" cy="114" r="111" stroke-dasharray="697.4" stroke-dashoffset="697.4"/></svg><div class="snd"><div class="play">${I.play}</div></div>${metaHtml(m)}`;
  const round = box.querySelector('.round'), ring = box.querySelector('.cring circle'), snd = box.querySelector('.snd');
  let video = null;
  box.addEventListener('click', async () => {
    if (video) {
      if (video.paused) { stopOtherCircles(video); video.muted = false; video.play(); snd.innerHTML = ''; }
      else if (video.muted) { video.muted = false; video.currentTime = 0; snd.innerHTML = ''; }
      else { video.pause(); snd.innerHTML = `<div class="play">${I.play}</div>`; }
      return;
    }
    snd.innerHTML = progSvg();
    try {
      const blob = await getMedia(p.file, fr => setProg(snd, fr));
      video = document.createElement('video'); video.playsInline = true; video.setAttribute('playsinline', '');
      video.src = await mediaUrl(p.file.id, blob);
      video.ontimeupdate = () => { ring.style.strokeDashoffset = String(697.4 * (1 - video.currentTime / (p.dur || video.duration || 1))); };
      video.onended = () => { ring.style.strokeDashoffset = '697.4'; snd.innerHTML = `<div class="play">${I.play}</div>`; };
      round.innerHTML = ''; round.appendChild(video);
      stopOtherCircles(video); snd.innerHTML = '';
      await video.play();
    } catch (e) { snd.innerHTML = `<div class="play">${I.play}</div>`; toast('Не удалось загрузить кружок'); video = null; }
  });
  return box;
}
function stopOtherCircles(except) { document.querySelectorAll('.circle-box video').forEach(v => { if (v !== except && !v.paused) v.pause(); }); stopVoicePlayback(); }

/* --- файлы --- */
function fileBubble(m) {
  const p = m.p, f = p.file;
  const b = document.createElement('div'); b.className = 'bubble';
  const ext = (f.name || '').split('.').pop().slice(0, 4).toUpperCase() || 'FILE';
  b.innerHTML = `<div class="file"><div class="fic">${esc(ext)}</div><div><div class="fname">${esc(f.name || 'файл')}</div><div class="fsize">${fmtSize(f.size)} · нажмите, чтобы сохранить</div></div></div>${metaHtml(m)}`;
  const sz = b.querySelector('.fsize');
  b.querySelector('.file').onclick = async () => {
    try {
      const blob = await getMedia(f, fr => { sz.textContent = 'загрузка ' + Math.round(fr * 100) + '%'; });
      sz.textContent = fmtSize(f.size) + ' · сохраняю…';
      await saveBlob(blob, f.name || ('file_' + stamp()), f.mime || 'application/octet-stream');
      sz.textContent = fmtSize(f.size) + ' · сохранено';
    } catch (e) { sz.textContent = fmtSize(f.size) + ' · ошибка, нажмите ещё раз'; }
  };
  return b;
}

/* ---------- меню сообщения ---------- */
function attachLongPress(el, fn) {
  let t = null, sx = 0, sy = 0;
  el.addEventListener('touchstart', e => { sx = e.touches[0].clientX; sy = e.touches[0].clientY; t = setTimeout(() => { t = null; vibrate(25); fn(); }, 480); }, { passive: true });
  el.addEventListener('touchmove', e => { if (t && (Math.abs(e.touches[0].clientX - sx) > 10 || Math.abs(e.touches[0].clientY - sy) > 10)) { clearTimeout(t); t = null; } }, { passive: true });
  el.addEventListener('touchend', () => { if (t) { clearTimeout(t); t = null; } });
  el.addEventListener('contextmenu', e => { e.preventDefault(); fn(); });
}
function sheet(items, hint) {
  const box = $('#sheet-box'); box.innerHTML = hint ? `<div class="hint">${esc(hint)}</div>` : '';
  for (const it of items) {
    const b = document.createElement('button'); if (it.danger) b.className = 'danger';
    b.innerHTML = (I[it.icon] || '') + `<span>${esc(it.label)}</span>`;
    b.onclick = () => { closeSheet(); it.fn(); }; box.appendChild(b);
  }
  $('#sheet').classList.remove('hidden');
}
function closeSheet() { $('#sheet').classList.add('hidden'); }
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') closeSheet(); });

function messageMenu(m) {
  if (m.del || !m.p) return;
  const p = m.p, items = [];
  if (p.t === 'text') items.push({ icon: 'copy', label: 'Копировать', fn: () => copyText(p.text) });
  if (p.caption) items.push({ icon: 'copy', label: 'Копировать подпись', fn: () => copyText(p.caption) });
  if (p.file) items.push({ icon: 'save', label: 'Сохранить на телефон', fn: () => saveMessageMedia(m) });
  items.push({
    icon: 'trash', label: 'Удалить у обоих', danger: true, fn: async () => {
      try {
        await api('/api/messages/' + m.id, { method: 'DELETE' });
        if (p.file) api('/api/files/' + p.file.id, { method: 'DELETE' }).catch(() => { });
        markDeleted(m.id);
      } catch (_) { toast('Не удалось удалить. Нет связи?'); }
    }
  });
  sheet(items);
}
async function saveMessageMedia(m) {
  const p = m.p, f = p.file;
  try {
    toast('Загрузка…', 60000);
    const blob = await getMedia(f, fr => toast('Загрузка ' + Math.round(fr * 100) + '%', 60000));
    await saveBlob(blob, fileNameFor(p), f.mime || blob.type);
  } catch (e) { toast('Ошибка: ' + e.message); }
}
function fileNameFor(p) {
  if (p.file.name) return p.file.name;
  const ext = mimeExt(p.file.mime);
  const base = { image: 'photo', video: 'video', voice: 'voice', circle: 'circle' }[p.t] || 'file';
  return base + '_' + stamp() + ext;
}
function mimeExt(mime) {
  mime = (mime || '').split(';')[0];
  return { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif', 'image/heic': '.heic', 'video/mp4': '.mp4', 'video/webm': '.webm', 'video/quicktime': '.mov', 'audio/webm': '.webm', 'audio/ogg': '.ogg', 'audio/mp4': '.m4a' }[mime] || '';
}

/* ---------- просмотр ---------- */
let viewerMsg = null;
async function openViewer(m, blob) {
  viewerMsg = m;
  const body = $('#v-body'); body.innerHTML = '';
  const url = await mediaUrl(m.p.file.id, blob);
  if (m.p.t === 'image') { const img = document.createElement('img'); img.src = url; body.appendChild(img); }
  else { const v = document.createElement('video'); v.src = url; v.controls = true; v.playsInline = true; v.autoplay = true; body.appendChild(v); }
  $('#v-info').textContent = (m.mine ? 'Вы' : (S.partner || '')) + ' · ' + fmtTime(m.ts);
  $('#viewer').classList.remove('hidden');
}
function closeViewer() { $('#viewer').classList.add('hidden'); const v = $('#v-body video'); if (v) v.pause(); $('#v-body').innerHTML = ''; viewerMsg = null; }
$('#v-close').onclick = closeViewer;
$('#v-save').onclick = () => viewerMsg && saveMessageMedia(viewerMsg);

/* ================= медиа: загрузка и скачивание ================= */
const urlCache = new Map();
async function mediaUrl(id, blob) {
  if (urlCache.has(id)) return urlCache.get(id);
  const u = URL.createObjectURL(blob); urlCache.set(id, u); return u;
}
const inflight = new Map();
function getMedia(f, onProg) {
  if (inflight.has(f.id)) { const x = inflight.get(f.id); if (onProg) x.listeners.push(onProg); return x.promise; }
  const listeners = onProg ? [onProg] : [];
  const promise = (async () => {
    const cached = await DB.getMedia(f.id);
    if (cached) return cached;
    const parts = [];
    for (let i = 0; i < f.chunks; i++) {
      const data = await retry(() => api(`/api/files/${f.id}/${i}`, { raw: true, timeout: 180000 }));
      parts.push(await Crypto.open(S.key, data, f.id + ':' + i));
      listeners.forEach(l => l((i + 1) / f.chunks));
    }
    const blob = new Blob(parts, { type: (f.mime || '').split(';')[0] || 'application/octet-stream' });
    DB.putMedia(f.id, blob);
    return blob;
  })();
  inflight.set(f.id, { promise, listeners });
  promise.finally(() => inflight.delete(f.id));
  return promise;
}
async function uploadBlob(blob, mime, name, onProg) {
  const { id } = await retry(() => api('/api/files', { method: 'POST' }));
  const chunks = Math.max(1, Math.ceil(blob.size / CHUNK));
  for (let i = 0; i < chunks; i++) {
    const part = new Uint8Array(await blob.slice(i * CHUNK, (i + 1) * CHUNK).arrayBuffer());
    const sealed = await Crypto.seal(S.key, part, id + ':' + i);
    await retry(() => api(`/api/files/${id}/${i}`, { method: 'PUT', body: sealed, headers: { 'Content-Type': 'application/octet-stream' }, timeout: 300000 }), 6);
    onProg && onProg((i + 1) / chunks);
  }
  // своё сразу кладём в кэш — не придётся скачивать обратно
  DB.putMedia(id, blob.type ? blob : new Blob([blob], { type: mime }));
  const f = { id, chunks, size: blob.size, mime: mime || blob.type || 'application/octet-stream' };
  if (name) f.name = name;
  return f;
}
async function saveBlob(blob, name, mime) {
  if (Native && Native.saveStart) {
    const h = Native.saveStart(name, (mime || blob.type || 'application/octet-stream').split(';')[0]);
    if (h < 0) throw new Error('нет доступа к памяти');
    const step = 768 * 1024;
    for (let off = 0; off < blob.size; off += step) {
      const part = new Uint8Array(await blob.slice(off, off + step).arrayBuffer());
      if (!Native.saveChunk(h, b64(part))) throw new Error('ошибка записи');
    }
    const res = Native.saveEnd(h);
    toast(res || 'Сохранено');
  } else {
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  }
}

/* ================= отправка ================= */
async function sendPayload(p) {
  p.n = S.name; p.nonce = p.nonce || hex(crypto.getRandomValues(new Uint8Array(8)));
  const ct = b64(await Crypto.seal(S.key, enc.encode(JSON.stringify(p))));
  const res = await retry(() => api('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, ct }) }), 6);
  // показываем сразу, не дожидаясь синхронизации
  const r = { id: res.id, ts: res.ts, dev: S.dev, ct };
  if (await ingest(r) === 'new') onNewMessages([res.id]);
  else if (S.pending.has(p.nonce)) { S.pending.get(p.nonce).el.remove(); S.pending.delete(p.nonce); }
  return res;
}

// черновик на время загрузки
function addPending(kind, label, thumb) {
  const nonce = hex(crypto.getRandomValues(new Uint8Array(8)));
  const el = document.createElement('div'); el.className = 'msg mine pending';
  el.innerHTML = `<div class="bubble media"><div class="pic" style="width:200px;height:${thumb ? 200 : 90}px">${thumb ? `<img class="blur" src="${thumb}">` : ''}<div class="center">${progSvg()}</div></div><span class="meta">${esc(label)}</span></div>`;
  $('#msgs').appendChild(el); scrollBottom(true);
  const p = { el, nonce, prog: f => setProg(el, f), fail: msg => { el.querySelector('.meta').textContent = msg; el.querySelector('.center').innerHTML = `<div class="play">${I.x}</div>`; el.onclick = () => { el.remove(); S.pending.delete(nonce); }; } };
  S.pending.set(nonce, p); return p;
}

// текст
const ta = $('#text');
function updateComposer() {
  const has = ta.value.trim().length > 0;
  $('#btn-send').classList.toggle('hidden', !has);
  $('#btn-voice').classList.toggle('hidden', has);
  $('#btn-circle').classList.toggle('hidden', has);
  ta.style.height = 'auto'; ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
}
ta.addEventListener('input', updateComposer);
ta.addEventListener('focus', () => setTimeout(() => scrollBottom(true), 300));
$('#btn-send').onclick = async () => {
  const text = ta.value.trim(); if (!text) return;
  ta.value = ''; updateComposer(); ta.focus();
  const nonce = hex(crypto.getRandomValues(new Uint8Array(8)));
  const el = document.createElement('div'); el.className = 'msg mine pending';
  el.innerHTML = `<div class="bubble">${linkify(text)}<span class="meta">⏳</span></div>`;
  $('#msgs').appendChild(el); scrollBottom(true);
  S.pending.set(nonce, { el, nonce });
  try { await sendPayload({ t: 'text', text, nonce }); }
  catch (_) {
    el.querySelector('.meta').textContent = '⚠️ не отправлено — нажмите';
    el.onclick = () => { el.remove(); S.pending.delete(nonce); ta.value = text; updateComposer(); };
  }
};

// вложения
$('#attach').onclick = () => sheet([
  { icon: 'image', label: 'Фото и видео', fn: () => { S.pickOrig = false; $('#pick-media').click(); } },
  { icon: 'file', label: 'Фото и видео без сжатия', fn: () => { S.pickOrig = true; $('#pick-media').click(); } },
  { icon: 'file', label: 'Любой файл', fn: () => $('#pick-file').click() },
], 'Фото «со сжатием» весят в 5–10 раз меньше. Видео всегда отправляются в исходном качестве.');
$('#pick-media').onchange = e => { const files = [...e.target.files]; e.target.value = ''; sendFilesSequential(files, S.pickOrig ? 'orig' : 'media'); };
$('#pick-file').onchange = e => { const files = [...e.target.files]; e.target.value = ''; sendFilesSequential(files, 'file'); };

async function sendFilesSequential(files, mode) {
  for (const f of files) {
    try { await sendOneFile(f, mode); } catch (e) { console.error(e); }
  }
}
async function sendOneFile(file, mode) {
  const isImg = /^image\//.test(file.type) && !/heic|heif/i.test(file.type);
  const isVid = /^video\//.test(file.type);
  let thumb = null, w = 0, h = 0, dur = 0;
  try {
    if (isImg) ({ thumb, w, h } = await imageThumb(file));
    else if (isVid) ({ thumb, w, h, dur } = await videoThumb(file));
  } catch (_) { }
  const pend = addPending('', mode === 'media' && isImg ? 'сжимаю…' : fmtSize(file.size), thumb);
  try {
    let payload;
    if (mode === 'media' && isImg) {
      const small = await compressImage(file);
      pend.el.querySelector('.meta').textContent = fmtSize(small.blob.size);
      const f = await uploadBlob(small.blob, 'image/jpeg', null, pend.prog);
      payload = { t: 'image', file: f, w: small.w, h: small.h, thumb };
    } else if ((mode === 'media' || mode === 'orig') && (isImg || isVid)) {
      const f = await uploadBlob(file, file.type, file.name, pend.prog);
      payload = { t: isImg ? 'image' : 'video', file: f, w, h, thumb, dur, orig: mode === 'orig' || undefined };
    } else {
      const f = await uploadBlob(file, file.type || 'application/octet-stream', file.name || ('file_' + stamp()), pend.prog);
      payload = { t: 'file', file: f };
    }
    payload.nonce = pend.nonce;
    await sendPayload(payload);
  } catch (e) {
    pend.fail('⚠️ ошибка отправки — нажмите, чтобы убрать');
    throw e;
  }
}
async function loadImage(file) {
  if (window.createImageBitmap) { try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (_) { } }
  return new Promise((res, rej) => { const img = new Image(); img.onload = () => res(img); img.onerror = rej; img.src = URL.createObjectURL(file); });
}
function drawScaled(src, sw, sh, max, type, q) {
  const k = Math.min(1, max / Math.max(sw, sh));
  const c = document.createElement('canvas'); c.width = Math.round(sw * k); c.height = Math.round(sh * k);
  c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
  return { c, w: c.width, h: c.height };
}
const toBlob = (c, type, q) => new Promise(r => c.toBlob(r, type, q));
async function imageThumb(file) {
  const img = await loadImage(file);
  const w = img.width, h = img.height;
  const { c } = drawScaled(img, w, h, 40);
  return { thumb: c.toDataURL('image/jpeg', 0.5), w, h };
}
async function compressImage(file) {
  const img = await loadImage(file);
  const { c, w, h } = drawScaled(img, img.width, img.height, 2048);
  const blob = await toBlob(c, 'image/jpeg', 0.85);
  return { blob, w, h };
}
function videoThumb(file) {
  return new Promise((res, rej) => {
    const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'metadata';
    const url = URL.createObjectURL(file); v.src = url;
    const done = x => { URL.revokeObjectURL(url); res(x); };
    const to = setTimeout(() => done({ thumb: null, w: 0, h: 0, dur: 0 }), 8000);
    v.onloadedmetadata = () => { v.currentTime = Math.min(0.5, (v.duration || 1) / 3); };
    v.onseeked = () => {
      clearTimeout(to);
      const { c } = drawScaled(v, v.videoWidth, v.videoHeight, 160);
      done({ thumb: c.toDataURL('image/jpeg', 0.6), w: v.videoWidth, h: v.videoHeight, dur: v.duration });
    };
    v.onerror = () => { clearTimeout(to); done({ thumb: null, w: 0, h: 0, dur: 0 }); };
  });
}

/* ---------- голосовые: запись ---------- */
function pickMime(list) { for (const m of list) { try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (_) { } } return ''; }
const R = { rec: null, stream: null, chunks: [], start: 0, timer: null, levels: [], ctx: null, cancelled: false };
$('#btn-voice').onclick = startVoice;
async function startVoice() {
  if (R.rec) return;
  try {
    R.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  } catch (_) { toast('Нет доступа к микрофону. Разрешите его в настройках телефона.'); return; }
  stopVoicePlayback();
  const mime = pickMime(['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm']);
  R.rec = new MediaRecorder(R.stream, mime ? { mimeType: mime, audioBitsPerSecond: 48000 } : undefined);
  R.chunks = []; R.levels = []; R.cancelled = false;
  R.rec.ondataavailable = e => { if (e.data.size) R.chunks.push(e.data); };
  R.rec.onstop = finishVoice;
  // уровень громкости для «волны»
  try {
    R.ctx = new (window.AudioContext || window.webkitAudioContext)();
    const an = R.ctx.createAnalyser(); an.fftSize = 512;
    R.ctx.createMediaStreamSource(R.stream).connect(an);
    const buf = new Uint8Array(an.fftSize);
    R.sample = () => { an.getByteTimeDomainData(buf); let mx = 0; for (const x of buf) mx = Math.max(mx, Math.abs(x - 128)); return Math.min(31, Math.round(mx / 128 * 31 * 1.6)); };
  } catch (_) { R.sample = () => 8; }
  R.rec.start(1000); R.start = Date.now();
  $('#composer').classList.add('hidden'); $('#recbar').classList.remove('hidden');
  const wave = $('#rec-wave'); wave.innerHTML = '';
  vibrate(30);
  R.timer = setInterval(() => {
    const t = (Date.now() - R.start) / 1000;
    $('#rec-time').textContent = fmtDur(t);
    const lv = R.sample(); R.levels.push(lv);
    const i = document.createElement('i'); i.style.height = (3 + lv) + 'px'; wave.appendChild(i);
    if (wave.children.length > 80) wave.firstChild.remove();
    if (t > 600) stopVoice(false); // 10 минут максимум
  }, 100);
}
function stopVoice(cancel) {
  if (!R.rec) return;
  R.cancelled = cancel;
  clearInterval(R.timer);
  try { R.rec.stop(); } catch (_) { }
  R.stream.getTracks().forEach(t => t.stop());
  try { R.ctx && R.ctx.close(); } catch (_) { }
  $('#recbar').classList.add('hidden'); $('#composer').classList.remove('hidden');
}
$('#rec-cancel').onclick = () => stopVoice(true);
$('#rec-send').onclick = () => stopVoice(false);
async function finishVoice() {
  const rec = R.rec; R.rec = null;
  const dur = (Date.now() - R.start) / 1000;
  if (R.cancelled || dur < 0.7) { if (!R.cancelled) toast('Слишком коротко'); return; }
  const mime = (rec.mimeType || 'audio/webm').split(';')[0];
  const blob = new Blob(R.chunks, { type: mime });
  // волна: 64 значения
  const lv = R.levels, wave = [];
  for (let i = 0; i < 64; i++) { const a = Math.floor(i * lv.length / 64), b = Math.max(a + 1, Math.floor((i + 1) * lv.length / 64)); let mx = 0; for (let j = a; j < b && j < lv.length; j++) mx = Math.max(mx, lv[j]); wave.push(mx); }
  const pend = addPending('', 'голосовое ' + fmtDur(dur));
  try {
    const f = await uploadBlob(blob, mime, null, pend.prog);
    await sendPayload({ t: 'voice', file: f, dur: Math.round(dur * 10) / 10, wave, nonce: pend.nonce });
  } catch (_) { pend.fail('⚠️ ошибка отправки — нажмите, чтобы убрать'); }
}

/* ---------- кружки: запись ---------- */
const CR = { stream: null, rec: null, canvas: null, raf: 0, start: 0, facing: 'user', chunks: [], thumb: null, cancelled: false, video: null, audio: null };
$('#btn-circle').onclick = startCircle;
async function openCamera(facing) {
  const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 720 }, height: { ideal: 720 }, frameRate: { ideal: 30 } }, audio: false });
  if (CR.camStream) CR.camStream.getTracks().forEach(t => t.stop());
  CR.camStream = s;
  const v = $('#circle-preview'); v.srcObject = s; v.classList.toggle('back', facing !== 'user');
  await v.play().catch(() => { });
}
async function startCircle() {
  if (CR.rec) return;
  try {
    CR.facing = 'user';
    await openCamera(CR.facing);
    CR.audio = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  } catch (_) { stopCircleStreams(); toast('Нет доступа к камере или микрофону. Разрешите их в настройках телефона.'); return; }
  stopVoicePlayback();
  $('#circle-rec').classList.remove('hidden');
  // рисуем квадрат с камеры на холст — так кружок всегда ровный, а камеру можно переключать на ходу
  const SIZE = 480;
  const c = document.createElement('canvas'); c.width = SIZE; c.height = SIZE; CR.canvas = c;
  const g = c.getContext('2d'); const v = $('#circle-preview');
  const draw = () => {
    if (v.videoWidth) {
      const s = Math.min(v.videoWidth, v.videoHeight), sx = (v.videoWidth - s) / 2, sy = (v.videoHeight - s) / 2;
      g.save();
      if (CR.facing === 'user') { g.translate(SIZE, 0); g.scale(-1, 1); }
      g.drawImage(v, sx, sy, s, s, 0, 0, SIZE, SIZE);
      g.restore();
      if (!CR.thumb && Date.now() - CR.start > 300) { const t = document.createElement('canvas'); t.width = t.height = 96; t.getContext('2d').drawImage(c, 0, 0, 96, 96); CR.thumb = t.toDataURL('image/jpeg', 0.6); }
    }
    const el = (Date.now() - CR.start) / 1000;
    $('#circle-time').textContent = fmtDur(el);
    $('#ring-c').style.strokeDashoffset = String(301.6 * (1 - el / 60));
    if (el >= 60) { finishCircle(false); return; }
    CR.raf = requestAnimationFrame(draw);
  };
  const out = c.captureStream(30);
  CR.audio.getAudioTracks().forEach(t => out.addTrack(t));
  const mime = pickMime(['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4']);
  CR.rec = new MediaRecorder(out, mime ? { mimeType: mime, videoBitsPerSecond: 1200000, audioBitsPerSecond: 64000 } : undefined);
  CR.chunks = []; CR.thumb = null; CR.cancelled = false;
  CR.rec.ondataavailable = e => { if (e.data.size) CR.chunks.push(e.data); };
  CR.rec.onstop = afterCircle;
  $('#ring-c').setAttribute('stroke-dasharray', '301.6');
  CR.start = Date.now(); CR.rec.start(1000); draw(); vibrate(30);
}
$('#circle-flip').onclick = async () => {
  if (!CR.rec) return;
  CR.facing = CR.facing === 'user' ? 'environment' : 'user';
  try { await openCamera(CR.facing); } catch (_) { toast('Не удалось переключить камеру'); }
};
$('#circle-cancel').onclick = () => finishCircle(true);
$('#circle-send').onclick = () => finishCircle(false);
function stopCircleStreams() {
  if (CR.camStream) CR.camStream.getTracks().forEach(t => t.stop());
  if (CR.audio) CR.audio.getTracks().forEach(t => t.stop());
  CR.camStream = CR.audio = null;
  $('#circle-preview').srcObject = null;
}
function finishCircle(cancel) {
  if (!CR.rec) return;
  CR.cancelled = cancel; CR.dur = (Date.now() - CR.start) / 1000;
  cancelAnimationFrame(CR.raf);
  try { CR.rec.stop(); } catch (_) { }
  stopCircleStreams();
  $('#circle-rec').classList.add('hidden');
}
async function afterCircle() {
  const rec = CR.rec; CR.rec = null;
  if (CR.cancelled) return;
  if (CR.dur < 1) { toast('Слишком коротко'); return; }
  const mime = (rec.mimeType || 'video/webm').split(';')[0];
  const blob = new Blob(CR.chunks, { type: mime });
  const pend = addPending('', 'кружок ' + fmtDur(CR.dur), CR.thumb);
  try {
    const f = await uploadBlob(blob, mime, null, pend.prog);
    await sendPayload({ t: 'circle', file: f, dur: Math.round(CR.dur * 10) / 10, thumb: CR.thumb, nonce: pend.nonce });
  } catch (_) { pend.fail('⚠️ ошибка отправки — нажмите, чтобы убрать'); }
}

/* ================= настройки ================= */
$('#open-settings').onclick = () => {
  $('#s-name').value = S.name;
  $('#s-info').textContent = `Версия ${VERSION} · сервер ${S.url.replace(/^https?:\/\//, '')} · шифрование AES-256-GCM`;
  $('#s-battery').classList.toggle('hidden', !Native);
  show('settings');
};
$('#set-back').onclick = () => { show('chat'); scrollBottom(true); };
$('#s-save-name').onclick = () => {
  const n = $('#s-name').value.trim(); if (!n) return;
  S.name = n; const st = Store.get(); st.name = n; Store.set(st); toast('Имя сохранено');
};
$('#s-battery').onclick = () => { Native && Native.requestBackground && Native.requestBackground(); };
$('#s-invite').onclick = () => { $('#inv-code').textContent = inviteCode(); $('#inv-done').onclick = () => show('settings'); $('#inv-done').textContent = 'Назад'; show('invite'); };
$('#s-pin').onclick = () => showLock('old');
$('#s-cache').onclick = async () => { await DB.clearMedia(); urlCache.forEach(u => URL.revokeObjectURL(u)); urlCache.clear(); toast('Кэш очищен'); };
$('#s-logout').onclick = () => sheet([{
  icon: 'trash', label: 'Да, отключить этот телефон', danger: true, fn: async () => {
    S.syncGen++; Store.clear();
    try { indexedDB.deleteDatabase('nashchat'); } catch (_) { }
    if (Native && Native.reset) Native.reset();
    location.reload();
  }
}], 'Переписка останется на сервере. Чтобы вернуться, понадобится код приглашения.');

/* ================= кнопка «Назад» Android ================= */
window.nativeBack = function () {
  if (!$('#circle-rec').classList.contains('hidden')) { finishCircle(true); return true; }
  if (R.rec) { stopVoice(true); return true; }
  if (!$('#viewer').classList.contains('hidden')) { closeViewer(); return true; }
  if (!$('#sheet').classList.contains('hidden')) { closeSheet(); return true; }
  if (!$('#settings').classList.contains('hidden')) { show('chat'); return true; }
  if (!$('#lock').classList.contains('hidden') && pinMode !== 'unlock') { show('settings'); return true; }
  if (!$('#create').classList.contains('hidden') || !$('#join').classList.contains('hidden')) { show('welcome'); return true; }
  return false;
};
// вызывается из Android, когда приложение вернулось на экран
window.nativeResume = function () { if (S.started) { kickSync(); markSeen(); } };

boot();
