'use strict';
/* Наш чат — приложение. Всё шифрование происходит здесь, на телефоне. */

const $ = (s, el = document) => el.querySelector(s);
const Native = window.NativeBridge || null;
const CHUNK = 8 * 1024 * 1024;
const enc = new TextEncoder(), dec = new TextDecoder();
const VERSION = '1.14';

/* ================= иконки ================= */
const I = {
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  clip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.4 11.1-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/></svg>',
  mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4"/></svg>',
  circle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/></svg>',
  send: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.4 20.4 21 12 3.4 3.6 3.4 10l12.6 2-12.6 2z"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
  save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0-5-5m5 5 5-5M4 19h16"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l13-7.5z"/></svg>',
  pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4.5" width="4" height="15" rx="1"/><rect x="14" y="4.5" width="4" height="15" rx="1"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>',
  file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
  flip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 7h-3l-2-3H9L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><path d="M9 13a3 3 0 0 0 5.2 2M15 12a3 3 0 0 0-5.2-2"/></svg>',
  finger: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/><path d="M2 12a10 10 0 0 1 18-6"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M9 6.8a6 6 0 0 1 9 5.2v2"/></svg>',
  link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
  select: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h1M9 4h1M14 4h1M18 4h1M4 9v1M4 14v1M20 9v1M20 14v1M5 20h1M9 20h1M14 20h1M18 20h1"/><path d="M8 10h8M8 14h5"/></svg>',
  edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5 10 17.5 19 7"/></svg>',
  tv: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="m17 2-5 5-5-5"/></svg>',
  expand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>',
  shrink: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>',
  reply: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg>',
  smile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><circle cx="9" cy="9.5" r=".6" fill="currentColor"/><circle cx="15" cy="9.5" r=".6" fill="currentColor"/></svg>',
  keyboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/></svg>',
  gift: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 8.5a5 5 0 0 1 0 7" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
};

/* ================= утилиты ================= */
function b64(buf) {
  const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}
function unb64(s) { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
const b64url = b => b64(b).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64url = s => unb64(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4));
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const pad2 = n => String(n).padStart(2, '0');
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + pad2(s % 60); };
const fmtTime = ts => { const d = new Date(ts); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };
function fmtSize(n) {
  if (n < 1024) return n + ' Б';
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' КБ';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1).replace('.', ',') + ' МБ';
  return (n / 1024 / 1024 / 1024).toFixed(2).replace('.', ',') + ' ГБ';
}
const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
function fmtDay(ts) {
  const d = new Date(ts), now = new Date();
  const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((day(now) - day(d)) / 86400000);
  if (diff === 0) return 'Сегодня';
  if (diff === 1) return 'Вчера';
  return d.getDate() + ' ' + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ' ' + d.getFullYear() : '');
}
function stamp() { const d = new Date(); return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '_' + pad2(d.getHours()) + pad2(d.getMinutes()) + pad2(d.getSeconds()); }
// ссылки, почта и телефоны в тексте
const TLD = 'ru|com|org|net|рф|su|io|me|info|tv|by|kz|ua|uz|am|ge|app|dev|ly|gl|co|cc|to|biz|pro|online|site|store|shop|club|xyz|tech|ai|gg|fm|be|de|fr|uk|us|eu|moscow|рус|онлайн|сайт';
const LINK_RE = new RegExp(
  '(\\b(?:https?:\\/\\/|www\\.)[^\\s<]+[^\\s<.,:;!?)»"\'\\]])' +
  '|([\\wа-яё.+-]+@[\\wа-яё-]+(?:\\.[\\wа-яё-]+)*\\.[a-zа-я]{2,})' +
  '|((?:^|(?<=[\\s(«]))(?:[a-z0-9а-яё-]+\\.)+(?:' + TLD + ')(?![\\wа-яё])(?:[\\/?#][^\\s<]*[^\\s<.,:;!?)»"\'\\]])?)' +
  '|((?:\\+7|(?<![\\d])8)[\\s(-]*\\d{3}[\\s)-]*\\d{3}[\\s-]*\\d{2}[\\s-]*\\d{2}(?!\\d))', 'gi');
function linkHref(m, url, mail, dom, tel) {
  if (url) return /^www\./i.test(url) ? 'https://' + url : url;
  if (mail) return 'mailto:' + mail;
  if (dom) return 'https://' + dom;
  if (tel) return 'tel:' + tel.replace(/[^\d+]/g, '');
  return m;
}
function linkify(text) {
  return esc(text).replace(LINK_RE, (m, url, mail, dom, tel) => {
    const raw = m.replace(/&amp;/g, '&');
    const href = linkHref(raw, url && raw, mail && raw, dom && raw, tel && raw);
    return `<a href="${esc(href)}" data-ext="1">${m}</a>`;
  });
}
function findLinks(text) {
  const out = []; let m; LINK_RE.lastIndex = 0;
  while ((m = LINK_RE.exec(text))) out.push({ text: m[0], href: linkHref(m[0], m[1], m[2], m[3], m[4]) });
  LINK_RE.lastIndex = 0;
  return out;
}
function openLink(href, direct) {
  const v = !direct && typeof parseVK === 'function' && parseVK(href);
  if (v && S.started) {
    sheet([
      { icon: 'tv', label: 'Смотреть вместе', fn: () => Watch.start(v) },
      { icon: 'link', label: 'Открыть в VK', fn: () => openLink(href, true) },
    ], 'Это видео VK — его можно посмотреть вдвоём, синхронно.');
    return;
  }
  if (Native && Native.openUrl) Native.openUrl(href); else window.open(href, '_blank');
}
let toastT;
function toast(msg, ms = 2500) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.add('hidden'), ms);
}
function vibrate(ms = 20) { try { navigator.vibrate && navigator.vibrate(ms); } catch (_) { } }

/* ================= шифрование ================= */
const Crypto = {
  async derive(raw) {
    const base = await crypto.subtle.importKey('raw', raw, 'HKDF', false, ['deriveKey', 'deriveBits']);
    const salt = enc.encode('nash-chat-v1');
    const key = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt, info: enc.encode('enc') }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
    const tok = await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info: enc.encode('auth') }, base, 256);
    return { key, token: hex(tok) };
  },
  async seal(key, data, aad) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const p = { name: 'AES-GCM', iv }; if (aad) p.additionalData = enc.encode(aad);
    const ct = new Uint8Array(await crypto.subtle.encrypt(p, key, data));
    const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12); return out;
  },
  async open(key, data, aad) {
    data = data instanceof Uint8Array ? data : new Uint8Array(data);
    const p = { name: 'AES-GCM', iv: data.subarray(0, 12) }; if (aad) p.additionalData = enc.encode(aad);
    return new Uint8Array(await crypto.subtle.decrypt(p, key, data.subarray(12)));
  },
  async pinKey(pin, salt) {
    const base = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 250000 }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  },
};

/* ================= хранилище ================= */
const Store = {
  get() { try { return JSON.parse(localStorage.getItem('nc') || 'null'); } catch (_) { return null; } },
  set(v) { localStorage.setItem('nc', JSON.stringify(v)); },
  clear() { localStorage.removeItem('nc'); },
};
const DB = {
  db: null,
  open() {
    return new Promise(res => {
      try {
        const r = indexedDB.open('nashchat', 1);
        r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('msgs', { keyPath: 'id' }); d.createObjectStore('media'); };
        r.onsuccess = () => { this.db = r.result; res(); };
        r.onerror = () => res();
      } catch (_) { res(); }
    });
  },
  run(store, mode, fn) {
    return new Promise((res, rej) => {
      if (!this.db) return res(undefined);
      try {
        const t = this.db.transaction(store, mode); const s = t.objectStore(store);
        let out; const rq = fn(s); if (rq) rq.onsuccess = () => { out = rq.result; };
        t.oncomplete = () => res(out); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
      } catch (e) { rej(e); }
    });
  },
  putMsgs(list) { return this.run('msgs', 'readwrite', s => { for (const m of list) s.put(m); }).catch(() => { }); },
  delMsg(id) { return this.run('msgs', 'readwrite', s => s.delete(id)).catch(() => { }); },
  lastMsgs(n) {
    return new Promise(res => {
      if (!this.db) return res([]);
      const out = [];
      try {
        const t = this.db.transaction('msgs', 'readonly');
        const c = t.objectStore('msgs').openCursor(null, 'prev');
        c.onsuccess = () => { const cur = c.result; if (cur && out.length < n) { out.push(cur.value); cur.continue(); } else res(out.reverse()); };
        c.onerror = () => res([]);
      } catch (_) { res([]); }
    });
  },
  msgsBefore(id, n) {
    return new Promise(res => {
      if (!this.db) return res([]);
      const out = [];
      try {
        const t = this.db.transaction('msgs', 'readonly');
        const c = t.objectStore('msgs').openCursor(IDBKeyRange.upperBound(id, true), 'prev');
        c.onsuccess = () => { const cur = c.result; if (cur && out.length < n) { out.push(cur.value); cur.continue(); } else res(out.reverse()); };
        c.onerror = () => res([]);
      } catch (_) { res([]); }
    });
  },
  getMedia(id) { return this.run('media', 'readonly', s => s.get(id)).catch(() => undefined); },
  putMedia(id, blob) { return this.run('media', 'readwrite', s => s.put(blob, id)).catch(() => { }); },
  delMedia(id) { return this.run('media', 'readwrite', s => s.delete(id)).catch(() => { }); },
  clearMedia() { return this.run('media', 'readwrite', s => s.clear()).catch(() => { }); },
};

/* ================= состояние ================= */
const S = {
  url: '', name: '', dev: '', key: null, token: '', raw: null,
  msgs: new Map(),        // id -> {id, ts, dev, mine, p, del}
  order: [],              // id по возрастанию
  last: 0, v: 0,
  oldestLoaded: Infinity, noMoreOlder: false,
  pending: new Map(),     // nonce -> {el, ...}
  online: false, syncing: false, syncGen: 0,
  locked: false, hiddenAt: 0,
};

/* ================= сеть ================= */
async function api(path, opt = {}) {
  const headers = Object.assign({ Authorization: 'Bearer ' + S.token }, opt.headers || {});
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), opt.timeout || 60000);
  try {
    const r = await fetch(S.url + path, { method: opt.method || 'GET', headers, body: opt.body, signal: ctl.signal });
    if (!r.ok) { const e = new Error('HTTP ' + r.status); e.status = r.status; throw e; }
    return opt.raw ? new Uint8Array(await r.arrayBuffer()) : r.json();
  } finally { clearTimeout(timer); }
}
async function retry(fn, tries = 4) {
  let err;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); } catch (e) { err = e; if (e.status && e.status < 500 && e.status !== 429) break; await sleep(1000 * (i + 1)); }
  }
  throw err;
}
function normUrl(u) {
  u = (u || '').trim().replace(/\/+$/, '');
  if (u && !/^https?:\/\//i.test(u)) u = 'https://' + u;
  return u;
}

/* ================= навигация ================= */
const screens = ['welcome', 'create', 'invite', 'join', 'lock', 'chat', 'settings', 'look', 'gifts', 'giftshop', 'cal', 'notes', 'noteed', 'bank'];
function show(id) { for (const s of screens) $('#' + s).classList.toggle('hidden', s !== id); }
document.addEventListener('click', e => {
  const go = e.target.closest('[data-go]'); if (go) show(go.dataset.go);
  const a = e.target.closest('a[data-ext]');
  if (a) { e.preventDefault(); e.stopPropagation(); openLink(a.getAttribute('href')); }
});

/* ================= запуск ================= */
async function boot() {
  for (const [id, ic] of [['open-settings', 'gear'], ['attach', 'clip'], ['btn-send', 'send'], ['wt-big', 'expand'], ['btn-emoji', 'smile'], ['rec-cancel', 'trash'], ['down', 'down'], ['v-close', 'x'], ['v-save', 'save'], ['circle-cancel', 'x'], ['circle-send', 'send'], ['circle-flip', 'flip']]) $('#' + id).innerHTML = I[ic];
  if (!window.crypto || !crypto.subtle) { document.body.innerHTML = '<p style="padding:24px">Шифрование недоступно в этом браузере.</p>'; return; }
  await DB.open();
  await Look.init();
  const st = Store.get();
  if (!st || !st.wrap) { show('welcome'); return; }
  S.url = st.url; S.name = st.name; S.dev = st.dev; S.creator = !!st.creator;
  showLock();
}

/* ---------- создание ---------- */
function checkPin(p1, p2) {
  if (!/^\d{4,8}$/.test(p1)) return 'PIN должен состоять из 4–8 цифр';
  if (p1 !== p2) return 'PIN-коды не совпадают';
  return '';
}
async function saveAll(raw, pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const k = await Crypto.pinKey(pin, salt);
  const wrapped = await Crypto.seal(k, raw);
  Store.set({ url: S.url, name: S.name, dev: S.dev, creator: !!S.creator, wrap: { salt: b64(salt), ct: b64(wrapped) } });
}
function inviteCode() { return 'NC1.' + b64url(S.raw) + '.' + b64url(enc.encode(S.url)); }

$('#c-go').onclick = async () => {
  const err = $('#c-err'); err.textContent = '';
  const url = normUrl($('#c-url').value), name = $('#c-name').value.trim(), pin = $('#c-pin').value;
  if (!/^https:\/\/[^\s/]+/.test(url) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url)) return err.textContent = 'Введите адрес сервера, начиная с https://';
  if (!name) return err.textContent = 'Введите имя';
  const pe = checkPin(pin, $('#c-pin2').value); if (pe) return err.textContent = pe;
  const btn = $('#c-go'); btn.disabled = true; btn.textContent = 'Подключаюсь…';
  try {
    let info;
    try { info = await (await fetch(url + '/api/ping')).json(); } catch (_) { throw new Error('Сервер не отвечает. Проверьте адрес и интернет.'); }
    if (!info || info.app !== 'nash-chat') throw new Error('По этому адресу не найден сервер «Нашего чата».');
    if (info.claimed) throw new Error('На этом сервере чат уже создан. Если это ваш сервер — нажмите «Назад» и подключитесь по коду приглашения.');
    const raw = crypto.getRandomValues(new Uint8Array(32));
    const { key, token } = await Crypto.derive(raw);
    const r = await fetch(url + '/api/claim', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) });
    if (!r.ok) throw new Error('Сервер отказал (' + r.status + ').');
    Object.assign(S, { url, name, dev: hex(crypto.getRandomValues(new Uint8Array(8))), key, token, raw, creator: true });
    await saveAll(raw, pin);
    $('#inv-code').textContent = inviteCode();
    $('#inv-done').onclick = () => startChat();
    show('invite');
  } catch (e) { err.textContent = e.message; }
  finally { btn.disabled = false; btn.textContent = 'Создать'; }
};
$('#inv-copy').onclick = () => copyText($('#inv-code').textContent, 'Код скопирован');

function copyText(t, msg) {
  if (Native && Native.copyText) { Native.copyText(t); toast(msg || 'Скопировано'); return; }
  (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast(msg || 'Скопировано'), () => toast('Не удалось скопировать'));
}

/* ---------- присоединение ---------- */
$('#j-go').onclick = async () => {
  const err = $('#j-err'); err.textContent = '';
  const code = $('#j-code').value.replace(/\s+/g, ''), name = $('#j-name').value.trim(), pin = $('#j-pin').value;
  const m = code.match(/^NC1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/);
  if (!m) return err.textContent = 'Код приглашения неверный. Скопируйте его целиком.';
  if (!name) return err.textContent = 'Введите имя';
  const pe = checkPin(pin, $('#j-pin2').value); if (pe) return err.textContent = pe;
  const btn = $('#j-go'); btn.disabled = true; btn.textContent = 'Подключаюсь…';
  try {
    const raw = unb64url(m[1]); const url = dec.decode(unb64url(m[2]));
    if (raw.length !== 32) throw new Error('Код приглашения повреждён.');
    const { key, token } = await Crypto.derive(raw);
    Object.assign(S, { url, name, dev: hex(crypto.getRandomValues(new Uint8Array(8))), key, token, raw });
    try { await api('/api/messages?last=1&limit=1', { timeout: 15000 }); }
    catch (e) { throw new Error(e.status === 401 ? 'Сервер не принял код. Попросите прислать его ещё раз.' : 'Сервер не отвечает. Проверьте интернет.'); }
    await saveAll(raw, pin);
    startChat();
  } catch (e) { err.textContent = e.message; }
  finally { btn.disabled = false; btn.textContent = 'Подключиться'; }
};

/* ---------- PIN ---------- */
let pinBuf = '', pinMode = 'unlock', pinNew = '';
function buildKeypad() {
  const kp = $('#keypad'); kp.innerHTML = '';
  for (const k of ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫']) {
    const b = document.createElement('button'); b.textContent = k;
    if (!k) {
      if (pinMode === 'unlock' && Bio.enabled()) { b.innerHTML = I.finger; b.className = 'ghost finger'; b.onclick = () => Bio.unlock(); kp.appendChild(b); continue; }
      b.style.visibility = 'hidden';
    }
    if (k === '⌫') b.className = 'ghost';
    b.onclick = () => pinKey(k); kp.appendChild(b);
  }
}
function drawDots() { $('#pin-dots').innerHTML = Array.from({ length: Math.max(4, pinBuf.length) }, (_, i) => `<i class="${i < pinBuf.length ? 'on' : ''}"></i>`).join(''); }
function showLock(mode = 'unlock') {
  pinMode = mode; pinBuf = ''; S.locked = mode === 'unlock';
  $('#lock h2').textContent = mode === 'unlock' ? 'Введите PIN' : mode === 'old' ? 'Текущий PIN' : mode === 'new' ? 'Новый PIN' : 'Повторите новый PIN';
  $('#lock-err').textContent = ''; buildKeypad(); drawDots(); show('lock');
  if (mode === 'unlock' && Bio.enabled()) setTimeout(() => { if (S.locked && !$('#lock').classList.contains('hidden')) Bio.unlock(); }, 350);
}
let pinTimer;
function pinKey(k) {
  if (k === '⌫') pinBuf = pinBuf.slice(0, -1);
  else if (pinBuf.length < 8) pinBuf += k;
  drawDots(); vibrate(8);
  clearTimeout(pinTimer);
  if (pinBuf.length >= 4) pinTimer = setTimeout(tryPin, pinMode === 'new' || pinMode === 'repeat' ? 900 : 350);
}
async function unwrap(pin) {
  const st = Store.get();
  const k = await Crypto.pinKey(pin, unb64(st.wrap.salt));
  return Crypto.open(k, unb64(st.wrap.ct));
}
async function enterWith(raw) {
  if (!S.key) { const d = await Crypto.derive(raw); S.key = d.key; S.token = d.token; S.raw = raw; }
  S.locked = false;
  if (!S.started) startChat(); else show('chat');
}
async function tryPin() {
  const pin = pinBuf;
  if (pinMode === 'new') { pinNew = pin; showLock('repeat'); return; }
  if (pinMode === 'repeat') {
    if (pin !== pinNew) { $('#lock-err').textContent = 'Не совпадает, попробуйте ещё раз'; pinMode = 'new'; pinBuf = ''; drawDots(); $('#lock h2').textContent = 'Новый PIN'; return; }
    await saveAll(S.raw, pin); toast('PIN изменён'); show('settings'); return;
  }
  try {
    const raw = await unwrap(pin);
    if (pinMode === 'old') { showLock('new'); return; }
    await enterWith(raw);
  } catch (_) {
    $('#lock-err').textContent = 'Неверный PIN'; pinBuf = ''; drawDots(); vibrate(120);
  }
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { S.hiddenAt = Date.now(); RxBar.close(); Watch.onHide(); stopVoicePlayback(); if (S.started) Presence.set('away', true); }
  else {
    if (S.started && !S.locked && S.hiddenAt && Date.now() - S.hiddenAt > 120000 && !$('#chat').classList.contains('hidden')) showLock();
    if (S.started) { markSeen(); kickSync(); Presence.set('online'); }
  }
});

/* ================= чат ================= */
async function startChat() {
  try { S.partnerRead = +(localStorage.getItem('nc_pread') || 0); } catch (_) { S.partnerRead = 0; }
  S.started = true; S.locked = false;
  show('chat');
  setTimeout(() => Presence.set('online'), 300);
  if (Native && Native.configure) Native.configure(S.url, S.token, S.dev);
  // сначала — то, что уже есть на телефоне
  const cached = await DB.lastMsgs(80);
  for (const r of cached) await ingest(r, false);
  renderAll(); scrollBottom(true);
  Gifts.renderLayer(); Gifts.updateBadge();
  await Docs.init(); setTimeout(() => Cal.todayCheck(), 1500);
  Profile.drawHeader();
  syncLoop();
}

async function ingest(r, persist = true) {
  if (S.msgs.has(r.id)) {
    const old = S.msgs.get(r.id);
    if (r.del && !old.del) { old.del = true; old.p = null; persist && DB.putMsgs([{ id: r.id, ts: r.ts, dev: r.dev, del: true }]); return 'changed'; }
    return null;
  }
  const m = { id: r.id, ts: r.ts, dev: r.dev, mine: r.dev === S.dev, del: !!r.del, p: null };
  if (!m.del) {
    try { m.p = JSON.parse(dec.decode(await Crypto.open(S.key, unb64(r.ct)))); }
    catch (_) { m.p = { t: 'text', text: '⚠️ Не удалось расшифровать сообщение' }; }
  }
  if (m.p && m.p.t === 'edit') {
    if (m.id > S.last) S.last = m.id;
    if (m.id < S.oldestLoaded) S.oldestLoaded = m.id;
    Edits.apply(m);
    if (persist) DB.putMsgs([r]);
    return 'react';
  }
  if (m.p && m.p.t === 'react') {
    if (m.id > S.last) S.last = m.id;
    if (m.id < S.oldestLoaded) S.oldestLoaded = m.id;
    Reacts.apply(m, persist && S.syncedOnce);
    if (persist) DB.putMsgs([r]);
    return 'react';
  }
  Edits.fix(m);
  S.msgs.set(m.id, m);
  // упорядоченная вставка
  if (!S.order.length || S.order[S.order.length - 1] < m.id) S.order.push(m.id);
  else { let i = S.order.length; while (i > 0 && S.order[i - 1] > m.id) i--; S.order.splice(i, 0, m.id); }
  if (m.id > S.last) S.last = m.id;
  if (m.id < S.oldestLoaded) S.oldestLoaded = m.id;
  if (!m.mine && m.p && m.p.n) setPartner(m.p.n);
  if (m.p && m.p.t === 'gift') Gifts.register(m);
  if (m.mine && m.p && m.p.t === 'text' && m.p.text.includes('💋')) Kiss.register(m.id);
  if (persist) DB.putMsgs([r]);
  return 'new';
}

function setPartner(n) {
  if (S.partner === n) return;
  S.partner = n;
  try { Native && Native.setPartnerName && Native.setPartnerName(n); } catch (_) { }
  if (typeof Profile !== 'undefined') { Profile.drawHeader(); return; }
  $('#partner-name').textContent = n;
  $('#partner-av').textContent = (n.trim()[0] || '♥').toUpperCase();
}
function setNet(on, text) {
  const was = S.online; S.online = on;
  if (on && Presence.partner) { if (!was) Presence.draw(); return; }
  $('#net').textContent = text || (on ? 'защищённое соединение' : 'нет связи с сервером…');
  if (!on) { $('#partner-av').classList.remove('online'); $('#typing').classList.add('hidden'); }
}

let syncWake = null;
function kickSync() { if (syncWake) syncWake(); }
async function syncLoop() {
  const gen = ++S.syncGen;
  let first = true, backoff = 1000;
  while (gen === S.syncGen) {
    try {
      let res;
      if (first) {
        // догоняем всё, что пришло, пока приложение было закрыто
        res = await api(`/api/messages?last=1&limit=100&dev=${S.dev}`, { timeout: 20000 });
        const known = S.last;
        if (known && res.messages.length && res.messages[0].id > known + 1) {
          // была большая пауза — пролистываем недостающее с конца, не перегружая
        }
        let changed = false;
        // удалённые среди известных
        for (const r of res.messages) { if (await ingest(r)) changed = true; }
        // проверяем, не удалены ли сообщения, которые у нас в кэше
        if (changed || !S.order.length) { renderAll(); scrollBottom(true); }
        S.v = res.v; first = false; S.syncedOnce = true; applyReads(res.reads); Presence.handle(res.presence);
        if (S.sig == null) S.sig = 0; // первый опрос заберёт сигналы за последнюю минуту (например, входящий звонок)
        Call.onRing(res.ring || null, res.ringEnd || null);
        if (typeof res.dv === 'number') Docs.check(res.dv, true);
        Gifts.checkNew();
        if (S.order.length && S.order[0] > 1) $('#older').classList.remove('hidden');
      } else {
        res = await api(`/api/messages?after=${S.last}&v=${S.v}&wait=25&limit=200&dev=${S.dev}${S.sig != null ? '&sig=' + S.sig : ''}`, { timeout: 40000 });
        let added = [];
        for (const r of res.messages) { const k = await ingest(r); if (k === 'new') added.push(r.id); }
        for (const id of res.deleted || []) markDeleted(id);
        S.v = res.v; applyReads(res.reads); Presence.handle(res.presence);
        Call.onRing(res.ring || null, res.ringEnd || null);
        if (res.signals && res.signals.length) await Sig.receive(res.signals);
        if (typeof res.dv === 'number') Docs.check(res.dv);
        if (typeof res.sig === 'number' && (S.sig == null || res.sig > S.sig)) S.sig = res.sig;
        if (added.length) { onNewMessages(added); Gifts.checkNew(); }
      }
      setNet(true); backoff = 1000;
      markSeen();
    } catch (e) {
      if (gen !== S.syncGen) return;
      if (e.status === 401) { setNet(false, 'сервер не принимает ключ'); await sleep(30000); continue; }
      setNet(false);
      await new Promise(r => { syncWake = r; setTimeout(r, backoff); });
      syncWake = null; backoff = Math.min(backoff * 2, 30000);
    }
  }
}

function markSeen() { if (Native && Native.setSeen && !document.hidden) Native.setSeen(String(S.last)); markRead(); }

async function loadOlder() {
  const btn = $('#older'); if (btn.dataset.busy) return; btn.dataset.busy = '1'; btn.textContent = 'Загрузка…';
  try {
    const first = S.order[0] || (S.last + 1);
    let list = await DB.msgsBefore(first, 60);
    // если в кэше пробел — берём с сервера
    if (list.length < 60 || list[list.length - 1].id !== first - 1) {
      const res = await api(`/api/messages?before=${first}&limit=100`);
      applyReads(res.reads);
      list = res.messages;
    }
    const box = $('#list'), h = box.scrollHeight;
    for (const r of list) await ingest(r);
    renderAll();
    box.scrollTop = box.scrollHeight - h;
    if (!list.length || list[0].id <= 1) btn.classList.add('hidden');
  } catch (_) { toast('Не удалось загрузить'); }
  finally { delete btn.dataset.busy; btn.textContent = 'Загрузить ранние сообщения'; }
}
$('#older').onclick = loadOlder;
$('#list').addEventListener('scroll', () => {
  const box = $('#list');
  if (box.scrollTop < 60 && !$('#older').classList.contains('hidden')) loadOlder();
  if (nearBottom()) { $('#down').classList.add('hidden'); S.unseenBelow = 0; }
});

/* ---------- отрисовка ---------- */
function nearBottom() { const b = $('#list'); return b.scrollHeight - b.scrollTop - b.clientHeight < 150; }
function scrollBottom(force) { const b = $('#list'); if (force || nearBottom()) requestAnimationFrame(() => { b.scrollTop = b.scrollHeight; }); }
$('#down').onclick = () => { const b = $('#list'); b.scrollTo({ top: b.scrollHeight, behavior: 'smooth' }); };

function dayKey(ts) { const d = new Date(ts); return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate(); }
function renderAll() {
  const box = $('#msgs'); box.innerHTML = '';
  let prevDay = '';
  for (const id of S.order) {
    const m = S.msgs.get(id);
    const dk = dayKey(m.ts);
    if (dk !== prevDay) { box.appendChild(dayEl(m.ts)); prevDay = dk; }
    box.appendChild(msgEl(m));
  }
  for (const p of S.pending.values()) box.appendChild(p.el);
}
function dayEl(ts) { const d = document.createElement('div'); d.className = 'day'; d.textContent = fmtDay(ts); d.dataset.day = dayKey(ts); return d; }
function onNewMessages(ids) {
  const wasNear = nearBottom();
  const box = $('#msgs');
  for (const id of ids) {
    const m = S.msgs.get(id);
    // своё сообщение, которое мы только что отправили, заменяет черновик
    if (m.p && m.p.nonce && S.pending.has(m.p.nonce)) { const p = S.pending.get(m.p.nonce); p.el.remove(); S.pending.delete(m.p.nonce); }
    if (document.querySelector(`.msg[data-id="${id}"]`)) continue;
    const idx = S.order.indexOf(id);
    const prev = idx > 0 ? S.msgs.get(S.order[idx - 1]) : null;
    if (idx !== S.order.length - 1) { renderAll(); continue; }
    if (!prev || dayKey(prev.ts) !== dayKey(m.ts)) insertBeforePending(box, dayEl(m.ts));
    const ne = msgEl(m); ne.classList.add('pop'); insertBeforePending(box, ne);
  }
  const fromPartner = ids.some(id => !S.msgs.get(id).mine);
  if (wasNear) scrollBottom(true);
  else if (fromPartner) {
    S.unseenBelow = (S.unseenBelow || 0) + ids.length;
    const d = $('#down'); d.classList.remove('hidden'); d.innerHTML = I.down + `<b>${S.unseenBelow}</b>`;
  }
  if (fromPartner && !document.hidden) vibrate(15);
  if (fromPartner) {
    Presence.partnerSent();
    const last = S.msgs.get(ids[ids.length - 1]);
    if (last && !last.mine && last.p && last.p.t === 'text') FX.check(last.p.text);
  }
}
function insertBeforePending(box, el) {
  const firstPending = box.querySelector('.msg.pending');
  if (firstPending) box.insertBefore(el, firstPending); else box.appendChild(el);
}
function markDeleted(id) {
  const m = S.msgs.get(id); if (!m) return;
  Gifts.forget(id);
  if (m.p && m.p.file) DB.delMedia(m.p.file.id);
  m.del = true; m.p = null;
  DB.putMsgs([{ id: m.id, ts: m.ts, dev: m.dev, del: true }]);
  const el = document.querySelector(`.msg[data-id="${id}"]`);
  if (el) el.replaceWith(msgEl(m));
}

const TICK1 = '<svg viewBox="0 0 16 11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 5.8 5 9.2 11.6 2"/></svg>';
const TICK2 = '<svg viewBox="0 0 18 11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M1.2 5.8 4.7 9.2 11.3 2"/><path d="M7.4 8.6l.6.6L14.6 2"/></svg>';
const CLOCK = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="8" cy="8" r="6.2"/><path d="M8 4.6V8l2.2 1.4"/></svg>';
function tickHtml(m) { const r = S.partnerRead >= m.id; return `<span class="tick${r ? ' read' : ''}" title="${r ? 'Прочитано' : 'Доставлено'}">${r ? TICK2 : TICK1}</span>`; }
function metaHtml(m) { return `<span class="meta">${m.edited ? '<i class="edited">изменено</i> ' : ''}${fmtTime(m.ts)}${m.mine ? tickHtml(m) : ''}</span>`; }
function applyReads(reads) {
  if (!reads) return;
  let pr = 0;
  for (const [dev, id] of Object.entries(reads)) if (dev !== S.dev && id > pr) pr = id;
  if (pr <= (S.partnerRead || 0)) return;
  S.partnerRead = pr;
  try { localStorage.setItem('nc_pread', String(pr)); } catch (_) { }
  document.querySelectorAll('.msg.mine[data-id]').forEach(el => {
    const t = el.querySelector('.tick'); if (!t || t.classList.contains('read')) return;
    if (+el.dataset.id <= pr) { t.classList.add('read'); t.innerHTML = TICK2; t.title = 'Прочитано'; t.classList.add('pop'); }
  });
}
let readTimer = null;
function markRead() {
  clearTimeout(readTimer);
  readTimer = setTimeout(async () => {
    if (document.hidden || S.locked || $('#chat').classList.contains('hidden')) return;
    // последнее сообщение собеседника, которое уже есть на экране
    let id = 0;
    for (let i = S.order.length - 1; i >= 0; i--) { const m = S.msgs.get(S.order[i]); if (m && !m.mine) { id = m.id; break; } }
    if (!id || id <= (S.readSent || 0)) return;
    S.readSent = id;
    try { const r = await api('/api/read', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, id }), timeout: 15000 }); applyReads(r.reads); }
    catch (_) { S.readSent = 0; }
  }, 400);
}
function msgEl(m) {
  const el = document.createElement('div');
  el.className = 'msg' + (m.mine ? ' mine' : '');
  el.dataset.id = m.id;
  if (m.del || !m.p) { el.classList.add('deleted'); el.innerHTML = `<div class="bubble">Сообщение удалено${metaHtml(m)}</div>`; return el; }
  const p = m.p;
  switch (p.t) {
    case 'text': {
      const j = jumboCount(p.text);
      if (j) { el.classList.add('jumbo'); el.innerHTML = `<div class="jumbo-box n${j}${p.text.includes('💋') ? ' kiss' : ''}"><span>${esc(p.text.trim())}</span>${metaHtml(m)}</div>`; }
      else el.innerHTML = `<div class="bubble">${linkify(p.text)}${metaHtml(m)}</div>`;
      break;
    }
    case 'sticker': el.classList.add('sticker'); el.innerHTML = `<div class="sticker-box"><img src="stickers/${esc(p.s)}.webp" alt="стикер" loading="lazy">${metaHtml(m)}</div>`; break;
    case 'image': case 'video': el.appendChild(mediaBubble(m)); break;
    case 'voice': el.appendChild(voiceBubble(m)); break;
    case 'circle': el.appendChild(circleBubble(m)); break;
    case 'gift': el.classList.add('gift'); el.appendChild(Gifts.bubble(m)); break;
    case 'watch': el.classList.add('gift'); el.appendChild(Watch.bubble(m)); break;
    case 'call': el.appendChild(callBubble(m)); break;
    default: el.appendChild(fileBubble(m));
  }
  if (p.re) {
    const q = Reply.quoteHtml(p.re), bub = el.querySelector('.bubble');
    if (bub) bub.insertAdjacentHTML('afterbegin', q); else { el.insertAdjacentHTML('afterbegin', q); el.firstElementChild.classList.add('solo'); }
  }
  const rx = Reacts.html(m.id); if (rx) el.insertAdjacentHTML('beforeend', rx);
  attachLongPress(el, () => messageMenu(m));
  return el;
}

/* --- фото и видео --- */
function boxSize(p) {
  const maxW = Math.min(280, window.innerWidth * 0.72), maxH = 340;
  let w = p.w || 300, h = p.h || 300;
  const k = Math.min(maxW / w, maxH / h, 10); w = Math.round(w * k); h = Math.round(h * k);
  return { w: Math.max(w, 120), h: Math.max(h, 90) };
}
function progSvg() { return `<svg class="prog" viewBox="0 0 56 56"><circle class="bg" cx="28" cy="28" r="24"/><circle class="fg" cx="28" cy="28" r="24" stroke-dasharray="150.8" stroke-dashoffset="150.8"/></svg>`; }
function setProg(el, f) { const c = el && el.querySelector('.prog .fg'); if (c) c.style.strokeDashoffset = String(150.8 * (1 - Math.max(0.02, Math.min(1, f)))); }

function mediaBubble(m) {
  const p = m.p, f = p.file;
  const b = document.createElement('div'); b.className = 'bubble media';
  const { w, h } = boxSize(p);
  const pic = document.createElement('div'); pic.className = 'pic'; pic.style.width = w + 'px'; pic.style.height = h + 'px';
  pic.innerHTML = (p.thumb ? `<img class="blur" src="${p.thumb}" alt="">` : '') +
    (p.orig ? `<span class="badge">Оригинал · ${fmtSize(f.size)}</span>` : p.t === 'video' ? `<span class="badge">${fmtDur(p.dur)} · ${fmtSize(f.size)}</span>` : '') +
    `<div class="center">${p.t === 'video' ? `<div class="play">${I.play}</div>` : ''}</div>`;
  b.appendChild(pic);
  if (p.caption) { const c = document.createElement('div'); c.className = 'caption'; c.innerHTML = linkify(p.caption); b.appendChild(c); }
  b.insertAdjacentHTML('beforeend', metaHtml(m));

  const showFull = async (auto) => {
    const center = pic.querySelector('.center');
    try {
      const blob = await getMedia(f, fr => { if (!center.querySelector('.prog')) center.innerHTML = progSvg(); setProg(center, fr); });
      if (p.t === 'image') {
        const img = document.createElement('img'); img.alt = ''; img.src = await mediaUrl(f.id, blob);
        img.onload = () => { const old = pic.querySelector('img.blur'); if (old) old.remove(); };
        pic.insertBefore(img, pic.firstChild); center.innerHTML = '';
      } else {
        center.innerHTML = `<div class="play">${I.play}</div>`;
        if (!auto) openViewer(m, blob);
      }
      pic.dataset.ready = '1';
    } catch (e) { center.innerHTML = `<div class="play">${I.save}</div>`; if (!auto) toast('Не удалось загрузить: ' + e.message); }
  };
  pic.addEventListener('click', async () => {
    if (pic.dataset.loading) return;
    if (pic.dataset.ready) { const blob = await getMedia(f); return openViewer(m, blob); }
    pic.dataset.loading = '1'; await showFull(false); delete pic.dataset.loading;
  });
  // маленькие сжатые фото загружаем сразу
  if (p.t === 'image' && (!p.orig || f.size < 4e6)) { pic.dataset.loading = '1'; showFull(true).then(() => { delete pic.dataset.loading; }); }
  else if (!p.thumb || p.t === 'image') pic.querySelector('.center').innerHTML = `<div class="play">${I.save}</div>`;
  if (p.t === 'image' && p.orig && f.size >= 4e6) pic.querySelector('.center').innerHTML = `<div class="play">${I.save}</div>`;
  // если уже в кэше — показываем без нажатия
  if (p.t === 'video') DB.getMedia(f.id).then(x => { if (x) pic.dataset.ready = '1'; });
  return b;
}

/* --- голосовые --- */
let voiceAudio = null, voiceCur = null;
function stopVoicePlayback() { if (voiceAudio) { voiceAudio.pause(); } }
function voiceBubble(m) {
  const p = m.p;
  const b = document.createElement('div'); b.className = 'bubble';
  const bars = normWave(p.wave, 40);
  b.innerHTML = `<div class="voice"><button class="pbtn">${I.play}</button><div class="wave">${bars.map(v => `<i style="height:${4 + v * 24}px"></i>`).join('')}</div><span class="dur">${fmtDur(p.dur)}</span></div>${metaHtml(m)}`;
  const btn = b.querySelector('.pbtn'), waveEl = b.querySelector('.wave'), durEl = b.querySelector('.dur');
  const paint = fr => { const n = Math.round(fr * bars.length); waveEl.querySelectorAll('i').forEach((x, i) => x.classList.toggle('on', i < n)); };
  const ctl = {
    set(playing) { btn.innerHTML = playing ? I.pause : I.play; },
    tick(t) { paint(Math.min(1, t / (p.dur || 1))); durEl.textContent = fmtDur(t); },
    reset() { paint(0); durEl.textContent = fmtDur(p.dur); this.set(false); },
  };
  btn.onclick = async () => {
    if (voiceCur === ctl && voiceAudio && !voiceAudio.paused) { voiceAudio.pause(); ctl.set(false); return; }
    if (voiceCur === ctl && voiceAudio && voiceAudio.paused && voiceAudio.src) { voiceAudio.play(); ctl.set(true); return; }
    try {
      btn.innerHTML = '…';
      const blob = await getMedia(p.file);
      playVoice(ctl, await mediaUrl(p.file.id, blob), m.id);
    } catch (e) { ctl.set(false); toast('Не удалось загрузить голосовое'); }
  };
  // seek по волне
  waveEl.addEventListener('click', e => {
    if (voiceCur !== ctl || !voiceAudio) return;
    const r = waveEl.getBoundingClientRect(); voiceAudio.currentTime = (e.clientX - r.left) / r.width * (p.dur || 0);
  });
  return b;
}
function playVoice(ctl, url, id) {
  if (voiceCur && voiceCur !== ctl) voiceCur.reset();
  if (!voiceAudio) voiceAudio = new Audio();
  voiceAudio.onended = voiceAudio.onpause = voiceAudio.ontimeupdate = null;
  voiceCur = ctl; voiceAudio.src = url;
  voiceAudio.ontimeupdate = () => ctl.tick(voiceAudio.currentTime);
  voiceAudio.onpause = () => ctl.set(false);
  voiceAudio.onended = () => {
    ctl.reset(); voiceCur = null;
    // следующее голосовое подряд — играем автоматически
    const idx = S.order.indexOf(id), next = S.msgs.get(S.order[idx + 1]);
    if (next && next.p && next.p.t === 'voice') { const el = document.querySelector(`.msg[data-id="${next.id}"] .pbtn`); el && el.click(); }
  };
  voiceAudio.play().then(() => ctl.set(true)).catch(() => ctl.set(false));
}
function normWave(w, n) {
  if (!w || !w.length) return Array.from({ length: n }, (_, i) => 0.25 + 0.2 * Math.abs(Math.sin(i * 1.7)));
  const out = []; for (let i = 0; i < n; i++) { const a = Math.floor(i * w.length / n), bnd = Math.max(a + 1, Math.floor((i + 1) * w.length / n)); let mx = 0; for (let j = a; j < bnd; j++) mx = Math.max(mx, w[j]); out.push(mx / 31); }
  return out;
}

/* --- кружки --- */
function circleBubble(m) {
  const p = m.p;
  const box = document.createElement('div'); box.className = 'circle-box';
  box.innerHTML = `<div class="round">${p.thumb ? `<img src="${p.thumb}" alt="">` : ''}</div><svg class="cring" viewBox="0 0 228 228"><circle class="track" cx="114" cy="114" r="111" stroke-dasharray="697.4" stroke-dashoffset="697.4"/><circle class="knob" cx="114" cy="3" r="7"/></svg><div class="snd"><div class="play">${I.play}</div></div><span class="ctime"></span>${metaHtml(m)}`;
  const round = box.querySelector('.round'), ring = box.querySelector('.cring .track'), knob = box.querySelector('.cring .knob'), snd = box.querySelector('.snd'), ctime = box.querySelector('.ctime');
  let video = null, seeking = false, wasPlaying = false, justSeeked = false;
  const dur = () => (video && isFinite(video.duration) && video.duration > 0) ? video.duration : (p.dur || 1);
  const paint = () => {
    const f = Math.max(0, Math.min(1, video.currentTime / dur())), a = f * 2 * Math.PI;
    ring.style.strokeDashoffset = String(697.4 * (1 - f));
    knob.setAttribute('cx', (114 + 111 * Math.sin(a)).toFixed(1)); knob.setAttribute('cy', (114 - 111 * Math.cos(a)).toFixed(1));
    ctime.textContent = fmtDur(video.currentTime) + ' / ' + fmtDur(dur());
  };
  const grow = on => {
    if (box.classList.contains('big') === on) return;
    box.classList.toggle('big', on);
    if (on) setTimeout(() => { const r = box.getBoundingClientRect(), L = $('#list').getBoundingClientRect(); if (r.bottom > L.bottom || r.top < L.top) box.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 320);
  };
  const where = e => { const r = box.getBoundingClientRect(); const x = e.clientX - (r.left + r.width / 2), y = e.clientY - (r.top + r.height / 2); return { x, y, d: Math.hypot(x, y) / (r.width / 2) }; };
  const seekTo = e => {
    const { x, y } = where(e); let a = Math.atan2(x, -y); if (a < 0) a += 2 * Math.PI;
    video.currentTime = Math.min(dur() - 0.05, a / (2 * Math.PI) * dur()); paint();
  };
  const onRing = e => video && box.classList.contains('big') && where(e).d > 0.6;
  // не даём долгому нажатию на кольце открыть меню сообщения
  box.addEventListener('touchstart', e => { if (onRing(e.touches[0])) e.stopPropagation(); }, { passive: true });
  box.addEventListener('pointerdown', e => {
    if (!onRing(e)) return;
    e.preventDefault(); e.stopPropagation();
    seeking = true; box.classList.add('seeking');
    try { box.setPointerCapture(e.pointerId); } catch (_) { }
    wasPlaying = !video.paused; video.pause(); seekTo(e); vibrate(8);
  });
  box.addEventListener('pointermove', e => { if (seeking) seekTo(e); });
  const endSeek = () => {
    if (!seeking) return;
    seeking = false; box.classList.remove('seeking');
    justSeeked = true; setTimeout(() => { justSeeked = false; }, 80);
    stopOtherCircles(video); video.play().catch(() => { }); snd.innerHTML = '';
  };
  box.addEventListener('pointerup', endSeek);
  box.addEventListener('pointercancel', endSeek);
  box.addEventListener('click', async () => {
    if (justSeeked || seeking) return;
    if (video) {
      if (video.paused) { stopOtherCircles(video); if (video.ended) video.currentTime = 0; video.play(); snd.innerHTML = ''; grow(true); }
      else { video.pause(); snd.innerHTML = `<div class="play">${I.play}</div>`; }
      return;
    }
    snd.innerHTML = progSvg();
    try {
      const blob = await getMedia(p.file, fr => setProg(snd, fr));
      video = document.createElement('video'); video.playsInline = true; video.setAttribute('playsinline', '');
      video.preload = 'auto';
      video.src = await mediaUrl(p.file.id, blob);
      video.ontimeupdate = () => { if (!seeking) paint(); };
      video.onplay = () => grow(true);
      video.onended = () => { ring.style.strokeDashoffset = '697.4'; snd.innerHTML = `<div class="play">${I.play}</div>`; grow(false); };
      round.innerHTML = ''; round.appendChild(video);
      stopOtherCircles(video); snd.innerHTML = '';
      await waitFrame(video, 3000);
      video.currentTime = 0;
      grow(true);
      await video.play();
    } catch (e) { snd.innerHTML = `<div class="play">${I.play}</div>`; toast('Не удалось загрузить кружок'); video = null; }
  });
  return box;
}
function stopOtherCircles(except) {
  document.querySelectorAll('.circle-box video').forEach(v => {
    if (v === except) return;
    if (!v.paused) v.pause();
    const b = v.closest('.circle-box');
    if (b && b.classList.contains('big')) { b.classList.remove('big'); const s = b.querySelector('.snd'); if (s) s.innerHTML = `<div class="play">${I.play}</div>`; }
  });
  stopVoicePlayback();
}

/* --- файлы --- */
function fileBubble(m) {
  const p = m.p, f = p.file;
  const b = document.createElement('div'); b.className = 'bubble';
  const ext = (f.name || '').split('.').pop().slice(0, 4).toUpperCase() || 'FILE';
  b.innerHTML = `<div class="file"><div class="fic">${esc(ext)}</div><div><div class="fname">${esc(f.name || 'файл')}</div><div class="fsize">${fmtSize(f.size)} · нажмите, чтобы сохранить</div></div></div>${metaHtml(m)}`;
  const sz = b.querySelector('.fsize');
  b.querySelector('.file').onclick = async () => {
    try {
      const blob = await getMedia(f, fr => { sz.textContent = 'загрузка ' + Math.round(fr * 100) + '%'; });
      sz.textContent = fmtSize(f.size) + ' · сохраняю…';
      await saveBlob(blob, f.name || ('file_' + stamp()), f.mime || 'application/octet-stream');
      sz.textContent = fmtSize(f.size) + ' · сохранено';
    } catch (e) { sz.textContent = fmtSize(f.size) + ' · ошибка, нажмите ещё раз'; }
  };
  return b;
}

/* ---------- меню сообщения ---------- */
function nearEdge(x) { return x < 28 || x > window.innerWidth - 28; }
function attachLongPress(el, fn) {
  let t = null, sx = 0, sy = 0;
  el.addEventListener('touchstart', e => {
    sx = e.touches[0].clientX; sy = e.touches[0].clientY;
    if (nearEdge(sx) || e.touches.length > 1) return; // край экрана — это жест «назад»
    t = setTimeout(() => { t = null; vibrate(25); fn(); }, 480);
  }, { passive: true });
  el.addEventListener('touchcancel', () => { if (t) { clearTimeout(t); t = null; } });
  el.addEventListener('touchmove', e => { if (t && (Math.abs(e.touches[0].clientX - sx) > 10 || Math.abs(e.touches[0].clientY - sy) > 10)) { clearTimeout(t); t = null; } }, { passive: true });
  el.addEventListener('touchend', () => { if (t) { clearTimeout(t); t = null; } });
  el.addEventListener('contextmenu', e => { e.preventDefault(); if (e.pointerType === 'touch' || (e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents)) return; if (!nearEdge(e.clientX)) fn(); });
}
function sheet(items, hint) {
  const box = $('#sheet-box'); box.innerHTML = hint ? `<div class="hint">${esc(hint)}</div>` : '';
  for (const it of items) {
    const b = document.createElement('button'); if (it.danger) b.className = 'danger';
    b.innerHTML = (I[it.icon] || '') + `<span>${esc(it.label)}</span>`;
    b.onclick = () => { closeSheet(); it.fn(); }; box.appendChild(b);
  }
  $('#sheet').classList.remove('hidden');
}
function closeSheet() { $('#sheet').classList.add('hidden'); }
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') closeSheet(); });

function messageMenu(m) {
  if (m.del || !m.p) return;
  const p = m.p, items = [];
  if (m.mine && p.t === 'text') items.unshift({ icon: 'edit', label: 'Изменить', fn: () => Edits.start(m) });
  items.unshift({ icon: 'reply', label: 'Ответить', fn: () => Reply.set(m) });
  items.unshift({ icon: 'smile', label: 'Поставить реакцию', fn: () => setTimeout(() => { const el = document.querySelector(`.msg[data-id="${m.id}"]`); if (el) RxBar.open(el, m); }, 50) });
  if (p.t === 'text' && parseVK(p.text)) items.unshift({ icon: 'tv', label: 'Смотреть вместе', fn: () => Watch.start(parseVK(p.text)) });
  if (p.t === 'text') {
    const links = findLinks(p.text);
    for (const l of links.slice(0, 3)) items.push({ icon: 'link', label: 'Открыть ' + (l.text.length > 34 ? l.text.slice(0, 32) + '…' : l.text), fn: () => openLink(l.href) });
    if (links.length === 1) items.push({ icon: 'copy', label: 'Скопировать ссылку', fn: () => copyText(links[0].text.replace(/^(?!https?:|mailto:|tel:)/, ''), 'Ссылка скопирована') });
    items.push({ icon: 'copy', label: 'Копировать всё', fn: () => copyText(p.text) });
    items.push({ icon: 'select', label: 'Выделить текст', fn: () => openSelect(p.text) });
  }
  if (p.caption) items.push({ icon: 'copy', label: 'Копировать подпись', fn: () => copyText(p.caption) });
  if (p.file) items.push({ icon: 'save', label: 'Сохранить на телефон', fn: () => saveMessageMedia(m) });
  items.push({
    icon: 'trash', label: 'Удалить у обоих', danger: true, fn: async () => {
      try {
        await api('/api/messages/' + m.id, { method: 'DELETE' });
        if (p.file) api('/api/files/' + p.file.id, { method: 'DELETE' }).catch(() => { });
        markDeleted(m.id);
      } catch (_) { toast('Не удалось удалить. Нет связи?'); }
    }
  });
  sheet(items);
}
async function saveMessageMedia(m) {
  const p = m.p, f = p.file;
  try {
    toast('Загрузка…', 60000);
    const blob = await getMedia(f, fr => toast('Загрузка ' + Math.round(fr * 100) + '%', 60000));
    await saveBlob(blob, fileNameFor(p), f.mime || blob.type);
  } catch (e) { toast('Ошибка: ' + e.message); }
}
function fileNameFor(p) {
  if (p.file.name) return p.file.name;
  const ext = mimeExt(p.file.mime);
  const base = { image: 'photo', video: 'video', voice: 'voice', circle: 'circle' }[p.t] || 'file';
  return base + '_' + stamp() + ext;
}
function mimeExt(mime) {
  mime = (mime || '').split(';')[0];
  return { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif', 'image/heic': '.heic', 'video/mp4': '.mp4', 'video/webm': '.webm', 'video/quicktime': '.mov', 'audio/webm': '.webm', 'audio/ogg': '.ogg', 'audio/mp4': '.m4a' }[mime] || '';
}

/* ---------- просмотр ---------- */
let viewerMsg = null;
async function openViewer(m, blob) {
  viewerMsg = m;
  const body = $('#v-body'); body.innerHTML = '';
  const url = await mediaUrl(m.p.file.id, blob);
  if (m.p.t === 'image') { const img = document.createElement('img'); img.src = url; body.appendChild(img); }
  else { const v = document.createElement('video'); v.src = url; v.controls = true; v.playsInline = true; v.autoplay = true; body.appendChild(v); }
  $('#v-info').textContent = (m.mine ? 'Вы' : (S.partner || '')) + ' · ' + fmtTime(m.ts);
  $('#viewer').classList.remove('hidden');
}
function closeViewer() { $('#viewer').classList.add('hidden'); const v = $('#v-body video'); if (v) v.pause(); $('#v-body').innerHTML = ''; viewerMsg = null; }
$('#v-close').onclick = closeViewer;
$('#v-save').onclick = () => viewerMsg && saveMessageMedia(viewerMsg);

/* ================= медиа: загрузка и скачивание ================= */
const urlCache = new Map();
async function mediaUrl(id, blob) {
  if (urlCache.has(id)) return urlCache.get(id);
  const u = URL.createObjectURL(blob); urlCache.set(id, u); return u;
}
const inflight = new Map();
function getMedia(f, onProg) {
  if (inflight.has(f.id)) { const x = inflight.get(f.id); if (onProg) x.listeners.push(onProg); return x.promise; }
  const listeners = onProg ? [onProg] : [];
  const promise = (async () => {
    const cached = await DB.getMedia(f.id);
    if (cached) return cached;
    const parts = [];
    for (let i = 0; i < f.chunks; i++) {
      const data = await retry(() => api(`/api/files/${f.id}/${i}`, { raw: true, timeout: 180000 }));
      parts.push(await Crypto.open(S.key, data, f.id + ':' + i));
      listeners.forEach(l => l((i + 1) / f.chunks));
    }
    const blob = new Blob(parts, { type: (f.mime || '').split(';')[0] || 'application/octet-stream' });
    DB.putMedia(f.id, blob);
    return blob;
  })();
  inflight.set(f.id, { promise, listeners });
  promise.finally(() => inflight.delete(f.id));
  return promise;
}
async function uploadBlob(blob, mime, name, onProg) {
  const { id } = await retry(() => api('/api/files', { method: 'POST' }));
  const chunks = Math.max(1, Math.ceil(blob.size / CHUNK));
  for (let i = 0; i < chunks; i++) {
    const part = new Uint8Array(await blob.slice(i * CHUNK, (i + 1) * CHUNK).arrayBuffer());
    const sealed = await Crypto.seal(S.key, part, id + ':' + i);
    await retry(() => api(`/api/files/${id}/${i}`, { method: 'PUT', body: sealed, headers: { 'Content-Type': 'application/octet-stream' }, timeout: 300000 }), 6);
    onProg && onProg((i + 1) / chunks);
  }
  // своё сразу кладём в кэш — не придётся скачивать обратно
  DB.putMedia(id, blob.type ? blob : new Blob([blob], { type: mime }));
  const f = { id, chunks, size: blob.size, mime: mime || blob.type || 'application/octet-stream' };
  if (name) f.name = name;
  return f;
}
async function saveBlob(blob, name, mime) {
  if (Native && Native.saveStart) {
    const h = Native.saveStart(name, (mime || blob.type || 'application/octet-stream').split(';')[0]);
    if (h < 0) throw new Error('нет доступа к памяти');
    const step = 768 * 1024;
    for (let off = 0; off < blob.size; off += step) {
      const part = new Uint8Array(await blob.slice(off, off + step).arrayBuffer());
      if (!Native.saveChunk(h, b64(part))) throw new Error('ошибка записи');
    }
    const res = Native.saveEnd(h);
    toast(res || 'Сохранено');
  } else {
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  }
}

/* ================= отправка ================= */
async function sendPayload(p) {
  if (S.reply && p.t !== 'react' && p.t !== 'edit') { p.re = S.reply; Reply.clear(); }
  p.n = S.name; p.nonce = p.nonce || hex(crypto.getRandomValues(new Uint8Array(8)));
  const ct = b64(await Crypto.seal(S.key, enc.encode(JSON.stringify(p))));
  const res = await retry(() => api('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, ct }) }), 6);
  // показываем сразу, не дожидаясь синхронизации
  const r = { id: res.id, ts: res.ts, dev: S.dev, ct };
  if (await ingest(r) === 'new') onNewMessages([res.id]);
  else if (S.pending.has(p.nonce)) { S.pending.get(p.nonce).el.remove(); S.pending.delete(p.nonce); }
  return res;
}

// черновик на время загрузки
function addPending(kind, label, thumb) {
  const nonce = hex(crypto.getRandomValues(new Uint8Array(8)));
  const el = document.createElement('div'); el.className = 'msg mine pending';
  el.innerHTML = `<div class="bubble media"><div class="pic" style="width:200px;height:${thumb ? 200 : 90}px">${thumb ? `<img class="blur" src="${thumb}">` : ''}<div class="center">${progSvg()}</div></div><span class="meta">${esc(label)} <span class="tick">${CLOCK}</span></span></div>`;
  $('#msgs').appendChild(el); scrollBottom(true);
  const p = { el, nonce, prog: f => setProg(el, f), fail: msg => { el.querySelector('.meta').textContent = msg; el.querySelector('.center').innerHTML = `<div class="play">${I.x}</div>`; el.onclick = () => { el.remove(); S.pending.delete(nonce); }; } };
  S.pending.set(nonce, p); return p;
}

// текст
const ta = $('#text');
function updateComposer() {
  const has = ta.value.trim().length > 0;
  $('#btn-send').classList.toggle('hidden', !has);
  $('#btn-rec').classList.toggle('hidden', has);
  ta.style.height = 'auto'; ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
}
ta.addEventListener('input', () => { updateComposer(); Presence.typing(); });
ta.addEventListener('focus', () => { Panel.close(true); setTimeout(() => scrollBottom(true), 300); });
$('#btn-send').onclick = async () => {
  if (S.editing) { Edits.save(); return; }
  const text = ta.value.trim(); if (!text) return;
  if (text.includes('💋')) S.kissPending = true;
  FX.check(text); Presence.set('online');
  ta.value = ''; updateComposer(); if (!Panel.open_) ta.focus();
  const nonce = hex(crypto.getRandomValues(new Uint8Array(8)));
  const el = document.createElement('div'); el.className = 'msg mine pending';
  el.innerHTML = `<div class="bubble">${linkify(text)}<span class="meta">${fmtTime(Date.now())}<span class="tick">${CLOCK}</span></span></div>`;
  $('#msgs').appendChild(el); scrollBottom(true);
  S.pending.set(nonce, { el, nonce });
  try { await sendPayload({ t: 'text', text, nonce }); }
  catch (_) {
    el.querySelector('.meta').textContent = '⚠️ не отправлено — нажмите';
    el.onclick = () => { el.remove(); S.pending.delete(nonce); ta.value = text; updateComposer(); };
  }
};

// вложения
$('#attach').onclick = () => sheet([
  { icon: 'image', label: 'Фото и видео', fn: () => { S.pickOrig = false; $('#pick-media').click(); } },
  { icon: 'file', label: 'Фото и видео без сжатия', fn: () => { S.pickOrig = true; $('#pick-media').click(); } },
  { icon: 'file', label: 'Любой файл', fn: () => $('#pick-file').click() },
  { icon: 'gift', label: 'Подарок', fn: () => Gifts.openShop() },
], 'Фото «со сжатием» весят в 5–10 раз меньше. Видео всегда отправляются в исходном качестве.');
$('#pick-media').onchange = e => { const files = [...e.target.files]; e.target.value = ''; sendFilesSequential(files, S.pickOrig ? 'orig' : 'media'); };
$('#pick-file').onchange = e => { const files = [...e.target.files]; e.target.value = ''; sendFilesSequential(files, 'file'); };

async function sendFilesSequential(files, mode) {
  for (const f of files) {
    try { await sendOneFile(f, mode); } catch (e) { console.error(e); }
  }
}
async function sendOneFile(file, mode) {
  const isImg = /^image\//.test(file.type) && !/heic|heif/i.test(file.type);
  const isVid = /^video\//.test(file.type);
  let thumb = null, w = 0, h = 0, dur = 0;
  try {
    if (isImg) ({ thumb, w, h } = await imageThumb(file));
    else if (isVid) ({ thumb, w, h, dur } = await videoThumb(file));
  } catch (_) { }
  const pend = addPending('', mode === 'media' && isImg ? 'сжимаю…' : fmtSize(file.size), thumb);
  try {
    let payload;
    if (mode === 'media' && isImg) {
      const small = await compressImage(file);
      pend.el.querySelector('.meta').textContent = fmtSize(small.blob.size);
      const f = await uploadBlob(small.blob, 'image/jpeg', null, pend.prog);
      payload = { t: 'image', file: f, w: small.w, h: small.h, thumb };
    } else if ((mode === 'media' || mode === 'orig') && (isImg || isVid)) {
      const f = await uploadBlob(file, file.type, file.name, pend.prog);
      payload = { t: isImg ? 'image' : 'video', file: f, w, h, thumb, dur, orig: mode === 'orig' || undefined };
    } else {
      const f = await uploadBlob(file, file.type || 'application/octet-stream', file.name || ('file_' + stamp()), pend.prog);
      payload = { t: 'file', file: f };
    }
    payload.nonce = pend.nonce;
    await sendPayload(payload);
  } catch (e) {
    pend.fail('⚠️ ошибка отправки — нажмите, чтобы убрать');
    throw e;
  }
}
async function loadImage(file) {
  if (window.createImageBitmap) { try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (_) { } }
  return new Promise((res, rej) => { const img = new Image(); img.onload = () => res(img); img.onerror = rej; img.src = URL.createObjectURL(file); });
}
function drawScaled(src, sw, sh, max, type, q) {
  const k = Math.min(1, max / Math.max(sw, sh));
  const c = document.createElement('canvas'); c.width = Math.round(sw * k); c.height = Math.round(sh * k);
  c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
  return { c, w: c.width, h: c.height };
}
const toBlob = (c, type, q) => new Promise(r => c.toBlob(r, type, q));
async function imageThumb(file) {
  const img = await loadImage(file);
  const w = img.width, h = img.height;
  const { c } = drawScaled(img, w, h, 40);
  return { thumb: c.toDataURL('image/jpeg', 0.5), w, h };
}
async function compressImage(file) {
  const img = await loadImage(file);
  const { c, w, h } = drawScaled(img, img.width, img.height, 2048);
  const blob = await toBlob(c, 'image/jpeg', 0.85);
  return { blob, w, h };
}
function videoThumb(file) {
  return new Promise((res, rej) => {
    const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'metadata';
    const url = URL.createObjectURL(file); v.src = url;
    const done = x => { URL.revokeObjectURL(url); res(x); };
    const to = setTimeout(() => done({ thumb: null, w: 0, h: 0, dur: 0 }), 8000);
    v.onloadedmetadata = () => { v.currentTime = Math.min(0.5, (v.duration || 1) / 3); };
    v.onseeked = () => {
      clearTimeout(to);
      const { c } = drawScaled(v, v.videoWidth, v.videoHeight, 160);
      done({ thumb: c.toDataURL('image/jpeg', 0.6), w: v.videoWidth, h: v.videoHeight, dur: v.duration });
    };
    v.onerror = () => { clearTimeout(to); done({ thumb: null, w: 0, h: 0, dur: 0 }); };
  });
}

/* ---------- голосовые: запись ---------- */
function pickMime(list) { for (const m of list) { try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (_) { } } return ''; }
const R = { rec: null, stream: null, chunks: [], start: 0, timer: null, levels: [], ctx: null, cancelled: false };
async function startVoice() {
  if (R.rec) return false;
  try {
    R.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  } catch (_) { toast('Нет доступа к микрофону. Разрешите его в настройках телефона.'); return false; }
  stopVoicePlayback();
  const mime = pickMime(['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm']);
  R.rec = new MediaRecorder(R.stream, mime ? { mimeType: mime, audioBitsPerSecond: 48000 } : undefined);
  R.chunks = []; R.levels = []; R.cancelled = false;
  R.rec.ondataavailable = e => { if (e.data.size) R.chunks.push(e.data); };
  R.rec.onstop = finishVoice;
  // уровень громкости для «волны»
  try {
    R.ctx = new (window.AudioContext || window.webkitAudioContext)();
    const an = R.ctx.createAnalyser(); an.fftSize = 512;
    R.ctx.createMediaStreamSource(R.stream).connect(an);
    const buf = new Uint8Array(an.fftSize);
    R.sample = () => { an.getByteTimeDomainData(buf); let mx = 0; for (const x of buf) mx = Math.max(mx, Math.abs(x - 128)); return Math.min(31, Math.round(mx / 128 * 31 * 1.6)); };
  } catch (_) { R.sample = () => 8; }
  R.rec.start(1000); R.start = Date.now(); Presence.set('voice');
  $('#recbar').classList.remove('hidden');
  const wave = $('#rec-wave'); wave.innerHTML = '';
  vibrate(30);
  R.timer = setInterval(() => {
    const t = (Date.now() - R.start) / 1000;
    $('#rec-time').textContent = fmtDur(t);
    const lv = R.sample(); R.levels.push(lv);
    const i = document.createElement('i'); i.style.height = (3 + lv) + 'px'; wave.appendChild(i);
    if (wave.children.length > 80) wave.firstChild.remove();
    if (t > 600) stopVoice(false); // 10 минут максимум
  }, 100);
  return true;
}
function stopVoice(cancel) {
  if (!R.rec) return;
  R.cancelled = cancel;
  clearInterval(R.timer);
  try { R.rec.stop(); } catch (_) { }
  R.stream.getTracks().forEach(t => t.stop());
  try { R.ctx && R.ctx.close(); } catch (_) { }
  $('#recbar').classList.add('hidden');
  recReset();
}
$('#rec-cancel').onclick = () => stopVoice(true);
async function finishVoice() {
  const rec = R.rec; R.rec = null;
  const dur = (Date.now() - R.start) / 1000;
  if (R.cancelled || dur < 0.7) { if (!R.cancelled) toast('Слишком коротко'); return; }
  const mime = (rec.mimeType || 'audio/webm').split(';')[0];
  const blob = new Blob(R.chunks, { type: mime });
  // волна: 64 значения
  const lv = R.levels, wave = [];
  for (let i = 0; i < 64; i++) { const a = Math.floor(i * lv.length / 64), b = Math.max(a + 1, Math.floor((i + 1) * lv.length / 64)); let mx = 0; for (let j = a; j < b && j < lv.length; j++) mx = Math.max(mx, lv[j]); wave.push(mx); }
  const pend = addPending('', 'голосовое ' + fmtDur(dur));
  try {
    const f = await uploadBlob(blob, mime, null, pend.prog);
    await sendPayload({ t: 'voice', file: f, dur: Math.round(dur * 10) / 10, wave, nonce: pend.nonce });
  } catch (_) { pend.fail('⚠️ ошибка отправки — нажмите, чтобы убрать'); }
}

/* ---------- кружки: запись ---------- */
const CR = { stream: null, rec: null, canvas: null, raf: 0, start: 0, facing: 'user', chunks: [], thumb: null, cancelled: false, video: null, audio: null };
function waitFrame(v, ms = 2000) {
  return new Promise(res => {
    if (v.readyState >= 2 && v.videoWidth) return res();
    const done = () => { clearTimeout(t); v.removeEventListener('loadeddata', done); v.removeEventListener('playing', done); res(); };
    const t = setTimeout(done, ms);
    v.addEventListener('loadeddata', done); v.addEventListener('playing', done);
  });
}
async function openCamera(facing) {
  // большинство телефонов не открывают вторую камеру, пока работает первая — сначала закрываем старую
  if (CR.camStream) { CR.camStream.getTracks().forEach(t => t.stop()); CR.camStream = null; }
  const size = { width: { ideal: 720 }, height: { ideal: 720 }, frameRate: { ideal: 30 } };
  let s;
  try { s = await navigator.mediaDevices.getUserMedia({ video: Object.assign({ facingMode: { exact: facing } }, size), audio: false }); }
  catch (_) { s = await navigator.mediaDevices.getUserMedia({ video: Object.assign({ facingMode: facing }, size), audio: false }); }
  CR.camStream = s;
  const v = $('#circle-preview'); v.srcObject = s; v.classList.toggle('back', facing !== 'user');
  await v.play().catch(() => { });
  await waitFrame(v);
}
async function startCircle() {
  if (CR.rec) return false;
  try {
    CR.facing = 'user';
    await openCamera(CR.facing);
    CR.audio = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  } catch (_) { stopCircleStreams(); toast('Нет доступа к камере или микрофону. Разрешите их в настройках телефона.'); return false; }
  stopVoicePlayback();
  $('#circle-rec').classList.remove('hidden');
  // рисуем квадрат с камеры на холст — так кружок всегда ровный, а камеру можно переключать на ходу
  const SIZE = 480;
  const c = document.createElement('canvas'); c.width = SIZE; c.height = SIZE; CR.canvas = c;
  const g = c.getContext('2d'); const v = $('#circle-preview');
  const draw = () => {
    if (v.videoWidth) {
      const s = Math.min(v.videoWidth, v.videoHeight), sx = (v.videoWidth - s) / 2, sy = (v.videoHeight - s) / 2;
      g.save();
      if (CR.facing === 'user') { g.translate(SIZE, 0); g.scale(-1, 1); }
      g.drawImage(v, sx, sy, s, s, 0, 0, SIZE, SIZE);
      g.restore();
      if (!CR.thumb && Date.now() - CR.start > 300) { const t = document.createElement('canvas'); t.width = t.height = 96; t.getContext('2d').drawImage(c, 0, 0, 96, 96); CR.thumb = t.toDataURL('image/jpeg', 0.6); }
    }
    const el = (Date.now() - CR.start) / 1000;
    $('#circle-time').textContent = fmtDur(el);
    $('#ring-c').style.strokeDashoffset = String(301.6 * (1 - el / 60));
    if (el >= 60) { finishCircle(false); return; }
    CR.raf = requestAnimationFrame(draw);
  };
  const out = c.captureStream(30);
  CR.audio.getAudioTracks().forEach(t => out.addTrack(t));
  const mime = pickMime(['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,opus', 'video/mp4', 'video/webm;codecs=vp8,opus', 'video/webm;codecs=vp9,opus', 'video/webm']);
  CR.rec = new MediaRecorder(out, mime ? { mimeType: mime, videoBitsPerSecond: 1200000, audioBitsPerSecond: 64000 } : undefined);
  CR.chunks = []; CR.thumb = null; CR.cancelled = false;
  CR.rec.ondataavailable = e => { if (e.data.size) CR.chunks.push(e.data); };
  CR.rec.onstop = afterCircle;
  $('#ring-c').setAttribute('stroke-dasharray', '301.6');
  CR.start = Date.now(); draw(); CR.rec.start(1000); vibrate(30); Presence.set('circle');
  return true;
}
$('.circle-wrap').addEventListener('click', () => $('#circle-flip').click());
$('#circle-flip').onclick = async () => {
  if (!CR.rec || CR.flipping) return;
  CR.flipping = true;
  const prev = CR.facing;
  CR.facing = prev === 'user' ? 'environment' : 'user';
  try { await openCamera(CR.facing); vibrate(10); }
  catch (_) {
    CR.facing = prev;
    try { await openCamera(prev); } catch (_) { }
    toast('Не удалось переключить камеру');
  }
  CR.flipping = false;
};
$('#circle-cancel').onclick = () => finishCircle(true);
$('#circle-send').onclick = () => finishCircle(false);
function stopCircleStreams() {
  if (CR.camStream) CR.camStream.getTracks().forEach(t => t.stop());
  if (CR.audio) CR.audio.getTracks().forEach(t => t.stop());
  CR.camStream = CR.audio = null;
  $('#circle-preview').srcObject = null;
}
function finishCircle(cancel) {
  if (!CR.rec) return;
  CR.cancelled = cancel; CR.dur = (Date.now() - CR.start) / 1000;
  cancelAnimationFrame(CR.raf);
  try { CR.rec.stop(); } catch (_) { }
  stopCircleStreams();
  $('#circle-rec').classList.add('hidden');
  recReset();
}
async function afterCircle() {
  const rec = CR.rec; CR.rec = null;
  if (CR.cancelled) return;
  if (CR.dur < 1) { toast('Слишком коротко'); return; }
  const mime = (rec.mimeType || 'video/webm').split(';')[0];
  const blob = new Blob(CR.chunks, { type: mime });
  const pend = addPending('', 'кружок ' + fmtDur(CR.dur), CR.thumb);
  try {
    const f = await uploadBlob(blob, mime, null, pend.prog);
    await sendPayload({ t: 'circle', file: f, dur: Math.round(CR.dur * 10) / 10, thumb: CR.thumb, nonce: pend.nonce });
  } catch (_) { pend.fail('⚠️ ошибка отправки — нажмите, чтобы убрать'); }
}

/* ---------- единая кнопка: голосовое / кружок ---------- */
// нажатие — сменить режим; удержание — запись, отпустить — отправить;
// вверх — закрепить запись; влево — отменить
const REC = { state: 'idle', mode: (() => { try { return localStorage.getItem('nc_recmode') || 'voice'; } catch (_) { return 'voice'; } })(), sx: 0, sy: 0, t: null, swallow: false };
const recBtn = $('#btn-rec');
function drawRecBtn() {
  const locked = REC.state === 'locked', holding = REC.state === 'holding' || REC.state === 'starting';
  recBtn.innerHTML = locked ? I.send : (REC.mode === 'voice' ? I.mic : I.circle);
  recBtn.classList.toggle('send', locked);
  recBtn.classList.toggle('recording', holding);
  recBtn.setAttribute('aria-label', REC.mode === 'voice' ? 'Голосовое (удерживайте)' : 'Кружок (удерживайте)');
  const hold = REC.state === 'holding';
  $('#rec-hint').classList.toggle('hidden', !hold || REC.mode !== 'voice');
  $('#rec-cancel').classList.toggle('hidden', hold);
  $('#rec-wave').classList.toggle('hidden', hold);
  $('#circle-hint').classList.toggle('hidden', !hold);
  $('#circle-cancel').classList.toggle('hidden', hold);
  $('#circle-send').classList.toggle('hidden', hold);
  $('#rec-lock').classList.toggle('hidden', !hold);
  if (hold) {
    const r = recBtn.getBoundingClientRect();
    const lk = $('#rec-lock'); lk.style.left = (r.left + r.width / 2) + 'px'; lk.style.top = (r.top - 96) + 'px'; lk.style.transform = 'translateX(-50%)';
  }
}
function recReset() { if (REC.state !== 'idle') { REC.state = 'idle'; drawRecBtn(); } Presence.set('online'); }
function toggleRecMode() {
  REC.mode = REC.mode === 'voice' ? 'circle' : 'voice';
  try { localStorage.setItem('nc_recmode', REC.mode); } catch (_) { }
  drawRecBtn(); vibrate(10);
  recBtn.classList.remove('flip'); void recBtn.offsetWidth; recBtn.classList.add('flip');
  toast(REC.mode === 'voice' ? '🎤 Голосовое — удерживайте, чтобы записать' : '⭕ Кружок — удерживайте, чтобы записать', 1600);
}
async function beginHold() {
  if (REC.state !== 'pending') return;
  REC.state = 'starting'; Panel.close(); drawRecBtn(); vibrate(25);
  const ok = REC.mode === 'voice' ? await startVoice() : await startCircle();
  if (!ok) { REC.state = 'idle'; drawRecBtn(); return; }
  if (REC.state === 'released') { REC.state = 'holding'; stopRec(false); return; }
  if (REC.state === 'aborted') { REC.state = 'holding'; stopRec(true); return; }
  REC.state = 'holding'; drawRecBtn();
}
function stopRec(cancel) { if (REC.mode === 'voice') stopVoice(cancel); else finishCircle(cancel); }
function lockRec() {
  REC.state = 'locked'; REC.justLocked = true; vibrate(30); drawRecBtn();
  toast('🔒 Запись закреплена — нажмите ' + (REC.mode === 'voice' ? '➤, чтобы отправить' : '➤ на экране, чтобы отправить'), 2000);
}
recBtn.addEventListener('pointerdown', e => {
  if (REC.state !== 'idle') return;
  e.preventDefault();
  try { recBtn.setPointerCapture(e.pointerId); } catch (_) { }
  REC.sx = e.clientX; REC.sy = e.clientY; REC.state = 'pending';
  REC.t = setTimeout(beginHold, 260);
});
recBtn.addEventListener('pointermove', e => {
  if (REC.state !== 'holding') return;
  const dx = e.clientX - REC.sx, dy = e.clientY - REC.sy;
  const lk = $('#rec-lock'); lk.style.transform = `translate(-50%, ${Math.min(0, Math.max(-60, dy * .6))}px)`;
  lk.classList.toggle('near', dy < -45);
  if (dy < -90) lockRec();
  else if (dx < -130) { stopRec(true); toast('Запись отменена', 1200); }
});
function endPointer(cancelled) {
  if (REC.state === 'pending') { clearTimeout(REC.t); REC.state = 'idle'; if (!cancelled) { REC.swallow = true; toggleRecMode(); } }
  else if (REC.state === 'starting') REC.state = cancelled ? 'aborted' : 'released';
  else if (REC.state === 'holding') stopRec(cancelled);
  else if (REC.state === 'locked' && REC.justLocked) { REC.justLocked = false; REC.swallow = true; }
  setTimeout(() => { REC.swallow = false; }, 60);
}
recBtn.addEventListener('pointerup', () => endPointer(false));
recBtn.addEventListener('pointercancel', () => endPointer(true));
recBtn.addEventListener('contextmenu', e => e.preventDefault());
recBtn.addEventListener('click', () => {
  if (REC.swallow) { REC.swallow = false; return; }
  if (REC.state === 'locked') stopRec(false);
});
drawRecBtn();

/* ================= настройки ================= */
function drawFxSetting() { $('#s-fx-sw').classList.toggle('on', FX.enabled()); }
$('#s-fx').onclick = () => {
  const on = !FX.enabled();
  try { localStorage.setItem('nc_fx', on ? 'on' : 'off'); } catch (_) { }
  drawFxSetting(); if (on) FX.play('love');
};
$('#open-settings').onclick = () => {
  drawFxSetting();
  Bio.drawSetting();
  $('#s-gifts-sub').textContent = Gifts.summary();
  $('#s-name').value = S.name;
  Profile.drawEditor();
  $('#s-info').textContent = `Версия ${VERSION} · сервер ${S.url.replace(/^https?:\/\//, '')} · шифрование AES-256-GCM`;
  $('#s-battery').classList.toggle('hidden', !Native);
  $('#s-hidebg').classList.toggle('hidden', !(Native && Native.openBgNotifSettings));
  $('#s-fullscreen').classList.toggle('hidden', !(Native && Native.canFullScreen && !Native.canFullScreen()));
  show('settings');
};
$('#set-back').onclick = () => { show('chat'); scrollBottom(true); markRead(); };
$('#s-save-name').onclick = () => {
  const n = $('#s-name').value.trim(); if (!n) { toast('Введите имя'); return; }
  S.name = n; const st = Store.get(); st.name = n; Store.set(st);
  Profile.save(); toast('Профиль сохранён ✨');
};
$('#s-fullscreen').onclick = () => {
  toast('Включите разрешение для «Наш чат» — тогда входящий звонок откроется на весь экран, даже на заблокированном телефоне.', 6000);
  setTimeout(() => Native.openFullScreenSettings(), 1200);
};
$('#s-hidebg').onclick = () => {
  toast('Выключите переключатель «Работа в фоне». «Новые сообщения» не трогайте — уведомления продолжат приходить.', 6000);
  setTimeout(() => Native.openBgNotifSettings(), 1200);
};
$('#s-battery').onclick = () => { Native && Native.requestBackground && Native.requestBackground(); };
$('#s-invite').onclick = () => { $('#inv-code').textContent = inviteCode(); $('#inv-done').onclick = () => show('settings'); $('#inv-done').textContent = 'Назад'; show('invite'); };
$('#s-pin').onclick = () => showLock('old');
$('#s-cache').onclick = async () => { await DB.clearMedia(); urlCache.forEach(u => URL.revokeObjectURL(u)); urlCache.clear(); toast('Кэш очищен'); };
$('#s-logout').onclick = () => sheet([{
  icon: 'trash', label: 'Да, отключить этот телефон', danger: true, fn: async () => {
    S.syncGen++; Store.clear(); Gifts.clear(); Kiss.clear(); Docs.clear();
    try { indexedDB.deleteDatabase('nashchat'); } catch (_) { }
    if (Native && Native.reset) Native.reset();
    location.reload();
  }
}], 'Переписка останется на сервере. Чтобы вернуться, понадобится код приглашения.');

/* ================= оформление ================= */
const ACCENTS = [['#c8553d', 'Терракота'], ['#e0457b', 'Малина'], ['#f27aa6', 'Роза'], ['#b05cd6', 'Сирень'], ['#7a6ff0', 'Лаванда'], ['#4b6fe0', 'Индиго'],
  ['#1f95d1', 'Небо'], ['#12a39a', 'Бирюза'], ['#2fa66b', 'Мята'], ['#e0a019', 'Янтарь'], ['#ef7d3c', 'Мандарин'], ['#5f6b7a', 'Графит']];
const FONTS = [
  { id: 'system', t: 'Обычный', f: 'system-ui, -apple-system, Roboto, sans-serif', w: 400 },
  { id: 'round', t: 'Округлый', f: '"NC Comfortaa", system-ui, sans-serif', w: 500 },
  { id: 'serif', t: 'С засечками', f: '"NC PT Serif", Georgia, serif', w: 400 },
  { id: 'book', t: 'Книжный', f: '"NC Kurale", Georgia, serif', w: 400 },
  { id: 'hand', t: 'Рукописный', f: '"NC Caveat", cursive', w: 500, k: 1.25 },
  { id: 'calli', t: 'Каллиграфия', f: '"NC Marck", cursive', w: 400, k: 1.2 },
  { id: 'script', t: 'Почерк', f: '"NC BadScript", cursive', w: 400, k: 1.05 },
  { id: 'pencil', t: 'Карандаш', f: '"NC Neucha", cursive', w: 400, k: 1.1 },
  { id: 'lobster', t: 'Лобстер', f: '"NC Lobster", cursive', w: 400, k: 1.05 },
  { id: 'pacifico', t: 'Пасифико', f: '"NC Pacifico", cursive', w: 400, k: .95 },
  { id: 'amatic', t: 'Узкий рисованный', f: '"NC Amatic", cursive', w: 400, k: 1.45 },
  { id: 'mono', t: 'Машинка', f: 'ui-monospace, "Courier New", monospace', w: 400, k: .95 },
];
const svgUrl = svg => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
const heartSvg = c => svgUrl(`<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64' viewBox='0 0 64 64'><path d='M16 26c-4-7-13-3-10 4 2 5 10 10 10 10s8-5 10-10c3-7-6-11-10-4z' fill='${c}'/><path d='M48 58c-3-5-10-2-8 3 2 4 8 7 8 7s6-3 8-7c2-5-5-8-8-3z' fill='${c}'/><path d='M50 14c-2-3-6-1-5 2 1 2 5 4 5 4s4-2 5-4c1-3-3-5-5-2z' fill='${c}'/></svg>`);
const stars = (() => {
  const pts = [[12, 18, 1.4], [38, 8, 1], [66, 22, 1.8], [84, 12, 1.1], [24, 46, 1.1], [54, 40, 1.5], [88, 52, 1.2], [8, 72, 1.6], [44, 70, 1], [70, 84, 1.4], [30, 92, 1.2], [92, 88, 1]];
  return pts.map(([x, y, r]) => `radial-gradient(${r}px ${r}px at ${x}% ${y}%, rgba(255,255,255,.9) 50%, transparent 100%) 0 0/240px 240px`).join(', ');
})();
const WALLS = [
  { id: 'classic', t: 'Классика', l: 'var(--wall)', d: 'var(--wall)' },
  { id: 'peach', t: 'Персик', l: 'linear-gradient(160deg,#ffe1d2,#f9c6cf)', d: 'linear-gradient(160deg,#3a2023,#22161c)' },
  { id: 'sky', t: 'Небо', l: 'linear-gradient(170deg,#d6ecff,#e9e1ff)', d: 'linear-gradient(170deg,#121c2e,#1d1733)' },
  { id: 'mint', t: 'Мята', l: 'linear-gradient(160deg,#d9f4e6,#f1f8d6)', d: 'linear-gradient(160deg,#0f241c,#1b2410)' },
  { id: 'lavender', t: 'Лаванда', l: 'linear-gradient(160deg,#ebe2ff,#ffe2f0)', d: 'linear-gradient(160deg,#211735,#2c1528)' },
  { id: 'sunset', t: 'Закат', l: 'linear-gradient(170deg,#ffd3a5 0%,#fd9fa8 55%,#c7a7e8 100%)', d: 'linear-gradient(170deg,#4a2a2a,#3a1d33 55%,#221d40)' },
  { id: 'aurora', t: 'Сияние', l: 'linear-gradient(140deg,#a8edea,#fed6e3)', d: 'linear-gradient(140deg,#0d2b30,#33152a)' },
  { id: 'night', t: 'Звёзды', l: stars + ', linear-gradient(180deg,#141a4a,#3a2160)', d: stars + ', linear-gradient(180deg,#0b1030,#251845)' },
  { id: 'hearts', t: 'Сердечки', l: heartSvg('rgba(224,69,123,.16)') + ' 0 0/64px 64px, #fdeef2', d: heartSvg('rgba(255,120,160,.12)') + ' 0 0/64px 64px, #22151a' },
  { id: 'dots', t: 'Горошек', l: 'radial-gradient(rgba(0,0,0,.09) 1.6px, transparent 1.8px) 0 0/18px 18px, #f3ede6', d: 'radial-gradient(rgba(255,255,255,.08) 1.6px, transparent 1.8px) 0 0/18px 18px, #15110e' },
  { id: 'paper', t: 'Крафт', l: 'repeating-linear-gradient(0deg, rgba(120,80,40,.05) 0 1px, transparent 1px 28px), linear-gradient(160deg,#efe2cc,#e6d3b5)', d: 'repeating-linear-gradient(0deg, rgba(255,255,255,.04) 0 1px, transparent 1px 28px), linear-gradient(160deg,#2a2218,#1e1912)' },
];
const LOOK_DEF = { mode: 'auto', accent: '#c8553d', wall: 'classic', dim: 0, blur: 0, bubble: 'soft', radius: 16, font: 'system', size: 16 };
function hexRgb(h) { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); }
function mixHex(a, b, t) { const A = hexRgb(a), B = hexRgb(b); return '#' + A.map((v, i) => Math.round(v * (1 - t) + B[i] * t).toString(16).padStart(2, '0')).join(''); }
function rgba(h, a) { const [r, g, b] = hexRgb(h); return `rgba(${r},${g},${b},${a})`; }

const Look = {
  v: null, wallUrl: null, mq: null,
  load() { try { return Object.assign({}, LOOK_DEF, JSON.parse(localStorage.getItem('nc_look') || '{}')); } catch (_) { return Object.assign({}, LOOK_DEF); } },
  save() { try { localStorage.setItem('nc_look', JSON.stringify(this.v)); } catch (_) { } },
  async init() {
    this.v = this.load();
    if (this.v.wall === 'custom') {
      const b = await DB.getMedia('__wall');
      if (b) this.wallUrl = URL.createObjectURL(b); else this.v.wall = 'classic';
    }
    this.mq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
    if (this.mq) (this.mq.addEventListener ? this.mq.addEventListener('change', () => this.apply()) : this.mq.addListener(() => this.apply()));
    this.apply();
  },
  dark() { return this.v.mode === 'dark' || (this.v.mode === 'auto' && this.mq && this.mq.matches); },
  wallCss() {
    if (this.v.wall === 'custom' && this.wallUrl) return `url("${this.wallUrl}") center/cover no-repeat`;
    const w = WALLS.find(x => x.id === this.v.wall) || WALLS[0];
    return this.dark() ? w.d : w.l;
  },
  apply() {
    const v = this.v, dark = this.dark(), root = document.documentElement;
    root.dataset.mode = dark ? 'dark' : 'light';
    const acc = v.accent;
    const mine = dark ? mixHex(acc, '#1c1714', .58) : mixHex(acc, '#ffffff', .78);
    root.style.setProperty('--accent', acc);
    root.style.setProperty('--mine', mine);
    root.style.setProperty('--mine-glass', rgba(mine, .72));
    root.style.setProperty('--r', v.radius + 'px');
    const f = FONTS.find(x => x.id === v.font) || FONTS[0];
    root.style.setProperty('--msg-font', f.f);
    root.style.setProperty('--msg-weight', String(f.w));
    root.style.setProperty('--msg-size', Math.round(v.size * (f.k || 1)) + 'px');
    document.body.classList.remove('b-soft', 'b-flat', 'b-glass');
    document.body.classList.add('b-' + v.bubble);
    for (const el of [$('#wall'), $('#pv-wall')]) {
      if (!el) continue;
      el.style.background = this.wallCss();
      el.style.setProperty('--dim', String((v.dim || 0) / 100));
      const custom = v.wall === 'custom';
      el.style.filter = custom && v.blur ? `blur(${v.blur}px)` : '';
      el.style.transform = custom && v.blur ? 'scale(1.08)' : '';
    }
    if (Native && Native.setDark) { try { Native.setDark(dark); } catch (_) { } }
  },
  set(k, val) { this.v[k] = val; this.save(); this.apply(); this.draw(); },

  // ----- экран -----
  open() { this.draw(); show('look'); $('#look').scrollTop = 0; },
  draw() {
    const v = this.v;
    document.querySelectorAll('#lk-mode button').forEach(b => b.classList.toggle('on', b.dataset.v === v.mode));
    document.querySelectorAll('#lk-bubble button').forEach(b => b.classList.toggle('on', b.dataset.v === v.bubble));
    $('#lk-accent').innerHTML = ACCENTS.map(([c, n]) => `<button style="background:${c}" data-c="${c}" class="${c === v.accent ? 'on' : ''}" aria-label="${n}"></button>`).join('');
    const dark = this.dark();
    $('#lk-walls').innerHTML = `<button class="add${v.wall === 'custom' ? ' on' : ''}" data-w="custom" ${v.wall === 'custom' && this.wallUrl ? `style="background:url('${this.wallUrl}') center/cover"` : ''}>${v.wall === 'custom' && this.wallUrl ? '' : '＋'}<span>Из галереи</span></button>` +
      WALLS.map(w => `<button data-w="${w.id}" class="${w.id === v.wall ? 'on' : ''}" style="background:${(dark ? w.d : w.l).replace(/"/g, '&quot;')}"><span>${w.t}</span></button>`).join('');
    $('#lk-wall-adj').classList.toggle('hidden', v.wall !== 'custom');
    $('#lk-dim').value = v.dim; $('#lk-dim-v').textContent = v.dim + '%';
    $('#lk-blur').value = v.blur; $('#lk-blur-v').textContent = v.blur ? v.blur + ' px' : 'нет';
    $('#lk-radius').value = v.radius; $('#lk-radius-v').textContent = v.radius + ' px';
    $('#lk-size').value = v.size; $('#lk-size-v').textContent = v.size + ' px';
    $('#lk-fonts').innerHTML = FONTS.map(f => `<button data-f="${f.id}" class="${f.id === v.font ? 'on' : ''}" style="font-family:${f.f.replace(/"/g, '&quot;')};font-weight:${f.w}"><b>Привет, любимая</b><small>${f.t}</small></button>`).join('');
  },
  async pickWall(file) {
    try {
      const img = await loadImage(file);
      const { c } = drawScaled(img, img.width, img.height, 1800);
      const blob = await toBlob(c, 'image/jpeg', 0.86);
      await DB.putMedia('__wall', blob);
      if (this.wallUrl) URL.revokeObjectURL(this.wallUrl);
      this.wallUrl = URL.createObjectURL(blob);
      if (!this.v.dim) this.v.dim = 15;
      this.set('wall', 'custom');
    } catch (_) { toast('Не удалось открыть картинку'); }
  },
};
$('#lk-mode').onclick = e => { const b = e.target.closest('button'); if (b) Look.set('mode', b.dataset.v); };
$('#lk-bubble').onclick = e => { const b = e.target.closest('button'); if (b) Look.set('bubble', b.dataset.v); };
$('#lk-accent').onclick = e => { const b = e.target.closest('button'); if (b) Look.set('accent', b.dataset.c); };
$('#lk-fonts').onclick = e => { const b = e.target.closest('button'); if (b) Look.set('font', b.dataset.f); };
$('#lk-walls').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.w === 'custom') { if (Look.wallUrl && Look.v.wall !== 'custom') Look.set('wall', 'custom'); else $('#pick-wall').click(); return; }
  Look.set('wall', b.dataset.w);
};
$('#pick-wall').onchange = e => { const f = e.target.files[0]; e.target.value = ''; if (f) Look.pickWall(f); };
for (const [id, key] of [['lk-dim', 'dim'], ['lk-blur', 'blur'], ['lk-radius', 'radius'], ['lk-size', 'size']]) {
  $('#' + id).oninput = e => { Look.v[key] = +e.target.value; Look.save(); Look.apply(); const lab = $('#' + id + '-v'); lab.textContent = key === 'dim' ? e.target.value + '%' : (key === 'blur' && !+e.target.value) ? 'нет' : e.target.value + ' px'; };
}
$('#lk-reset').onclick = () => { Look.v = Object.assign({}, LOOK_DEF); Look.save(); Look.apply(); Look.draw(); toast('Оформление сброшено'); };
$('#s-look').onclick = () => Look.open();

/* ================= подарки ================= */
const GIFTS = [
  { id: 'rose', e: '🌹', t: 'Роза', m: 'fall', n: 7 },
  { id: 'bouquet', e: '💐', t: 'Букет', m: 'float', n: 3 },
  { id: 'tulip', e: '🌷', t: 'Тюльпаны', m: 'fall', n: 7 },
  { id: 'sakura', e: '🌸', t: 'Сакура', m: 'fall', n: 12 },
  { id: 'sunflower', e: '🌻', t: 'Подсолнух', m: 'float', n: 3 },
  { id: 'teddy', e: '🧸', t: 'Мишка', m: 'float', n: 3 },
  { id: 'heart', e: '❤️', t: 'Сердце', m: 'rise', n: 7 },
  { id: 'hearts', e: '💕', t: 'Сердечки', m: 'rise', n: 8 },
  { id: 'sparkheart', e: '💖', t: 'Сияющее сердце', m: 'rise', n: 6 },
  { id: 'kiss', e: '💋', t: 'Поцелуй', m: 'rise', n: 6 },
  { id: 'balloon', e: '🎈', t: 'Шарик', m: 'rise', n: 6 },
  { id: 'butterfly', e: '🦋', t: 'Бабочка', m: 'flutter', n: 5 },
  { id: 'ring', e: '💍', t: 'Колечко', m: 'float', n: 2 },
  { id: 'gem', e: '💎', t: 'Бриллиант', m: 'float', n: 3 },
  { id: 'crown', e: '👑', t: 'Корона', m: 'float', n: 2 },
  { id: 'star', e: '⭐', t: 'Звезда', m: 'float', n: 5 },
  { id: 'sparkles', e: '✨', t: 'Искорки', m: 'float', n: 8 },
  { id: 'moon', e: '🌙', t: 'Луна', m: 'float', n: 2 },
  { id: 'rainbow', e: '🌈', t: 'Радуга', m: 'float', n: 2 },
  { id: 'kitty', e: '🐱', t: 'Котик', m: 'float', n: 3 },
  { id: 'bunny', e: '🐰', t: 'Зайчик', m: 'float', n: 3 },
  { id: 'chocolate', e: '🍫', t: 'Шоколадка', m: 'float', n: 3 },
  { id: 'cake', e: '🎂', t: 'Тортик', m: 'float', n: 2 },
  { id: 'strawberry', e: '🍓', t: 'Клубника', m: 'fall', n: 6 },
  { id: 'coffee', e: '☕', t: 'Кофе', m: 'float', n: 2 },
  { id: 'letter', e: '💌', t: 'Письмо', m: 'float', n: 3 },
  { id: 'leaf', e: '🍁', t: 'Листопад', m: 'fall', n: 9 },
  { id: 'snow', e: '❄️', t: 'Снежинки', m: 'fall', n: 12 },
];
const giftById = id => GIFTS.find(g => g.id === id) || { id, e: '🎁', t: 'Подарок', m: 'float', n: 3 };

const Gifts = {
  reg: null, popOpen: false, cur: null, snooze: false, from: 'chat', pick: null,
  load() { if (!this.reg) { try { this.reg = JSON.parse(localStorage.getItem('nc_gifts') || '{}'); } catch (_) { this.reg = {}; } } return this.reg; },
  save() { try { localStorage.setItem('nc_gifts', JSON.stringify(this.reg)); } catch (_) { } },
  clear() { this.reg = {}; try { localStorage.removeItem('nc_gifts'); } catch (_) { } },
  list() { return Object.values(this.load()).sort((a, b) => b.ts - a.ts); },
  register(m) {
    const r = this.load();
    if (r[m.id]) return;
    r[m.id] = { id: m.id, g: m.p.g, note: m.p.note || '', from: m.p.n || '', ts: m.ts, mine: m.mine, opened: m.mine, on: false };
    this.save();
  },
  forget(id) { const r = this.load(); if (r[id]) { delete r[id]; this.save(); this.renderLayer(); this.updateBadge(); } },
  unopened() { return this.list().filter(x => !x.mine && !x.opened).reverse(); },
  updateBadge() {
    const n = this.unopened().length, b = $('#gift-badge');
    b.textContent = n; b.classList.toggle('hidden', !n);
    const d = $('#dr-gift-badge'); d.textContent = n; d.classList.toggle('hidden', !n);
    $('#menu-dot').classList.toggle('hidden', !n);
  },
  summary() {
    const l = this.list(), on = l.filter(x => x.on).length;
    if (!l.length) return 'Подарите первый подарок';
    return `${l.length} ${plural(l.length, 'подарок', 'подарка', 'подарков')}` + (on ? ` · ${on} на фоне` : '');
  },
  checkNew() {
    this.updateBadge();
    if (this.popOpen || this.snooze || S.locked || $('#chat').classList.contains('hidden')) return;
    const q = this.unopened();
    if (q.length) this.showPop(q[0], false);
  },

  // ----- открытие -----
  showPop(entry, opened) {
    const g = giftById(entry.g);
    this.cur = entry; this.popOpen = true;
    $('#gp-from').textContent = entry.mine ? 'Ваш подарок' : `${entry.from || S.partner || 'Вам'} дарит вам подарок 💝`;
    $('#gp-box').className = 'gp-box'; $('#gp-box').classList.toggle('hidden', opened);
    $('#gp-gift').textContent = g.e; $('#gp-gift').className = 'gp-gift';
    $('#gp-title').textContent = ''; $('#gp-note').textContent = '';
    $('#gp-hint').classList.toggle('hidden', opened);
    $('#gp-btns').classList.add('hidden');
    $('#gp-confetti').innerHTML = '';
    $('#gift-pop').classList.remove('hidden');
    stopVoicePlayback();
    if (opened) this.reveal(true);
    else vibrate(40);
  },
  reveal(instant) {
    const e = this.cur, g = giftById(e.g);
    $('#gp-hint').classList.add('hidden');
    $('#gp-box').classList.add('open');
    setTimeout(() => {
      $('#gp-box').classList.add('hidden');
      $('#gp-gift').classList.add('show');
      $('#gp-title').textContent = g.t + '!';
      $('#gp-note').textContent = e.note ? '«' + e.note + '»' : '';
      if (!instant) { this.confetti(); vibrate([30, 60, 30]); }
      $('#gp-bg').textContent = e.on ? '✓ Уже летает на фоне' : '✨ Пусть летает на фоне';
      $('#gp-keep').textContent = e.opened ? 'Закрыть' : 'Сохранить в подарки';
      $('#gp-btns').classList.remove('hidden');
    }, instant ? 0 : 420);
  },
  confetti() {
    const box = $('#gp-confetti'), colors = ['#ff5d8f', '#ffd166', '#06d6a0', '#4cc9f0', '#f72585', '#ffffff', Look.v.accent];
    let html = '';
    for (let i = 0; i < 70; i++) {
      const a = Math.random() * Math.PI * 2, d = 140 + Math.random() * 260;
      html += `<i class="cf" style="background:${colors[i % colors.length]};--dx:${Math.cos(a) * d - 5}px;--dy:${Math.sin(a) * d - 7 + 120}px;--rot:${Math.random() * 720 - 360}deg;animation-delay:${Math.random() * .15}s;${Math.random() < .3 ? 'border-radius:50%;width:9px;height:9px;' : ''}"></i>`;
    }
    box.innerHTML = html;
  },
  closePop(setBg) {
    const e = this.cur;
    $('#gift-pop').classList.add('hidden'); this.popOpen = false; this.cur = null;
    if (!e) return;
    const opened = $('#gp-box').classList.contains('hidden');
    if (!opened) { this.snooze = true; return; }
    e.opened = true; if (setBg) e.on = true;
    this.save(); this.renderLayer(); this.updateBadge();
    if (setBg) toast(giftById(e.g).e + ' теперь летает на фоне чата');
    if (!$('#gifts').classList.contains('hidden')) this.drawList();
    setTimeout(() => this.checkNew(), 500);
  },

  // ----- в переписке -----
  bubble(m) {
    const g = giftById(m.p.g);
    const d = document.createElement('div'); d.className = 'gift-card';
    d.innerHTML = `<div class="ge">${g.e}</div><div class="gt">${m.mine ? 'Вы подарили' : esc(m.p.n || 'Вам') + ' дарит'}: ${esc(g.t)}</div>${m.p.note ? `<div class="gn">${linkify(m.p.note)}</div>` : ''}${metaHtml(m)}`;
    d.onclick = () => { const e = this.load()[m.id]; if (e) this.showPop(e, !!e.opened); };
    return d;
  },

  // ----- летающие на фоне -----
  renderLayer() {
    const layer = $('#giftlayer'); if (!layer) return;
    layer.innerHTML = '';
    const act = this.list().filter(x => x.on);
    if (!act.length) return;
    const W = layer.clientWidth || window.innerWidth, H = layer.clientHeight || window.innerHeight;
    const budget = 46, scale = Math.min(1, budget / act.reduce((s, x) => s + giftById(x.g).n, 0));
    const R = (a, b) => a + Math.random() * (b - a);
    let html = '';
    for (const e of act) {
      const g = giftById(e.g), n = Math.max(1, Math.round(g.n * scale));
      for (let i = 0; i < n; i++) {
        const size = R(24, g.m === 'float' ? 50 : 40);
        let st = `font-size:${size.toFixed(0)}px;`, inner = '';
        if (g.m === 'fall' || g.m === 'rise') {
          const dur = R(g.m === 'fall' ? 9 : 11, g.m === 'fall' ? 17 : 19);
          st += `--x:${R(0, W - size).toFixed(0)}px;--spin:${R(-360, 360).toFixed(0)}deg;animation-duration:${dur.toFixed(1)}s;animation-delay:-${R(0, dur).toFixed(1)}s;`;
          inner = `animation-duration:${R(2, 4).toFixed(1)}s;animation-delay:-${R(0, 4).toFixed(1)}s`;
        } else {
          const p = () => `${R(0, W - size).toFixed(0)}px, ${R(0, H - size).toFixed(0)}px`;
          const pts = [p(), p(), p(), p(), p()].map(x => x.split(', '));
          st += pts.map((q, k) => `--x${k ? k + 1 : ''}:${q[0]};--y${k ? k + 1 : ''}:${q[1]};`).join('');
          const dur = R(18, 32);
          st += `animation-duration:${dur.toFixed(1)}s;animation-delay:-${R(0, dur).toFixed(1)}s;`;
          inner = g.m === 'flutter' ? `animation-duration:${R(.25, .45).toFixed(2)}s` : `animation-duration:${R(3, 6).toFixed(1)}s;animation-delay:-${R(0, 6).toFixed(1)}s`;
        }
        html += `<span class="fly m-${g.m}" style="${st}"><i style="${inner}">${g.e}</i></span>`;
      }
    }
    layer.innerHTML = html;
  },

  // ----- коллекция -----
  openList(from) {
    if (from) this.from = from;
    $('#gifts-send').classList.remove('hidden');
    this.drawList(); show('gifts');
  },
  back() { if (this.from === 'settings') { $('#s-gifts-sub').textContent = this.summary(); show('settings'); } else show('chat'); },
  drawList() {
    const l = this.list(), grid = $('#gift-grid');
    $('#gifts-hint').classList.toggle('hidden', !l.length);
    if (!l.length) {
      grid.innerHTML = `<div class="empty"><div>🎁</div>Здесь будут подарки — и те, что дарите вы, и те, что дарят вам</div>`;
      return;
    }
    grid.innerHTML = l.map(e => {
      const g = giftById(e.g), d = new Date(e.ts);
      const isNew = !e.mine && !e.opened;
      return `<div class="gcard${e.on ? ' on' : ''}${isNew ? ' new' : ''}" data-id="${e.id}">
        <div class="ge">${isNew ? '🎁' : g.e}</div><div class="gt">${isNew ? 'Новый подарок!' : esc(g.t)}</div>
        <div class="gd">${e.mine ? 'от вас' : 'от ' + esc(e.from || '♥')} · ${d.getDate()} ${MONTHS[d.getMonth()].slice(0, 3)}</div>
        ${isNew ? '<div class="sw-l">нажмите, чтобы открыть</div>' : `<div class="switch${e.on ? ' on' : ''}" data-sw="${e.id}"></div><div class="sw-l">${e.on ? 'на фоне' : 'выключен'}</div>`}
      </div>`;
    }).join('');
  },
  // ----- магазин -----
  openShop() {
    this.pick = null; $('#shop-note').value = '';
    $('#shop-grid').innerHTML = GIFTS.map(g => `<button data-g="${g.id}"><span class="ge">${g.e}</span><span class="gt">${g.t}</span></button>`).join('');
    $('#shop-bottom').classList.add('hidden');
    show('giftshop');
  },
  async send() {
    if (!this.pick) return;
    const g = giftById(this.pick), note = $('#shop-note').value.trim();
    const btn = $('#shop-send'); btn.disabled = true; btn.textContent = 'Отправляю…';
    try {
      await sendPayload({ t: 'gift', g: g.id, note: note || undefined });
      toast(g.e + ' Подарок отправлен!');
      show('chat'); scrollBottom(true);
    } catch (_) { toast('Не удалось отправить. Нет связи?'); }
    finally { btn.disabled = false; btn.textContent = 'Подарить'; }
  },
};
function plural(n, a, b, c) { const x = n % 10, y = n % 100; return x === 1 && y !== 11 ? a : x >= 2 && x <= 4 && (y < 12 || y > 14) ? b : c; }

$('#gp-box').onclick = () => Gifts.reveal(false);
$('#gp-bg').onclick = () => Gifts.closePop(true);
$('#gp-keep').onclick = () => Gifts.closePop(false);
$('#open-gifts').onclick = () => Gifts.openList('chat');
$('#s-gifts').onclick = () => Gifts.openList('settings');
$('#gifts-back').onclick = () => Gifts.back();
$('#gifts-send').onclick = () => Gifts.openShop();
$('#gift-grid').onclick = e => {
  const c = e.target.closest('.gcard'); if (!c) return;
  const entry = Gifts.load()[c.dataset.id]; if (!entry) return;
  if (!entry.mine && !entry.opened) { Gifts.snooze = false; Gifts.showPop(entry, false); return; }
  if (e.target.closest('[data-sw]')) {
    entry.on = !entry.on; Gifts.save(); Gifts.renderLayer(); Gifts.drawList(); vibrate(10);
  } else Gifts.showPop(entry, true);
};
$('#shop-grid').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  Gifts.pick = b.dataset.g;
  document.querySelectorAll('#shop-grid button').forEach(x => x.classList.toggle('on', x === b));
  const g = giftById(b.dataset.g);
  $('#shop-sel').innerHTML = `Вы выбрали: <b>${g.e}</b> ${esc(g.t)}`;
  $('#shop-bottom').classList.remove('hidden');
};
$('#shop-send').onclick = () => Gifts.send();
window.addEventListener('resize', () => { clearTimeout(window.__glt); window.__glt = setTimeout(() => Gifts.renderLayer(), 400); });

/* ================= смайлики, стикеры, поцелуи ================= */
const EMOJI = [
  ['🕘', 'Недавние', null],
  ['😊', 'Смайлы', '😀 😃 😄 😁 😆 🥹 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😮‍💨 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🫣 🤗 🫡 🤔 🫢 🤭 🤫 🤥 😶 🫠 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👻 💀 🤡 💩 👽 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾'],
  ['❤️', 'Любовь', '💋 ❤️ 🧡 💛 💚 💙 💜 🤎 🖤 🤍 🩷 🩵 💔 ❤️‍🔥 ❤️‍🩹 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 💌 😍 🥰 😘 😻 💑 💏 👩‍❤️‍👨 👨‍❤️‍👨 👩‍❤️‍👩 💍 💐 🌹 🥀 🌷 🫶 🤟 🫰 🤗'],
  ['👋', 'Жесты', '👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 🫶 👐 🤲 🤝 🙏 ✍️ 💅 💪 🦵 🦶 👂 👃 🧠 👀 👁️ 👅 👄 🫦'],
  ['🐱', 'Животные', '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐻‍❄️ 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐢 🐍 🦖 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🦈 🐊 🦒 🦘 🐘 🦔 🦥 🦦 🐿️ 🦩 🦚 🦜 🕊️ 🐾'],
  ['🌸', 'Природа', '🌸 💮 🏵️ 🌹 🥀 🌺 🌻 🌼 🌷 🌱 🪴 🌲 🌳 🌴 🌵 🍀 🍁 🍂 🍃 🍄 🌾 💐 🌍 🌙 🌚 🌝 🌞 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ 🌤️ ⛅ 🌧️ ⛈️ 🌩️ ❄️ ☃️ ⛄ 🌊 💧 ☔ 🌪️ 🌫️'],
  ['🍓', 'Еда', '🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🍆 🥕 🌽 🥐 🥖 🧀 🥚 🍳 🥞 🧇 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍝 🍜 🍲 🍣 🍱 🥟 🍤 🍙 🍚 🍰 🎂 🧁 🥧 🍫 🍬 🍭 🍮 🍯 🍩 🍪 🍦 🍨 ☕ 🍵 🧋 🥤 🍷 🥂 🍾 🍺 🍹'],
  ['🎉', 'Праздник', '🎉 🎊 🎈 🎁 🎀 🎂 🪅 🎆 🎇 🧨 ✨ 🎄 🎃 🎗️ 🏆 🥇 🏅 🎖️ 👑 💎 🎵 🎶 🎤 🎧 🎮 🎲 🧸 🪄 🔮 📸 💡 🕯️ 🛁 🛌 🏠 ✈️ 🚗 🏖️ ⛱️ 🗺️ 🌃 🌅'],
  ['💯', 'Символы', '💯 ✅ ❌ ❓ ❗ ‼️ ⁉️ 💤 💢 💥 💫 💦 💨 🕳️ 💬 💭 🗯️ ♾️ ⚠️ 🔞 🆗 🆒 🆕 🔝 🔜 ➕ ➖ ✖️ ➗ 🟥 🟧 🟨 🟩 🟦 🟪 🟫 ⬛ ⬜ 🔴 🟠 🟡 🟢 🔵 🟣'],
].map(([icon, title, list]) => ({ icon, title, list: list ? list.split(' ') : null }));
const STICKER_PACKS = [
  { id: 'hello', t: 'Привет', price: 0, n: 8 },
  { id: 'love', t: 'Любовь', price: 5, n: 16 },
  { id: 'mood', t: 'Эмоции', price: 8, n: 16 },
  { id: 'cats', t: 'Котики', price: 10, n: 11 },
  { id: 'zoo', t: 'Зверята', price: 12, n: 16 },
  { id: 'sweet', t: 'Сладости', price: 15, n: 16 },
  { id: 'magic', t: 'Волшебство', price: 18, n: 16 },
  { id: 'party', t: 'Праздник', price: 20, n: 16 },
];
const stickerSrc = (pack, i) => `stickers/${pack}/${String(i).padStart(2, '0')}.webp`;

function jumboCount(text) {
  const t = (text || '').trim();
  if (!t || t.length > 40) return 0;
  if (!/^(?:\p{Extended_Pictographic}|\p{Emoji_Modifier}|\p{Emoji_Component}|‍|️|\s)+$/u.test(t)) return 0;
  if (/^[\d#*\s]+$/.test(t)) return 0;
  let n = 0;
  try { n = [...new Intl.Segmenter('ru', { granularity: 'grapheme' }).segment(t.replace(/\s+/g, ''))].length; }
  catch (_) { n = [...t.replace(/\s+/g, '')].length; }
  return n >= 1 && n <= 3 ? n : 0;
}

const Kiss = {
  d: null,
  load() { if (!this.d) { try { this.d = Object.assign({ ids: {}, spent: 0, unlocked: [] }, JSON.parse(localStorage.getItem('nc_kiss') || '{}')); } catch (_) { this.d = { ids: {}, spent: 0, unlocked: [] }; } } return this.d; },
  save() { try { localStorage.setItem('nc_kiss', JSON.stringify(this.d)); } catch (_) { } },
  clear() { this.d = null; try { localStorage.removeItem('nc_kiss'); } catch (_) { } },
  earned() { return Object.keys(this.load().ids).length; },
  balance() { return this.earned() - this.load().spent; },
  owns(pack) { const p = STICKER_PACKS.find(x => x.id === pack); return !p || p.price === 0 || this.load().unlocked.includes(pack); },
  register(id) {
    const d = this.load(); if (d.ids[id]) return;
    d.ids[id] = 1; this.save(); this.drawCount();
    if (S.kissPending) { S.kissPending = false; this.fly(); }
  },
  fly() {
    const btn = $('#btn-send').classList.contains('hidden') ? $('#composer') : $('#btn-send');
    const r = btn.getBoundingClientRect();
    const f = document.createElement('div'); f.className = 'kiss-fly'; f.textContent = '+1 💋';
    f.style.left = (r.left + r.width / 2) + 'px'; f.style.top = (r.top - 10) + 'px';
    document.body.appendChild(f); setTimeout(() => f.remove(), 1400);
    const k = $('#ep-kiss'); k.classList.remove('bump'); void k.offsetWidth; k.classList.add('bump');
    vibrate(15);
  },
  drawCount() { $('#kiss-count').textContent = this.balance(); },
  unlock(pack) {
    const p = STICKER_PACKS.find(x => x.id === pack); if (!p) return;
    if (this.balance() < p.price) return;
    const d = this.load(); d.spent += p.price; d.unlocked.push(pack); this.save();
    this.drawCount(); Panel.drawStickers(pack);
    toast(`Набор «${p.t}» открыт! 🎉`); vibrate([20, 40, 20]);
  },
};

const Panel = {
  tab: 'emoji', pack: 'hello', open_: false,
  recent() { try { return JSON.parse(localStorage.getItem('nc_recent_emoji') || '[]'); } catch (_) { return []; } },
  addRecent(e) { const r = this.recent().filter(x => x !== e); r.unshift(e); try { localStorage.setItem('nc_recent_emoji', JSON.stringify(r.slice(0, 32))); } catch (_) { } },
  recentSt() { try { return JSON.parse(localStorage.getItem('nc_recent_st') || '[]'); } catch (_) { return []; } },
  addRecentSt(s) { const r = this.recentSt().filter(x => x !== s); r.unshift(s); try { localStorage.setItem('nc_recent_st', JSON.stringify(r.slice(0, 12))); } catch (_) { } },
  toggle() { if (this.open_) { this.close(); ta.focus(); } else this.open(); },
  open() {
    this.open_ = true; ta.blur();
    $('#epanel').classList.remove('hidden'); $('#btn-emoji').innerHTML = I.keyboard;
    Kiss.drawCount();
    this.switchTab(this.tab);
    scrollBottom(true);
  },
  close(silent) {
    if (!this.open_) return;
    this.open_ = false;
    $('#epanel').classList.add('hidden'); $('#btn-emoji').innerHTML = I.smile;
  },
  switchTab(t) {
    this.tab = t;
    document.querySelectorAll('.ep-tabs [data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
    $('#ep-emoji').classList.toggle('hidden', t !== 'emoji');
    $('#ep-stickers').classList.toggle('hidden', t !== 'stickers');
    if (t === 'emoji') this.drawEmoji(); else this.drawStickers(this.pack);
  },
  drawEmoji() {
    const rec = this.recent();
    $('#ep-cats').innerHTML = EMOJI.map((c, i) => `<button data-cat="${i}" class="${i === (rec.length ? 0 : 1) ? 'on' : ''}">${c.icon}</button>`).join('');
    $('#ep-emoji-list').innerHTML = EMOJI.map((c, i) => {
      const list = c.list || rec;
      if (!list.length) return '';
      return `<div class="ep-h" id="epc-${i}">${c.title}</div><div class="ep-grid">${list.map(e => `<button data-e="${e}">${e}</button>`).join('')}</div>`;
    }).join('');
  },
  drawStickers(pack) {
    this.pack = pack;
    const rec = this.recentSt();
    $('#ep-packs').innerHTML = (rec.length ? `<button data-pack="recent" class="${pack === 'recent' ? 'on' : ''}">🕘</button>` : '') +
      STICKER_PACKS.map(p => `<button data-pack="${p.id}" class="${p.id === pack ? 'on' : ''}${Kiss.owns(p.id) ? '' : ' locked'}"><img src="${stickerSrc(p.id, 1)}" alt=""></button>`).join('');
    const box = $('#ep-sticker-list');
    if (pack === 'recent') {
      box.innerHTML = `<div class="ep-h">Недавние</div><div class="st-grid">${rec.map(s => `<button data-st="${s}"><img src="stickers/${s}.webp" alt=""></button>`).join('')}</div>`;
      return;
    }
    const p = STICKER_PACKS.find(x => x.id === pack) || STICKER_PACKS[0];
    const grid = `<div class="st-grid">${Array.from({ length: p.n }, (_, i) => `<button data-st="${p.id}/${String(i + 1).padStart(2, '0')}"><img src="${stickerSrc(p.id, i + 1)}" alt="" loading="lazy"></button>`).join('')}</div>`;
    if (Kiss.owns(p.id)) { box.innerHTML = `<div class="ep-h">${esc(p.t)}</div>` + grid; box.scrollTop = 0; return; }
    const bal = Kiss.balance(), need = p.price - bal;
    box.innerHTML = `<div class="st-lockbox"><div class="big">🔒</div><b>Набор «${esc(p.t)}»</b>
      <p>${need > 0 ? `Откроется за ${p.price} 💋. Нужно ещё ${need} ${plural(need, 'поцелуй', 'поцелуя', 'поцелуев')} — отправляйте 💋 в чат!` : `Хватает поцелуев, чтобы открыть!`}</p>
      <div class="kiss-bar"><i style="width:${Math.min(100, Math.round(bal / p.price * 100))}%"></i></div>
      <button class="btn primary" data-unlock="${p.id}" ${need > 0 ? 'disabled' : ''}>Открыть за ${p.price} 💋</button></div>
      <div class="st-locked">${grid}</div>`;
    box.scrollTop = 0;
  },
};
$('#btn-emoji').onclick = () => Panel.toggle();
document.querySelector('.ep-tabs').addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (b) Panel.switchTab(b.dataset.tab); });
$('#ep-kiss').onclick = () => sheet([{ icon: 'send', label: 'Отправить поцелуй 💋', fn: () => sendKiss() }],
  `У вас ${Kiss.balance()} 💋. Каждое ваше сообщение с 💋 даёт один поцелуй, а поцелуи открывают новые наборы стикеров (от 5 до 20 💋).`);
$('#ep-cats').onclick = e => {
  const b = e.target.closest('[data-cat]'); if (!b) return;
  document.querySelectorAll('#ep-cats button').forEach(x => x.classList.toggle('on', x === b));
  const h = $('#epc-' + b.dataset.cat); if (h) $('#ep-emoji-list').scrollTop = h.offsetTop - $('#ep-emoji-list').offsetTop;
};
$('#ep-emoji-list').onclick = e => {
  const b = e.target.closest('[data-e]'); if (!b) return;
  const em = b.dataset.e, st = ta.selectionStart ?? ta.value.length, en = ta.selectionEnd ?? ta.value.length;
  ta.setRangeText(em, st, en, 'end'); updateComposer(); Panel.addRecent(em); vibrate(5);
};
$('#ep-packs').onclick = e => { const b = e.target.closest('[data-pack]'); if (b) Panel.drawStickers(b.dataset.pack); };
$('#ep-sticker-list').onclick = async e => {
  const u = e.target.closest('[data-unlock]'); if (u) { Kiss.unlock(u.dataset.unlock); return; }
  const b = e.target.closest('[data-st]'); if (!b) return;
  const sid = b.dataset.st; Panel.addRecentSt(sid); vibrate(10);
  try { await sendPayload({ t: 'sticker', s: sid }); } catch (_) { toast('Не удалось отправить стикер'); }
};
async function sendKiss() {
  S.kissPending = true;
  try { await sendPayload({ t: 'text', text: '💋' }); } catch (_) { S.kissPending = false; toast('Не удалось отправить'); }
}

/* ================= вход по отпечатку ================= */
const Bio = {
  available() { try { return !!(Native && Native.bioAvailable && Native.bioAvailable()); } catch (_) { return false; } },
  enabled() { try { return !!(Native && Native.bioEnabled && Native.bioEnabled()); } catch (_) { return false; } },
  unlock() { if (this.enabled()) Native.bioUnlock(); },
  drawSetting() {
    const b = $('#s-bio');
    b.classList.toggle('hidden', !this.available());
    b.textContent = this.enabled() ? '👆 Вход по отпечатку: включён' : '👆 Включить вход по отпечатку';
  },
};
$('#s-bio').onclick = () => {
  if (Bio.enabled()) {
    sheet([{ icon: 'x', label: 'Выключить вход по отпечатку', danger: true, fn: () => { Native.bioDisable(); setTimeout(() => Bio.drawSetting(), 300); toast('Вход по отпечатку выключен'); } }],
      'PIN-код продолжит работать как обычно.');
  } else if (S.raw) Native.bioEnable(b64(S.raw));
};
window.onBio = async function (kind, data) {
  if (kind === 'unlock') {
    try { await enterWith(unb64(data)); } catch (_) { $('#lock-err').textContent = 'Не удалось войти, введите PIN'; }
  } else if (kind === 'enabled') {
    Bio.drawSetting(); toast('Готово! Теперь можно входить по отпечатку'); vibrate(30);
  } else if (kind === 'invalid') {
    if (!$('#lock').classList.contains('hidden')) buildKeypad();
    toast('Отпечатки на телефоне изменились. Войдите по PIN и снова включите вход по отпечатку в настройках.', 6000);
    Bio.drawSetting();
  } else if (kind === 'error') {
    toast(data || 'Ошибка отпечатка', 4000);
  }
};

/* ================= выделение части текста ================= */
function openSelect(text) {
  $('#sel-text').textContent = text;
  $('#selview').classList.remove('hidden');
}
function closeSelect() { $('#selview').classList.add('hidden'); try { getSelection().removeAllRanges(); } catch (_) { } }
$('#sel-close').onclick = closeSelect;
$('#sel-all').onclick = () => { copyText($('#sel-text').textContent); closeSelect(); };
$('#sel-copy').onclick = () => {
  const t = String(getSelection() || '');
  if (!t) { toast('Сначала выделите нужный кусок текста — нажмите на слово и потяните за ползунки'); return; }
  copyText(t, 'Скопировано'); closeSelect();
};
document.addEventListener('selectionchange', () => {
  if ($('#selview').classList.contains('hidden')) return;
  $('#sel-copy').disabled = !String(getSelection() || '');
});

/* ================= ответы ================= */
function snippetOf(m) {
  const p = m && m.p; if (!p) return 'Сообщение удалено';
  switch (p.t) {
    case 'text': return p.text.replace(/\s+/g, ' ').slice(0, 90);
    case 'image': return '📷 Фото' + (p.caption ? ': ' + p.caption.slice(0, 60) : '');
    case 'video': return '🎬 Видео';
    case 'voice': return '🎤 Голосовое ' + fmtDur(p.dur);
    case 'circle': return '⭕ Кружок ' + fmtDur(p.dur);
    case 'sticker': return '🧸 Стикер';
    case 'gift': return '🎁 Подарок: ' + giftById(p.g).t;
    case 'watch': return '📺 Совместный просмотр';
    case 'call': return (p.video ? '🎥' : '📞') + ' Звонок';
    case 'file': return '📎 ' + ((p.file && p.file.name) || 'Файл');
  }
  return 'Сообщение';
}
const Reply = {
  set(m) {
    if (!m || !m.p) return;
    S.reply = { id: m.id, d: m.dev, n: m.mine ? S.name : (m.p.n || S.partner || ''), s: snippetOf(m) };
    $('#rb-name').textContent = m.mine ? 'Ответ себе' : 'Ответ ' + (S.reply.n || '');
    $('#rb-text').textContent = S.reply.s;
    $('#replybar').classList.remove('hidden');
    Panel.close(); vibrate(12);
    setTimeout(() => ta.focus(), 30);
  },
  clear() { S.reply = null; $('#replybar').classList.add('hidden'); },
  quoteHtml(re) {
    const who = re.d === S.dev ? 'Вы' : (re.n || S.partner || '');
    return `<div class="quote" data-q="${+re.id}"><b>${esc(who)}</b><span>${esc(re.s || '')}</span></div>`;
  },
  jump(id) {
    const el = document.querySelector(`.msg[data-id="${id}"]`);
    if (!el) { toast('Это сообщение выше — пролистайте вверх, чтобы загрузить его'); return; }
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
  },
};
$('#rb-close').onclick = () => Reply.clear();

// свайп сообщения влево — ответить
(() => {
  const box = $('#msgs'); let sw = null;
  box.addEventListener('touchstart', e => {
    const msg = e.target.closest('.msg[data-id]');
    if (!msg || e.touches.length > 1 || e.target.closest('.circle-box.big') || nearEdge(e.touches[0].clientX)) { sw = null; return; }
    sw = { msg, x: e.touches[0].clientX, y: e.touches[0].clientY, dx: 0, on: false, buzz: false };
  }, { passive: true });
  box.addEventListener('touchmove', e => {
    if (!sw) return;
    const dx = e.touches[0].clientX - sw.x, dy = e.touches[0].clientY - sw.y;
    if (!sw.on) {
      if (Math.abs(dy) > 12 && Math.abs(dy) > Math.abs(dx)) { sw = null; return; }
      if (dx < -14 && Math.abs(dx) > Math.abs(dy) * 1.4) { sw.on = true; sw.msg.classList.add('swiping'); } else return;
    }
    sw.dx = Math.max(-96, Math.min(0, dx + 14));
    sw.msg.style.transform = `translateX(${sw.dx}px)`;
    sw.msg.style.setProperty('--sw', String(Math.min(1, -sw.dx / 70)));
    if (sw.dx < -70 && !sw.buzz) { sw.buzz = true; vibrate(12); }
  }, { passive: true });
  const end = () => {
    if (!sw) return;
    const { msg, dx, on } = sw; sw = null;
    if (!on) return;
    S.swipedAt = Date.now();
    msg.classList.remove('swiping'); msg.classList.add('swipe-back');
    msg.style.transform = ''; msg.style.removeProperty('--sw');
    setTimeout(() => msg.classList.remove('swipe-back'), 250);
    if (dx < -70) Reply.set(S.msgs.get(+msg.dataset.id));
  };
  box.addEventListener('touchend', end); box.addEventListener('touchcancel', end);
})();

/* ================= редактирование ================= */
const Edits = {
  pending: new Map(), // id исходного -> последняя правка, если исходное ещё не загружено
  apply(m) {
    const to = +m.p.to, text = String(m.p.text || '');
    const target = S.msgs.get(to);
    if (!target) { const prev = this.pending.get(to); if (!prev || prev.id < m.id) this.pending.set(to, { id: m.id, dev: m.dev, text, ts: m.ts }); return; }
    this.put(target, { id: m.id, dev: m.dev, text, ts: m.ts });
  },
  fix(m) { const e = this.pending.get(m.id); if (e) { this.pending.delete(m.id); this.put(m, e, true); } },
  put(target, e, silent) {
    // править можно только своё сообщение
    if (!target.p || target.p.t !== 'text' || target.dev !== e.dev || target.del) return;
    if (target.editId && target.editId > e.id) return;
    target.editId = e.id; target.p.text = e.text; target.edited = e.ts;
    if (silent) return;
    const el = document.querySelector(`.msg[data-id="${target.id}"]`);
    if (el) { const ne = msgEl(target); ne.classList.add('edit-flash'); el.replaceWith(ne); }
  },
  start(m) {
    Reply.clear(); Panel.close();
    S.editing = m.id;
    $('#eb-text').textContent = m.p.text.replace(/\s+/g, ' ').slice(0, 90);
    $('#editbar').classList.remove('hidden');
    ta.value = m.p.text; updateComposer();
    $('#btn-send').innerHTML = I.check;
    setTimeout(() => { ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }, 30);
  },
  cancel() {
    S.editing = 0;
    $('#editbar').classList.add('hidden');
    $('#btn-send').innerHTML = I.send;
    ta.value = ''; updateComposer();
  },
  async save() {
    const id = S.editing, m = S.msgs.get(id), text = ta.value.trim();
    if (!m || !text) { this.cancel(); return; }
    if (text === m.p.text) { this.cancel(); return; }
    this.cancel();
    // сразу показываем у себя
    this.put(m, { id: 1e15, dev: m.dev, text, ts: Date.now() });
    try {
      await sendPayload({ t: 'edit', to: id, text });
      m.editId = 0;
    } catch (_) { toast('Не удалось изменить сообщение. Нет связи?'); }
  },
};
$('#eb-close').onclick = () => Edits.cancel();

/* ================= реакции ================= */
const RX_QUICK = ['❤️', '🥰', '😂', '😮', '😢', '🔥', '👍', '💋'];
const Reacts = {
  map: new Map(), // id сообщения -> Map(dev -> {e, id})
  apply(m, live) {
    const to = +m.p.to; if (!to) return;
    let r = this.map.get(to); if (!r) this.map.set(to, r = new Map());
    const prev = r.get(m.dev); if (prev && prev.id > m.id) return;
    if (m.p.e) r.set(m.dev, { e: String(m.p.e).slice(0, 16), id: m.id }); else r.delete(m.dev);
    this.draw(to, live && !m.mine && !!m.p.e);
    if (live && !m.mine && m.p.e && !document.hidden) vibrate(10);
  },
  html(id) {
    const r = this.map.get(id); if (!r || !r.size) return '';
    const groups = new Map();
    for (const [dev, x] of r) { const g = groups.get(x.e) || { n: 0, mine: false }; g.n++; if (dev === S.dev) g.mine = true; groups.set(x.e, g); }
    return `<div class="reacts">${[...groups].map(([e, g]) => `<button class="rx${g.mine ? ' mine' : ''}" data-rx="${esc(e)}">${esc(e)}${g.n > 1 ? `<b>${g.n}</b>` : ''}</button>`).join('')}</div>`;
  },
  draw(id, pop) {
    const el = document.querySelector(`.msg[data-id="${id}"]`); if (!el) return;
    const old = el.querySelector(':scope > .reacts'); if (old) old.remove();
    const h = this.html(id); if (!h) return;
    el.insertAdjacentHTML('beforeend', h);
    if (pop) el.querySelector(':scope > .reacts').classList.add('pop');
    if (nearBottom()) scrollBottom(true);
  },
  mine(id) { const r = this.map.get(id); const x = r && r.get(S.dev); return x ? x.e : ''; },
  async toggle(id, e) {
    const ne = this.mine(id) === e ? '' : e;
    // показываем сразу, не дожидаясь сервера
    let r = this.map.get(id); if (!r) this.map.set(id, r = new Map());
    if (ne) r.set(S.dev, { e: ne, id: 1e15 }); else r.delete(S.dev);
    this.draw(id, !!ne); vibrate(10);
    try { await sendPayload({ t: 'react', to: id, e: ne }); }
    catch (_) { toast('Не удалось поставить реакцию'); }
    const x = r.get(S.dev); if (x && x.id === 1e15) x.id = 0;
  },
};
const RxBar = {
  el: null, msgId: 0,
  open(msgEl, m) {
    this.close();
    m = m || S.msgs.get(+msgEl.dataset.id); if (!m || m.del || !m.p) return;
    this.msgId = m.id;
    const cur = Reacts.mine(m.id);
    const bar = document.createElement('div'); bar.className = 'rxbar';
    bar.innerHTML = RX_QUICK.map((e, i) => `<button data-e="${e}" class="${e === cur ? 'on' : ''}" style="animation-delay:${i * 25}ms">${e}</button>`).join('') + `<button data-reply="1" class="rx-reply" title="Ответить">${I.reply}</button>`;
    document.body.appendChild(bar); this.el = bar;
    const r = msgEl.getBoundingClientRect(), w = bar.offsetWidth, h = bar.offsetHeight;
    let left = m.mine ? r.right - w : r.left; left = Math.max(8, Math.min(window.innerWidth - w - 8, left));
    let top = r.top - h - 8; if (top < 70) top = r.bottom + 8;
    bar.style.left = left + 'px'; bar.style.top = top + 'px';
    msgEl.classList.add('rx-target');
    bar.onclick = e => {
      const b = e.target.closest('button'); if (!b) return;
      const id = this.msgId; this.close();
      if (b.dataset.reply) Reply.set(S.msgs.get(id)); else Reacts.toggle(id, b.dataset.e);
    };
    vibrate(8);
  },
  close() {
    if (this.el) { this.el.remove(); this.el = null; }
    document.querySelectorAll('.rx-target').forEach(x => x.classList.remove('rx-target'));
  },
};
document.addEventListener('pointerdown', e => { if (RxBar.el && !e.target.closest('.rxbar')) RxBar.close(); }, true);
$('#list').addEventListener('scroll', () => RxBar.close(), { passive: true });
// одно нажатие на сообщение — панель реакций; нажатие на цитату — к исходному сообщению
$('#msgs').addEventListener('click', e => {
  const q = e.target.closest('.quote'); if (q) { Reply.jump(+q.dataset.q); return; }
  const rx = e.target.closest('.rx');
  if (rx) { const msg = rx.closest('.msg[data-id]'); Reacts.toggle(+msg.dataset.id, rx.dataset.rx); return; }
  const msg = e.target.closest('.msg[data-id]'); if (!msg || msg.classList.contains('deleted')) return;
  if (S.swipedAt && Date.now() - S.swipedAt < 400) return;
  if (e.target.closest('a, .pic, .pbtn, .wave, .circle-box, .file, .gift-card')) return;
  if (!$('#sheet').classList.contains('hidden')) return;
  RxBar.open(msg);
});

/* ================= анимации на фразы ================= */
const NB = '(^|[^а-яёa-z])', NE = '([^а-яёa-z]|$)';
const FX_RULES = [
  [new RegExp(NB + '(с\\s+(днём|днем)\\s+рождения|с\\s+др|с\\s+днюхой|happy\\s+birthday)' + NE, 'i'), 'birthday'],
  [/приятного\s+аппетита|приятного\s+обеда|приятного\s+ужина|вкусного/i, 'food'],
  [/спокойной\s+ночи|сладких\s+снов|доброй\s+ночи|спокойной\s+ночки/i, 'night'],
  [/доброе\s+утро|доброго\s+утра|с\s+добрым\s+утром|утречко/i, 'morning'],
  [/люблю|love\s+you|❤️|💖|💕|💞|😍|🥰/i, 'love'],
  [/целую|чмок|поцелу|💋|😘/i, 'kiss'],
  [/обнимаю|обнимашк|🤗/i, 'hug'],
  [/скучаю|соскучил|🥺/i, 'miss'],
  [new RegExp(NB + '(ура+|поздравляю|поздравля|урааа)' + NE + '|🎉|🥳', 'i'), 'party'],
];
const FX = {
  busy: false,
  enabled() { try { return localStorage.getItem('nc_fx') !== 'off'; } catch (_) { return true; } },
  check(text) {
    if (!text || !this.enabled() || this.busy) return;
    for (const [re, kind] of FX_RULES) if (re.test(text)) { this.play(kind); return; }
  },
  play(kind) {
    this.busy = true;
    const L = document.createElement('div'); L.className = 'fx fx-' + kind;
    const W = window.innerWidth, H = window.innerHeight, R = (a, b) => a + Math.random() * (b - a);
    const pick = a => a[Math.floor(Math.random() * a.length)];
    let html = '';
    const part = (cls, e, st) => { html += `<span class="fxp ${cls}" style="${st}">${e}</span>`; };
    const rise = (list, n, size = [26, 48]) => { for (let i = 0; i < n; i++) part('rise', pick(list), `left:${R(-20, W - 20)}px;bottom:-60px;font-size:${R(...size)}px;--dx:${R(-60, 60)}px;--rot:${R(-30, 30)}deg;animation-duration:${R(2.2, 3.6)}s;animation-delay:${R(0, 1.2)}s`); };
    const fall = (list, n, size = [26, 46]) => { for (let i = 0; i < n; i++) part('fall', pick(list), `left:${R(-20, W - 20)}px;top:-70px;font-size:${R(...size)}px;--dx:${R(-50, 50)}px;--rot:${R(-200, 200)}deg;animation-duration:${R(2.2, 3.6)}s;animation-delay:${R(0, 1.3)}s`); };
    const burst = (list, n, size = [24, 44]) => { for (let i = 0; i < n; i++) { const a = R(0, Math.PI * 2), d = R(120, Math.max(W, H) * .55); part('burst', pick(list), `left:50%;top:45%;font-size:${R(...size)}px;--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d}px;--rot:${R(-180, 180)}deg;animation-duration:${R(1.4, 2.2)}s;animation-delay:${R(0, .25)}s`); } };
    const twinkle = (list, n) => { for (let i = 0; i < n; i++) part('twinkle', pick(list), `left:${R(10, W - 30)}px;top:${R(60, H * .75)}px;font-size:${R(14, 30)}px;animation-duration:${R(1.6, 2.6)}s;animation-delay:${R(0, 1.4)}s`); };
    const confetti = n => { const c = ['#ff5d8f', '#ffd166', '#06d6a0', '#4cc9f0', '#f72585', '#ffffff', '#ff9f1c']; for (let i = 0; i < n; i++) { const a = R(0, Math.PI * 2), d = R(150, Math.max(W, H) * .6); part('burst cf2', '', `left:50%;top:40%;background:${c[i % c.length]};--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d + 200}px;--rot:${R(-720, 720)}deg;animation-duration:${R(1.6, 2.4)}s;animation-delay:${R(0, .2)}s`); } };
    const big = e => part('big', e, '');
    switch (kind) {
      case 'love': big('💖'); rise(['❤️', '💖', '💕', '💗', '💓', '💘'], 34); break;
      case 'kiss': big('💋'); burst(['💋', '💋', '😘', '💗'], 24); break;
      case 'food': big('😋'); fall(['🍕', '🍝', '🍰', '🍓', '🥐', '🍜', '🍩', '🧁', '🍔', '🍣', '🥗'], 30); break;
      case 'night': big('🌙'); twinkle(['⭐', '✨', '🌟', '💫'], 26); fall(['💤'], 5, [22, 34]); break;
      case 'morning': big('☀️'); rise(['🌼', '☕', '🌸', '🌻', '✨', '🥐'], 18); break;
      case 'birthday': big('🎂'); confetti(70); rise(['🎈', '🎈', '🎉', '🎁', '🎊'], 18); break;
      case 'party': big('🎉'); confetti(80); break;
      case 'hug': big('🤗'); burst(['💞', '💗', '🫶', '✨'], 18); break;
      case 'miss': big('🥺'); rise(['💭', '💗', '🥺', '💞'], 16); break;
    }
    L.innerHTML = html; document.body.appendChild(L);
    if (kind === 'love' || kind === 'kiss') vibrate([15, 80, 15]);
    setTimeout(() => { L.classList.add('out'); }, 3600);
    setTimeout(() => { L.remove(); this.busy = false; }, 4200);
  },
};

/* ================= в сети и «печатает…» ================= */
const Presence = {
  my: '', sent: 0, typingT: null, partner: null, prevOnline: null, supported: false,
  set(s, beacon) {
    if (!S.started || !S.token) return;
    const now = Date.now();
    if (s === this.my && now - this.sent < 3000) return;
    this.my = s; this.sent = now;
    const body = JSON.stringify({ dev: S.dev, s });
    fetch(S.url + '/api/presence', { method: 'POST', keepalive: !!beacon, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + S.token }, body })
      .then(r => r.ok ? r.json() : null).then(j => { if (j && j.presence) this.handle(j.presence); }).catch(() => { });
  },
  typing() {
    if (!ta.value.trim()) { this.set('online'); return; }
    if (this.my !== 'typing' || Date.now() - this.sent > 4000) { this.sent = 0; this.set('typing'); }
    clearTimeout(this.typingT);
    this.typingT = setTimeout(() => this.set('online'), 5000);
  },
  partnerSent() { if (this.partner && this.partner.s === 'typing') { this.partner.s = 'online'; this.draw(); } },
  handle(p) {
    if (!p) return;
    this.supported = true;
    const rank = { typing: 5, voice: 5, circle: 5, online: 4, away: 2, offline: 1 };
    let best = null;
    for (const [dev, x] of Object.entries(p)) {
      if (dev === S.dev) continue;
      if (!best || (rank[x.s] || 0) > (rank[best.s] || 0) || ((rank[x.s] || 0) === (rank[best.s] || 0) && x.seen > best.seen)) best = x;
    }
    this.partner = best;
    this.draw();
  },
  draw() {
    const net = $('#net'), av = $('#partner-av'), tb = $('#typing');
    if (!S.online) return;
    const p = this.partner;
    const st = p ? p.s : '';
    const active = st === 'online' || st === 'typing' || st === 'voice' || st === 'circle';
    av.classList.toggle('online', active);
    tb.classList.toggle('hidden', !(st === 'typing' || st === 'voice' || st === 'circle'));
    tb.dataset.kind = st;
    if (st === 'typing') net.innerHTML = '<span class="st-typing">печатает<i>.</i><i>.</i><i>.</i></span>';
    else if (st === 'voice') net.innerHTML = '<span class="st-typing">записывает голосовое 🎤</span>';
    else if (st === 'circle') net.innerHTML = '<span class="st-typing">записывает кружок 📹</span>';
    else if (st === 'online') net.innerHTML = '<span class="st-online">в сети</span>';
    else if (p && p.seen) net.textContent = 'был(а) в сети ' + this.ago(p.seen);
    else net.textContent = this.supported ? 'не в сети' : 'защищённое соединение';
    if ((st === 'typing' || st === 'voice' || st === 'circle') && nearBottom()) scrollBottom(true);
    // приветствие, когда собеседник зашёл
    if (this.prevOnline === false && active && !document.hidden && !$('#chat').classList.contains('hidden')) this.hello();
    this.prevOnline = active;
  },
  hello() {
    const b = document.createElement('div'); b.className = 'hello';
    b.innerHTML = `<span>💚</span> ${esc(S.partner || 'Собеседник')} в сети`;
    $('#chat').appendChild(b); setTimeout(() => b.remove(), 3200);
  },
  ago(ts) {
    const d = new Date(ts), now = new Date(), min = Math.round((now - d) / 60000);
    if (min < 1) return 'только что';
    if (min < 60) return min + ' ' + plural(min, 'минуту', 'минуты', 'минут') + ' назад';
    const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const dd = Math.round((day(now) - day(d)) / 86400000);
    if (dd === 0) return 'в ' + fmtTime(ts);
    if (dd === 1) return 'вчера в ' + fmtTime(ts);
    return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' в ' + fmtTime(ts);
  },
};
setInterval(() => { if (S.started && Presence.partner && Presence.partner.s !== 'online' && Presence.partner.s !== 'typing') Presence.draw(); }, 60000);

/* ================= быстрые сигналы (зашифрованы, не сохраняются) ================= */
const Sig = {
  async send(obj) {
    if (!S.key) return;
    const ct = b64(await Crypto.seal(S.key, enc.encode(JSON.stringify(obj)), 'sig'));
    try { await api('/api/signal', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dev: S.dev, ct }), timeout: 10000 }); return true; }
    catch (_) { return false; }
  },
  async receive(list) {
    for (const x of list) {
      try {
        const o = JSON.parse(dec.decode(await Crypto.open(S.key, unb64(x.ct), 'sig')));
        if (o.k === 'w') Watch.onSignal(o);
        else if (o.k === 'c') Call.onSignal(o, x.ts);
      } catch (_) { }
    }
  },
};

/* ================= смотреть вместе (VK) ================= */
function parseVK(text) {
  if (!text) return null;
  const t = String(text).replace(/&amp;/g, '&');
  let m = t.match(/video_ext\.php\?[^\s"'<>]*/i);
  if (m) {
    const q = new URLSearchParams(m[0].split('?')[1]);
    const oid = q.get('oid'), id = q.get('id');
    if (/^-?\d+$/.test(oid || '') && /^\d+$/.test(id || '')) return { oid, id, hash: (q.get('hash') || '').replace(/[^\w]/g, '') || undefined, host: /vk\.com/i.test(t) ? 'vk.com' : 'vk.ru' };
  }
  if (!/(vk\.(com|ru)|vkvideo\.ru|vk\.cc)/i.test(t) && !/^\s*(video|clip)-?\d+_\d+\s*$/i.test(t)) return null;
  m = t.match(/(?:video|clip)(-?\d+)_(\d+)/i);
  if (!m) return null;
  const h = t.match(/[?&](?:hash|access_key)=([\w]+)/i) || t.match(/video-?\d+_\d+_([0-9a-f]{6,})/i);
  return { oid: m[1], id: m[2], hash: h ? h[1] : undefined, host: 'vk.ru' };
}
const Watch = {
  sid: '', v: null, frame: null, ready: false, big: false, playing: false, t: 0, tWall: 0, suppress: 0,
  partnerAt: 0, pendingState: null, ad: false, tickT: null, frameOrigin: '',
  // --- приглашение ---
  dialog() {
    $('#wd-url').value = ''; $('#wd-err').textContent = '';
    $('#watchdlg').classList.remove('hidden');
    setTimeout(() => $('#wd-url').focus(), 50);
  },
  async start(v) {
    if (!v) return;
    $('#watchdlg').classList.add('hidden');
    const sid = hex(crypto.getRandomValues(new Uint8Array(6)));
    this.open(v, sid, null);
    try { await sendPayload({ t: 'watch', v, sid }); } catch (_) { toast('Не удалось отправить приглашение'); }
    Sig.send({ k: 'w', a: 'open', sid, v });
  },
  bubble(m) {
    const p = m.p;
    const d = document.createElement('div'); d.className = 'gift-card watch-card';
    d.innerHTML = `<div class="ge">📺</div><div class="gt">${m.mine ? 'Вы позвали смотреть видео' : esc(p.n || 'Вас') + ' зовёт смотреть видео'}</div>
      <div class="gn">Видео VK · смотрим вместе</div><button class="btn primary wc-go">${m.mine ? 'Открыть' : 'Смотреть вместе'}</button>${metaHtml(m)}`;
    d.querySelector('.wc-go').onclick = e => { e.stopPropagation(); this.open(p.v, p.sid, 'join'); };
    return d;
  },
  // --- плеер ---
  open(v, sid, mode) {
    if (!S.url) return;
    const origin = new URL(S.url).origin;
    this.close(true);
    this.v = v; this.sid = sid; this.ready = false; this.playing = false; this.t = 0; this.tWall = Date.now();
    this.partnerAt = 0; this.pendingState = null; this.ad = false; this.frameOrigin = origin;
    const box = $('#watch'); box.classList.remove('hidden');
    $('#wt-status').textContent = 'Загрузка…';
    const f = document.createElement('iframe');
    f.src = origin + '/watch.html';
    f.allow = 'autoplay; encrypted-media; fullscreen; picture-in-picture';
    f.setAttribute('allowfullscreen', '');
    this.frame = f; this.loaded = false;
    f.addEventListener('load', () => { if (this.frame === f) setTimeout(() => this.cmd('load', { v: this.v }), 50); });
    $('#wt-frame').innerHTML = ''; $('#wt-frame').appendChild(f);
    if (mode === 'join') Sig.send({ k: 'w', a: 'hello', sid });
    clearInterval(this.tickT);
    this.tickT = setInterval(() => this.tick(), 6000);
    this.draw(); Panel.close();
  },
  close(silent) {
    if (!this.sid) return;
    if (!silent) Sig.send({ k: 'w', a: 'bye', sid: this.sid });
    clearInterval(this.tickT);
    this.sid = ''; this.v = null; this.frame = null; this.ready = false;
    $('#wt-frame').innerHTML = ''; $('#watch').classList.add('hidden');
    this.expand(false);
  },
  expand(on) {
    this.big = !!on;
    $('#watch').classList.toggle('big', this.big);
    $('#wt-big').innerHTML = this.big ? I.shrink : I.expand;
  },
  cmd(c, extra) { if (this.frame && this.frame.contentWindow) this.frame.contentWindow.postMessage(Object.assign({ nc: 'cmd', cmd: c }, extra || {}), this.frameOrigin); },
  now() { return this.playing ? this.t + (Date.now() - this.tWall) / 1000 : this.t; },
  hold(ms = 1800) { this.suppress = Date.now() + ms; },
  // команды от собеседника
  apply(t, playing) {
    if (!this.ready || this.ad) { this.pendingState = { t, playing, at: Date.now() }; return; }
    const target = t + (playing ? 0.4 : 0);
    this.hold();
    if (Math.abs(this.now() - target) > 1.5) { this.cmd('seek', { t: target }); this.t = target; this.tWall = Date.now(); }
    if (playing && !this.playing) this.cmd('play');
    if (!playing && this.playing) this.cmd('pause');
    this.playing = playing;
  },
  onSignal(o) {
    if (o.a === 'open') { if (!this.sid) toast('📺 ' + (S.partner || 'Собеседник') + ' включил(а) видео', 2500); return; }
    if (!this.sid || o.sid !== this.sid) return;
    const wasHere = Date.now() - this.partnerAt < 20000;
    this.partnerAt = Date.now();
    switch (o.a) {
      case 'hello':
        if (!wasHere) toast('👀 ' + (S.partner || 'Собеседник') + ' смотрит вместе с вами');
        Sig.send({ k: 'w', a: 'state', sid: this.sid, t: this.now(), playing: this.playing });
        break;
      case 'state': this.apply(o.t, o.playing); break;
      case 'play': this.apply(o.t, true); break;
      case 'pause': this.apply(o.t, false); break;
      case 'seek': this.apply(o.t, o.playing); break;
      case 'tick':
        // догоняем, если отстали больше чем на 3 секунды
        if (this.ready && !this.ad && Date.now() > this.suppress) {
          const theirs = o.t + (o.playing ? 0.4 : 0);
          if (o.playing !== this.playing || theirs - this.now() > 3) this.apply(o.t, o.playing);
        }
        break;
      case 'bye': this.partnerAt = 0; toast((S.partner || 'Собеседник') + ' вышел(ла) из просмотра'); break;
    }
    this.draw();
  },
  tick() {
    if (!this.sid) return;
    if (this.ready && !this.ad) Sig.send({ k: 'w', a: 'tick', sid: this.sid, t: this.now(), playing: this.playing });
    this.draw();
  },
  // события плеера
  onFrame(d) {
    if (!this.sid) return;
    const mine = Date.now() > this.suppress;
    switch (d.ev) {
      case 'boot': break;
      case 'ready':
        this.ready = true;
        if (this.pendingState) { const p = this.pendingState; this.pendingState = null; this.apply(p.t + (p.playing ? (Date.now() - p.at) / 1000 : 0), p.playing); }
        break;
      case 'play':
        this.t = d.t; this.tWall = Date.now();
        if (!this.playing) { this.playing = true; if (mine) Sig.send({ k: 'w', a: 'play', sid: this.sid, t: d.t }); }
        break;
      case 'pause':
        this.t = d.t; this.tWall = Date.now();
        if (this.playing) { this.playing = false; if (mine) Sig.send({ k: 'w', a: 'pause', sid: this.sid, t: d.t }); }
        break;
      case 'ended': this.playing = false; this.t = d.t; break;
      case 'time': {
        const expect = this.now();
        if (mine && Math.abs(d.t - expect) > 3) Sig.send({ k: 'w', a: 'seek', sid: this.sid, t: d.t, playing: this.playing });
        this.t = d.t; this.tWall = Date.now();
        break;
      }
      case 'ad':
        this.ad = d.on;
        if (!d.on) Sig.send({ k: 'w', a: 'hello', sid: this.sid });
        break;
      case 'error':
        if (d.code === 'video') toast('Это видео нельзя встроить. Скопируйте в VK «Поделиться → Экспортировать» и пришлите код или выберите другое видео.', 6000);
        break;
    }
    this.draw();
  },
  draw() {
    if (!this.sid) return;
    const here = Date.now() - this.partnerAt < 20000;
    $('#wt-status').innerHTML = here ? `<span class="wt-dot"></span> Смотрите вместе с ${esc(S.partner || 'собеседником')}` : 'Ждём ' + esc(S.partner || 'собеседника') + '…';
  },
  onHide() { /* в фоне видео ставится на паузу системой; при возврате синхронизируемся */ if (this.sid) setTimeout(() => this.sid && Sig.send({ k: 'w', a: 'hello', sid: this.sid }), 100); },
};
window.addEventListener('message', e => {
  if (!Watch.frame || e.source !== Watch.frame.contentWindow || e.origin !== Watch.frameOrigin) return;
  const d = e.data || {}; if (d.nc !== 'watch') return;
  Watch.onFrame(d);
});
$('#open-watch').onclick = () => Watch.dialog();
$('#wd-cancel').onclick = () => $('#watchdlg').classList.add('hidden');
$('#wd-go').onclick = () => {
  const v = parseVK($('#wd-url').value);
  if (!v) { $('#wd-err').textContent = 'Не похоже на ссылку на видео VK. Пример: vk.com/video-12345_67890'; return; }
  Watch.start(v);
};
$('#wt-close').onclick = () => Watch.close();
$('#wt-big').onclick = () => Watch.expand(!Watch.big);

/* ================= выдвижное меню ================= */
const Drawer = {
  isOpen: false,
  open() {
    Profile.drawDrawer();
    $('#dr-kiss').textContent = Kiss.balance() + ' 💋';
    $('#dr-fx-sw').classList.toggle('on', FX.enabled());
    $('#dr-foot').textContent = 'Наш чат · версия ' + VERSION;
    $('#dr-cal').textContent = Cal.soonLabel();
    Gifts.updateBadge(); Panel.close(); RxBar.close();
    try { ta.blur(); } catch (_) { }
    this.isOpen = true;
    $('#drawer').classList.add('open'); $('#drawer').setAttribute('aria-hidden', 'false');
    vibrate(8);
  },
  close() {
    this.isOpen = false;
    $('#drawer').classList.remove('open'); $('#drawer').setAttribute('aria-hidden', 'true');
    $('#dr-panel').style.transform = '';
  },
  act(a) {
    if (a === 'fx') {
      const on = !FX.enabled();
      try { localStorage.setItem('nc_fx', on ? 'on' : 'off'); } catch (_) { }
      $('#dr-fx-sw').classList.toggle('on', on);
      if (on) { this.close(); setTimeout(() => FX.play('love'), 250); }
      return;
    }
    this.close();
    setTimeout(() => {
      if (a === 'watch') Watch.dialog();
      else if (a === 'gifts') Gifts.openList('chat');
      else if (a === 'cal') Cal.open();
      else if (a === 'notes') Notes.open();
      else if (a === 'bank') Bank.open();
      else if (a === 'stickers') { Panel.open(); Panel.switchTab('stickers'); }
      else if (a === 'look') { $('#open-settings').onclick(); Look.open(); }
      else if (a === 'settings') $('#open-settings').onclick();
    }, 180);
  },
};
$('#open-menu').onclick = () => Drawer.open();
$('#dr-shade').onclick = () => Drawer.close();
$('#dr-panel').addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (b) Drawer.act(b.dataset.act); });
// закрыть меню свайпом влево
(() => {
  const p = $('#dr-panel'); let sx = null, dx = 0;
  p.addEventListener('touchstart', e => { sx = e.touches[0].clientX; dx = 0; p.style.transition = 'none'; }, { passive: true });
  p.addEventListener('touchmove', e => { if (sx == null) return; dx = Math.min(0, e.touches[0].clientX - sx); p.style.transform = `translateX(${dx}px)`; }, { passive: true });
  p.addEventListener('touchend', () => { p.style.transition = ''; if (dx < -70) Drawer.close(); else p.style.transform = ''; sx = null; });
})();

/* ================= кнопка «Назад» Android ================= */
window.nativeBack = function () {
  if (!$('#callui').classList.contains('hidden')) { if (Call.st === 'incoming') Call.decline(); else if (Call.st !== 'idle' && Call.st !== 'ended') $('#cu-min').click(); return true; }
  if (Shared.back()) return true;
  if (Drawer.isOpen) { Drawer.close(); return true; }
  if (!$('#watchdlg').classList.contains('hidden')) { $('#watchdlg').classList.add('hidden'); return true; }
  if (Watch.big) { Watch.expand(false); return true; }
  if (RxBar.el) { RxBar.close(); return true; }
  if (!$('#selview').classList.contains('hidden')) { closeSelect(); return true; }
  if (S.editing) { Edits.cancel(); return true; }
  if (!$('#epanel').classList.contains('hidden')) { Panel.close(); return true; }
  if (!$('#gift-pop').classList.contains('hidden')) { Gifts.closePop(false); return true; }
  if (!$('#look').classList.contains('hidden')) { show('settings'); return true; }
  if (!$('#giftshop').classList.contains('hidden')) { Gifts.openList(); return true; }
  if (!$('#gifts').classList.contains('hidden')) { Gifts.back(); return true; }
  if (!$('#circle-rec').classList.contains('hidden')) { finishCircle(true); return true; }
  if (R.rec) { stopVoice(true); return true; }
  if (!$('#viewer').classList.contains('hidden')) { closeViewer(); return true; }
  if (!$('#sheet').classList.contains('hidden')) { closeSheet(); return true; }
  if (!$('#settings').classList.contains('hidden')) { show('chat'); return true; }
  if (!$('#lock').classList.contains('hidden') && pinMode !== 'unlock') { show('settings'); return true; }
  if (!$('#create').classList.contains('hidden') || !$('#join').classList.contains('hidden')) { show('welcome'); return true; }
  return false;
};
// вызывается из Android, когда приложение вернулось на экран
window.nativeResume = function () { if (S.started) { kickSync(); markSeen(); } };

boot();
