'use strict';
/* «Наш чат» — какой чат открыт на этой странице.
   Подключается ПЕРВЫМ: всё, что относится к одному чату (кэш, отметки «прочитано», общие записи),
   хранится отдельно для каждого чата. Общие настройки (оформление, имя, PIN) — одни на все чаты. */

const CHAT = (() => {
  let id = 'main';
  try { id = sessionStorage.getItem('nc_cur') || 'main'; } catch (_) { }
  // приложение открыли из уведомления конкретного чата
  try {
    const nb = window.NativeBridge;
    const want = nb && nb.takeOpenChat ? nb.takeOpenChat() : '';
    if (want) { id = want; sessionStorage.setItem('nc_cur', id); sessionStorage.setItem('nc_view', 'chat'); }
    // открыли кнопкой звонка из другого чата
    const cr = nb && nb.peekCallRoom ? nb.peekCallRoom() : '';
    if (cr) { id = cr; sessionStorage.setItem('nc_cur', id); sessionStorage.setItem('nc_view', 'chat'); }
  } catch (_) { }
  let list = [];
  try { list = JSON.parse(localStorage.getItem('nc_chats') || '[]') || []; } catch (_) { }
  let main = null;
  try { main = JSON.parse(localStorage.getItem('nc') || 'null'); } catch (_) { }
  const x = list.find(c => c.id === id);
  if (id !== 'main' && !x) id = 'main';
  return {
    id,
    kind: id === 'main' ? ((main && main.kind) || 'pair') : x.kind,
    title: id === 'main' ? '' : (x.title || ''),
    isPair() { return this.kind === 'pair'; },
    isGroup() { return this.kind === 'group'; },
  };
})();
try { sessionStorage.setItem('nc_cur', CHAT.id); } catch (_) { }

// отдельное хранилище для каждого дополнительного чата
(() => {
  if (CHAT.id === 'main') return;
  const GLOBAL = /^nc(_chats|_look|_fx|_recmode|_recent_emoji|_recent_st|_kiss|_myprof|_list|_seen|_notif)?$/;
  const P = Storage.prototype, g = P.getItem, s = P.setItem, r = P.removeItem;
  const k = (st, key) => (st === window.localStorage && !GLOBAL.test(String(key))) ? 'c' + CHAT.id + ':' + key : key;
  P.getItem = function (key) { return g.call(this, k(this, key)); };
  P.setItem = function (key, v) { return s.call(this, k(this, key), v); };
  P.removeItem = function (key) { return r.call(this, k(this, key)); };
})();

document.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('k-' + CHAT.kind);
  if (CHAT.id === 'main') document.body.classList.add('c-main');
  try { if ((JSON.parse(localStorage.getItem('nc_chats') || '[]') || []).length) document.body.classList.add('multi'); } catch (_) { }
});
