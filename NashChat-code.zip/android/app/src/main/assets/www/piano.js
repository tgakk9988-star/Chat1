'use strict';
/* «Наш чат» — 🎹 Пианино с енотом. Клавиши бегут сверху вниз по 4 дорожкам, нажимайте их на линии.
   Мелодии — только классика и народные песни (общественное достояние), записаны нотами вручную.
   Запись: нота + длительность. Без знака — четверть, «/» — вдвое короче, «-» — +1 доля, «.» — ×1,5, R — пауза. */

const PIANO_SONGS = [
  { id: 'twinkle', t: 'Маленькая звёздочка', a: 'Народная', lv: 1, bpm: 100, n: 'C4 C4 G4 G4 A4 A4 G4- F4 F4 E4 E4 D4 D4 C4- G4 G4 F4 F4 E4 E4 D4- G4 G4 F4 F4 E4 E4 D4- C4 C4 G4 G4 A4 A4 G4- F4 F4 E4 E4 D4 D4 C4-' },
  { id: 'mary', t: 'У Мэри был барашек', a: 'Народная', lv: 1, bpm: 110, n: 'E4 D4 C4 D4 E4 E4 E4- D4 D4 D4- E4 G4 G4- E4 D4 C4 D4 E4 E4 E4 E4 D4 D4 E4 D4 C4--' },
  { id: 'jacques', t: 'Братец Яков', a: 'Народная', lv: 1, bpm: 110, n: 'C4 D4 E4 C4 C4 D4 E4 C4 E4 F4 G4- E4 F4 G4- G4/ A4/ G4/ F4/ E4 C4 G4/ A4/ G4/ F4/ E4 C4 C4 G3 C4- C4 G3 C4-' },
  { id: 'london', t: 'Лондонский мост', a: 'Народная', lv: 1, bpm: 110, n: 'G4. A4/ G4 F4 E4 F4 G4- D4 E4 F4- E4 F4 G4- G4. A4/ G4 F4 E4 F4 G4- D4- G4 E4 C4--' },
  { id: 'farm', t: 'Ферма старого Макдональда', a: 'Народная', lv: 1, bpm: 120, n: 'G4 G4 G4 D4 E4 E4 D4- B4 B4 A4 A4 G4-- D4 G4 G4 G4 D4 E4 E4 D4- B4 B4 A4 A4 G4--' },
  { id: 'bday', t: 'С днём рождения', a: 'Сёстры Хилл, 1893', lv: 1, bpm: 100, n: 'G4. G4/ A4 G4 C5 B4- G4. G4/ A4 G4 D5 C5- G4. G4/ G5 E5 C5 B4 A4- F5. F5/ E5 C5 D5 C5--' },
  { id: 'ode', t: 'Ода к радости', a: 'Бетховен', lv: 1, bpm: 110, n: 'E4 E4 F4 G4 G4 F4 E4 D4 C4 C4 D4 E4 E4. D4/ D4- E4 E4 F4 G4 G4 F4 E4 D4 C4 C4 D4 E4 D4. C4/ C4- D4 D4 E4 C4 D4 E4/ F4/ E4 C4 D4 E4/ F4/ E4 D4 C4 D4 G3- E4 E4 F4 G4 G4 F4 E4 D4 C4 C4 D4 E4 D4. C4/ C4-' },
  { id: 'jingle', t: 'Бубенцы', a: 'Пьерпонт', lv: 1, bpm: 150, n: 'E4 E4 E4- E4 E4 E4- E4 G4 C4. D4/ E4--- F4 F4 F4. F4/ F4 E4 E4 E4/ E4/ E4 D4 D4 E4 D4- G4- E4 E4 E4- E4 E4 E4- E4 G4 C4. D4/ E4--- F4 F4 F4. F4/ F4 E4 E4 E4/ E4/ G4 G4 F4 D4 C4---' },
  { id: 'yankee', t: 'Янки-дудл', a: 'Народная', lv: 1, bpm: 130, n: 'C4 C4 D4 E4 C4 E4 D4 G3 C4 C4 D4 E4 C4- B3- C4 C4 D4 E4 F4 E4 D4 C4 B3 G3 A3 B3 C4- C4-' },
  { id: 'august', t: 'Ах, мой милый Августин', a: 'Народная', lv: 1, bpm: 140, n: 'G4. A4/ G4 F4 E4 C4 C4 D4 G3 G3 E4 C4 C4 G4. A4/ G4 F4 E4 C4 C4 D4 G3 E4 C4--' },
  { id: 'brahms', t: 'Колыбельная', a: 'Брамс', lv: 1, bpm: 100, n: 'E4/ E4/ G4- E4/ E4/ G4- E4/ G4/ C5 B4. A4/ A4 G4 D4/ E4/ F4 D4 D4/ E4/ F4- D4/ F4/ B4/ A4/ G4 B4 C5- C4/ C4/ C5- A4/ F4/ G4- E4/ C4/ F4 G4 A4 G4- C4/ C4/ C5- A4/ F4/ G4- E4/ C4/ F4 E4 D4 C4--' },
  { id: 'morning', t: 'Утро', a: 'Григ', lv: 1, bpm: 90, n: 'G4/ E4/ D4/ C4/ D4/ E4/ G4/ E4/ D4/ C4/ D4/. E4// D4/. E4// G4/ E4/ G4/ A4/ E4/ A4/ G4/ E4/ D4/ C4-' },
  { id: 'wagner', t: 'Свадебный хор', a: 'Вагнер', lv: 1, bpm: 80, n: 'C4 F4. F4/ F4- C4 G4. E4/ F4- C4 F4. A#4/ A#4. A4/ G4. F4/ E4. F4/ G4-- C4 F4. F4/ F4- C4 G4. E4/ F4- C4 F4. A#4/ A#4 G4 E4. F4/ G4 A4 F4--' },
  { id: 'chopin', t: 'Похоронный марш', a: 'Шопен', lv: 1, bpm: 60, hw: 1, n: 'A#3 A#3. A#3/ A#3- C#4. C4/ C4. A#3/ A#3. A3/ A#3- A#3 A#3. A#3/ A#3- C#4. C4/ C4. A#3/ A#3. A3/ A#3-' },
  { id: 'fifth', t: 'Пятая симфония', a: 'Бетховен', lv: 1, bpm: 108, n: 'R/ G4/ G4/ G4/ D#4--- R/ F4/ F4/ F4/ D4--- R/ G4/ G4/ G4/ D#4/ G#4/ G#4/ G#4/ G4/ D#5/ D#5/ D#5/ C5-- R/ G4/ G4/ G4/ D4/ G#4/ G#4/ G#4/ G4/ F5/ F5/ F5/ D5--' },
  { id: 'elise', t: 'К Элизе', a: 'Бетховен', lv: 2, bpm: 70, n: 'E5/ D#5/ E5/ D#5/ E5/ B4/ D5/ C5/ A4 C4/ E4/ A4/ B4 E4/ G#4/ B4/ C5 E4/ E5/ D#5/ E5/ D#5/ E5/ B4/ D5/ C5/ A4 C4/ E4/ A4/ B4 E4/ C5/ B4/ A4--' },
  { id: 'korob', t: 'Коробейники', a: 'Народная', lv: 2, bpm: 140, n: 'E5 B4/ C5/ D5 C5/ B4/ A4 A4/ C5/ E5 D5/ C5/ B4. C5/ D5 E5 C5 A4 A4- R/ D5 F5/ A5 G5/ F5/ E5. C5/ E5 D5/ C5/ B4 B4/ C5/ D5 E5 C5 A4 A4-' },
  { id: 'king', t: 'В пещере горного короля', a: 'Григ', lv: 2, bpm: 100, hw: 1, n: 'B3/ C#4/ D4/ E4/ F#4/ D4/ F#4 F4/ C#4/ F4 E4/ C4/ E4 B3/ C#4/ D4/ E4/ F#4/ D4/ F#4/ B4/ A4/ F#4/ D4/ F#4/ A4-' },
  { id: 'toccata', t: 'Токката ре минор', a: 'Бах', lv: 2, bpm: 70, hw: 1, n: 'A5/ G5/ A5-- G5/ F5/ E5/ D5/ C#5- D5-- R A4/ G4/ A4-- E4 F4 C#4 D4-- R A3/ G3/ A3-- G3/ F3/ E3/ D3/ C#3- D3--' },
  { id: 'serenade', t: 'Маленькая ночная серенада', a: 'Моцарт', lv: 2, bpm: 120, n: 'G4 R/ D4/ G4 R/ D4/ G4/ D4/ G4/ B4/ D5- C5 R/ A4/ C5 R/ A4/ C5/ A4/ F#4/ A4/ D4-' },
  { id: 'cancan', t: 'Канкан', a: 'Оффенбах', lv: 2, bpm: 130, n: 'C4- D4/ F4/ E4/ D4/ G4 G4 G4/ A4/ E4/ F4/ D4 D4 D4/ F4/ E4/ D4/ C4/ C5/ B4/ A4/ G4/ F4/ E4/ D4/ C4- D4/ F4/ E4/ D4/ G4 G4 G4/ A4/ E4/ F4/ D4 D4 D4/ F4/ E4/ D4/ C4/ G4/ D4/ E4/ C4-' },
  { id: 'toreador', t: 'Марш тореадора', a: 'Бизе', lv: 2, bpm: 90, n: 'C5 D5/. C5// A4 A4 A4/ G4/ A4/ A#4/ A4-- A#4 G4. C5/ A4 F4. D4/ G4 C4-- C5 D5/. C5// A4 A4 A4/ G4/ A4/ A#4/ A4-- A#4 G4. C5/ A4 F4. D4/ G4 C4--' },
  { id: 'habanera', t: 'Хабанера', a: 'Бизе', lv: 2, bpm: 80, n: 'D5. C#5/ C5 C5 B4. A#4/ A4 A4 G#4 G4 F#4/ F4/ E4- R D5. C#5/ C5 C5 B4. A#4/ A4 A4 G#4 G4 F#4/ G4/ A4-' },
  { id: 'spring', t: 'Весна', a: 'Вивальди', lv: 2, bpm: 100, n: 'E4 G#4 G#4 G#4 F#4/ E4/ B4- B4/ A4/ G#4 G#4 G#4 F#4/ E4/ B4- B4/ A4/ G#4 A4/ B4/ A4 G#4 F#4-' },
  { id: 'swan', t: 'Лебединое озеро', a: 'Чайковский', lv: 2, bpm: 80, n: 'F#4-- B3/ C#4/ D4/ E4/ F#4. D4/ F#4. D4/ F#4. B3/ D4/ B3/ G3/ D4/ B3-- E4/ D4/ C#4/ B3/ C#4- D4. E4/ F#4- D4 F#4 D4 B3--' },
  { id: 'green', t: 'Зелёные рукава', a: 'Народная', lv: 2, bpm: 130, n: 'A4 C5- D5 E5. F5/ E5 D5- B4 G4. A4/ B4 C5- A4 A4. G#4/ A4 B4- G#4 E4- A4 C5- D5 E5. F5/ E5 D5- B4 G4. A4/ B4 C5. B4/ A4 G#4. F#4/ G#4 A4-- A4-' },
  { id: 'canon', t: 'Канон', a: 'Пахельбель', lv: 2, bpm: 80, n: 'F#5- E5- D5- C#5- B4- A4- B4- C#5- D5 C#5 B4 A4 G4 F#4 G4 E4 D4 F#4 A4 G4 F#4 D4 F#4 E4 D4 B3 D4 A4 G4 B4 A4 G4 F#4 D4 E4 C#5 D5 F#5 A5 A4 B4 G4 A4 F#4 D4 D5 D5--' },
  { id: 'danube', t: 'На прекрасном голубом Дунае', a: 'Штраус', lv: 2, bpm: 170, n: 'D4 D4 F#4 A4 A4- A5 A5- F#5 F#5- D4 D4 F#4 A4 A4- A5 A5- G5 G5- C#4 C#4 E4 B4 B4- B5 B5- G5 G5- C#4 C#4 E4 B4 B4- B5 B5- F#5 F#5- D4 D4 F#4 A4 D5- D6 D6- A5 A5- D4 D4 F#4 A4 D5- D6 D6- B5 B5--' },
  { id: 'minuet', t: 'Менуэт соль мажор', a: 'Бах', lv: 2, bpm: 120, n: 'D5 G4/ A4/ B4/ C5/ D5 G4 G4 E5 C5/ D5/ E5/ F#5/ G5 G4 G4 C5 D5/ C5/ B4/ A4/ B4 C5/ B4/ A4/ G4/ F#4 G4/ A4/ B4/ G4/ A4-- D5 G4/ A4/ B4/ C5/ D5 G4 G4 E5 C5/ D5/ E5/ F#5/ G5 G4 G4 C5 D5/ C5/ B4/ A4/ B4 C5/ B4/ A4/ G4/ A4 B4/ A4/ G4/ F#4/ G4--' },
  { id: 'mozart40', t: 'Симфония № 40', a: 'Моцарт', lv: 3, bpm: 110, n: 'D#5/ D5/ D5 D#5/ D5/ D5 D#5/ D5/ D5 A#5 R A#5/ A5/ G5 G5/ F5/ D#5 D#5/ D5/ C5 C5 R D5/ C5/ C5 D5/ C5/ C5 D5/ C5/ C5 A5 R A5/ G5/ F#5 F#5/ D#5/ D5 D5/ C5/ A#4 A#4 R' },
  { id: 'turca', t: 'Турецкий марш', a: 'Моцарт', lv: 3, bpm: 66, n: 'B4// A4// G#4// A4// C5- D5// C5// B4// C5// E5- F5// E5// D#5// E5// B5// A5// G#5// A5// B5// A5// G#5// A5// C6- A5/ C6/ B5/ A5/ G5/ A5/ B5/ A5/ G5/ A5/ B5/ A5/ G5/ F#5/ E5-' },
  { id: 'bee', t: 'Полёт шмеля', a: 'Римский-Корсаков', lv: 3, bpm: 60, n: 'E5// D#5// D5// C#5// D5// C#5// C5// B4// C5// B4// A#4// A4// G#4// G4// F#4// F4// E4// F4// E4// D#4// E4// F4// F#4// G4// G#4// A4// A#4// B4// C5// C#5// D5// D#5// E5// D#5// D5// C#5// C5// F5// E5// D#5// E5// D#5// D5// C#5// D5// C#5// C5// B4// E5-' },
];
const PIANO_COINS = { 1: 2, 2: 3, 3: 5 }; // за полностью сыгранную песню (+1 без ошибок), без дневного лимита
const PIANO_LV = { 1: 'Лёгкая', 2: 'Средняя', 3: 'Сложная' };

const PnAudio = {
  init() {
    try {
      if (!this.ctx) {
        const c = this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.comp = c.createDynamicsCompressor(); this.comp.connect(c.destination);
        this.master = c.createGain(); this.master.gain.value = 0.5; this.master.connect(this.comp);
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
    } catch (_) { }
  },
  // мягкий «фортепианный» звук из нескольких гармоник с затуханием
  note(m, dur) {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime, f = 440 * Math.pow(2, (m - 69) / 12), len = Math.max(0.7, Math.min(2.4, dur * 1.5 + 0.5));
    const g = c.createGain(), lp = c.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(Math.min(9000, f * 9), t); lp.frequency.exponentialRampToValueAtTime(Math.max(400, f * 1.6), t + 0.9);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.55, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.22, t + 0.15); g.gain.exponentialRampToValueAtTime(0.0006, t + len);
    lp.connect(g); g.connect(this.master);
    for (const [type, mul, vol, det] of [['triangle', 1, 0.75, 3], ['sine', 1, 0.5, -3], ['sine', 2, 0.22, 0], ['sine', 3, 0.07, 0], ['sine', 0.5, 0.16, 0]]) {
      const o = c.createOscillator(), og = c.createGain();
      o.type = type; o.frequency.value = f * mul; o.detune.value = det; og.gain.value = vol;
      o.connect(og); og.connect(lp); o.start(t); o.stop(t + len + 0.05);
    }
  },
  thud() {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime, o = c.createOscillator(), g = c.createGain();
    o.type = 'square'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(60, t + 0.25);
    g.gain.setValueAtTime(0.18, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t + 0.32);
  },
};

const Piano = {
  midi(s) { const m = /^([A-G])(#|b)?(-?\d)$/.exec(s); if (!m) return null; return { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + (+m[3] + 1) * 12; },
  // ноты песни → список клавиш { b: доля начала, d: длительность, m: midi }
  parse(song) {
    const one = [];
    let b = 0;
    for (const tok of song.n.split(/\s+/)) {
      const k = /^([A-G][#b]?-?\d|R)([\/\-\.]*)$/.exec(tok); if (!k) continue;
      let d = 1; for (const ch of k[2]) if (ch === '/') d /= 2;
      for (const ch of k[2]) if (ch === '-') d += 1;
      if (k[2].includes('.')) d *= 1.5;
      if (k[1] !== 'R') one.push({ b, d, m: this.midi(k[1]) });
      b += d;
    }
    // короткие песни повторяем, чтобы игра длилась хотя бы ~35 секунд
    const secs = b / (song.bpm / 60), reps = Math.max(1, Math.min(4, Math.ceil(35 / secs)));
    const out = []; const first = one.length ? one[0].b : 0;
    for (let r = 0; r < reps; r++) for (const x of one) out.push({ b: x.b - first + r * b, d: x.d, m: x.m });
    return out;
  },
  done() { const p = Pet.pet(); return (p && p.piano) || {}; },
  // ---------- список песен ----------
  list() {
    const p = Pet.pet();
    if (Pet.asleep()) { toast(`${p.name} спит 😴 Поиграем утром`); return; }
    PnAudio.init();
    this.stop();
    const box = $('#pgame'); box.classList.remove('hidden'); box.classList.add('pn');
    Pet.game = { id: 'piano', score: 0, over: false, timers: [() => this.stop(), () => box.classList.remove('pn')] };
    const done = this.done(), cnt = PIANO_SONGS.filter(s => done[s.id]).length;
    const stars = n => '⭐'.repeat(n) + '<span class="pn-off">' + '⭐'.repeat(3 - n) + '</span>';
    box.innerHTML = `<div class="pg-top"><button id="pg-x">✕</button><b class="pn-title">🎹 Пианино</b><span></span></div>
      <div class="pn-list">
        <div class="pn-intro">${Pet.svg({ mood: 'happy', hat: p.hat, costume: p.costume, lv: 5 })}<div><b>Выберите песню</b><small>Пройдено ${cnt} из ${PIANO_SONGS.length}. За каждую сыгранную до конца песню — монетки, сколько угодно раз 🪙</small></div></div>
        ${[1, 2, 3].map(lv => `<div class="pn-h">${PIANO_LV[lv]} <small>🪙 ${PIANO_COINS[lv]} за песню</small></div>` + PIANO_SONGS.filter(s => s.lv === lv).map(s => {
          const r = done[s.id];
          return `<button class="pn-song ${s.hw ? 'hw' : ''}" data-song="${s.id}"><span class="pn-ic">${s.hw ? '🎃' : '🎵'}</span><span class="pn-st"><b>${esc(s.t)}</b><small>${esc(s.a)}</small></span><span class="pn-rs">${r ? stars(r.st) + `<small>${esc(r.who === S.name ? 'вы' : r.who)}</small>` : '<small>▶ Играть</small>'}</span></button>`;
        }).join('')).join('')}
        <p class="gd-tip">Все мелодии — классика и народные песни. Звёзды: ⭐⭐⭐ — без ошибок.</p>
      </div>`;
    $('#pg-x').onclick = () => Pet.endGame(true);
    box.querySelector('.pn-list').onclick = e => { const b = e.target.closest('[data-song]'); if (b) this.start(b.dataset.song); };
  },
  // ---------- игра ----------
  start(id) {
    const song = PIANO_SONGS.find(s => s.id === id); if (!song) return;
    PnAudio.init(); this.stop();
    const p = Pet.pet(), box = $('#pgame');
    Pet.game = { id: 'piano', score: 0, over: false, timers: [() => this.stop(), () => box.classList.remove('pn')] };
    box.innerHTML = `<div class="pg-top"><button id="pg-x">✕</button><b id="pn-prog">0 / 0</b><span id="pn-lives">❤️❤️❤️</span></div>
      <div class="pn-stage">
        <div class="pn-coon-band"><div class="pn-coon" id="pn-coon">${Pet.svg({ mood: 'happy', hat: p.hat, costume: p.costume, lv: 5 })}</div>
          <svg class="pn-keys" viewBox="0 0 140 26">${Array.from({ length: 10 }, (_, i) => `<rect x="${i * 14}" y="0" width="13" height="26" rx="2" fill="#fff"/>`).join('')}${[0, 1, 3, 4, 5, 7, 8].map(i => `<rect x="${i * 14 + 9}" y="0" width="9" height="15" rx="1.5" fill="#2a2333"/>`).join('')}</svg>
          <b class="pn-song-t">${esc(song.t)}</b></div>
        <div class="pn-field" id="pn-field"><i class="pn-lane"></i><i class="pn-lane"></i><i class="pn-lane"></i><div class="pn-line" id="pn-line"></div><div class="pn-bar"><i id="pn-bar"></i></div></div>
      </div>`;
    $('#pg-x').onclick = () => this.list();
    const field = $('#pn-field'), H = field.clientHeight, W = field.clientWidth;
    const notes = this.parse(song);
    const minD = Math.min(...notes.map(x => x.d));
    const beatPx = Math.max(H * 0.2, Math.min(H * 0.45, 64 / minD));
    let prev = -1, prev2 = -1;
    for (const x of notes) {
      let lane; do { lane = Math.floor(Math.random() * 4); } while (lane === prev || (x.d < 0.5 && lane === prev2));
      prev2 = prev; prev = lane;
      x.lane = lane; x.h = Math.max(56, Math.min(beatPx * 2.2, x.d * beatPx - 4)); x.hb = x.h / beatPx;
    }
    const lineY = Math.round(H * 0.74);
    $('#pn-line').style.top = lineY + 'px';
    const g = this.g = { song, notes, beatPx, lineY, H, W, field, s: notes[0].b + 26 / beatPx, paused: true, hits: 0, lives: 3, miss: 0, last: performance.now(), over: false, mult: 1 };
    $('#pn-prog').textContent = `0 / ${notes.length}`;
    field.addEventListener('pointerdown', e => this.tap(e));
    const loop = t => { if (g.over || this.g !== g) return; this.frame(t); g.raf = requestAnimationFrame(loop); };
    g.raf = requestAnimationFrame(loop);
    this.vis = () => { if (document.hidden && !g.paused && !g.over) this.pause(); };
    document.addEventListener('visibilitychange', this.vis);
  },
  stop() {
    const g = this.g; if (g) { g.over = true; cancelAnimationFrame(g.raf); }
    this.g = null;
    if (this.vis) { document.removeEventListener('visibilitychange', this.vis); this.vis = null; }
  },
  pause() {
    const g = this.g; g.paused = true;
    const o = document.createElement('button'); o.className = 'pn-pause'; o.innerHTML = '⏸<b>Пауза</b><small>Нажмите, чтобы продолжить</small>';
    o.onclick = () => { o.remove(); g.last = performance.now(); g.paused = false; };
    g.field.appendChild(o);
  },
  frame(t) {
    const g = this.g, dt = Math.min(0.05, (t - g.last) / 1000); g.last = t;
    if (!g.paused) {
      // постепенно ускоряемся: к концу песни — в 1,3–1,5 раза быстрее
      g.mult = 1 + ({ 1: 0.5, 2: 0.45, 3: 0.3 }[g.song.lv]) * (g.hits / g.notes.length);
      g.s += dt * (g.song.bpm / 60) * g.mult;
    }
    for (const x of g.notes) {
      const bottom = g.lineY - (x.b - g.s) * g.beatPx, top = bottom - x.h;
      if (bottom < -20) break;
      if (!x.hit && !g.paused && g.s > x.b + x.hb + 0.02) { this.fail(x); return; }
      if (top > g.H + 20) { if (x.el) { x.el.remove(); x.el = null; } continue; }
      if (!x.el && !x.gone) {
        x.el = document.createElement('i');
        x.el.className = 'pn-tile' + (x.d >= 2 ? ' long' : '') + (g.song.hw ? ' hw' : '');
        x.el.style.cssText = `left:${x.lane * 25}%;height:${x.h}px`;
        if (g.paused && x === g.notes[0]) x.el.innerHTML = '<span>Жми!</span>';
        g.field.appendChild(x.el);
      }
      if (x.el) x.el.style.transform = `translate3d(0,${top}px,0)`;
    }
    if (g.hits === g.notes.length) {
      const last = g.notes[g.notes.length - 1];
      if (g.s > last.b + last.d + 0.6) this.win();
    }
  },
  tap(e) {
    const g = this.g; if (!g || g.over) return;
    if (e.target.closest('.pn-pause')) return;
    e.preventDefault();
    const r = g.field.getBoundingClientRect(), lane = Math.max(0, Math.min(3, Math.floor((e.clientX - r.left) / (r.width / 4))));
    let hit = null;
    for (const x of g.notes) {
      if (x.hit || x.lane !== lane) continue;
      const bottom = g.lineY - (x.b - g.s) * g.beatPx;
      if (bottom < g.lineY - 140) break;
      hit = x; break;
    }
    if (g.paused && hit !== g.notes[0] && !g.hits) return;
    if (!hit) { this.mistake(lane); return; }
    if (g.paused) { g.paused = false; g.last = performance.now(); }
    hit.hit = true; g.hits++;
    PnAudio.note(hit.m, hit.d / (g.song.bpm / 60));
    if (hit.el) { hit.el.classList.add('done'); hit.el.innerHTML = ''; const el = hit.el; hit.el = null; hit.gone = true; setTimeout(() => el.remove(), 260); el.style.transform = `translate3d(0,${g.lineY - (hit.b - g.s) * g.beatPx - hit.h}px,0)`; }
    $('#pn-prog').textContent = `${g.hits} / ${g.notes.length}`;
    $('#pn-bar').style.width = (g.hits / g.notes.length * 100) + '%';
    this.react(lane);
  },
  react(lane) {
    const c = $('#pn-coon'); if (!c) return;
    c.classList.remove('l', 'r'); void c.offsetWidth; c.classList.add(lane < 2 ? 'l' : 'r');
    if (Math.random() < 0.45) {
      const n = document.createElement('i'); n.className = 'pn-note'; n.textContent = ['♪', '♫', '♩', '♬'][Math.floor(Math.random() * 4)];
      n.style.left = (35 + Math.random() * 30) + '%'; n.style.color = ['#ff5f9e', '#a67bff', '#5ee7df', '#ffd34d'][Math.floor(Math.random() * 4)];
      c.parentNode.appendChild(n); setTimeout(() => n.remove(), 1100);
    }
  },
  flash(lane, cls) {
    const g = this.g, f = document.createElement('i'); f.className = 'pn-flash ' + cls; f.style.left = lane * 25 + '%';
    g.field.appendChild(f); setTimeout(() => f.remove(), 450);
  },
  mistake(lane) {
    const g = this.g; if (g.paused) return;
    g.lives--; g.miss++; PnAudio.thud(); vibrate(60); this.flash(lane, 'bad');
    $('#pn-lives').textContent = '❤️'.repeat(Math.max(0, g.lives)) + '🤍'.repeat(3 - Math.max(0, g.lives));
    const c = $('#pn-coon'); if (c) { c.classList.remove('ouch'); void c.offsetWidth; c.classList.add('ouch'); }
    if (g.lives <= 0) this.fail(null);
  },
  fail(x) {
    const g = this.g; g.over = true; cancelAnimationFrame(g.raf);
    PnAudio.thud(); vibrate([60, 40, 60]);
    if (x && x.el) x.el.classList.add('missed');
    const c = $('#pn-coon'); if (c) c.innerHTML = Pet.svg({ mood: 'sad', hat: Pet.pet().hat, costume: Pet.pet().costume, lv: 5 });
    if (typeof Season !== 'undefined' && g.hits > 0) Season.track('game', 1, { game: 'piano', score: g.hits });
    setTimeout(() => { if (this.g === g) this.end(false); }, 1300);
  },
  win() {
    const g = this.g; g.over = true; cancelAnimationFrame(g.raf);
    const p = Pet.pet(), st = g.miss === 0 ? 3 : g.miss === 1 ? 2 : 1;
    const coins = PIANO_COINS[g.song.lv] + (g.miss === 0 ? 1 : 0);
    const piano = Object.assign({}, p.piano || {}), old = piano[g.song.id];
    if (!old || st > old.st) piano[g.song.id] = { st, who: S.name };
    const xp = !Pet.cool('pnxp', 10 * 60000);
    Pet.save({ piano, coins: (p.coins || 0) + coins, joy: Pet.stats(p).joy + 6, xp: xp ? Pet.addXp(4) : (p.xp || 0) }, `сыграл(а) на пианино «${g.song.t}» ${'⭐'.repeat(st)}`);
    if (typeof Season !== 'undefined') { Season.track('game', 1, { game: 'piano', score: g.hits }); Season.track('pianoWin'); }
    g.coins = coins; g.st = st;
    vibrate([20, 40, 20, 40, 60]);
    this.end(true);
  },
  end(won) {
    const g = this.g, p = Pet.pet(), box = $('#pgame');
    const pct = Math.round(g.hits / g.notes.length * 100);
    this.stop();
    box.innerHTML = `<div class="pg-end">${Pet.svg({ mood: won ? 'happy' : 'sad', hat: p.hat, costume: p.costume, lv: 5 })}
      <b>${won ? '🎉 Песня сыграна!' : 'Ой! Клавиша убежала…'}</b>
      ${won ? `<div class="pn-stars">${'⭐'.repeat(g.st)}<span class="pn-off">${'⭐'.repeat(3 - g.st)}</span></div><div class="pg-big">+🪙 ${g.coins}</div><small>${esc(g.song.t)} · ошибок: ${g.miss}</small>`
        : `<div class="pg-big">${pct}%</div><small>${esc(g.song.t)} — сыграно ${g.hits} из ${g.notes.length} нот. Монетки — за песню до конца.</small>`}
      <div class="pg-btns"><button class="btn" id="pn-again">Ещё раз</button><button class="btn primary" id="pn-list">К песням</button></div></div>`;
    Pet.game = { id: 'piano', score: 0, over: false, timers: [() => box.classList.remove('pn')] };
    $('#pn-again').onclick = () => this.start(g.song.id);
    $('#pn-list').onclick = () => this.list();
  },
  // «назад» на телефоне: из игры — к списку песен
  back() {
    if ($('#pgame').classList.contains('hidden') || !$('#pgame').classList.contains('pn')) return false;
    if (this.g || $('#pn-again')) { this.list(); return true; }
    return false;
  },
};

// подключаем к играм енота
GAMES.push({ id: 'piano', e: '🎹', t: 'Пианино', d: 'Нажимайте клавиши на линии под музыку. 30+ мелодий, монетки за каждую песню — без лимита!' });
(() => {
  const start = Pet.startGame.bind(Pet);
  Pet.startGame = function (id) { if (id === 'piano') { Piano.list(); return; } return start(id); };
  const dg = Pet.drawGames.bind(Pet);
  Pet.drawGames = function (p) {
    dg(p);
    const i = document.querySelector('.pg-card[data-game="piano"] .pg-t i');
    if (i) { const done = p.piano || {}; i.textContent = `🎵 Пройдено песен: ${PIANO_SONGS.filter(s => done[s.id]).length} из ${PIANO_SONGS.length}`; }
  };
})();
