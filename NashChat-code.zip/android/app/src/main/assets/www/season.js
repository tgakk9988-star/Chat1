'use strict';
/* «Наш чат» — 🎃 сезон «Хэллоуин»: задания → 🍬 конфеты → хэллоуинские вещи для енота и комнаты.
   Конфеты общие на двоих, задания у каждого свои. Шкала пасса даёт бесплатные награды. */

const SEASON = { id: 'hw2026', t: 'Хэллоуин', e: '🎃', end: new Date(2026, 10, 30, 23, 59) };
const HW_ITEMS = [
  { id: 'hw_room', e: '🌙', t: 'Ночная комната', d: 'Тёмные стены, луна и звёзды', price: 150, kind: 'room' },
  { id: 'hw_web', e: '🕸', t: 'Паутина', price: 50, kind: 'decor' },
  { id: 'hw_bats', e: '🦇', t: 'Летучие мышки', price: 80, kind: 'decor' },
  { id: 'hw_lanterns', e: '🎃', t: 'Тыквы-фонари', price: 90, kind: 'decor' },
  { id: 'hw_candles', e: '🕯', t: 'Свечи', price: 60, kind: 'decor' },
  { id: 'hw_ghost', e: '👻', t: 'Привидение-друг', price: 120, kind: 'decor' },
  { id: 'witch', e: '🧙', t: 'Шляпа ведьмы', price: 100, kind: 'hat' },
  { id: 'pumpkinhat', e: '🎃', t: 'Тыква на голову', price: 110, kind: 'hat' },
  { id: 'cape', e: '🧛', t: 'Плащ вампира', price: 140, kind: 'costume' },
  { id: 'sheet', e: '👻', t: 'Костюм привидения', price: 160, kind: 'costume' },
];
// бесплатные награды пасса — только здесь
const HW_PASS = [
  { at: 40, id: 'hw_spider', e: '🕷', t: 'Паучок на ниточке', kind: 'decor' },
  { at: 120, id: 'hw_broom', e: '🧹', t: 'Волшебная метла', kind: 'decor' },
  { at: 250, id: 'hw_cauldron', e: '🧪', t: 'Котёл с зельем', kind: 'decor' },
  { at: 400, id: 'pkcrown', e: '👑', t: 'Тыквенная корона', kind: 'hat' },
  { at: 600, id: 'hw_moonbig', e: '🌕', t: 'Кровавая луна', kind: 'decor' },
];
const HW_DAILY = [
  { id: 'feed2', t: 'Покормите енота 2 раза', ev: 'feed', n: 2, r: 15 },
  { id: 'pet5', t: 'Погладьте енота 5 раз', ev: 'pet', n: 5, r: 10 },
  { id: 'water3', t: 'Полейте грядки 3 раза', ev: 'water', n: 3, r: 12 },
  { id: 'game1', t: 'Сыграйте в мини-игру', ev: 'game', n: 1, r: 12 },
  { id: 'catch15', t: 'Поймайте 15 вкусняшек за игру', ev: 'catchScore', n: 15, r: 20 },
  { id: 'bub20', t: 'Лопните 20 пузырей за игру', ev: 'bubScore', n: 20, r: 20 },
  { id: 'harvest1', t: 'Соберите урожай', ev: 'harvest', n: 1, r: 12 },
  { id: 'plant2', t: 'Посадите 2 растения', ev: 'plant', n: 2, r: 10 },
  { id: 'wash1', t: 'Помойте енота', ev: 'wash', n: 1, r: 10 },
  { id: 'think1', t: 'Отправьте «💗 Думаю о тебе»', ev: 'think', n: 1, r: 10 },
  { id: 'piano1', t: 'Сыграйте песню на пианино до конца', ev: 'pianoWin', n: 1, r: 15 },
  { id: 'play1', t: 'Поиграйте с енотом мячиком', ev: 'play', n: 1, r: 10 },
];
const HW_SEASONAL = [
  { id: 's_days', t: 'Заходите к еноту 7 разных дней', ev: 'day', n: 7, r: 120 },
  { id: 's_pumpkin', t: 'Вырастите 4 тыквы 🎃', ev: 'pumpkin', n: 4, r: 100 },
  { id: 's_games', t: 'Сыграйте 15 мини-игр', ev: 'game', n: 15, r: 90 },
  { id: 's_feed', t: 'Покормите енота 25 раз', ev: 'feed', n: 25, r: 90 },
  { id: 's_record', t: 'Поставьте рекорд в любой игре', ev: 'record', n: 1, r: 50 },
];

const Season = {
  KEY: 'nc_season',
  active() { return Date.now() < SEASON.end.getTime(); },
  st() {
    let j = null; try { j = JSON.parse(localStorage.getItem(this.KEY) || 'null'); } catch (_) { }
    if (!j || j.sid !== SEASON.id) j = { sid: SEASON.id, day: '', d: {}, dc: {}, s: {}, sc: {}, days: {} };
    const today = ymd(new Date());
    if (j.day !== today) { j.day = today; j.d = {}; j.dc = {}; }
    return j;
  },
  save(j) { try { localStorage.setItem(this.KEY, JSON.stringify(j)); } catch (_) { } },
  // 4 задания на сегодня — у каждого свои
  daily() {
    let seed = 0; for (const ch of ymd(new Date()) + S.dev) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
    const pool = HW_DAILY.slice(), out = [];
    while (out.length < 4 && pool.length) { seed = (seed * 1664525 + 1013904223) >>> 0; out.push(pool.splice(seed % pool.length, 1)[0]); }
    return out;
  },
  track(ev, n, extra) {
    if (!this.active() || !CHAT.isPair()) return;
    const j = this.st();
    const add = (k, v) => { j.d[k] = (j.d[k] || 0) + v; j.s[k] = (j.s[k] || 0) + v; };
    if (ev === 'game') {
      add('game', 1);
      if (extra && extra.game === 'catch') j.d.catchScore = Math.max(j.d.catchScore || 0, extra.score);
      if (extra && extra.game === 'bubbles') j.d.bubScore = Math.max(j.d.bubScore || 0, extra.score);
    } else add(ev, n === undefined ? 1 : n);
    if (!j.days[j.day]) { j.days[j.day] = 1; j.s.day = Object.keys(j.days).length; }
    this.save(j);
    const ready = this.daily().some(q => !j.dc[q.id] && (j.d[q.ev] || 0) >= q.n) || HW_SEASONAL.some(q => !j.sc[q.id] && (j.s[q.ev] || 0) >= q.n);
    if (ready && !this.toasted) { this.toasted = true; setTimeout(() => { this.toasted = false; }, 60000); toast('🎃 Задание выполнено — заберите конфеты в «Сезоне»!', 3500); }
  },
  candy() { const p = Pet.pet(); return (p && p.candy) || 0; },
  owned() { const p = Pet.pet(); return new Set((p && p.hw) || []); },
  claim(q, seasonal) {
    const j = this.st(), done = seasonal ? j.sc : j.dc;
    if (done[q.id]) return;
    done[q.id] = 1; this.save(j);
    const p = Pet.pet(), total = (p.candyTotal || 0) + q.r;
    const passNew = HW_PASS.filter(x => x.at > (p.candyTotal || 0) && x.at <= total);
    const hw = [...new Set([...(p.hw || []), ...passNew.map(x => x.id)])];
    Pet.save({ candy: (p.candy || 0) + q.r, candyTotal: total, hw }, `выполнил(а) задание «${q.t}» +🍬${q.r}`);
    toast(`+🍬 ${q.r}` + (passNew.length ? ` · награда пасса: ${passNew.map(x => x.e + ' ' + x.t).join(', ')}!` : ''), 3500);
    vibrate([15, 30, 15]); Pet.anim && Pet.anim('hearts', 6);
    setTimeout(() => Pet.draw(), 80);
  },
  buy(it) {
    const p = Pet.pet(), own = this.owned();
    if (own.has(it.id)) { this.toggle(it); return; }
    if ((p.candy || 0) < it.price) { toast(`Не хватает 🍬 ${it.price - (p.candy || 0)}`); return; }
    sheet([{ icon: 'check', label: `Купить ${it.e} «${it.t}» за 🍬 ${it.price}`, fn: () => {
      const q = Pet.pet(); if ((q.candy || 0) < it.price) return;
      const patch = { candy: q.candy - it.price, hw: [...(q.hw || []), it.id] };
      if (it.kind === 'hat') patch.hat = it.id; else if (it.kind === 'costume') patch.costume = it.id;
      Pet.save(patch, `купил(а) ${it.e} ${it.t.toLowerCase()} 🎃`);
      toast(`${it.e} Куплено!`); vibrate([15, 30, 15]); setTimeout(() => Pet.draw(), 80);
    } }], it.d || '');
  },
  // надеть / снять / убрать из комнаты
  toggle(it) {
    const p = Pet.pet();
    if (it.kind === 'hat') Pet.save({ hat: p.hat === it.id ? '' : it.id });
    else if (it.kind === 'costume') Pet.save({ costume: p.costume === it.id ? '' : it.id });
    else { const off = p.hwOff || [], n = off.includes(it.id) ? off.filter(x => x !== it.id) : [...off, it.id]; Pet.save({ hwOff: n }); }
    setTimeout(() => Pet.draw(), 80);
  },
  isOn(p, it) { if (it.kind === 'hat') return p.hat === it.id; if (it.kind === 'costume') return p.costume === it.id; return !(p.hwOff || []).includes(it.id); },
  draw(p) {
    const j = this.st(), candy = p.candy || 0, total = p.candyTotal || 0, own = this.owned();
    const daysLeft = Math.max(0, Math.ceil((SEASON.end - Date.now()) / 86400000));
    const maxAt = HW_PASS[HW_PASS.length - 1].at;
    const q = (x, seasonal) => {
      const have = Math.min(x.n, (seasonal ? j.s : j.d)[x.ev] || 0), done = (seasonal ? j.sc : j.dc)[x.id];
      return `<div class="hw-q ${done ? 'done' : ''}"><div class="hw-qt"><b>${esc(x.t)}</b><span class="hw-qbar"><i style="width:${Math.round(have / x.n * 100)}%"></i></span><small>${have} / ${x.n}</small></div>
        ${done ? '<span class="hw-ok">✅</span>' : have >= x.n ? `<button class="hw-claim" data-claim="${x.id}" data-s="${seasonal ? 1 : 0}">+🍬${x.r}</button>` : `<span class="hw-r">🍬${x.r}</span>`}</div>`;
    };
    const item = it => {
      const has = own.has(it.id), on = has && this.isOn(p, it);
      return `<button class="hw-it ${on ? 'on' : ''}" data-hw="${it.id}"><span>${it.e}</span><b>${esc(it.t)}</b><small>${has ? (on ? (it.kind === 'hat' || it.kind === 'costume' ? '✅ Надето · снять' : '✅ Стоит · убрать') : (it.kind === 'hat' || it.kind === 'costume' ? 'Надеть' : 'Поставить')) : this.active() ? '🍬 ' + it.price : 'Сезон закончился'}</small></button>`;
    };
    $('#pet-body').innerHTML = `
      <div class="hw-banner"><div class="hw-bats">🦇 🦇</div><b>🎃 ${SEASON.t}</b><span>${this.active() ? `Сезон идёт ещё ${daysLeft} ${plural(daysLeft, 'день', 'дня', 'дней')}` : 'Сезон закончился — купленное остаётся навсегда'}</span><div class="hw-candy">🍬 <b>${candy}</b> <small>конфет на двоих</small></div></div>
      <div class="hw-h">🎟 Пасс сезона <small>собрано за сезон: ${total} 🍬</small></div>
      <div class="hw-pass"><div class="hw-track"><i style="width:${Math.min(100, total / maxAt * 100)}%"></i></div>
        ${HW_PASS.map(x => `<div class="hw-pt ${total >= x.at ? 'got' : ''}" style="left:${x.at / maxAt * 100}%"><span>${x.e}</span><small>${x.at}</small></div>`).join('')}</div>
      <div class="hw-pass-names">${HW_PASS.map(x => `<span class="${total >= x.at ? 'got' : ''}">${x.e} ${esc(x.t)}</span>`).join('')}</div>
      ${this.active() ? `<div class="hw-h">📋 Задания на сегодня <small>обновятся завтра</small></div>${this.daily().map(x => q(x, false)).join('')}
      <div class="hw-h">🏆 Задания сезона</div>${HW_SEASONAL.map(x => q(x, true)).join('')}` : ''}
      <div class="hw-h">🛍 Хэллоуинская лавка</div><div class="ps-grid">${HW_ITEMS.map(item).join('')}</div>
      ${HW_PASS.some(x => own.has(x.id)) ? `<div class="hw-h">🎁 Награды пасса</div><div class="ps-grid">${HW_PASS.filter(x => own.has(x.id)).map(x => item(Object.assign({}, x, { price: 0 }))).join('')}</div>` : ''}
      <p class="gd-tip">Задания у каждого свои, а конфеты — общие. Выполняйте вместе, чтобы пройти пасс до конца!</p>`;
  },
  // ---------- рисуем хэллоуин ----------
  roomLayer(p) {
    const own = new Set(p.hw || []), off = new Set(p.hwOff || []), on = id => own.has(id) && !off.has(id);
    let g = '';
    if (on('hw_moonbig')) g += '<circle cx="250" cy="44" r="26" fill="#ff7b5c" opacity=".85"/><circle cx="244" cy="38" r="26" fill="none"/>';
    if (on('hw_web')) g += '<g stroke="rgba(255,255,255,.75)" stroke-width="1" fill="none"><path d="M0 0l52 52M0 0l26 56M0 0l56 24M8 8q8 6 16-2M16 18q14 10 28-4M26 30q18 14 38-6"/><path d="M320 0l-52 52M320 0l-26 56M320 0l-56 24M312 8q-8 6-16-2M304 18q-14 10-28-4M294 30q-18 14-38-6"/></g>';
    if (on('hw_spider')) g += '<g class="hw-spider"><path d="M150 0v46" stroke="rgba(255,255,255,.8)" stroke-width="1"/><ellipse cx="150" cy="52" rx="7" ry="8" fill="#2a2333"/><path d="M143 48l-8-4M143 52l-9 0M143 56l-8 4M157 48l8-4M157 52l9 0M157 56l8 4" stroke="#2a2333" stroke-width="2" stroke-linecap="round"/><circle cx="147" cy="50" r="1.4" fill="#ff5f5f"/><circle cx="153" cy="50" r="1.4" fill="#ff5f5f"/></g>';
    if (on('hw_bats')) g += [[40, 30, 0], [200, 22, .6], [120, 50, 1.2]].map(([x, y, d]) => `<g transform="translate(${x} ${y})"><g class="hw-bat" style="animation-delay:${d}s"><path d="M0 0c-6-6-14-6-18 0 4-1 7 1 8 4 2-3 5-3 7-1 1-3 2-3 3-3s2 0 3 3c2-2 5-2 7 1 1-3 4-5 8-4-4-6-12-6-18 0z" fill="#2a2333"/></g></g>`).join('');
    if (on('hw_candles')) g += [36, 60].map(x => `<g transform="translate(${x} 168)"><rect x="-5" y="0" width="10" height="22" rx="2" fill="#f4ead2"/><path class="hw-flame" d="M0-12c4 5 4 9 0 11-4-2-4-6 0-11z" fill="#ffb84d"/></g>`).join('');
    if (on('hw_broom')) g += '<g transform="translate(296 108) rotate(14)"><path d="M0 0v74" stroke="#8a5a3a" stroke-width="4"/><path d="M-10 74h20l6 26h-32z" fill="#e0b24a"/><path d="M-6 80l-3 20M0 80v20M6 80l3 20" stroke="#b58a2e"/></g>';
    if (on('hw_cauldron')) g += '<g transform="translate(70 168)"><ellipse cx="0" cy="18" rx="28" ry="20" fill="#2a2333"/><ellipse cx="0" cy="2" rx="24" ry="6" fill="#58e07a"/><circle class="hw-bubble" cx="-6" cy="-4" r="4" fill="#7cf09a"/><circle class="hw-bubble" cx="8" cy="-8" r="3" fill="#7cf09a" style="animation-delay:.6s"/></g>';
    if (on('hw_lanterns')) g += [[264, 178, 1], [300, 186, .8]].map(([x, y, s]) => `<g transform="translate(${x} ${y}) scale(${s})"><ellipse rx="18" ry="15" fill="#ff8a1f"/><path d="M-6-14q6-4 12 0" stroke="#d96a00" fill="none"/><path d="M-2-15l2-7 3 1-2 6z" fill="#4f7a2a"/><path d="M-9-3l4-4 4 4zM1-3l4-4 4 4z" fill="#ffe27a"/><path d="M-10 4q10 8 20 0l-3 3-3-2-4 3-4-3-3 2z" fill="#ffe27a"/></g>`).join('');
    if (on('hw_ghost')) g += '<g transform="translate(40 70)"><g class="hw-ghostf"><path d="M0 30V12a16 16 0 0 1 32 0v18l-5-4-5 4-6-4-5 4-5-4z" fill="#fff" opacity=".92"/><circle cx="11" cy="12" r="2.6" fill="#2a2333"/><circle cx="21" cy="12" r="2.6" fill="#2a2333"/><ellipse cx="16" cy="19" rx="3" ry="2" fill="#2a2333"/></g></g>';
    return g;
  },
  night(p) { const own = new Set(p.hw || []), off = new Set(p.hwOff || []); return own.has('hw_room') && !off.has('hw_room'); },
};

// подключаем к еноту: ночная комната и хэллоуинский декор
(() => {
  const room = Pet.room.bind(Pet);
  Pet.room = function (p) {
    let svg = room(p);
    if (Season.night(p)) svg = svg.replace(/fill="#(fbe7d0|e8e2ff)"/, 'fill="#2e2448"').replace(/fill="#(e2b98f|ecc9a2)"/, 'fill="#4a3b5e"')
      .replace('<path d="M0 150h320"', '<circle cx="60" cy="40" r="18" fill="#fff6c9"/><circle cx="52" cy="35" r="17" fill="#2e2448"/>' + [[120, 20], [180, 50], [220, 18], [280, 60], [30, 100], [150, 90]].map(([x, y], i) => `<circle class="hw-star" style="animation-delay:${i * .4}s" cx="${x}" cy="${y}" r="1.8" fill="#fff"/>`).join('') + '<path d="M0 150h320"');
    const i = svg.lastIndexOf('</svg>');
    return i > 0 ? svg.slice(0, i) + Season.roomLayer(p) + svg.slice(i) : svg;
  };
})();
// учёт заданий — по записям в журнале енота (так ловим и посадку из меню, и урожай)
(() => {
  const save = Pet.save.bind(Pet);
  Pet.save = function (patch, log) {
    if (log) {
      const L = [[/^погладил/, 'pet'], [/^покормил/, 'feed'], [/^помыл/, 'wash'], [/^поиграл\(а\) с енотом/, 'play'], [/^посадил/, 'plant'], [/^полил/, 'water'], [/^собрал\(а\) урожай/, 'harvest'], [/новый рекорд/, 'record']];
      for (const [re, ev] of L) if (re.test(log)) Season.track(ev);
      if (/^собрал\(а\) урожай: 🎃/.test(log)) Season.track('pumpkin');
    }
    return save(patch, log);
  };
  const ts = Think.send.bind(Think); Think.send = function () { Season.track('think'); return ts.apply(null, arguments); };
  const open = Pet.open.bind(Pet); Pet.open = function () { const r = open.apply(null, arguments); Season.track('visit', 0); return r; };
})();
$('#pet-body').addEventListener('click', e => {
  const c = e.target.closest('[data-claim]');
  if (c) { const s = c.dataset.s === '1', q = (s ? HW_SEASONAL : HW_DAILY).find(x => x.id === c.dataset.claim); if (q) Season.claim(q, s); return; }
  const h = e.target.closest('[data-hw]');
  if (h) {
    const id = h.dataset.hw, it = HW_ITEMS.find(x => x.id === id) || HW_PASS.find(x => x.id === id);
    if (!it) return;
    if (Season.owned().has(id)) Season.toggle(it);
    else if (Season.active() && it.price) Season.buy(it);
  }
});
