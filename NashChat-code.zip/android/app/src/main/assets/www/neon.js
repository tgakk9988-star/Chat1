'use strict';
/* «Наш чат» — неоновые иконки меню (нарисованы для приложения, без чужих картинок). */
const NEON = {
  chats: ['#34f5ff', '<path d="M4 4h11a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H9l-4 3v-3H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M20 9a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2v3l-4-3h-4"/><path d="M6 8h7M6 11h4"/>'],
  newchat: ['#3dffa8', '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>'],
  pins: ['#ff5a8a', '<path d="M9 3h6l-1 6 3.5 3.5h-11L10 9z"/><path d="M12 12.5V21"/>'],
  invite: ['#ffc24a', '<circle cx="8" cy="15" r="4.5"/><path d="M11.2 11.8 20 3M16.5 6.5l3 3M14 9l2 2"/>'],
  members: ['#7aa8ff', '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.4 2.7-6 6-6s6 2.6 6 6"/><circle cx="17.2" cy="9" r="2.5"/><path d="M16.5 14.2c2.8.3 4.5 2.4 4.5 5"/>'],
  gedit: ['#ff9b4a', '<path d="M4 20l1-4.5L16.5 4a2.1 2.1 0 0 1 3 3L8 18.5z"/><path d="M14.5 6l3 3"/><path d="M13 20h7"/>'],
  gphoto: ['#5ee7df', '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="M21 15.5l-4.5-4.5L7 20"/>'],
  watch: ['#a67bff', '<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/><path d="M10.5 8.5v5l4-2.5z"/>'],
  cal: ['#ff5a6e', '<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18M8 3v4M16 3v4"/><path d="M7.5 14h.01M12 14h.01M16.5 14h.01M7.5 17.5h.01M12 17.5h.01"/>'],
  notes: ['#ffe14a', '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/><path d="M9 12h7M9 15.5h7M9 19h4"/>'],
  bank: ['#3dffa8', '<ellipse cx="12" cy="6.5" rx="8" ry="3"/><path d="M4 6.5v5c0 1.7 3.6 3 8 3s8-1.3 8-3v-5"/><path d="M4 11.5v5c0 1.7 3.6 3 8 3s8-1.3 8-3v-5"/>'],
  gifts: ['#ff4fd8', '<rect x="3" y="8" width="18" height="4.5" rx="1"/><path d="M5 12.5V21h14v-8.5M12 8v13"/><path d="M12 8C10.5 4 6.5 3.5 6.5 6S12 8 12 8zm0 0c1.5-4 5.5-4.5 5.5-2S12 8 12 8z"/>'],
  stickers: ['#ff4f8b', '<path d="M12 20.5s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.6a4.2 4.2 0 0 1 7.5 2.6c0 5.7-7.5 10.3-7.5 10.3z"/><path d="M8.5 10.5a1.8 1.8 0 0 1 1.8-1.8"/>'],
  look: ['#34f5ff', '<path d="M12 3a9 9 0 1 0 0 18c1.2 0 1.6-.9 1.6-1.6 0-1.4-1.2-2 0-3.1 1-1 3-.5 4.6-.5A2.8 2.8 0 0 0 21 13c0-5.5-4-10-9-10z"/><path d="M7.5 12h.01M9.5 7.5h.01M14.5 7.5h.01M17 11h.01"/>'],
  fx: ['#ffc24a', '<path d="M11 3l1.9 5.1L18 10l-5.1 1.9L11 17l-1.9-5.1L4 10l5.1-1.9z"/><path d="M18.5 14.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>'],
  settings: ['#9fd0ff', '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/><circle cx="12" cy="12" r="6.3"/>'],
  srv: ['#4da3ff', '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01M11 7.5h6M11 16.5h6"/>'],
  leave: ['#ff5a6e', '<path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4"/><path d="M10 16l-4-4 4-4M6 12h10"/>'],
  creators: ['#b47bff', '<path d="M10.6 9.2C8.5 7.5 5 6.2 1.5 6c1.5 2.2 1.9 4.2 1.7 6.4 1.4-1 2.8-.9 3.6.4.9-1.1 2.2-1.1 3.2.6.8 1 1.5 2.2 2 3.4.5-1.2 1.2-2.4 2-3.4 1-1.7 2.3-1.7 3.2-.6.8-1.3 2.2-1.4 3.6-.4-.2-2.2.2-4.2 1.7-6.4-3.5.2-7 1.5-9.1 3.2l-.2-2.6-.8 1.5h-.8l-.8-1.5z"/><path d="M11.3 10.3h.01M12.7 10.3h.01"/>'],
};
function neonSvg(act, size) {
  const n = NEON[act]; if (!n) return '';
  return `<svg class="neon" viewBox="0 0 24 24" width="${size || 24}" height="${size || 24}" fill="none" stroke="${n[0]}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" style="--n:${n[0]}">${n[1]}</svg>`;
}
document.querySelectorAll('.dr-ic').forEach(el => {
  const act = (el.className.match(/ic-([a-z]+)/) || [])[1];
  if (NEON[act]) { el.innerHTML = neonSvg(act); el.style.setProperty('--n', NEON[act][0]); el.classList.add('neon-tile'); }
});
{ const b = document.querySelector('.dr-creators img'); if (b) b.outerHTML = neonSvg('creators', 18); }
{ const c = document.querySelector('.cr-card img'); if (c) c.outerHTML = neonSvg('creators', 92).replace('class="neon"', 'class="neon cr-gem"').replace('stroke-width="1.7"', 'stroke-width="1.1"'); }
