'use strict';
/* «Наш чат» — 🦝 домик, мебель, монетки и мини-игры с енотом. Всё нарисовано для приложения. */

const PET_PRICE = { carrot: 3, straw: 4, corn: 6, blue: 6, apple: 8, grape: 10, pumpkin: 14, melon: 18 };
const HOUSES = [
  { id: 'box', e: '📦', t: 'Картонная коробка', price: 60 },
  { id: 'tent', e: '🛖', t: 'Уютный шалаш', price: 200 },
  { id: 'wood', e: '🏡', t: 'Деревянный домик', price: 500 },
  { id: 'tree', e: '🌳', t: 'Домик на дереве', price: 1000 },
  { id: 'castle', e: '🏰', t: 'Замок', price: 2500 },
];
const DECOR = [
  { id: 'rug', e: '🟠', t: 'Пушистый коврик', price: 40 },
  { id: 'pic', e: '🖼', t: 'Картина с сердечком', price: 80 },
  { id: 'plant', e: '🪴', t: 'Цветок в горшке', price: 60 },
  { id: 'lamp', e: '✨', t: 'Гирлянда', price: 90 },
  { id: 'bed', e: '🛏', t: 'Мягкая лежанка', price: 120 },
];
const GAMES = [
  { id: 'catch', e: '🍎', t: 'Лови вкусняшки', d: 'Двигайте енота пальцем и ловите фрукты. Носки и камешки — мимо!' },
  { id: 'pairs', e: '🃏', t: 'Найди пару', d: 'Переворачивайте карточки и находите одинаковые. Чем быстрее — тем больше очков.' },
  { id: 'bubbles', e: '🫧', t: 'Лопни пузыри', d: 'Енот пускает пузыри — лопайте их, пока не улетели. Золотые — ×3!' },
];
const PAID_PLAYS = 6; // сколько раз в день игра даёт монетки

Object.assign(Pet, {
  coins() { const p = this.pet(); return (p && p.coins) || 0; },
  addCoins(n, log) { const p = this.pet(); return this.save({ coins: Math.max(0, (p.coins || 0) + n) }, log); },
  // ---------- комната ----------
  room(p) {
    const house = p.house || '', d = new Set(p.decor || []);
    const H = {
      box: '<g transform="translate(18 92)"><path d="M0 30 60 30 60 100 0 100z" fill="#c9965e"/><path d="M0 30 18 12 78 12 60 30z" fill="#dcae78"/><path d="M60 30 78 12 78 82 60 100z" fill="#b5834e"/><path d="M14 52h32v48H14z" fill="#3a2a1e" opacity=".75"/><text x="30" y="44" font-size="9" fill="#7a4e31" text-anchor="middle">НАШ</text></g>',
      tent: '<g transform="translate(10 70)"><path d="M50 0 0 122h100z" fill="#e9a35b"/><path d="M50 0 22 122h56z" fill="#f6c47e"/><path d="M50 50 36 122h28z" fill="#5a3a24"/><path d="M50-8v18M44-10l6 8M56-10l-6 8" stroke="#7a4e31" stroke-width="3" stroke-linecap="round"/><path d="M56 6l18-6-18 12z" fill="#ff5f9e"/></g>',
      wood: '<g transform="translate(6 62)"><path d="M6 52h96v80H6z" fill="#b97a4a"/><path d="M6 64h96M6 80h96M6 96h96M6 112h96" stroke="#9a6236" stroke-width="2"/><path d="M-4 56 54 10l58 46z" fill="#c0392b"/><path d="M40 92h26v40H40z" fill="#6d4027"/><circle cx="61" cy="113" r="2" fill="#ffd34d"/><rect x="14" y="74" width="18" height="16" fill="#ffe9a8" stroke="#6d4027" stroke-width="3"/><rect x="76" y="74" width="18" height="16" fill="#ffe9a8" stroke="#6d4027" stroke-width="3"/><path d="M80 20v20h12V30z" fill="#8a5a3a"/></g>',
      tree: '<g transform="translate(0 20)"><path d="M48 180V80h22v100z" fill="#7a4e31"/><circle cx="58" cy="40" r="44" fill="#5fb84f"/><circle cx="30" cy="60" r="28" fill="#4caf50"/><circle cx="88" cy="58" r="28" fill="#66bb6a"/><path d="M22 70h74v44H22z" fill="#c98b56"/><path d="M14 74 59 46l45 28z" fill="#e57373"/><path d="M50 88h18v26H50z" fill="#6d4027"/><path d="M60 114v66M66 114v66M60 130h6M60 146h6M60 162h6" stroke="#8a5a3a" stroke-width="3"/></g>',
      castle: '<g transform="translate(0 40)"><path d="M10 60h100v100H10z" fill="#c9cfd9"/><path d="M0 40h28v120H0zM92 40h28v120H92z" fill="#b8c0cc"/><path d="M0 40l14-26 14 26zM92 40l14-26 14 26z" fill="#7a6ff0"/><path d="M14 14V0M106 14V0" stroke="#7a4e31" stroke-width="2"/><path d="M14 0l12 4-12 4zM106 0l12 4-12 4z" fill="#ff5f9e"/><path d="M10 60v-10h12v10h12v-10h12v10h12v-10h12v10h12v-10h12v10" fill="#c9cfd9" stroke="#c9cfd9"/><path d="M44 112a16 16 0 0 1 32 0v48H44z" fill="#6d4027"/><rect x="6" y="64" width="16" height="22" rx="8" fill="#5b6c8f"/><rect x="98" y="64" width="16" height="22" rx="8" fill="#5b6c8f"/></g>',
    }[house] || '';
    return `<svg viewBox="0 0 320 210" class="pt-room" preserveAspectRatio="xMidYMax slice">
      <rect width="320" height="150" fill="${house === 'castle' ? '#e8e2ff' : '#fbe7d0'}"/>
      <rect y="150" width="320" height="60" fill="${house ? '#e2b98f' : '#ecc9a2'}"/>
      <path d="M0 150h320" stroke="#c99a6e" stroke-width="2"/>
      ${d.has('lamp') ? `<path d="M0 14q80 26 160 6 80 26 160 4" stroke="#6d4f3a" stroke-width="1.5" fill="none"/>${[20, 60, 100, 140, 180, 220, 260, 300].map((x, i) => `<circle class="pt-bulb" cx="${x}" cy="${18 + (i % 2) * 6}" r="5" fill="${['#ffd34d', '#ff5f9e', '#5ee7df', '#a67bff'][i % 4]}" style="animation-delay:${i * .2}s"/>`).join('')}` : ''}
      ${d.has('pic') ? '<g transform="translate(230 40)"><rect width="56" height="44" rx="4" fill="#8a5a3a"/><rect x="5" y="5" width="46" height="34" fill="#fff8ee"/><path d="M28 32c-10-6-14-11-11-16 2-4 8-4 11 1 3-5 9-5 11-1 3 5-1 10-11 16z" fill="#ff5f9e"/></g>' : ''}
      ${H}
      ${d.has('rug') ? '<ellipse cx="200" cy="186" rx="78" ry="16" fill="#ff9d5c" opacity=".85"/><ellipse cx="200" cy="186" rx="60" ry="11" fill="#ffc28f" opacity=".8"/>' : ''}
      ${d.has('bed') ? '<g transform="translate(232 158)"><ellipse cx="34" cy="24" rx="40" ry="14" fill="#a67bff"/><ellipse cx="34" cy="18" rx="30" ry="9" fill="#d6c4ff"/></g>' : ''}
      ${d.has('plant') ? '<g transform="translate(282 112)"><path d="M6 40h24l-4 30H10z" fill="#d9764a"/><path d="M18 40c-2-16-14-20-16-34 10 4 16 14 16 34zM18 40c2-18 14-22 18-36-12 6-18 16-18 36zM18 40V8" stroke="#3f8f3a" fill="#5fb84f" stroke-width="1.5"/></g>' : ''}
    </svg>`;
  },
  // ---------- магазин ----------
  drawShop(p) {
    const c = this.coins(), own = new Set(p.decor || []), houses = new Set(p.houses || []);
    const inv = this.inv(), have = CROPS.filter(x => inv[x.id] > 0);
    let h = `<div class="ps-coins">🪙 <b>${c}</b> <small>монеток на двоих</small></div>
      <div class="ps-h">🏠 Домики</div><div class="ps-grid">`;
    for (const x of HOUSES) {
      const has = houses.has(x.id), on = p.house === x.id;
      h += `<button class="ps-it ${on ? 'on' : ''}" data-house="${x.id}"><span>${x.e}</span><b>${x.t}</b><small>${on ? '✅ Енот живёт тут' : has ? 'Поселить сюда' : '🪙 ' + x.price}</small></button>`;
    }
    h += `</div><div class="ps-h">🛋 Мебель и украшения</div><div class="ps-grid">`;
    for (const x of DECOR) {
      const has = own.has(x.id), off = (p.decorOff || []).includes(x.id);
      h += `<button class="ps-it ${has && !off ? 'on' : ''}" data-decor="${x.id}"><span>${x.e}</span><b>${x.t}</b><small>${has ? (off ? 'Поставить' : '✅ Стоит · убрать') : '🪙 ' + x.price}</small></button>`;
    }
    h += `</div><div class="ps-h">🧺 Продать урожай</div><div class="ps-sell">${have.length ? have.map(x => `<button data-sell="${x.id}">${x.e} ×${inv[x.id]}<small>по 🪙${PET_PRICE[x.id]}</small></button>`).join('') : '<small>В амбаре пусто — урожай с огорода можно продать за монетки</small>'}</div>
      <p class="gd-tip">Монетки дают мини-игры, продажа урожая и уход за енотом. Кошелёк общий — копите вместе!</p>`;
    $('#pet-body').innerHTML = h;
  },
  buyHouse(id) {
    const p = this.pet(), x = HOUSES.find(h => h.id === id), houses = p.houses || [];
    if (houses.includes(id)) { this.save({ house: id }, `переселил(а) енота: ${x.e} ${x.t.toLowerCase()}`); setTimeout(() => this.draw(), 80); return; }
    if (this.coins() < x.price) { toast(`Не хватает 🪙 ${x.price - this.coins()}`); return; }
    sheet([{ icon: 'check', label: `Купить «${x.t}» за 🪙 ${x.price}`, fn: () => {
      const q = this.pet(); if ((q.coins || 0) < x.price) return;
      this.save({ coins: q.coins - x.price, houses: [...(q.houses || []), id], house: id, xp: this.addXp(20) }, `купил(а) еноту ${x.e} ${x.t.toLowerCase()}! 🎉`);
      this.anim('hearts', 12); vibrate([20, 40, 20]); toast(`${x.e} Новоселье! 🎉`);
      setTimeout(() => { this.tab = 'pet'; this.draw(); }, 400);
    } }], `${x.e} ${x.t}`);
  },
  buyDecor(id) {
    const p = this.pet(), x = DECOR.find(h => h.id === id), own = p.decor || [], off = p.decorOff || [];
    if (own.includes(id)) { const n = off.includes(id) ? off.filter(i => i !== id) : [...off, id]; this.save({ decorOff: n }); setTimeout(() => this.draw(), 80); return; }
    if (this.coins() < x.price) { toast(`Не хватает 🪙 ${x.price - this.coins()}`); return; }
    this.save({ coins: p.coins - x.price, decor: [...own, id], xp: this.addXp(6) }, `купил(а) ${x.e} ${x.t.toLowerCase()}`);
    toast(`${x.e} Куплено!`); vibrate(15); setTimeout(() => this.draw(), 80);
  },
  sell(id) {
    const inv = this.inv(), n = inv[id] || 0; if (!n) return;
    const c = CROPS.find(x => x.id === id);
    sheet([
      { icon: 'check', label: `Продать 1 ${c.e} за 🪙 ${PET_PRICE[id]}`, fn: () => this.doSell(id, 1) },
      ...(n > 1 ? [{ icon: 'check', label: `Продать все ${n} ${c.e} за 🪙 ${PET_PRICE[id] * n}`, fn: () => this.doSell(id, n) }] : []),
    ], `${c.e} ${c.t}: в амбаре ${n}`);
  },
  doSell(id, n) {
    const inv = this.inv(); n = Math.min(n, inv[id] || 0); if (!n) return;
    inv[id] -= n; Docs.put(this.invId(), { c: 'inv', items: inv });
    this.addCoins(PET_PRICE[id] * n, `продал(а) урожай: ${CROPS.find(x => x.id === id).e} ×${n}`);
    toast(`+🪙 ${PET_PRICE[id] * n}`); setTimeout(() => this.draw(), 80);
  },
  // ---------- игры ----------
  plays() { try { const j = JSON.parse(localStorage.getItem('nc_petplay') || '{}'); return j.d === ymd(new Date()) ? j.n : 0; } catch (_) { return 0; } },
  usePlay() { const n = this.plays() + 1; try { localStorage.setItem('nc_petplay', JSON.stringify({ d: ymd(new Date()), n })); } catch (_) { } return n <= PAID_PLAYS; },
  drawGames(p) {
    const rec = p.rec || {}, left = Math.max(0, PAID_PLAYS - this.plays());
    $('#pet-body').innerHTML = `<div class="ps-coins">🪙 <b>${this.coins()}</b> <small>· сегодня с наградой ещё ${left} ${plural(left, 'игра', 'игры', 'игр')}</small></div>` +
      GAMES.map(g => `<button class="pg-card" data-game="${g.id}"><span class="pg-e">${g.e}</span><span class="pg-t"><b>${g.t}</b><small>${g.d}</small><i>${rec[g.id] ? `🏆 Рекорд: ${rec[g.id].s} — ${esc(rec[g.id].who === S.name ? 'вы' : rec[g.id].who)}` : 'Рекорда пока нет'}</i></span></button>`).join('') +
      '<p class="gd-tip">Игры поднимают еноту настроение и приносят монетки. Побейте рекорд друг друга! 😉</p>';
  },
  startGame(id) {
    const p = this.pet();
    if (this.asleep()) { toast(`${p.name} спит 😴 Поиграем утром`); return; }
    const box = $('#pgame'); box.classList.remove('hidden');
    box.innerHTML = `<div class="pg-top"><button id="pg-x">✕</button><b id="pg-score">0</b><span id="pg-time"></span></div><div class="pg-area" id="pg-area"></div>`;
    $('#pg-x').onclick = () => this.endGame(true);
    this.game = { id, score: 0, over: false, timers: [] };
    ({ catch: () => this.gCatch(), pairs: () => this.gPairs(), bubbles: () => this.gBubbles() })[id]();
  },
  setScore(s) { this.game.score = s; const e = $('#pg-score'); if (e) e.textContent = s; },
  countdown(sec, onEnd) {
    const g = this.game, t0 = Date.now();
    const tk = setInterval(() => { const l = Math.max(0, sec - (Date.now() - t0) / 1000); const e = $('#pg-time'); if (e) e.textContent = '⏱ ' + Math.ceil(l); if (l <= 0) { clearInterval(tk); onEnd(); } }, 200);
    g.timers.push(() => clearInterval(tk));
  },
  endGame(quit) {
    const g = this.game; if (!g || g.over) return;
    g.over = true; g.timers.forEach(f => f());
    const box = $('#pgame');
    if (quit) { box.classList.add('hidden'); box.innerHTML = ''; return; }
    const p = this.pet(), rec = Object.assign({}, p.rec || {}), old = rec[g.id];
    const record = !old || g.score > old.s;
    if (record && g.score > 0) rec[g.id] = { s: g.score, who: S.name };
    const paid = g.score > 0 && this.usePlay();
    const coins = paid ? Math.max(1, Math.round(g.score / 3)) : 0;
    const st = this.stats(p);
    this.save({ rec, coins: (p.coins || 0) + coins, joy: st.joy + (g.score > 0 ? 10 : 2), xp: this.addXp(g.score > 0 ? 8 : 0) },
      `сыграл(а) в «${GAMES.find(x => x.id === g.id).t}»: ${g.score} очков${record && g.score > 0 ? ' — новый рекорд! 🏆' : ''}`);
    box.innerHTML = `<div class="pg-end">${this.svg({ mood: 'happy', hat: p.hat, lv: 5 })}<b>${record && g.score > 0 ? '🏆 Новый рекорд!' : 'Игра окончена'}</b><div class="pg-big">${g.score}</div>
      <small>${coins ? `+🪙 ${coins} монеток` : paid ? '' : 'На сегодня монетки за игры закончились — но настроение енот получил!'}</small>
      <div class="pg-btns"><button class="btn" id="pg-again">Ещё раз</button><button class="btn primary" id="pg-ok">Готово</button></div></div>`;
    $('#pg-again').onclick = () => this.startGame(g.id);
    $('#pg-ok').onclick = () => { box.classList.add('hidden'); box.innerHTML = ''; this.draw(); };
    if (record && g.score > 0) vibrate([20, 40, 20, 40, 60]);
  },
  // 🍎 лови вкусняшки
  gCatch() {
    const area = $('#pg-area'), g = this.game;
    area.innerHTML = `<div class="pg-sky"></div><div class="pg-coon" id="pg-coon">${this.svg({ mood: 'happy', lv: 1 })}</div>`;
    const coon = $('#pg-coon'), W = () => area.clientWidth, H = () => area.clientHeight;
    let x = W() / 2, items = [], last = performance.now(), spawn = 0;
    const move = cx => { const r = area.getBoundingClientRect(); x = Math.max(40, Math.min(W() - 40, cx - r.left)); coon.style.left = x + 'px'; };
    area.addEventListener('touchmove', e => { e.preventDefault(); move(e.touches[0].clientX); }, { passive: false });
    area.addEventListener('touchstart', e => move(e.touches[0].clientX), { passive: true });
    area.addEventListener('mousemove', e => move(e.clientX));
    move(area.getBoundingClientRect().left + W() / 2);
    const good = ['🍓', '🍎', '🫐', '🍇', '🥕', '🌽', '🍉'], bad = ['🧦', '🪨'];
    const loop = now => {
      if (g.over) return;
      const dt = Math.min(50, now - last); last = now; spawn -= dt;
      const speedUp = 1 + g.score / 60;
      if (spawn <= 0) {
        spawn = Math.max(380, 900 - g.score * 10);
        const isBad = Math.random() < 0.22, el = document.createElement('i'); el.className = 'pg-fall';
        el.textContent = isBad ? bad[Math.random() * bad.length | 0] : good[Math.random() * good.length | 0];
        const it = { el, x: 20 + Math.random() * (W() - 40), y: -30, v: (0.16 + Math.random() * 0.1) * speedUp, bad: isBad };
        el.style.left = it.x + 'px'; area.appendChild(el); items.push(it);
      }
      const cy = H() - 70;
      items = items.filter(it => {
        it.y += it.v * dt; it.el.style.transform = `translate(-50%, ${it.y}px)`;
        if (it.y > cy - 20 && it.y < cy + 30 && Math.abs(it.x - x) < 46) {
          it.el.remove();
          if (it.bad) { this.setScore(Math.max(0, g.score - 3)); coon.classList.add('ouch'); setTimeout(() => coon.classList.remove('ouch'), 300); vibrate(60); }
          else { this.setScore(g.score + 1); const s = document.createElement('i'); s.className = 'pg-plus'; s.textContent = '+1'; s.style.left = it.x + 'px'; s.style.top = (cy - 30) + 'px'; area.appendChild(s); setTimeout(() => s.remove(), 600); vibrate(8); }
          return false;
        }
        if (it.y > H()) { it.el.remove(); return false; }
        return true;
      });
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
    this.countdown(35, () => this.endGame());
  },
  // 🃏 найди пару
  gPairs() {
    const area = $('#pg-area'), g = this.game;
    const set = ['🍓', '🥕', '🌽', '🍎', '🍇', '🫐', '🍉', '🎃'];
    const cards = [...set, ...set].sort(() => Math.random() - .5);
    area.innerHTML = `<div class="pg-pairs">${cards.map((e, i) => `<button data-i="${i}"><span class="pg-back">🦝</span><span class="pg-face">${e}</span></button>`).join('')}</div>`;
    let open = [], found = 0, t0 = Date.now(), lock = false;
    area.querySelector('.pg-pairs').onclick = e => {
      const b = e.target.closest('button'); if (!b || lock || b.classList.contains('open') || g.over) return;
      b.classList.add('open'); open.push(b); vibrate(6);
      if (open.length < 2) return;
      const [a, c] = open; open = [];
      if (cards[a.dataset.i] === cards[c.dataset.i]) {
        a.classList.add('ok'); c.classList.add('ok'); found++; vibrate(15);
        if (found === set.length) { this.setScore(Math.max(5, Math.round(120 - (Date.now() - t0) / 1000 * 1.5))); setTimeout(() => this.endGame(), 600); }
      } else { lock = true; setTimeout(() => { a.classList.remove('open'); c.classList.remove('open'); lock = false; }, 700); }
    };
    const tk = setInterval(() => { const e = $('#pg-time'); if (e) e.textContent = '⏱ ' + Math.round((Date.now() - t0) / 1000); }, 500);
    g.timers.push(() => clearInterval(tk));
    $('#pg-score').textContent = '🃏';
  },
  // 🫧 лопни пузыри
  gBubbles() {
    const area = $('#pg-area'), g = this.game;
    area.innerHTML = `<div class="pg-coon static">${this.svg({ mood: 'happy', lv: 1 })}</div>`;
    const blow = () => {
      if (g.over) return;
      const gold = Math.random() < 0.12, b = document.createElement('button'); b.className = 'pg-bub' + (gold ? ' gold' : '');
      const s = 34 + Math.random() * 30; b.style.width = b.style.height = s + 'px';
      b.style.left = (10 + Math.random() * 80) + '%'; b.style.animationDuration = (3.2 + Math.random() * 2) + 's';
      b.onclick = () => { if (g.over) return; this.setScore(g.score + (gold ? 3 : 1)); b.classList.add('pop'); vibrate(gold ? 20 : 6); setTimeout(() => b.remove(), 200); };
      b.addEventListener('animationend', () => b.remove());
      area.appendChild(b);
      const t = setTimeout(blow, Math.max(260, 650 - g.score * 6)); g.timers.push(() => clearTimeout(t));
    };
    blow();
    this.countdown(30, () => this.endGame());
  },
});

// в уходе за енотом тоже понемногу капают монетки
(() => {
  const act = Pet.act.bind(Pet);
  Pet.act = function (a) {
    const p = this.pet(); const before = p ? JSON.stringify([p.food, p.clean]) : '';
    act(a);
    if ((a === 'wash' || a === 'play') && p && !this.cool('coin_' + a, a === 'wash' ? 2 * 3600000 : 30 * 60000)) setTimeout(() => { const q = this.pet(); if (q) this.save({ coins: (q.coins || 0) + 2 }); }, 300);
  };
})();
$('#pet-body').addEventListener('click', e => {
  const h = e.target.closest('[data-house]'); if (h) { Pet.buyHouse(h.dataset.house); return; }
  const d = e.target.closest('[data-decor]'); if (d) { Pet.buyDecor(d.dataset.decor); return; }
  const s = e.target.closest('[data-sell]'); if (s) { Pet.sell(s.dataset.sell); return; }
  const g = e.target.closest('[data-game]'); if (g) { Pet.startGame(g.dataset.game); return; }
});
