'use strict';
/* «Наш чат» — 🦝 наш енот и огород. Только для пары.
   Состояние хранится в общих зашифрованных записях (как календарь): енот — общий, грядки — общие,
   амбар с урожаем — у каждого свой (кормите тем, что вырастили сами). */

const CROPS = [
  { id: 'carrot', e: '🥕', t: 'Морковка', h: 1, lv: 1, food: 15, joy: 4, xp: 6 },
  { id: 'straw', e: '🍓', t: 'Клубника', h: 2, lv: 1, food: 10, joy: 12, xp: 8 },
  { id: 'corn', e: '🌽', t: 'Кукуруза', h: 3, lv: 2, food: 25, joy: 6, xp: 10 },
  { id: 'blue', e: '🫐', t: 'Черника', h: 2.5, lv: 3, food: 14, joy: 14, xp: 10 },
  { id: 'apple', e: '🍎', t: 'Яблоко', h: 4, lv: 3, food: 22, joy: 8, xp: 12 },
  { id: 'grape', e: '🍇', t: 'Виноград', h: 5, lv: 4, food: 15, joy: 18, xp: 14 },
  { id: 'pumpkin', e: '🎃', t: 'Тыква', h: 6, lv: 5, food: 40, joy: 8, xp: 18 },
  { id: 'melon', e: '🍉', t: 'Арбуз', h: 8, lv: 6, food: 40, joy: 22, xp: 24 },
];
const PET_HATS = [[3, 'bow', '🎀 Бантик'], [5, 'flower', '🌼 Цветочек'], [7, 'cap', '🧢 Кепка'], [9, 'crown', '👑 Корона']];
const WET_H = 3;           // сколько часов грядка остаётся политой
const RATE = { food: 3, joy: 2.5, clean: 1.5 }; // сколько теряется в час

const Pet = {
  ID: 'pet_main',
  tab: 'pet',
  // ---------- данные ----------
  pet() { return Docs.get(this.ID); },
  invId(dev) { return 'inv_' + (dev || S.dev); },
  inv() { const d = Docs.get(this.invId()); return (d && d.items) || {}; },
  bedId(i) { return 'bed_' + String(i).padStart(4, '0'); },
  bed(i) { return Docs.get(this.bedId(i)); },
  lvlOf(xp) { let l = 1, need = 150; while (xp >= need && l < 30) { xp -= need; l++; need = Math.round(need * 1.3); } return { l, cur: xp, need }; },
  stats(p) {
    p = p || this.pet(); if (!p) return null;
    const h = Math.max(0, (Date.now() - p.at) / 3600000), sleeping = this.asleep();
    const k = sleeping ? 0.4 : 1;
    return { food: Math.max(0, p.food - RATE.food * h * k), joy: Math.max(0, p.joy - RATE.joy * h * k), clean: Math.max(0, p.clean - RATE.clean * h * k) };
  },
  asleep() { const hr = new Date().getHours(); return hr < 7; },
  fav(p) { let s = 0; for (const ch of String((p && p.born) || '0')) s = (s * 31 + ch.charCodeAt(0)) >>> 0; return CROPS[s % CROPS.length].id; },
  save(patch, log) {
    const p = this.pet(), st = this.stats(p) || { food: 70, joy: 70, clean: 80 };
    const n = Object.assign({}, p, { food: st.food, joy: st.joy, clean: st.clean }, patch, { c: 'pet', at: Date.now() });
    for (const k of ['food', 'joy', 'clean']) n[k] = Math.max(0, Math.min(100, n[k]));
    if (log) n.log = { who: S.name, a: log, ts: Date.now() };
    return Docs.put(this.ID, n);
  },
  addXp(n) { const p = this.pet(); const before = this.lvlOf(p.xp || 0).l; const xp = (p.xp || 0) + n; const after = this.lvlOf(xp).l; if (after > before) setTimeout(() => this.levelUp(after), 500); return xp; },
  // ---------- открыть ----------
  open() {
    show('pet');
    if (!this.pet()) { this.adopt(); return; }
    this.draw();
    clearInterval(this.tick); this.tick = setInterval(() => { if ($('#pet').classList.contains('hidden')) clearInterval(this.tick); else this.draw(true); }, 30000);
  },
  adopt() {
    $('#pet-body').innerHTML = `<div class="pt-adopt">${this.svg({ mood: 'happy' })}<b>У вас появился енотик! 🦝</b><p>Он будет жить в вашем чате. Кормите его тем, что вырастите на огороде, гладьте, мойте и играйте с ним — вместе.</p><button class="btn primary" id="pt-name">Дать имя</button></div>`;
    $('#pt-name').onclick = () => this.rename(true);
  },
  rename(first) {
    const p = this.pet();
    Form.open({
      title: first ? 'Как назовём енота?' : 'Новое имя', saveLabel: first ? 'Готово 🦝' : 'Сохранить',
      values: { name: p ? p.name : '' }, fields: [{ k: 'name', label: 'Имя', ph: 'Например: Тошка', focus: true, max: 20 }],
      onSave: v => {
        const name = String(v.name || '').trim(); if (!name) return 'Придумайте имя';
        if (!p) Docs.put(this.ID, { c: 'pet', name, born: Date.now(), xp: 0, food: 70, joy: 80, clean: 90, at: Date.now(), hat: '', log: { who: S.name, a: 'назвал(а) енота «' + name + '»', ts: Date.now() } });
        else this.save({ name }, 'назвал(а) енота «' + name + '»');
        setTimeout(() => this.open(), 100);
      },
    });
  },
  // ---------- экран ----------
  draw(soft) {
    const p = this.pet(); if (!p) return;
    document.querySelectorAll('#pet-tabs [data-pt]').forEach(b => b.classList.toggle('on', b.dataset.pt === this.tab));
    const L = this.lvlOf(p.xp || 0);
    $('#pet-title').textContent = p.name;
    $('#pet-lv').innerHTML = `<b>Ур. ${L.l}</b><span class="pt-xp"><i style="width:${Math.round(L.cur / L.need * 100)}%"></i></span>`;
    if (this.tab === 'pet') this.drawPet(p, soft); else if (this.tab === 'garden') this.drawGarden(p); else if (this.tab === 'shop') this.drawShop(p); else if (this.tab === 'season' && typeof Season !== 'undefined') Season.draw(p); else this.drawGames(p);
  },
  mood(st) {
    if (this.asleep()) return 'sleep';
    if (st.food < 20) return 'hungry';
    if (st.clean < 25) return 'dirty';
    if (st.joy < 25) return 'sad';
    return 'happy';
  },
  moodText(m, p) {
    return { sleep: `${p.name} сладко спит… тсс 😴`, hungry: `${p.name} проголодался — покормите его!`, dirty: `${p.name} весь в пыли — пора помыться 🫧`, sad: `${p.name} скучает — погладьте или поиграйте`, happy: `${p.name} счастлив 💕` }[m];
  },
  drawPet(p, soft) {
    const st = this.stats(p), m = this.mood(st);
    const bar = (k, e, t) => `<div class="pt-st"><span>${e}</span><div class="pt-bar ${st[k] < 25 ? 'low' : ''}"><i style="width:${Math.round(st[k])}%"></i></div><small>${t}</small></div>`;
    const inv = this.inv(), foods = CROPS.filter(c => inv[c.id] > 0);
    const log = p.log ? `${esc(p.log.who === S.name ? 'Вы' : p.log.who)} — ${esc(p.log.a)} · ${agoShort(p.log.ts)}` : '';
    const pv = Object.assign({}, p, { decor: (p.decor || []).filter(d => !(p.decorOff || []).includes(d)) });
    const inner = `${this.room ? this.room(pv) : ''}<div class="pt-coon">${this.svg({ mood: m, dirty: st.clean < 30, hat: p.hat, costume: p.costume, lv: this.lvlOf(p.xp || 0).l })}</div>`;
    const scene = `<div class="pt-scene" id="pt-scene">${inner}</div>`;
    if (soft && $('#pt-scene')) { $('#pt-scene').innerHTML = inner; }
    else {
      $('#pet-body').innerHTML = `${scene}
        <div class="pt-mood">${esc(this.moodText(m, p))}</div>
        <div class="pt-stats">${bar('food', '🍽', 'Сытость')}${bar('joy', '😊', 'Настроение')}${bar('clean', '🫧', 'Чистота')}</div>
        <div class="pt-acts">
          <button data-pa="pet"><span>🤲</span>Погладить</button>
          <button data-pa="feed"><span>🍓</span>Покормить</button>
          <button data-pa="wash"><span>🛁</span>Помыть</button>
          <button data-pa="play"><span>⚽</span>Поиграть</button>
        </div>
        <div class="pt-food hidden" id="pt-food">${foods.length ? foods.map(c => `<button data-food="${c.id}">${c.e}<b>${inv[c.id]}</b>${c.id === this.fav(p) ? '<i>❤️</i>' : ''}</button>`).join('') : '<span class="pt-empty">Амбар пуст — вырастите что-нибудь на огороде 🌱</span>'}</div>
        <div class="pt-log">${log}</div>
        <div class="pt-more"><button id="pt-rename">✏️ Имя</button><button id="pt-hat">🎩 Наряд</button><span>Любимая еда: ${CROPS.find(c => c.id === this.fav(p)).e}</span></div>`;
      $('#pt-rename').onclick = () => this.rename(false);
      $('#pt-hat').onclick = () => this.hats();
    }
  },
  // ---------- действия ----------
  cool(key, ms) { const k = 'nc_petcd_' + key, t = +(localStorage.getItem(k) || 0); if (Date.now() - t < ms) return Math.ceil((ms - (Date.now() - t)) / 60000); localStorage.setItem(k, String(Date.now())); return 0; },
  act(a) {
    const p = this.pet(); if (!p) return;
    const sleeping = this.asleep();
    if (sleeping && a !== 'pet') { toast(`${p.name} спит 😴 Можно только тихонько погладить`); return; }
    if (a === 'pet') {
      const w = this.cool('pet', 20000); if (w) { this.anim('hearts', 3); return; }
      this.anim('hearts', 8); this.anim('purr'); vibrate([15, 40, 15, 40, 15]);
      const gainXp = !this.cool('petxp', 10 * 60000);
      this.save({ joy: this.stats(p).joy + (sleeping ? 3 : 8), xp: gainXp ? this.addXp(2) : (p.xp || 0) }, 'погладил(а) енота');
    } else if (a === 'feed') {
      $('#pt-food').classList.toggle('hidden');
    } else if (a === 'wash') {
      const w = this.cool('wash', 2 * 3600000); if (w) { toast(`${p.name} уже чистенький ✨ Через ${w} мин можно снова`); return; }
      this.anim('bubbles'); vibrate(30);
      this.save({ clean: 100, joy: this.stats(p).joy + 4, xp: this.addXp(6) }, 'помыл(а) енота 🫧');
    } else if (a === 'play') {
      const w = this.cool('play', 30 * 60000); if (w) { toast(`${p.name} ещё отдыхает после игры. Через ${w} мин`); return; }
      this.anim('ball'); vibrate([10, 30, 10]);
      this.save({ joy: this.stats(p).joy + 18, food: this.stats(p).food - 3, xp: this.addXp(6) }, 'поиграл(а) с енотом ⚽');
    }
    setTimeout(() => this.draw(true), 50);
  },
  feed(id) {
    const p = this.pet(), c = CROPS.find(x => x.id === id), inv = this.inv(); if (!c || !(inv[id] > 0)) return;
    const st = this.stats(p);
    if (st.food >= 98) { toast(`${p.name} уже наелся 🥴`); return; }
    const fav = id === this.fav(p);
    inv[id]--; Docs.put(this.invId(), { c: 'inv', items: inv });
    this.anim('eat', c.e); vibrate(20);
    if (fav) setTimeout(() => this.anim('hearts', 10), 500);
    this.save({ food: st.food + c.food, joy: st.joy + c.joy * (fav ? 2 : 1), xp: this.addXp(c.xp / 2 | 0) }, `покормил(а) енота: ${c.e} ${c.t.toLowerCase()}${fav ? ' — любимое! 😍' : ''}`);
    setTimeout(() => this.draw(), 900);
  },
  hats() {
    const p = this.pet(), L = this.lvlOf(p.xp || 0).l;
    const items = [{ icon: 'x', label: 'Без наряда', fn: () => { this.save({ hat: '', costume: '' }); setTimeout(() => this.draw(), 80); } }];
    if (typeof HW_ITEMS !== 'undefined') for (const it of [...HW_ITEMS, ...HW_PASS]) if ((it.kind === 'hat' || it.kind === 'costume') && (p.hw || []).includes(it.id)) items.push({ icon: 'smile', label: `${it.e} ${it.t}`, fn: () => Season.toggle(it) });
    for (const [lv, id, t] of PET_HATS) items.push({ icon: 'smile', label: L >= lv ? t : `🔒 ${t} — с ${lv} уровня`, fn: () => { if (L >= lv) { this.save({ hat: id }, 'нарядил(а) енота'); setTimeout(() => this.draw(), 80); } else toast(`Откроется на ${lv} уровне`); } });
    sheet(items, 'Наряды открываются с уровнями енота');
  },
  levelUp(l) {
    const b = document.createElement('div'); b.className = 'tr-up'; b.innerHTML = `🎉<b>Енот подрос!</b><span>Уровень ${l}</span>`;
    $('#pet').appendChild(b); setTimeout(() => b.remove(), 3500); vibrate([30, 50, 30]);
  },
  anim(kind, n) {
    const sc = $('#pt-scene'); if (!sc) return;
    const svg = sc.querySelector('.pt-svg');
    if (kind === 'hearts') for (let i = 0; i < (n || 6); i++) { const h = document.createElement('i'); h.className = 'pt-heart'; h.textContent = ['💕', '💗', '💖'][i % 3]; h.style.left = (30 + Math.random() * 40) + '%'; h.style.animationDelay = (i * .08) + 's'; sc.appendChild(h); setTimeout(() => h.remove(), 1800); }
    if (kind === 'purr' && svg) { svg.classList.remove('purr'); void svg.offsetWidth; svg.classList.add('purr'); }
    if (kind === 'eat') { const f = document.createElement('i'); f.className = 'pt-eat'; f.textContent = n; sc.appendChild(f); setTimeout(() => f.remove(), 1200); if (svg) { svg.classList.remove('chew'); void svg.offsetWidth; svg.classList.add('chew'); } }
    if (kind === 'bubbles') for (let i = 0; i < 18; i++) { const b = document.createElement('i'); b.className = 'pt-bub'; b.style.left = (20 + Math.random() * 60) + '%'; b.style.width = b.style.height = (8 + Math.random() * 18) + 'px'; b.style.animationDelay = (Math.random() * .8) + 's'; sc.appendChild(b); setTimeout(() => b.remove(), 2200); }
    if (kind === 'ball') { const b = document.createElement('i'); b.className = 'pt-ball'; b.textContent = '⚽'; sc.appendChild(b); setTimeout(() => b.remove(), 1600); if (svg) { svg.classList.remove('jump'); void svg.offsetWidth; svg.classList.add('jump'); } }
  },
  // ---------- огород ----------
  beds(p) { return Math.min(6, 3 + Math.floor((this.lvlOf((p || this.pet()).xp || 0).l - 1) / 2)); },
  grow(b) { // сколько часов роста набрано и полита ли грядка
    const now = Date.now(), c = CROPS.find(x => x.id === b.crop);
    const wetEnd = Math.min(now, b.wetUntil || 0), extra = Math.max(0, wetEnd - b.at) / 3600000;
    const g = (b.prog || 0) + extra;
    return { c, g, ready: g >= c.h, wet: (b.wetUntil || 0) > now, pct: Math.min(1, g / c.h), left: Math.max(0, c.h - g) };
  },
  drawGarden(p) {
    const n = this.beds(p), L = this.lvlOf(p.xp || 0).l;
    let h = '<div class="gd-field">';
    for (let i = 1; i <= 6; i++) {
      if (i > n) { h += `<div class="gd-bed locked"><span>🔒</span><small>с ${3 + (i - 3) * 2} ур.</small></div>`; continue; }
      const b = this.bed(i);
      if (!b || !b.crop) { h += `<button class="gd-bed gd-empty" data-bed="${i}"><span>➕</span><small>Посадить</small></button>`; continue; }
      const g = this.grow(b), stage = g.ready ? 3 : g.pct > .6 ? 2 : g.pct > .2 ? 1 : 0;
      const plant = g.ready ? `<span class="gd-crop ready">${g.c.e}${g.c.e}</span>` : stage === 2 ? `<span class="gd-crop s2">🌿<i>${g.c.e}</i></span>` : stage === 1 ? '<span class="gd-crop s1">🌿</span>' : '<span class="gd-crop s0">🌱</span>';
      const lm = Math.ceil(g.left * 60), left = lm < 60 ? lm + ' мин' : Math.floor(lm / 60) + ' ч' + (lm % 60 ? ' ' + (lm % 60) + ' мин' : '');
      h += `<button class="gd-bed ${g.wet ? 'wet' : 'dry'} ${g.ready ? 'done' : ''}" data-bed="${i}">${plant}
        <small>${g.ready ? '✨ Собрать урожай' : g.wet ? `💧 растёт · ещё ${left}` : `🥀 сухо — полейте!`}</small>
        <span class="gd-prog"><i style="width:${Math.round(g.pct * 100)}%"></i></span></button>`;
    }
    h += '</div>';
    const inv = this.inv(), have = CROPS.filter(c => inv[c.id] > 0);
    h += `<div class="gd-barn"><b>🧺 Ваш амбар</b><div>${have.length ? have.map(c => `<span>${c.e} ${inv[c.id]}</span>`).join('') : '<small>Пока пусто</small>'}</div></div>
      <p class="gd-tip">Растения растут, только пока грядка полита (${WET_H} часа после полива). Поливать может любой из вас — урожай достаётся тому, кто собрал.</p>`;
    $('#pet-body').innerHTML = h;
  },
  tapBed(i) {
    const p = this.pet(), b = this.bed(i), L = this.lvlOf(p.xp || 0).l;
    if (!b || !b.crop) {
      sheet(CROPS.map(c => ({ icon: 'smile', label: L >= c.lv ? `${c.e} ${c.t} — ${c.h} ч` : `🔒 ${c.e} ${c.t} — с ${c.lv} уровня`, fn: () => {
        if (L < c.lv) { toast(`Откроется на ${c.lv} уровне енота`); return; }
        const now = Date.now();
        Docs.put(this.bedId(i), { c: 'bed', crop: c.id, prog: 0, at: now, wetUntil: now + WET_H * 3600000, planted: now });
        this.save({ xp: this.addXp(2) }, `посадил(а) ${c.e} ${c.t.toLowerCase()}`);
        toast(`${c.e} Посажено и полито!`); vibrate(15); setTimeout(() => this.draw(), 80);
      } })), 'Что посадим? Время роста — пока грядка полита');
      return;
    }
    const g = this.grow(b);
    if (g.ready) {
      const n = 2 + Math.floor(Math.random() * 3), inv = this.inv();
      inv[b.crop] = (inv[b.crop] || 0) + n;
      Docs.put(this.invId(), { c: 'inv', items: inv });
      Docs.del(this.bedId(i));
      this.save({ xp: this.addXp(g.c.xp) }, `собрал(а) урожай: ${g.c.e} ×${n}`);
      toast(`Урожай: ${g.c.e} ×${n} — в амбаре!`); vibrate([15, 30, 15]);
      setTimeout(() => this.draw(), 80); return;
    }
    if (g.wet && (b.wetUntil - Date.now()) > (WET_H - 0.5) * 3600000) { toast('Грядка ещё мокрая 💧'); return; }
    const now = Date.now();
    Docs.put(this.bedId(i), Object.assign({}, b, { prog: g.g, at: now, wetUntil: now + WET_H * 3600000 }));
    this.save({ xp: this.addXp(1) }, `полил(а) ${g.c.e}`);
    const el = document.querySelector(`.gd-bed[data-bed="${i}"]`); if (el) { el.classList.add('watering'); }
    toast('💧 Полито!'); vibrate(10); setTimeout(() => this.draw(), 700);
  },
  // ---------- рисуем енота (свой, нарисованный для приложения) ----------
  svg(o) {
    const m = o.mood || 'happy', sleep = m === 'sleep', sad = m === 'sad' || m === 'hungry';
    const eyes = sleep
      ? `<path d="M72 84q8 6 16 0M112 84q8 6 16 0" stroke="#1f2328" stroke-width="3.2" fill="none" stroke-linecap="round"/>`
      : `<g class="pt-eyes"><circle cx="80" cy="83" r="9.5" fill="#fff"/><circle cx="120" cy="83" r="9.5" fill="#fff"/>
         <circle cx="${sad ? 80 : 81}" cy="${sad ? 86 : 84}" r="6" fill="#1f2328"/><circle cx="${sad ? 120 : 121}" cy="${sad ? 86 : 84}" r="6" fill="#1f2328"/>
         <circle cx="83" cy="81" r="2.2" fill="#fff"/><circle cx="123" cy="81" r="2.2" fill="#fff"/>
         ${sad ? '<path d="M70 74l18 4M130 74l-18 4" stroke="#1f2328" stroke-width="2.5" stroke-linecap="round"/>' : ''}</g>`;
    const mouth = sleep ? '<path d="M95 106q5 3 10 0" stroke="#1f2328" stroke-width="2.5" fill="none" stroke-linecap="round"/>'
      : sad ? '<path d="M93 109q7-6 14 0" stroke="#1f2328" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
        : '<path class="pt-mouth" d="M92 104q8 9 16 0" stroke="#1f2328" stroke-width="2.6" fill="#ff8fa3" stroke-linecap="round"/>';
    const hat = { bow: '<g transform="translate(128 42) rotate(18)"><path d="M0 0l-14-9v18zM0 0l14-9v18z" fill="#ff5f9e"/><circle r="4.5" fill="#ff85b3"/></g>',
      flower: '<g transform="translate(130 44)">' + [0, 72, 144, 216, 288].map(a => `<ellipse rx="5" ry="8" fill="#fff6a8" transform="rotate(${a}) translate(0 -7)"/>`).join('') + '<circle r="5" fill="#ffb300"/></g>',
      cap: '<g transform="translate(100 40)"><path d="M-34 6a34 26 0 0 1 68 0z" fill="#4b6fe0"/><path d="M14 4h34q4 6-6 8H14z" fill="#3a59c4"/><circle cy="-20" r="4" fill="#fff"/></g>',
      crown: '<g transform="translate(100 34)"><path d="M-22 10l-4-20 14 10 12-16 12 16 14-10-4 20z" fill="#ffd34d" stroke="#e0a800" stroke-width="2"/><circle cy="2" r="3.5" fill="#ff5f9e"/></g>',
      witch: '<g transform="translate(100 44)"><ellipse cy="8" rx="46" ry="8" fill="#2a2333"/><path d="M-24 8 4-40q4-4 8 0l-2 7 4 8L24 8z" fill="#3a2f4d"/><path d="M-22 1h45v7h-45z" fill="#a67bff"/><circle cx="12" cy="-10" r="3" fill="#ffd34d"/></g>',
      pumpkinhat: '<g transform="translate(100 38)"><ellipse rx="36" ry="20" fill="#ff8a1f"/><path d="M-12-19q12-6 24 0M-14-18q-6 18 0 36M14-18q6 18 0 36" stroke="#d96a00" stroke-width="2" fill="none"/><path d="M-3-19l2-12 6 2-4 11z" fill="#4f7a2a"/><path d="M5-26q10-6 14 2" stroke="#4f7a2a" stroke-width="2" fill="none"/></g>',
      pkcrown: '<g transform="translate(100 34)"><path d="M-26 10l-4-22 15 12 15-18 15 18 15-12-4 22z" fill="#ff8a1f" stroke="#d96a00" stroke-width="2"/><circle cy="2" r="4" fill="#7a2bd6"/><circle cx="-15" cy="4" r="2.6" fill="#58e07a"/><circle cx="15" cy="4" r="2.6" fill="#58e07a"/></g>' }[o.hat] || '';
    const cape = o.costume === 'cape', ghost = o.costume === 'sheet';
    const dirt = o.dirty ? '<g fill="#8a6a4a" opacity=".55"><circle cx="70" cy="140" r="6"/><circle cx="128" cy="152" r="5"/><circle cx="104" cy="60" r="4"/><circle cx="140" cy="100" r="3.5"/></g>' : '';
    const scale = 0.86 + Math.min(0.14, ((o.lv || 1) - 1) * 0.02);
    return `<svg viewBox="0 0 200 210" class="pt-svg ${sleep ? 'sleeping' : ''}" style="--s:${scale}">
      <ellipse cx="100" cy="196" rx="62" ry="9" fill="rgba(0,0,0,.12)"/>
      <g class="pt-tail"><path d="M140 168c30 6 52-10 50-40-1-14-12-20-20-12-6 6 2 18-8 26-8 7-20 6-28 8z" fill="#8b929b"/>
        <path d="M176 132c6 2 9 6 8 12M168 150c7 0 12-3 14-8M154 162c6-1 10-4 12-9" stroke="#3b3f46" stroke-width="6" fill="none" stroke-linecap="round"/></g>
      ${cape ? '<path d="M50 120q50 24 100 0l14 72q-64 14-128 0z" fill="#8b1e3f"/>' : ''}
      <g class="pt-body">
        <ellipse cx="100" cy="150" rx="50" ry="44" fill="#9aa1aa"/>
        <ellipse cx="100" cy="158" rx="30" ry="30" fill="#e4e6ea"/>
        <ellipse cx="74" cy="188" rx="14" ry="8" fill="#3b3f46"/><ellipse cx="126" cy="188" rx="14" ry="8" fill="#3b3f46"/>
        <ellipse cx="66" cy="152" rx="9" ry="14" fill="#3b3f46" transform="rotate(20 66 152)"/><ellipse cx="134" cy="152" rx="9" ry="14" fill="#3b3f46" transform="rotate(-20 134 152)"/>
      </g>
      ${cape ? '<path d="M64 118 54 100l30 14zM136 118l10-18-30 14z" fill="#c2185b"/><circle cx="100" cy="122" r="4" fill="#ffd34d"/>' : ''}
      ${ghost ? '<path d="M44 194v-58q0-34 56-34t56 34v58l-8-7-8 7-8-7-8 7-8-7-8 7-8-7-8 7-8-7-8 7-8-7z" fill="#fbfbff" opacity=".95"/>' : ''}
      <g class="pt-head">
        <path d="M58 64 52 30q2-6 8-3l26 22z" fill="#8b929b"/><path d="M60 54 57 35l18 14z" fill="#3b3f46"/>
        <path d="M142 64 148 30q-2-6-8-3l-26 22z" fill="#8b929b"/><path d="M140 54 143 35l-18 14z" fill="#3b3f46"/>
        <ellipse cx="100" cy="86" rx="52" ry="44" fill="#9aa1aa"/>
        <path d="M50 96q-2 18 14 26 14 4 22-6M150 96q2 18-14 26-14 4-22-6" fill="#f2f3f5"/>
        <path d="M58 80q2-18 22-18 12 0 20 10 8-10 20-10 20 0 22 18 2 14-14 16-14 2-28-6-14 8-28 6-16-2-14-16z" fill="#3b3f46"/>
        <path d="M86 48q14-8 28 0-6 10-14 12-8-2-14-12z" fill="#eef0f2" opacity=".9"/>
        ${eyes}
        <ellipse cx="100" cy="104" rx="20" ry="14" fill="#f2f3f5"/>
        <ellipse cx="100" cy="97" rx="7" ry="5" fill="#1f2328"/><ellipse cx="98" cy="95.5" rx="2" ry="1.2" fill="#fff" opacity=".7"/>
        ${mouth}
        ${m === 'happy' ? '<circle cx="66" cy="102" r="7" fill="#ff9db5" opacity=".55"/><circle cx="134" cy="102" r="7" fill="#ff9db5" opacity=".55"/>' : ''}
        ${hat}
      </g>
      ${dirt}
      ${sleep ? '<g class="pt-z" fill="#6d7a99" font-weight="800"><text x="150" y="50" font-size="16">z</text><text x="162" y="34" font-size="20">Z</text></g>' : ''}
    </svg>`;
  },
};
$('#pet-back').onclick = () => show('chat');
$('#pet-tabs').onclick = e => { const b = e.target.closest('[data-pt]'); if (b) { Pet.tab = b.dataset.pt; Pet.draw(); } };
$('#pet-body').addEventListener('click', e => {
  const a = e.target.closest('[data-pa]'); if (a) { Pet.act(a.dataset.pa); return; }
  const f = e.target.closest('[data-food]'); if (f) { Pet.feed(f.dataset.food); return; }
  const bd = e.target.closest('[data-bed]'); if (bd) { Pet.tapBed(+bd.dataset.bed); return; }
  if (e.target.closest('#pt-scene .pt-svg')) Pet.act('pet');
});
// второй человек что-то сделал — обновляем экран
Docs.on(ch => {
  if ($('#pet').classList.contains('hidden')) return;
  if (ch.some(c => /^(pet_|bed_|inv_)/.test(c.id))) Pet.draw(Pet.tab === 'pet');
  const x = ch.find(c => c.id === Pet.ID && !c.local && c.after && c.after.log && c.after.dev !== S.dev);
  if (x) toast(`🦝 ${x.after.log.who} ${x.after.log.a}`, 3000);
});
