#!/usr/bin/env bash
# Установка сервера «Наш чат» на чистый Ubuntu 22.04 / 24.04 (или Debian 12).
# Запуск:  curl -fsSL <ссылка на этот файл> | sudo bash
set -euo pipefail

REPO_RAW="${REPO_RAW:-}"   # откуда скачать server.js (подставляется в инструкции)
APP_DIR=/opt/nash-chat
DATA_DIR=/var/lib/nash-chat

if [ "$(id -u)" != "0" ]; then echo "Запустите через sudo"; exit 1; fi

echo "==> Устанавливаю Node.js и Caddy (HTTPS)…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nodejs caddy curl ufw coturn

NODE_MAJOR=$(node -v | sed 's/v\([0-9]*\).*/\1/')
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "Нужен Node.js 18 или новее, установлен $(node -v). Используйте Ubuntu 24.04."; exit 1
fi

echo "==> Скачиваю сервер…"
mkdir -p "$APP_DIR" "$DATA_DIR"
if [ -n "$REPO_RAW" ]; then
  curl -fsSL "$REPO_RAW/server/server.js" -o "$APP_DIR/server.js"
  curl -fsSL "$REPO_RAW/server/watch.html" -o "$APP_DIR/watch.html" || true
elif [ -f "$(dirname "$0")/server.js" ]; then
  cp "$(dirname "$0")/server.js" "$APP_DIR/server.js"
  [ -f "$(dirname "$0")/watch.html" ] && cp "$(dirname "$0")/watch.html" "$APP_DIR/watch.html"
else
  echo "Не задан REPO_RAW"; exit 1
fi

id -u nashchat >/dev/null 2>&1 || useradd --system --home "$DATA_DIR" --shell /usr/sbin/nologin nashchat
chown -R nashchat:nashchat "$DATA_DIR"

echo "==> Определяю адрес сервера…"
IP=$(ip -4 route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')
if [ -z "${DOMAIN:-}" ]; then DOMAIN="$(echo "$IP" | tr . -).sslip.io"; fi

echo "==> Настраиваю посредника для звонков (TURN)…"
mkdir -p /etc/nash-chat
SECRET_FILE=/etc/nash-chat/turn.secret
if [ ! -s "$SECRET_FILE" ]; then head -c 48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 40 > "$SECRET_FILE"; fi
chown nashchat:nashchat "$SECRET_FILE"; chmod 600 "$SECRET_FILE"
TURN_SECRET=$(cat "$SECRET_FILE")
cat > /etc/turnserver.conf <<TURNCONF
listening-port=3478
fingerprint
use-auth-secret
static-auth-secret=$TURN_SECRET
realm=nash-chat
external-ip=$IP
min-port=49160
max-port=49260
no-cli
no-tls
no-dtls
no-multicast-peers
no-tcp-relay
denied-peer-ip=0.0.0.0-0.255.255.255
denied-peer-ip=10.0.0.0-10.255.255.255
denied-peer-ip=100.64.0.0-100.127.255.255
denied-peer-ip=127.0.0.0-127.255.255.255
denied-peer-ip=169.254.0.0-169.254.255.255
denied-peer-ip=172.16.0.0-172.31.255.255
denied-peer-ip=192.168.0.0-192.168.255.255
user-quota=12
total-quota=24
syslog
TURNCONF
if [ -f /etc/default/coturn ]; then sed -i 's/^#*TURNSERVER_ENABLED=.*/TURNSERVER_ENABLED=1/' /etc/default/coturn; fi
systemctl enable coturn >/dev/null 2>&1 || true
systemctl restart coturn || echo "⚠️  Посредник для звонков не запустился — звонки будут работать только при прямом соединении"

cat > /etc/systemd/system/nash-chat.service <<EOF
[Unit]
Description=Nash chat server
After=network.target

[Service]
User=nashchat
Environment=DATA_DIR=$DATA_DIR
Environment=PORT=8080
Environment=HOST=127.0.0.1
Environment=TURN_HOST=$IP
Environment=TURN_SECRET_FILE=/etc/nash-chat/turn.secret
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=$DATA_DIR
ReadOnlyPaths=/etc/nash-chat
ProtectHome=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF


cat > /etc/caddy/Caddyfile <<EOF
$DOMAIN {
	encode gzip
	reverse_proxy 127.0.0.1:8080 {
		flush_interval -1
	}
}
EOF

echo "==> Открываю порты 22, 80, 443 и порты для звонков…"
ufw allow 22/tcp >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw allow 3478/udp >/dev/null
ufw allow 3478/tcp >/dev/null
ufw allow 49160:49260/udp >/dev/null
ufw --force enable >/dev/null

systemctl daemon-reload
systemctl enable nash-chat
systemctl restart nash-chat
systemctl restart caddy

echo "==> Жду сертификат HTTPS (до минуты)…"
for i in $(seq 1 30); do
  if curl -fsS "https://$DOMAIN/api/ping" >/dev/null 2>&1; then break; fi
  sleep 2
done

echo
if curl -fsS "https://$DOMAIN/api/ping" >/dev/null 2>&1; then
  echo "✅ Готово! Адрес вашего сервера (вставьте его в приложение):"
  echo
  echo "    https://$DOMAIN"
  echo
else
  echo "⚠️  Сервер установлен, но HTTPS пока не отвечает."
  echo "   Подождите пару минут и откройте в браузере телефона: https://$DOMAIN"
  echo "   Если не открывается — пришлите вывод команды:  journalctl -u caddy -n 30"
fi
