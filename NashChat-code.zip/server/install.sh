#!/usr/bin/env bash
# Установка сервера «Наш чат» на чистый Ubuntu 22.04 / 24.04 (или Debian 12).
# Запуск:  curl -fsSL <ссылка на этот файл> | sudo bash
set -euo pipefail

REPO_RAW="${REPO_RAW:-}"   # откуда скачать server.js (подставляется в инструкции)
APP_DIR=/opt/nash-chat
DATA_DIR=/var/lib/nash-chat

if [ "$(id -u)" != "0" ]; then echo "Запустите через sudo"; exit 1; fi

echo "==> Устанавливаю Node.js и Caddy (HTTPS)…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nodejs caddy curl ufw

NODE_MAJOR=$(node -v | sed 's/v\([0-9]*\).*/\1/')
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "Нужен Node.js 18 или новее, установлен $(node -v). Используйте Ubuntu 24.04."; exit 1
fi

echo "==> Скачиваю сервер…"
mkdir -p "$APP_DIR" "$DATA_DIR"
if [ -n "$REPO_RAW" ]; then
  curl -fsSL "$REPO_RAW/server/server.js" -o "$APP_DIR/server.js"
elif [ -f "$(dirname "$0")/server.js" ]; then
  cp "$(dirname "$0")/server.js" "$APP_DIR/server.js"
else
  echo "Не задан REPO_RAW"; exit 1
fi

id -u nashchat >/dev/null 2>&1 || useradd --system --home "$DATA_DIR" --shell /usr/sbin/nologin nashchat
chown -R nashchat:nashchat "$DATA_DIR"

cat > /etc/systemd/system/nash-chat.service <<EOF
[Unit]
Description=Nash chat server
After=network.target

[Service]
User=nashchat
Environment=DATA_DIR=$DATA_DIR
Environment=PORT=8080
Environment=HOST=127.0.0.1
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=$DATA_DIR
ProtectHome=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

echo "==> Определяю адрес сервера…"
IP=$(ip -4 route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')
if [ -z "${DOMAIN:-}" ]; then DOMAIN="$(echo "$IP" | tr . -).sslip.io"; fi

cat > /etc/caddy/Caddyfile <<EOF
$DOMAIN {
	encode gzip
	reverse_proxy 127.0.0.1:8080 {
		flush_interval -1
	}
}
EOF

echo "==> Открываю порты 22, 80, 443…"
ufw allow 22/tcp >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw --force enable >/dev/null

systemctl daemon-reload
systemctl enable nash-chat
systemctl restart nash-chat
systemctl restart caddy

echo "==> Жду сертификат HTTPS (до минуты)…"
for i in $(seq 1 30); do
  if curl -fsS "https://$DOMAIN/api/ping" >/dev/null 2>&1; then break; fi
  sleep 2
done

echo
if curl -fsS "https://$DOMAIN/api/ping" >/dev/null 2>&1; then
  echo "✅ Готово! Адрес вашего сервера (вставьте его в приложение):"
  echo
  echo "    https://$DOMAIN"
  echo
else
  echo "⚠️  Сервер установлен, но HTTPS пока не отвечает."
  echo "   Подождите пару минут и откройте в браузере телефона: https://$DOMAIN"
  echo "   Если не открывается — пришлите вывод команды:  journalctl -u caddy -n 30"
fi
