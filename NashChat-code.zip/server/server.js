// Наш чат — сервер. Никаких внешних зависимостей, нужен только Node.js 18+.
// Сервер хранит ТОЛЬКО зашифрованные данные: ключ шифрования есть лишь на телефонах.
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '8080', 10);
const HOST = process.env.HOST || '127.0.0.1';
const DATA = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const MAX_CHUNK = 9 * 1024 * 1024;      // одна часть файла (8 МБ + шифрование)
const MAX_MSG = 256 * 1024;             // одно сообщение (с миниатюрой)
const MAX_PAGE = 200;

fs.mkdirSync(path.join(DATA, 'files'), { recursive: true });
const CONF_FILE = path.join(DATA, 'config.json');
const LOG_FILE = path.join(DATA, 'messages.jsonl');
const READS_FILE = path.join(DATA, 'reads.json');
const DOCS_FILE = path.join(DATA, 'docs.json');

// ---------- состояние ----------
let config = fs.existsSync(CONF_FILE) ? JSON.parse(fs.readFileSync(CONF_FILE, 'utf8')) : {};
const messages = [];   // {id, ts, dev, ct} | удалённые: {id, ts, dev, del:true}
let delCount = 0;
if (fs.existsSync(LOG_FILE)) {
  for (const line of fs.readFileSync(LOG_FILE, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try {
      const m = JSON.parse(line);
      if (m.delOf) { delCount++; const t = messages.find(x => x.id === m.delOf); if (t) { t.ct = null; t.del = true; } }
      else messages.push(m);
    } catch (_) { /* повреждённая строка — пропускаем */ }
  }
}
let lastId = messages.length ? messages[messages.length - 1].id : 0;
let version = lastId + delCount;  // растёт и при удалении, чтобы ожидающие клиенты узнали об изменениях
const waiters = new Set();
// до какого сообщения дочитал каждый телефон (только номера, без содержимого)
let reads = {};
try { reads = JSON.parse(fs.readFileSync(READS_FILE, 'utf8')) || {}; } catch (_) { reads = {}; }
let readsTimer = null;
// присутствие: кто сейчас в приложении и кто печатает (только в памяти, без содержимого)
const pres = {};
const PRES_STATES = new Set(['online', 'away', 'typing', 'voice', 'circle']);
const okDev = d => typeof d === 'string' && /^[0-9a-f]{4,64}$/.test(d);
function presOf(dev) { return pres[dev] || (pres[dev] = { state: 'away', stAt: 0, at: 0, polls: 0, seen: 0 }); }
function presView() {
  const now = Date.now(), out = {};
  for (const [dev, x] of Object.entries(pres)) {
    const alive = x.polls > 0 || now - x.at < 20000;
    let st = alive ? x.state : 'offline';
    if ((st === 'typing' || st === 'voice' || st === 'circle') && now - x.stAt > (st === 'typing' ? 7000 : 70000)) st = 'online';
    if (st === 'online' || st === 'typing' || st === 'voice' || st === 'circle') x.seen = now;
    out[dev] = { s: st, seen: x.seen };
  }
  return out;
}
// быстрые сигналы (совместный просмотр, в будущем — звонки): зашифрованы, живут в памяти до минуты,
// не попадают в историю и не вызывают уведомлений
const signals = []; let sigId = 0;
function sigAfter(after, dev) {
  const cut = Date.now() - 60000;
  while (signals.length && (signals[0].ts < cut || signals.length > 300)) signals.shift();
  return signals.filter(x => x.sid > after && x.dev !== dev).map(x => ({ sid: x.sid, ct: x.ct, ts: x.ts }));
}
// общие записи (календарь, заметки, банк): каждая зашифрована на телефоне, сервер хранит только шифр
let docs = {}, docsV = 0;
try { const j = JSON.parse(fs.readFileSync(DOCS_FILE, 'utf8')); docs = j.docs || {}; docsV = j.v || 0; } catch (_) { }
let docsTimer = null;
function saveDocs() {
  clearTimeout(docsTimer);
  docsTimer = setTimeout(() => { try { fs.writeFileSync(DOCS_FILE + '.tmp', JSON.stringify({ v: docsV, docs })); fs.renameSync(DOCS_FILE + '.tmp', DOCS_FILE); } catch (_) { } }, 500);
}
const docIdOk = s => typeof s === 'string' && /^[a-z]{2,8}_[0-9a-z]{4,40}$/.test(s);
let presSig = '';
function presChanged() {
  const v = presView(), sig = Object.keys(v).sort().map(k => k + ':' + v[k].s).join(',');
  if (sig !== presSig) { presSig = sig; version++; wake(); }
}
setInterval(presChanged, 2000).unref();
function saveReads() {
  clearTimeout(readsTimer);
  readsTimer = setTimeout(() => { try { fs.writeFileSync(READS_FILE + '.tmp', JSON.stringify(reads)); fs.renameSync(READS_FILE + '.tmp', READS_FILE); } catch (_) { } }, 1000);
}

function saveConfig() {
  fs.writeFileSync(CONF_FILE + '.tmp', JSON.stringify(config));
  fs.renameSync(CONF_FILE + '.tmp', CONF_FILE);
}
const sha = s => crypto.createHash('sha256').update(s).digest('hex');

// ---------- ответы ----------
function send(res, code, obj) {
  const body = obj === undefined ? '' : JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.setHeader('Access-Control-Max-Age', '86400');
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const parts = []; let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too big'), { code: 413 })); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}
async function readJson(req, limit) {
  const b = await readBody(req, limit);
  try { return JSON.parse(b.toString('utf8') || '{}'); }
  catch (_) { throw Object.assign(new Error('bad json'), { code: 400 }); }
}

// ---------- защита от перебора ----------
const fails = new Map(); // ip -> {n, until}
function ipOf(req) { return (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }
function blocked(ip) { const f = fails.get(ip); return f && f.until > Date.now(); }
function failed(ip) {
  const f = fails.get(ip) || { n: 0, until: 0 };
  f.n++; if (f.n >= 10) { f.until = Date.now() + 15 * 60 * 1000; f.n = 0; }
  fails.set(ip, f);
}
function authed(req) {
  if (!config.tokenHash) return false;
  const h = req.headers.authorization || '';
  const tok = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
  if (!/^[0-9a-f]{64}$/.test(tok)) return false;
  const a = Buffer.from(sha(tok)), b = Buffer.from(config.tokenHash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ---------- сообщения ----------
function view(m) { return m.del ? { id: m.id, ts: m.ts, dev: m.dev, del: true } : { id: m.id, ts: m.ts, dev: m.dev, ct: m.ct }; }
function after(id, limit) {
  // бинарный поиск первого сообщения с id > id
  let lo = 0, hi = messages.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (messages[mid].id <= id) lo = mid + 1; else hi = mid; }
  return messages.slice(lo, lo + limit).map(view);
}
function before(id, limit) {
  let lo = 0, hi = messages.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (messages[mid].id < id) lo = mid + 1; else hi = mid; }
  return messages.slice(Math.max(0, lo - limit), lo).map(view);
}
function wake() {
  for (const w of waiters) w();
  waiters.clear();
}
const deletedSince = []; // {v, id} — чтобы ожидающие узнали об удалениях
function changesSince(v) { return deletedSince.filter(d => d.v > v).map(d => d.id); }

// ---------- файлы ----------
const idOk = s => /^[0-9a-f]{32}$/.test(s);
function filePath(id, idx) { return path.join(DATA, 'files', id.slice(0, 2), id, String(idx)); }

// ---------- маршруты ----------
async function handle(req, res) {
  cors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, 'http://x');
  const p = url.pathname.replace(/\/+$/, '') || '/';
  const ip = ipOf(req);

  // страница-обёртка для плеера VK (отдельный адрес, чтобы чужой код не видел данных приложения)
  if (p === '/watch.html' && req.method === 'GET') {
    fs.readFile(path.join(__dirname, 'watch.html'), (err, buf) => {
      if (err) return send(res, 404, { error: 'not found' });
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', 'Referrer-Policy': 'origin' });
      res.end(buf);
    });
    return;
  }
  if (p === '/' || p === '/api/ping') return send(res, 200, { ok: true, app: 'nash-chat', claimed: !!config.tokenHash });

  // Первое подключение: телефон, создавший чат, «занимает» сервер своим токеном.
  if (p === '/api/claim' && req.method === 'POST') {
    const b = await readJson(req, 4096);
    if (!/^[0-9a-f]{64}$/.test(b.token || '')) return send(res, 400, { error: 'bad token' });
    if (config.tokenHash) {
      return sha(b.token) === config.tokenHash ? send(res, 200, { ok: true, already: true }) : send(res, 409, { error: 'already claimed' });
    }
    config.tokenHash = sha(b.token); config.created = Date.now(); saveConfig();
    return send(res, 200, { ok: true });
  }

  if (blocked(ip)) return send(res, 429, { error: 'too many attempts' });
  if (!p.startsWith('/api/')) return send(res, 404, { error: 'not found' });
  if (!authed(req)) { failed(ip); return send(res, 401, { error: 'unauthorized' }); }
  fails.delete(ip);

  // Отправить сообщение
  if (p === '/api/messages' && req.method === 'POST') {
    const b = await readJson(req, MAX_MSG);
    if (typeof b.ct !== 'string' || !b.ct || typeof b.dev !== 'string' || b.dev.length > 64) return send(res, 400, { error: 'bad message' });
    const m = { id: ++lastId, ts: Date.now(), dev: b.dev, ct: b.ct };
    fs.appendFileSync(LOG_FILE, JSON.stringify(m) + '\n');
    messages.push(m); version++;
    wake();
    return send(res, 200, { id: m.id, ts: m.ts });
  }

  // Получить сообщения: ?after=ID&wait=25 (долгое ожидание) или ?before=ID
  if (p === '/api/messages' && req.method === 'GET') {
    const limit = Math.min(MAX_PAGE, Math.max(1, parseInt(url.searchParams.get('limit') || '100', 10)));
    if (url.searchParams.has('before')) {
      return send(res, 200, { messages: before(parseInt(url.searchParams.get('before'), 10) || 0, limit), last: lastId, v: version, reads, presence: presView() });
    }
    if (url.searchParams.has('last')) {
      return send(res, 200, { messages: before(lastId + 1, limit), last: lastId, v: version, reads, presence: presView(), sig: sigId, dv: docsV });
    }
    const a = parseInt(url.searchParams.get('after') || '0', 10) || 0;
    const v = parseInt(url.searchParams.get('v') || '0', 10) || 0;
    const wait = Math.min(50, Math.max(0, parseInt(url.searchParams.get('wait') || '0', 10)));
    const pdev = url.searchParams.get('dev');
    let px = null;
    if (okDev(pdev)) { px = presOf(pdev); px.at = Date.now(); px.polls++; presChanged(); }
    let polled = !!px;
    const unpoll = () => { if (polled) { polled = false; px.polls--; px.at = Date.now(); setTimeout(presChanged, 50); } };
    const sg = parseInt(url.searchParams.get('sig') || '-1', 10);
    const reply = () => send(res, 200, { messages: after(a, limit), deleted: v ? changesSince(v) : [], last: lastId, v: version, reads, presence: presView(), dv: docsV, sig: sigId, signals: sg >= 0 ? sigAfter(sg, pdev) : [] });
    if (lastId > a || (v && version > v) || !wait || (sg >= 0 && sigAfter(sg, pdev).length)) { unpoll(); return reply(); }
    let done = false;
    const fin = () => { if (done) return; done = true; clearTimeout(t); waiters.delete(fin); unpoll(); reply(); };
    const t = setTimeout(fin, wait * 1000);
    waiters.add(fin);
    req.on('close', () => { if (!done) { done = true; clearTimeout(t); waiters.delete(fin); unpoll(); } });
    return;
  }

  // Общие записи: получить изменения
  if (p === '/api/docs' && req.method === 'GET') {
    const since = parseInt(url.searchParams.get('since') || '0', 10) || 0;
    const list = [];
    for (const [id, d] of Object.entries(docs)) if (d.v > since) list.push({ id, v: d.v, ct: d.ct, del: !!d.del });
    list.sort((a, b) => a.v - b.v);
    return send(res, 200, { dv: docsV, docs: list });
  }
  // Общие записи: сохранить или удалить
  if (p === '/api/doc' && req.method === 'POST') {
    const b = await readJson(req, 300 * 1024);
    if (!docIdOk(b.id) || !okDev(b.dev)) return send(res, 400, { error: 'bad doc' });
    const del = b.ct == null;
    if (!del && (typeof b.ct !== 'string' || !b.ct)) return send(res, 400, { error: 'bad doc' });
    if (!docs[b.id] && Object.keys(docs).length >= 20000) return send(res, 400, { error: 'too many docs' });
    docs[b.id] = del ? { v: ++docsV, del: true } : { v: ++docsV, ct: b.ct };
    saveDocs(); version++; wake();
    return send(res, 200, { ok: true, v: docs[b.id].v, dv: docsV });
  }

  // Быстрый сигнал второму телефону
  if (p === '/api/signal' && req.method === 'POST') {
    const b = await readJson(req, 16384);
    if (!okDev(b.dev) || typeof b.ct !== 'string' || !b.ct) return send(res, 400, { error: 'bad signal' });
    signals.push({ sid: ++sigId, dev: b.dev, ct: b.ct, ts: Date.now() });
    version++; wake();
    return send(res, 200, { ok: true, sid: sigId });
  }

  // Статус: в сети / свернул приложение / печатает / записывает
  if (p === '/api/presence' && req.method === 'POST') {
    const b = await readJson(req, 1024);
    if (!okDev(b.dev) || !PRES_STATES.has(b.s)) return send(res, 400, { error: 'bad presence' });
    if (!pres[b.dev] && Object.keys(pres).length >= 8) return send(res, 400, { error: 'too many devices' });
    const x = presOf(b.dev); x.state = b.s; x.stAt = x.at = Date.now();
    presChanged();
    return send(res, 200, { ok: true, presence: presView() });
  }

  // Отметка «прочитано»
  if (p === '/api/read' && req.method === 'POST') {
    const b = await readJson(req, 4096);
    const id = Math.min(parseInt(b.id, 10) || 0, lastId);
    if (typeof b.dev !== 'string' || !b.dev || b.dev.length > 64) return send(res, 400, { error: 'bad dev' });
    if (id > (reads[b.dev] || 0)) {
      if (!reads[b.dev] && Object.keys(reads).length >= 8) return send(res, 400, { error: 'too many devices' });
      reads[b.dev] = id; saveReads();
      version++; wake();
    }
    return send(res, 200, { ok: true, reads });
  }

  // Удалить сообщение у обоих
  let mm = p.match(/^\/api\/messages\/(\d+)$/);
  if (mm && req.method === 'DELETE') {
    const id = parseInt(mm[1], 10);
    const m = messages.find(x => x.id === id);
    if (!m) return send(res, 404, { error: 'not found' });
    if (!m.del) {
      m.del = true; m.ct = null;
      fs.appendFileSync(LOG_FILE, JSON.stringify({ delOf: id, ts: Date.now() }) + '\n');
      version++; deletedSince.push({ v: version, id });
      if (deletedSince.length > 1000) deletedSince.shift();
      wake();
    }
    return send(res, 200, { ok: true });
  }

  // Новый файл
  if (p === '/api/files' && req.method === 'POST') {
    const id = crypto.randomBytes(16).toString('hex');
    fs.mkdirSync(path.dirname(filePath(id, 0)), { recursive: true });
    return send(res, 200, { id });
  }

  // Части файла: PUT загрузить / GET скачать
  mm = p.match(/^\/api\/files\/([0-9a-f]{32})\/(\d{1,6})$/);
  if (mm && idOk(mm[1])) {
    const fp = filePath(mm[1], parseInt(mm[2], 10));
    if (req.method === 'PUT') {
      if (!fs.existsSync(path.dirname(fp))) return send(res, 404, { error: 'no such file' });
      const body = await readBody(req, MAX_CHUNK);
      fs.writeFileSync(fp + '.tmp', body); fs.renameSync(fp + '.tmp', fp);
      return send(res, 200, { ok: true, size: body.length });
    }
    if (req.method === 'GET') {
      fs.stat(fp, (err, st) => {
        if (err) return send(res, 404, { error: 'not found' });
        res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'private, max-age=31536000, immutable' });
        fs.createReadStream(fp).pipe(res);
      });
      return;
    }
  }

  // Удалить файл (вместе с сообщением)
  mm = p.match(/^\/api\/files\/([0-9a-f]{32})$/);
  if (mm && req.method === 'DELETE') {
    fs.rmSync(path.dirname(filePath(mm[1], 0)), { recursive: true, force: true });
    return send(res, 200, { ok: true });
  }

  return send(res, 404, { error: 'not found' });
}

const server = http.createServer((req, res) => {
  handle(req, res).catch(e => {
    if (!res.headersSent) send(res, e.code && e.code >= 400 && e.code < 600 ? e.code : 500, { error: e.message });
  });
});
server.requestTimeout = 0;          // долгие загрузки больших файлов
server.headersTimeout = 60000;
server.keepAliveTimeout = 65000;
server.listen(PORT, HOST, () => console.log(`Наш чат: сервер слушает ${HOST}:${PORT}, данные в ${DATA}`));
