// Наш чат — сервер. Никаких внешних зависимостей, нужен только Node.js 18+.
// Сервер хранит ТОЛЬКО зашифрованные данные: ключ шифрования есть лишь на телефонах.
// Чатов может быть много: «главный» (самый первый, лежит прямо в папке данных) и дополнительные
// личные чаты и группы (папка rooms/). У каждого свой пропуск и свой ключ — чужой чат не прочитать.
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '8080', 10);
// посредник для звонков (TURN): секрет хранится в файле, пароли выдаются на 12 часов
const TURN_HOST = process.env.TURN_HOST || '';
let TURN_SECRET = '';
try { if (process.env.TURN_SECRET_FILE) TURN_SECRET = fs.readFileSync(process.env.TURN_SECRET_FILE, 'utf8').trim(); } catch (_) { }
const HOST = process.env.HOST || '127.0.0.1';
const DATA = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const MAX_CHUNK = 9 * 1024 * 1024;      // одна часть файла (8 МБ + шифрование)
const MAX_MSG = 256 * 1024;             // одно сообщение (с миниатюрой)
const MAX_PAGE = 200;
const MAX_ROOMS = 500;
const RING_MS = 45000;
const PRES_STATES = new Set(['online', 'away', 'typing', 'voice', 'circle']);
const okDev = d => typeof d === 'string' && /^[0-9a-f]{4,64}$/.test(d);
const docIdOk = s => typeof s === 'string' && /^[a-z]{2,8}_[0-9a-z]{4,40}$/.test(s);
const idOk = s => /^[0-9a-f]{32}$/.test(s);
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
function writeJson(file, obj) { fs.writeFileSync(file + '.tmp', JSON.stringify(obj)); fs.renameSync(file + '.tmp', file); }

// ожидающие сразу нескольких чатов (список чатов и фоновая служба телефона)
const multiWaiters = new Set();
function wakeMulti() { for (const w of multiWaiters) w(); multiWaiters.clear(); }

// ================= один чат =================
class Room {
  constructor(dir, id, maxDev) {
    this.dir = dir; this.id = id; this.maxDev = maxDev;
    fs.mkdirSync(path.join(dir, 'files'), { recursive: true });
    this.CONF = path.join(dir, 'config.json'); this.LOG = path.join(dir, 'messages.jsonl');
    this.READS = path.join(dir, 'reads.json'); this.DOCS = path.join(dir, 'docs.json');
    this.config = fs.existsSync(this.CONF) ? JSON.parse(fs.readFileSync(this.CONF, 'utf8')) : {};
    this.messages = []; let delCount = 0;
    if (fs.existsSync(this.LOG)) {
      const byId = new Map();
      for (const line of fs.readFileSync(this.LOG, 'utf8').split('\n')) {
        if (!line.trim()) continue;
        try {
          const m = JSON.parse(line);
          if (m.delOf) { delCount++; const t = byId.get(m.delOf); if (t) { t.ct = null; t.del = true; } }
          else { this.messages.push(m); byId.set(m.id, m); }
        } catch (_) { /* повреждённая строка — пропускаем */ }
      }
    }
    this.lastId = this.messages.length ? this.messages[this.messages.length - 1].id : 0;
    this.version = this.lastId + delCount;   // растёт и при удалении, чтобы ожидающие узнали об изменениях
    this.waiters = new Set();
    try { this.reads = JSON.parse(fs.readFileSync(this.READS, 'utf8')) || {}; } catch (_) { this.reads = {}; }
    this.pres = {}; this.presSig = '';
    this.signals = []; this.sigId = 0;
    this.docs = {}; this.docsV = 0;
    try { const j = JSON.parse(fs.readFileSync(this.DOCS, 'utf8')); this.docs = j.docs || {}; this.docsV = j.v || 0; } catch (_) { }
    this.ring = null; this.ringEnd = null;
    this.deletedSince = [];
  }
  saveConfig() { writeJson(this.CONF, this.config); }
  saveReads() { clearTimeout(this.readsT); this.readsT = setTimeout(() => { try { writeJson(this.READS, this.reads); } catch (_) { } }, 1000); }
  saveDocs() { clearTimeout(this.docsT); this.docsT = setTimeout(() => { try { writeJson(this.DOCS, { v: this.docsV, docs: this.docs }); } catch (_) { } }, 500); }
  wake() { for (const w of this.waiters) w(); this.waiters.clear(); wakeMulti(); }
  presOf(dev) { return this.pres[dev] || (this.pres[dev] = { state: 'away', stAt: 0, at: 0, polls: 0, seen: 0 }); }
  presView() {
    const now = Date.now(), out = {};
    for (const [dev, x] of Object.entries(this.pres)) {
      const alive = x.polls > 0 || now - x.at < 20000;
      let st = alive ? x.state : 'offline';
      if ((st === 'typing' || st === 'voice' || st === 'circle') && now - x.stAt > (st === 'typing' ? 7000 : 70000)) st = 'online';
      if (st === 'online' || st === 'typing' || st === 'voice' || st === 'circle') x.seen = now;
      out[dev] = { s: st, seen: x.seen };
    }
    return out;
  }
  presChanged() {
    const v = this.presView(), sig = Object.keys(v).sort().map(k => k + ':' + v[k].s).join(',');
    if (sig !== this.presSig) { this.presSig = sig; this.version++; for (const w of this.waiters) w(); this.waiters.clear(); }
  }
  sigAfter(after, dev) {
    const cut = Date.now() - 60000;
    while (this.signals.length && (this.signals[0].ts < cut || this.signals.length > 300)) this.signals.shift();
    return this.signals.filter(x => x.sid > after && x.dev !== dev).map(x => ({ sid: x.sid, ct: x.ct, ts: x.ts }));
  }
  ringView(dev) {
    const now = Date.now();
    if (this.ring && now - this.ring.ts > RING_MS) { this.ringEnd = { id: this.ring.id, why: 'timeout', ts: now }; this.ring = null; }
    return {
      ring: this.ring && this.ring.dev !== dev ? { id: this.ring.id, video: this.ring.video, ts: this.ring.ts } : null,
      ringEnd: this.ringEnd && now - this.ringEnd.ts < 60000 ? this.ringEnd : null,
    };
  }
  view(m) { return m.del ? { id: m.id, ts: m.ts, dev: m.dev, del: true } : { id: m.id, ts: m.ts, dev: m.dev, ct: m.ct }; }
  after(id, limit) {
    const a = this.messages; let lo = 0, hi = a.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (a[mid].id <= id) lo = mid + 1; else hi = mid; }
    return a.slice(lo, lo + limit).map(m => this.view(m));
  }
  before(id, limit) {
    const a = this.messages; let lo = 0, hi = a.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (a[mid].id < id) lo = mid + 1; else hi = mid; }
    return a.slice(Math.max(0, lo - limit), lo).map(m => this.view(m));
  }
  changesSince(v) { return this.deletedSince.filter(d => d.v > v).map(d => d.id); }
  filePath(id, idx) { return path.join(this.dir, 'files', id.slice(0, 2), id, String(idx)); }
  devCount(map) { return Object.keys(map).length; }
}

// ================= все чаты =================
fs.mkdirSync(path.join(DATA, 'rooms'), { recursive: true });
const main = new Room(DATA, 'main', 8);
const rooms = new Map();       // id -> Room (кроме главного)
const byToken = new Map();     // sha(token) -> Room
if (main.config.tokenHash) byToken.set(main.config.tokenHash, main);
for (const name of fs.readdirSync(path.join(DATA, 'rooms'))) {
  if (!/^[0-9a-f]{24}$/.test(name)) continue;
  try {
    const r = new Room(path.join(DATA, 'rooms', name), name, 64);
    if (!r.config.tokenHash) continue;
    rooms.set(name, r); byToken.set(r.config.tokenHash, r);
  } catch (e) { console.error('Не удалось открыть чат', name, e.message); }
}
setInterval(() => { main.presChanged(); for (const r of rooms.values()) r.presChanged(); }, 2000).unref();

// ---------- ответы ----------
function send(res, code, obj) {
  const body = obj === undefined ? '' : JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.setHeader('Access-Control-Max-Age', '86400');
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const parts = []; let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too big'), { code: 413 })); req.destroy(); return; }
      parts.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}
async function readJson(req, limit) {
  const b = await readBody(req, limit);
  try { return JSON.parse(b.toString('utf8') || '{}'); }
  catch (_) { throw Object.assign(new Error('bad json'), { code: 400 }); }
}

// ---------- защита от перебора ----------
const fails = new Map(); // ip -> {n, until}
function ipOf(req) { return (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }
function blocked(ip) { const f = fails.get(ip); return f && f.until > Date.now(); }
function failed(ip) {
  const f = fails.get(ip) || { n: 0, until: 0 };
  f.n++; if (f.n >= 10) { f.until = Date.now() + 15 * 60 * 1000; f.n = 0; }
  fails.set(ip, f);
}
function roomByToken(tok) {
  if (typeof tok !== 'string' || !/^[0-9a-f]{64}$/.test(tok)) return null;
  const h = sha(tok), r = byToken.get(h);
  if (!r) return null;
  const a = Buffer.from(h), b = Buffer.from(r.config.tokenHash);
  return a.length === b.length && crypto.timingSafeEqual(a, b) ? r : null;
}
function authRoom(req) {
  const h = req.headers.authorization || '';
  return roomByToken(h.startsWith('Bearer ') ? h.slice(7).trim() : '');
}

// ---------- маршруты ----------
async function handle(req, res) {
  cors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, 'http://x');
  const p = url.pathname.replace(/\/+$/, '') || '/';
  const ip = ipOf(req);

  // страница-обёртка для плеера VK (отдельный адрес, чтобы чужой код не видел данных приложения)
  if (p === '/watch.html' && req.method === 'GET') {
    fs.readFile(path.join(__dirname, 'watch.html'), (err, buf) => {
      if (err) return send(res, 404, { error: 'not found' });
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', 'Referrer-Policy': 'origin' });
      res.end(buf);
    });
    return;
  }
  if (p === '/' || p === '/api/ping') return send(res, 200, { ok: true, app: 'nash-chat', ver: 16, rooms: true, turn: !!(TURN_HOST && TURN_SECRET), claimed: !!main.config.tokenHash });

  // Первое подключение: телефон, создавший чат, «занимает» сервер своим токеном.
  if (p === '/api/claim' && req.method === 'POST') {
    const b = await readJson(req, 4096);
    if (!/^[0-9a-f]{64}$/.test(b.token || '')) return send(res, 400, { error: 'bad token' });
    if (main.config.tokenHash) {
      return sha(b.token) === main.config.tokenHash ? send(res, 200, { ok: true, already: true }) : send(res, 409, { error: 'already claimed' });
    }
    main.config.tokenHash = sha(b.token); main.config.created = Date.now(); main.saveConfig();
    byToken.set(main.config.tokenHash, main);
    return send(res, 200, { ok: true });
  }

  if (blocked(ip)) return send(res, 429, { error: 'too many attempts' });
  if (!p.startsWith('/api/')) return send(res, 404, { error: 'not found' });

  // Несколько чатов сразу: что нового и кто звонит (для списка чатов и уведомлений).
  // Пропуска передаются в теле запроса; ответ — когда в любом из чатов что-то появится.
  if (p === '/api/multi' && req.method === 'POST') {
    const b = await readJson(req, 64 * 1024);
    if (!Array.isArray(b.rooms) || !b.rooms.length || b.rooms.length > 100) return send(res, 400, { error: 'bad rooms' });
    const dev = okDev(b.dev) ? b.dev : '';
    const list = b.rooms.map(x => ({ r: roomByToken(x && x.t), a: Math.max(0, parseInt(x && x.a, 10) || 0), rs: x && typeof x.rs === 'string' ? x.rs : null }));
    if (list.every(x => !x.r)) { failed(ip); return send(res, 401, { error: 'unauthorized' }); }
    const lim = Math.min(50, Math.max(1, parseInt(b.limit, 10) || 30));
    const reply = () => send(res, 200, {
      rooms: list.map(x => {
        if (!x.r) return { err: 401 };
        const rv = x.r.ringView(dev);
        const ms = x.r.messages, top = ms.length ? x.r.view(ms[ms.length - 1]) : null;
        return { last: x.r.lastId, msgs: x.a ? x.r.after(x.a, lim) : [], top, reads: x.r.reads, ring: rv.ring, ringEnd: rv.ringEnd };
      }),
    });
    const ready = () => list.some(x => {
      if (!x.r) return false;
      if (x.r.lastId > x.a) return true;
      if (x.rs == null) return false;
      const rv = x.r.ringView(dev);
      return (rv.ring && rv.ring.id !== x.rs) || (!rv.ring && x.rs !== '');
    });
    const wait = Math.min(50, Math.max(0, parseInt(b.wait, 10) || 0));
    if (!wait || ready()) return reply();
    let done = false;
    const check = () => { if (done) return; if (ready()) fin(); else multiWaiters.add(check); };
    const fin = () => { if (done) return; done = true; clearTimeout(t); multiWaiters.delete(check); reply(); };
    const t = setTimeout(fin, wait * 1000);
    multiWaiters.add(check);
    req.on('close', () => { if (!done) { done = true; clearTimeout(t); multiWaiters.delete(check); } });
    return;
  }

  const room = authRoom(req);
  if (!room) { failed(ip); return send(res, 401, { error: 'unauthorized' }); }
  fails.delete(ip);
  const R = room;

  // Новый чат (личный или группа). Создать может любой, у кого уже есть доступ к серверу.
  if (p === '/api/rooms' && req.method === 'POST') {
    const b = await readJson(req, 4096);
    if (!/^[0-9a-f]{64}$/.test(b.token || '')) return send(res, 400, { error: 'bad token' });
    const h = sha(b.token);
    if (byToken.has(h)) return send(res, 200, { ok: true, already: true });
    if (rooms.size >= MAX_ROOMS) return send(res, 400, { error: 'too many rooms' });
    const id = h.slice(0, 24);
    const r = new Room(path.join(DATA, 'rooms', id), id, 64);
    r.config = { tokenHash: h, created: Date.now(), kind: b.kind === 'group' ? 'group' : 'dm' }; r.saveConfig();
    rooms.set(id, r); byToken.set(h, r);
    return send(res, 200, { ok: true });
  }

  // Отправить сообщение
  if (p === '/api/messages' && req.method === 'POST') {
    const b = await readJson(req, MAX_MSG);
    if (typeof b.ct !== 'string' || !b.ct || typeof b.dev !== 'string' || b.dev.length > 64) return send(res, 400, { error: 'bad message' });
    const m = { id: ++R.lastId, ts: Date.now(), dev: b.dev, ct: b.ct };
    fs.appendFileSync(R.LOG, JSON.stringify(m) + '\n');
    R.messages.push(m); R.version++;
    R.wake();
    return send(res, 200, { id: m.id, ts: m.ts });
  }

  // Получить сообщения: ?after=ID&wait=25 (долгое ожидание) или ?before=ID
  if (p === '/api/messages' && req.method === 'GET') {
    const limit = Math.min(MAX_PAGE, Math.max(1, parseInt(url.searchParams.get('limit') || '100', 10)));
    if (url.searchParams.has('before')) {
      return send(res, 200, { messages: R.before(parseInt(url.searchParams.get('before'), 10) || 0, limit), last: R.lastId, v: R.version, reads: R.reads, presence: R.presView() });
    }
    if (url.searchParams.has('last')) {
      const pdev = url.searchParams.get('dev'), sdev = url.searchParams.get('sdev') || pdev;
      return send(res, 200, Object.assign({ messages: R.before(R.lastId + 1, limit), last: R.lastId, v: R.version, reads: R.reads, presence: R.presView(), sig: R.sigId, dv: R.docsV }, R.ringView(sdev)));
    }
    const a = parseInt(url.searchParams.get('after') || '0', 10) || 0;
    const v = parseInt(url.searchParams.get('v') || '0', 10) || 0;
    const wait = Math.min(50, Math.max(0, parseInt(url.searchParams.get('wait') || '0', 10)));
    const pdev = url.searchParams.get('dev');
    let px = null;
    if (okDev(pdev) && (R.pres[pdev] || R.devCount(R.pres) < R.maxDev)) { px = R.presOf(pdev); px.at = Date.now(); px.polls++; R.presChanged(); }
    let polled = !!px;
    const unpoll = () => { if (polled) { polled = false; px.polls--; px.at = Date.now(); setTimeout(() => R.presChanged(), 50); } };
    const sg = parseInt(url.searchParams.get('sig') || '-1', 10);
    const sdev = url.searchParams.get('sdev') || pdev;
    const reply = () => send(res, 200, Object.assign({ messages: R.after(a, limit), deleted: v ? R.changesSince(v) : [], last: R.lastId, v: R.version, reads: R.reads, presence: R.presView(), dv: R.docsV, sig: R.sigId, signals: sg >= 0 ? R.sigAfter(sg, pdev) : [] }, R.ringView(sdev)));
    const rseen = url.searchParams.get('rs');
    const rv = R.ringView(sdev), ringNew = rseen != null && ((rv.ring && rv.ring.id !== rseen) || (!rv.ring && rseen !== ''));
    if (R.lastId > a || (v && R.version > v) || !wait || ringNew || (sg >= 0 && R.sigAfter(sg, pdev).length)) { unpoll(); return reply(); }
    let done = false;
    const fin = () => { if (done) return; done = true; clearTimeout(t); R.waiters.delete(fin); unpoll(); reply(); };
    const t = setTimeout(fin, wait * 1000);
    R.waiters.add(fin);
    req.on('close', () => { if (!done) { done = true; clearTimeout(t); R.waiters.delete(fin); unpoll(); } });
    return;
  }

  // Общие записи: получить изменения
  if (p === '/api/docs' && req.method === 'GET') {
    const since = parseInt(url.searchParams.get('since') || '0', 10) || 0;
    const list = [];
    for (const [id, d] of Object.entries(R.docs)) if (d.v > since) list.push({ id, v: d.v, ct: d.ct, del: !!d.del });
    list.sort((a, b) => a.v - b.v);
    return send(res, 200, { dv: R.docsV, docs: list });
  }
  // Общие записи: сохранить или удалить
  if (p === '/api/doc' && req.method === 'POST') {
    const b = await readJson(req, 300 * 1024);
    if (!docIdOk(b.id) || !okDev(b.dev)) return send(res, 400, { error: 'bad doc' });
    const del = b.ct == null;
    if (!del && (typeof b.ct !== 'string' || !b.ct)) return send(res, 400, { error: 'bad doc' });
    if (!R.docs[b.id] && Object.keys(R.docs).length >= 20000) return send(res, 400, { error: 'too many docs' });
    R.docs[b.id] = del ? { v: ++R.docsV, del: true } : { v: ++R.docsV, ct: b.ct };
    R.saveDocs(); R.version++; for (const w of R.waiters) w(); R.waiters.clear();
    return send(res, 200, { ok: true, v: R.docs[b.id].v, dv: R.docsV });
  }

  // Пароль для посредника звонков
  if (p === '/api/turn' && req.method === 'GET') {
    const ice = [];
    if (TURN_HOST && TURN_SECRET) {
      const username = Math.floor(Date.now() / 1000 + 12 * 3600) + ':nc';
      const credential = crypto.createHmac('sha1', TURN_SECRET).update(username).digest('base64');
      ice.push({ urls: ['stun:' + TURN_HOST + ':3478'] });
      ice.push({ urls: ['turn:' + TURN_HOST + ':3478?transport=udp', 'turn:' + TURN_HOST + ':3478?transport=tcp'], username, credential });
    } else {
      ice.push({ urls: ['stun:stun.l.google.com:19302'] });
    }
    return send(res, 200, { ice, turn: !!(TURN_HOST && TURN_SECRET) });
  }
  // «Звонит» / «перестал звонить» / «отклонено»
  if (p === '/api/ring' && req.method === 'POST') {
    const b = await readJson(req, 2048);
    if (!okDev(b.dev) || typeof b.id !== 'string' || !/^[0-9a-f]{6,32}$/.test(b.id)) return send(res, 400, { error: 'bad ring' });
    if (b.act === 'start') { R.ring = { id: b.id, dev: b.dev, ts: Date.now(), video: !!b.video }; R.ringEnd = null; }
    else if (R.ring && R.ring.id === b.id) { R.ringEnd = { id: b.id, why: b.act === 'decline' ? 'decline' : 'stop', ts: Date.now() }; R.ring = null; }
    else if (b.act === 'decline') R.ringEnd = { id: b.id, why: 'decline', ts: Date.now() };
    R.version++; R.wake();
    return send(res, 200, { ok: true });
  }

  // Быстрый сигнал второму телефону
  if (p === '/api/signal' && req.method === 'POST') {
    const b = await readJson(req, 16384);
    if (!okDev(b.dev) || typeof b.ct !== 'string' || !b.ct) return send(res, 400, { error: 'bad signal' });
    R.signals.push({ sid: ++R.sigId, dev: b.dev, ct: b.ct, ts: Date.now() });
    R.version++; for (const w of R.waiters) w(); R.waiters.clear();
    return send(res, 200, { ok: true, sid: R.sigId });
  }

  // Статус: в сети / свернул приложение / печатает / записывает
  if (p === '/api/presence' && req.method === 'POST') {
    const b = await readJson(req, 1024);
    if (!okDev(b.dev) || !PRES_STATES.has(b.s)) return send(res, 400, { error: 'bad presence' });
    if (!R.pres[b.dev] && R.devCount(R.pres) >= R.maxDev) return send(res, 400, { error: 'too many devices' });
    const x = R.presOf(b.dev); x.state = b.s; x.stAt = x.at = Date.now();
    R.presChanged();
    return send(res, 200, { ok: true, presence: R.presView() });
  }

  // Отметка «прочитано»
  if (p === '/api/read' && req.method === 'POST') {
    const b = await readJson(req, 4096);
    const id = Math.min(parseInt(b.id, 10) || 0, R.lastId);
    if (typeof b.dev !== 'string' || !b.dev || b.dev.length > 64) return send(res, 400, { error: 'bad dev' });
    if (id > (R.reads[b.dev] || 0)) {
      if (!R.reads[b.dev] && R.devCount(R.reads) >= R.maxDev) return send(res, 400, { error: 'too many devices' });
      R.reads[b.dev] = id; R.saveReads();
      R.version++; for (const w of R.waiters) w(); R.waiters.clear();
    }
    return send(res, 200, { ok: true, reads: R.reads });
  }

  // Удалить сообщение у всех
  let mm = p.match(/^\/api\/messages\/(\d+)$/);
  if (mm && req.method === 'DELETE') {
    const id = parseInt(mm[1], 10);
    const m = R.messages.find(x => x.id === id);
    if (!m) return send(res, 404, { error: 'not found' });
    if (!m.del) {
      m.del = true; m.ct = null;
      fs.appendFileSync(R.LOG, JSON.stringify({ delOf: id, ts: Date.now() }) + '\n');
      R.version++; R.deletedSince.push({ v: R.version, id });
      if (R.deletedSince.length > 1000) R.deletedSince.shift();
      for (const w of R.waiters) w(); R.waiters.clear();
    }
    return send(res, 200, { ok: true });
  }

  // Новый файл
  if (p === '/api/files' && req.method === 'POST') {
    const id = crypto.randomBytes(16).toString('hex');
    fs.mkdirSync(path.dirname(R.filePath(id, 0)), { recursive: true });
    return send(res, 200, { id });
  }

  // Части файла: PUT загрузить / GET скачать
  mm = p.match(/^\/api\/files\/([0-9a-f]{32})\/(\d{1,6})$/);
  if (mm && idOk(mm[1])) {
    const fp = R.filePath(mm[1], parseInt(mm[2], 10));
    if (req.method === 'PUT') {
      if (!fs.existsSync(path.dirname(fp))) return send(res, 404, { error: 'no such file' });
      const body = await readBody(req, MAX_CHUNK);
      fs.writeFileSync(fp + '.tmp', body); fs.renameSync(fp + '.tmp', fp);
      return send(res, 200, { ok: true, size: body.length });
    }
    if (req.method === 'GET') {
      fs.stat(fp, (err, st) => {
        if (err) return send(res, 404, { error: 'not found' });
        res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'private, max-age=31536000, immutable' });
        fs.createReadStream(fp).pipe(res);
      });
      return;
    }
  }

  // Удалить файл (вместе с сообщением)
  mm = p.match(/^\/api\/files\/([0-9a-f]{32})$/);
  if (mm && req.method === 'DELETE') {
    fs.rmSync(path.dirname(R.filePath(mm[1], 0)), { recursive: true, force: true });
    return send(res, 200, { ok: true });
  }

  return send(res, 404, { error: 'not found' });
}

const server = http.createServer((req, res) => {
  handle(req, res).catch(e => {
    if (!res.headersSent) send(res, e.code && e.code >= 400 && e.code < 600 ? e.code : 500, { error: e.message });
  });
});
server.requestTimeout = 0;          // долгие загрузки больших файлов
server.headersTimeout = 60000;
server.keepAliveTimeout = 65000;
server.listen(PORT, HOST, () => console.log(`Наш чат: сервер слушает ${HOST}:${PORT}, данные в ${DATA}, чатов: ${1 + rooms.size}`));
